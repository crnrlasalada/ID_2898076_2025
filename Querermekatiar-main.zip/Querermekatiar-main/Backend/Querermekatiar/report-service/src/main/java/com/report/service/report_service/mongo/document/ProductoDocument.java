package com.report.service.report_service.mongo.document;

import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductoDocument {
    private Integer id;
    private String nombre;
    private String urlImagen;
    private Integer cantidad;
    private String descripcion;
    private Long precio;
    private List<AdicionDocument> adiciones;
}
