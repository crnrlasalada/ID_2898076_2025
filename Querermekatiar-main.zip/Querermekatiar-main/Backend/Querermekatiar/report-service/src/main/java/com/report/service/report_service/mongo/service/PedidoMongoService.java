package com.report.service.report_service.mongo.service;

import com.report.service.report_service.mongo.document.PedidoDocument;
import org.springframework.data.domain.Page;


import java.time.LocalDateTime;
import java.util.List;

public interface PedidoMongoService {

    // Obtener los 10 pedidos más recientes
    List<PedidoDocument> obtenerPrimeros10();

    // Buscar por rango de fechas (día, semana, mes, año)
    List<PedidoDocument> buscarPorRango(LocalDateTime desde, LocalDateTime hasta);

    // Buscar solo por año
    List<PedidoDocument> buscarPorAnio(int anio);

    // Buscar por año y mes
    List<PedidoDocument> buscarPorMesYAnio(int anio, int mes);

    // Guardar un pedido recibido por RabbitMQ
    boolean guardarPedido(PedidoDocument pedido);

    Page<PedidoDocument> buscarPorRangoPaginado(LocalDateTime desde, LocalDateTime hasta, int page, int size);

}
