package com.report.service.report_service.service;

import com.report.service.report_service.dto.AddOnDTO;
import com.report.service.report_service.dto.OrderDTO;
import com.report.service.report_service.dto.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@ConditionalOnProperty(name = "invoice.test", havingValue = "true")
public class InvoiceTestRunner implements CommandLineRunner {

    private final HtmlInvoiceService htmlInvoiceService;

    @Autowired
    public InvoiceTestRunner(HtmlInvoiceService htmlInvoiceService) {
        this.htmlInvoiceService = htmlInvoiceService;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("[InvoiceTestRunner] Generating test invoice PDF...");

        // Crear datos de prueba
        OrderDTO order = new OrderDTO();
        order.setOrderId("TEST-001");
        order.setCustomerName("Juan");
        order.setCustomerLastName("Pérez");
        order.setFechaHora(new Date());

        List<ProductDTO> products = new ArrayList<>();

        ProductDTO p1 = new ProductDTO();
        p1.setProductName("Hamburguesa clásica");
        p1.setCant(2);
        p1.setPrice(new BigDecimal("12.50"));
        List<AddOnDTO> p1adds = new ArrayList<>();
        AddOnDTO ao1 = new AddOnDTO(); ao1.setName("Queso"); ao1.setQuantity(1); ao1.setPrice(new BigDecimal("1.50"));
        p1adds.add(ao1);
        p1.setAddOns(p1adds);

        ProductDTO p2 = new ProductDTO();
        p2.setProductName("Papas medianas");
        p2.setCant(1);
        p2.setPrice(new BigDecimal("5.00"));
        p2.setAddOns(new ArrayList<>());

        products.add(p1);
        products.add(p2);

        order.setProducts(products);

        List<OrderDTO> orders = new ArrayList<>();
        orders.add(order);

        byte[] pdf = htmlInvoiceService.generateInvoicePdfFromOrders(orders);

        String out = "target/invoice_test.pdf";
        try (FileOutputStream fos = new FileOutputStream(out)) {
            fos.write(pdf);
        }

        System.out.println("[InvoiceTestRunner] PDF generado en: " + out + " (bytes=" + (pdf != null ? pdf.length : 0) + ")");
    }
}
