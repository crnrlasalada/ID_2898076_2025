package com.report.service.report_service.mongo.document;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Document(collection = "pedido")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PedidoDocument {

    @Id
    private String idMongo;  // ID interno de MongoDB

    private Integer id; // ID original del pedido (desde MySQL)
    private Integer idUsuario;
    private String nombres;
    private String apellidos;
    private String telefono;
    private String estadoPedido;
    private String direccion;
    private java.util.Date fechaHora;
    private String tipoEntrega;
    private String formaPago;
    private BigDecimal latitud;
    private BigDecimal longitud;
    private String mensajeCliente;
    private String motivoRechazo;
    private BigDecimal domicilio;
    private BigDecimal subtotal;
    private BigDecimal total;

    private List<ProductoDocument> productos;
}
