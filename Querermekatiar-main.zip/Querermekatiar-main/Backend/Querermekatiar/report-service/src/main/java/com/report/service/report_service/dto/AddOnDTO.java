package com.report.service.report_service.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class AddOnDTO {
    // Campos alineados con la plantilla JasperReports
    private String name;  // Cambiado de productName a name
    private int quantity;
    private BigDecimal price;
}