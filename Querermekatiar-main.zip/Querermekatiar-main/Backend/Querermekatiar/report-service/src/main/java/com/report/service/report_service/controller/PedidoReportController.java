package com.report.service.report_service.controller;

import com.report.service.report_service.dto.OrderDTO;
import com.report.service.report_service.service.HtmlInvoiceService;
import com.report.service.report_service.mongo.document.PedidoDocument;
import com.report.service.report_service.mongo.service.PedidoMongoService;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@CrossOrigin(origins = {"http://localhost:5174"})
@RestController
@RequestMapping("/api/report")

public class PedidoReportController {

    private final PedidoMongoService pedidoMongoService;
    private final HtmlInvoiceService htmlInvoiceService;

    @Autowired
    public PedidoReportController(PedidoMongoService pedidoMongoService, HtmlInvoiceService htmlInvoiceService) {
        this.pedidoMongoService = pedidoMongoService;
        this.htmlInvoiceService = htmlInvoiceService;
    }

    // 🟢 primeros 10 pedidos
    @GetMapping("/primeros")
    public List<PedidoDocument> ObtenerPrimeros10() {
        return pedidoMongoService.obtenerPrimeros10();
    }

    // 🔵 Buscar por rango de fechas (día, semana, mes)
    @GetMapping("/rango")
    public List<PedidoDocument> buscarPorRango(
            @RequestParam("desde") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam("hasta") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {

        // Desde las 00:00:00 hasta las 23:59:59.999999999
        LocalDateTime inicio = desde.atStartOfDay();
        LocalDateTime fin = hasta.atTime(LocalTime.MAX);

        return pedidoMongoService.buscarPorRango(inicio, fin);
    }


    // 🟣 Buscar por año
    @GetMapping("/anio/{anio}")
    public List<PedidoDocument> buscarPorAnio(@PathVariable int anio) {
        return pedidoMongoService.buscarPorAnio(anio);
    }

    // 🟡 Buscar por mes y año
    @GetMapping("/mes")
    public List<PedidoDocument> buscarPorMesYAnio(
            @RequestParam("anio") int anio,
            @RequestParam("mes") int mes) {
        return pedidoMongoService.buscarPorMesYAnio(anio, mes);
    }


    @GetMapping("/rango/paginado")
    public Page<PedidoDocument> buscarPorRangoPaginado(
            @RequestParam("desde") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam("hasta") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "10") int size
    ) {
        LocalDateTime inicio = desde.atStartOfDay();
        LocalDateTime fin = hasta.atTime(LocalTime.MAX);
        return pedidoMongoService.buscarPorRangoPaginado(inicio, fin, page, size);
    }

    // Endpoint para recibir una lista de pedidos (dto) y generar PDF usando la plantilla invoice.html
    @PostMapping(value = "/generate-html-pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generarPdfDesdePedidos(@RequestBody List<OrderDTO> pedidos) {
        byte[] pdf = htmlInvoiceService.generateInvoicePdfFromOrders(pedidos);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("filename", "reporte_ventas.pdf");

        return ResponseEntity.ok().headers(headers).body(pdf);
    }

}
