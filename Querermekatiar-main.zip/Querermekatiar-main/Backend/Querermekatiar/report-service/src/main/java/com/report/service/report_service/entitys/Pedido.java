package com.report.service.report_service.entitys;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    @Column(name = "id_usuario")
    private Integer idUsuario;
    private String nombres;
    private String apellidos;
    @Column(name = "estado_pedido")
    private String estadoPedido;
    private String telefono;
    private Integer documento;
    @Column(name = "tipo_entrega")
    private String tipoEntrega;
    private String direccion;
    @Column(name = "fecha_hora")
    private LocalDateTime fechaHora;
    @Column(name = "forma_pago")
    private String formaPago;
    private BigDecimal latitud;
    private BigDecimal longitud;
    @Column(name = "mensaje_cliente")
    private String mensajeCliente;
    @Column(name = "motivo_rechazo")
    private String motivoRechazo;
    private BigDecimal domicilio;
    private BigDecimal subtotal;
    private BigDecimal total;
}
