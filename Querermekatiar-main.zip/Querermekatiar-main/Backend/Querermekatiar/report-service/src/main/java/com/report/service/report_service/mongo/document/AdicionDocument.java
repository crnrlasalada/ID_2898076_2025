package com.report.service.report_service.mongo.document;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdicionDocument {
    private Integer id;
    private String nombre;
    private Integer cantidad;
    private Long precio;
}
