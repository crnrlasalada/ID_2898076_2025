package com.report.service.report_service.mongo.repository;

import com.report.service.report_service.mongo.document.PedidoDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PedidoMongoRepository extends MongoRepository<PedidoDocument, String> {

    // primeros 10 pedidos
    List<PedidoDocument> findTop10ByOrderByFechaHoraAsc();

    // Por rango de fechas (día, semana, mes, año completo)
    List<PedidoDocument> findByFechaHoraBetween(LocalDateTime desde, LocalDateTime hasta);

    // Por año
    @Query("{ $expr: { $eq: [ { $year: '$fechaHora' }, ?0 ] } }")
    List<PedidoDocument> findByAnio(int anio);

    // Por año y mes
    @Query("{ $expr: { $and: [ { $eq: [ { $year: '$fechaHora' }, ?0 ] }, { $eq: [ { $month: '$fechaHora' }, ?1 ] } ] } }")
    List<PedidoDocument> findByAnioYMes(int anio, int mes);

    Page<PedidoDocument> findByFechaHoraBetween(LocalDateTime desde, LocalDateTime hasta, Pageable pageable);
}
