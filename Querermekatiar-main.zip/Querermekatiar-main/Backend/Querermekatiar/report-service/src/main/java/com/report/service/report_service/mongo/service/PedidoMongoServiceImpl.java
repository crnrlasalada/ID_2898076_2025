package com.report.service.report_service.mongo.service;

import com.report.service.report_service.mongo.document.PedidoDocument;
import com.report.service.report_service.mongo.repository.PedidoMongoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.List;

@Service
public class PedidoMongoServiceImpl implements PedidoMongoService {

    private final PedidoMongoRepository pedidoMongoRepository;

    public PedidoMongoServiceImpl(PedidoMongoRepository pedidoMongoRepository) {
        this.pedidoMongoRepository = pedidoMongoRepository;
    }

    @Override
    public List<PedidoDocument> obtenerPrimeros10() {
        return pedidoMongoRepository.findTop10ByOrderByFechaHoraAsc();
    }


    @Override
    public List<PedidoDocument> buscarPorRango(LocalDateTime desde, LocalDateTime hasta) {
        return pedidoMongoRepository.findByFechaHoraBetween(desde, hasta);
    }

    @Override
    public List<PedidoDocument> buscarPorAnio(int anio) {
        return pedidoMongoRepository.findByAnio(anio);
    }

    @Override
    public List<PedidoDocument> buscarPorMesYAnio(int anio, int mes) {
        return pedidoMongoRepository.findByAnioYMes(anio, mes);
    }

    @Override
    public boolean guardarPedido(PedidoDocument pedido) {
        try {
            pedidoMongoRepository.save(pedido);
            return true;
        } catch (Exception e) {
            System.err.println("❌ Error al guardar en MongoDB: " + e.getMessage());
            return false;
        }
    }

    // En la implementación
    @Override
    public Page<PedidoDocument> buscarPorRangoPaginado(LocalDateTime desde, LocalDateTime hasta, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "fechaHora"));
        return pedidoMongoRepository.findByFechaHoraBetween(desde, hasta, pageable);
    }
}
