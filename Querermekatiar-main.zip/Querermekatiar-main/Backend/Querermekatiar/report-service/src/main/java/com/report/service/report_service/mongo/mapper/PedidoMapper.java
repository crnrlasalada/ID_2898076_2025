package com.report.service.report_service.mongo.mapper;

import com.report.service.report_service.dto.AdicionDTO;
import com.report.service.report_service.dto.PedidoDetalleDTO;
import com.report.service.report_service.dto.ProductoDTO;
import com.report.service.report_service.mongo.document.AdicionDocument;
import com.report.service.report_service.mongo.document.PedidoDocument;
import com.report.service.report_service.mongo.document.ProductoDocument;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class PedidoMapper {

    public PedidoDocument toDocument(PedidoDetalleDTO dto) {
        return PedidoDocument.builder()
                .id(dto.getId())
                .idUsuario(dto.getIdUsuario())
                .nombres(dto.getNombres())
                .apellidos(dto.getApellidos())
                .telefono(dto.getTelefono())
                .estadoPedido(dto.getEstadoPedido())
                .direccion(dto.getDireccion())
                .fechaHora(dto.getFechaHora())
                .tipoEntrega(dto.getTipoEntrega())
                .formaPago(dto.getFormaPago())
                .latitud(dto.getLatitud())
                .longitud(dto.getLongitud())
                .mensajeCliente(dto.getMensajeCliente())
                .motivoRechazo(dto.getMotivoRechazo())
                .domicilio(dto.getDomicilio())
                .subtotal(dto.getSubtotal())
                .total(dto.getTotal())
                .productos(mapProductos(dto.getProductos()))
                .build();
    }

    private List<ProductoDocument> mapProductos(List<ProductoDTO> productos) {
        if (productos == null) return List.of();

        return productos.stream().map(prod -> ProductoDocument.builder()
                .id(prod.getId())
                .nombre(prod.getNombre())
                .descripcion(prod.getDescripcion())
                .cantidad(prod.getCantidad())
                .precio(prod.getPrecio())
                .adiciones(mapAdiciones(prod.getAdiciones()))
                .build()).collect(Collectors.toList());
    }

    private List<AdicionDocument> mapAdiciones(List<AdicionDTO> adiciones) {
        if (adiciones == null) return List.of();

        return adiciones.stream().map(ad -> AdicionDocument.builder()
                .id(ad.getId())
                .nombre(ad.getNombre())
                .cantidad(ad.getCantidad())
                .precio(ad.getPrecio())
                .build()).collect(Collectors.toList());
    }
}
