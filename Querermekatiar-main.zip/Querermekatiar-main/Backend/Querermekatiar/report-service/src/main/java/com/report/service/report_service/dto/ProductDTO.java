package com.report.service.report_service.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Data
public class ProductDTO {
    // Campos principales alineados con la plantilla JasperReports
    private String productName;
    private int cant;  // Renombrado de quantity para coincidir con la plantilla
    private BigDecimal price;
    private BigDecimal orderTotal;
    private String Field_1;  // Campo requerido por la plantilla
    @JsonAlias({"adiciones", "addOns"})
    private List<AddOnDTO> addOns;
    // Alias para compatibilidad con el frontend que envía 'adiciones'
    private List<AddOnDTO> adiciones;
    
    // Campos adicionales para reporte
    private String orderId;
    private String customerName;
    private String customerLastName;
    private String nombreCompleto; // Campo específico para JasperReports
    private java.util.Date fechaHora;
    private BigDecimal orderSubTotal;
    private boolean lastProductOfOrder; // Para saber cuándo mostrar totales

    // Getter robusto para addOns: si es null, usa adiciones
    public List<AddOnDTO> getAddOns() {
        if (addOns != null) return addOns;
        if (adiciones != null) return adiciones;
        return null;
    }

    public BigDecimal getTotal() {
        BigDecimal addOnsTotal = BigDecimal.ZERO;
        List<AddOnDTO> effectiveAddOns = getAddOns();
        if (effectiveAddOns != null) {
            for (AddOnDTO addOn : effectiveAddOns) {
                BigDecimal price = addOn.getPrice() != null ? addOn.getPrice() : BigDecimal.ZERO;
                addOnsTotal = addOnsTotal.add(price.multiply(BigDecimal.valueOf(addOn.getQuantity())));
            }
        }
        BigDecimal unitTotal = price.add(addOnsTotal);
        return unitTotal.multiply(BigDecimal.valueOf(cant));
    }

    // Método para mostrar las adiciones como string
    public String getAddOnsAsString() {
        List<AddOnDTO> effectiveAddOns = getAddOns();
        if (effectiveAddOns == null || effectiveAddOns.isEmpty()) {
            return "-";
        }
        return effectiveAddOns.stream()
                .map(addOn -> addOn.getName() + " x" + addOn.getQuantity())
                .collect(Collectors.joining(", "));
    }
    
    // Getter para el campo nombreCompleto que necesita JasperReports
    public String getNombreCompleto() {
        if (nombreCompleto == null) {
            nombreCompleto = (customerName != null ? customerName : "") + " " + 
                    (customerLastName != null ? customerLastName : "");
        }
        return nombreCompleto;
    }

    // Setter para el campo nombreCompleto
    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    // Mantener el método original por compatibilidad
    public String getCustomerFullName() {
        return getNombreCompleto();
    }
}