package com.report.service.report_service.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data
public class OrderDTO {
    private String orderId;
    private String customerName;
    private String customerLastName;
    private java.util.Date fechaHora;
    private BigDecimal subTotal;
    private BigDecimal total;
    private List<ProductDTO> products;


    public String getNombreCompleto() {
        String nombre = (this.customerName != null ? this.customerName : "");
        String apellido = (this.customerLastName != null ? this.customerLastName : "");
        String completo = (nombre + " " + apellido).trim();
        return completo.isEmpty() ? "---" : completo;
    }

    // Compatibilidad con la plantilla: order.orderTotal
    public BigDecimal getOrderTotal() {
        return this.total != null ? this.total : BigDecimal.ZERO;
    }
}

