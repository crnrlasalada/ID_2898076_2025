package com.report.service.report_service.service;

import com.report.service.report_service.dto.OrderDTO;
import com.report.service.report_service.dto.ProductDTO;
import com.report.service.report_service.dto.AddOnDTO;
import org.springframework.core.io.ClassPathResource;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Locale;

@Service
public class HtmlInvoiceService {

    private final TemplateEngine templateEngine;

    @Autowired
    public HtmlInvoiceService(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }

    public byte[] generateInvoicePdfFromOrders(List<OrderDTO> orders) {
        try {
            if (orders == null || orders.isEmpty()) {
                throw new IllegalArgumentException("No hay pedidos para generar la factura");
            }

            // Recalcular totales de productos y pedidos en servidor para evitar inconsistencias
            for (OrderDTO order : orders) {
                BigDecimal orderTotal = BigDecimal.ZERO;
                if (order.getProducts() != null) {
                    for (ProductDTO prod : order.getProducts()) {
                        // Asegurar campos no nulos
                        BigDecimal price = prod.getPrice() != null ? prod.getPrice() : BigDecimal.ZERO;
                        int cantidad = prod.getCant();

                        BigDecimal addOnsTotal = BigDecimal.ZERO;
                        if (prod.getAddOns() != null) {
                            for (AddOnDTO ao : prod.getAddOns()) {
                                BigDecimal aoPrice = ao.getPrice() != null ? ao.getPrice() : BigDecimal.ZERO;
                                int aoQty = ao.getQuantity();
                                addOnsTotal = addOnsTotal.add(aoPrice.multiply(BigDecimal.valueOf(aoQty)));
                            }
                        }

                        BigDecimal unitTotal = price.add(addOnsTotal);
                        BigDecimal productTotal = unitTotal.multiply(BigDecimal.valueOf(Math.max(0, cantidad)));

                        // Si el DTO tiene métodos para obtener total, lo respetamos; en cualquier caso
                        // aseguramos que el cálculo del pedido use este valor
                        orderTotal = orderTotal.add(productTotal);
                    }
                }
                order.setTotal(orderTotal);
            }

            Context ctx = new Context(new Locale("es"));
            ctx.setVariable("orders", orders);

            String html = templateEngine.process("invoice", ctx);

            // Embedir imágenes como data URIs para que funcionen dentro del JAR/executable
            html = embedImageAsDataUri(html, "/images/waves_design.png");
            html = embedImageAsDataUri(html, "/images/logotype_both.png");

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(html);
            renderer.layout();
            renderer.createPDF(outputStream);

            return outputStream.toByteArray();
        } catch (Exception ex) {
            throw new RuntimeException("Error generating PDF from HTML", ex);
        }
    }

    // Lee una imagen del classpath y reemplaza su ruta en el HTML por un data URI (base64)
    private String embedImageAsDataUri(String html, String classpathImagePath) {
        try {
            if (!html.contains(classpathImagePath)) return html;
            ClassPathResource res = new ClassPathResource(classpathImagePath.startsWith("/") ? classpathImagePath.substring(1) : classpathImagePath);
            if (!res.exists()) return html;
            try (InputStream is = res.getInputStream()) {
                byte[] bytes = is.readAllBytes();
                String base64 = Base64.getEncoder().encodeToString(bytes);
                String dataUri = "data:image/png;base64," + base64;
                return html.replace(classpathImagePath, dataUri);
            }
        } catch (Exception e) {
            // no bloquear la generación de PDF por fallo al embedir imagen; loguear minimalmente
            System.err.println("Warning: no se pudo embeber imagen " + classpathImagePath + " - " + e.getMessage());
            return html;
        }
    }
}
