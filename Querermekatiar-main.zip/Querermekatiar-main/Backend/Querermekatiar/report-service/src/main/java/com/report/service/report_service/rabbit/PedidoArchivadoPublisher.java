package com.report.service.report_service.rabbit;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class PedidoArchivadoPublisher {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void publicarPedidoArchivado(Integer pedidoId) {
        Map<String, Object> mensaje = new HashMap<>();
        mensaje.put("pedidoId", pedidoId);
        rabbitTemplate.convertAndSend("pedido-archivado-exchange", "pedido.archivado", mensaje);
    }
}

