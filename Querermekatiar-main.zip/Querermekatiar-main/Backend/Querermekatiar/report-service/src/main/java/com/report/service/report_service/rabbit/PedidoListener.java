package com.report.service.report_service.rabbit;

import com.report.service.report_service.mongo.document.PedidoDocument;
import com.report.service.report_service.mongo.mapper.PedidoMapper;
import com.report.service.report_service.mongo.service.PedidoMongoService;
import com.report.service.report_service.dto.PedidoDetalleDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class PedidoListener {

    private final PedidoMongoService pedidoMongoService;
    private final PedidoMapper pedidoMapper;
    private final PedidoArchivadoPublisher pedidoArchivadoPublisher;

    public PedidoListener(PedidoMongoService pedidoMongoService, PedidoMapper pedidoMapper, PedidoArchivadoPublisher pedidoArchivadoPublisher) {
        this.pedidoMongoService = pedidoMongoService;
        this.pedidoMapper = pedidoMapper;
        this.pedidoArchivadoPublisher = pedidoArchivadoPublisher;
    }

    @RabbitListener(queues = "report.pedido.queue")
    public void recibirPedidoFinalizado(PedidoDetalleDTO pedidoDTO) {
        System.out.println("📥 Pedido recibido por RabbitMQ (report): " + pedidoDTO);

        PedidoDocument documento = pedidoMapper.toDocument(pedidoDTO);

        boolean guardado = pedidoMongoService.guardarPedido(documento);

        if (guardado) {
            System.out.println("💾 Pedido guardado en MongoDB correctamente.");
            System.out.println(pedidoDTO);
            pedidoArchivadoPublisher.publicarPedidoArchivado(pedidoDTO.getId());
            System.out.println("📤 Notificación enviada a admin-panel para eliminar el pedido.");
        } else {
            System.err.println("❌ No se pudo guardar en MongoDB. No se notificará al admin-panel.");
        }
    }

}
