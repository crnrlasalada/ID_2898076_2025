package com.report.service.report_service.config;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PedidoArchivadoRabbitConfig {

    public static final String EXCHANGE_NAME = "pedido-archivado-exchange";
    public static final String QUEUE_NAME = "pedido.archivado.queue";
    public static final String ROUTING_KEY = "pedido.archivado";

    @Bean(name = "pedidoArchivadoExchange")
    public TopicExchange pedidoArchivadoExchange() {
        return new TopicExchange(EXCHANGE_NAME);
    }

    @Bean(name = "pedidoArchivadoQueue")
    public Queue pedidoArchivadoQueue() {
        return new Queue(QUEUE_NAME, true);
    }

    @Bean
    public Binding bindingPedidoArchivado(Queue pedidoArchivadoQueue, TopicExchange pedidoArchivadoExchange) {
        return BindingBuilder.bind(pedidoArchivadoQueue)
                .to(pedidoArchivadoExchange)
                .with(ROUTING_KEY);
    }
}