package com.admin_panel.mapper;

import com.admin_panel.dto.OrderDTO;

import java.util.stream.Collectors;

public class OrderMapper {

    public static OrderDTO toNotificationDTO(
           OrderDTO source) {

        if (source == null) return null;

        OrderDTO target = new OrderDTO();
        target.setOrderId(source.getOrderId());
        target.setCustomerName(source.getCustomerName());
        target.setCustomerDocument(source.getCustomerDocument());
        target.setCustomerEmail(source.getCustomerEmail());
        target.setCustomerAddress(source.getCustomerAddress());
        target.setOrderDate(source.getOrderDate());
        target.setCustomerPhone(source.getCustomerPhone());
        target.setDeliveryAddress(source.getDeliveryAddress());
        target.setDeliveryFee(source.getDeliveryFee());
        target.setSubTotal(source.getSubTotal());
        target.setTotal(source.getTotal());

        target.setProducts(
                source.getProducts() != null
                        ? source.getProducts().stream()
                        .map(ProductMapper::toNotificationDTO)
                        .collect(Collectors.toList())
                        : null
        );

        return target;
    }
}