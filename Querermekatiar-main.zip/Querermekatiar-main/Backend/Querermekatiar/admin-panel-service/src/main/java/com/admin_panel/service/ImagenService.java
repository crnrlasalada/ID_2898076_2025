package com.admin_panel.service;

import com.admin_panel.dto.ImagenUploadResponse;
import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Map;

@Service
public class ImagenService {

    private final Cloudinary cloudinary;

    public ImagenService(Cloudinary cloudinary) {
        this.cloudinary = cloudinary;
    }

    public ImagenUploadResponse subirImagen(MultipartFile file) throws IOException {
        File tmp = File.createTempFile("upload-", file.getOriginalFilename());
        file.transferTo(tmp);

        Map<?, ?> res = cloudinary.uploader().upload(
                tmp,
                ObjectUtils.asMap("folder", "Novedades")
        );

        ImagenUploadResponse dto = new ImagenUploadResponse();
        dto.setSecureUrl(res.get("secure_url").toString());
        dto.setPublicId(res.get("public_id").toString());
        return dto;
    }

    public boolean eliminarImagen(String publicId) throws IOException {
        Map<?, ?> res = cloudinary.uploader().destroy(
                publicId, ObjectUtils.asMap("invalidate", true)
        );
        Object r = res.get("result");
        return r != null && "ok".equalsIgnoreCase(r.toString());
    }
}