package com.admin_panel.config;


import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class RabbitMQCreateOrderConfig {

    public static final String EXCHANGE_NAME = "create.exchange";
    public static final String QUEUE_NAME = "create.status.queue";
    public static final String ROUTING_KEY = "create.status.updated";

    @Bean(name="orderCreateExchange")
    public DirectExchange orderCreateExchange() {
        return new DirectExchange(EXCHANGE_NAME);
    }

    @Bean(name="orderCreateQueue")
    public Queue orderCreateQueue() {
        return new Queue(QUEUE_NAME);
    }

    @Bean
    public Binding createBinding(@Qualifier("orderCreateQueue") Queue orderCreateQueue, @Qualifier("orderCreateExchange") DirectExchange orderCreateExchange) {
        return BindingBuilder
                .bind(orderCreateQueue)
                .to(orderCreateExchange)
                .with(ROUTING_KEY);
    }

}