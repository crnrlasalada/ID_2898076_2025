package com.admin_panel.controller;

import com.admin_panel.dto.PedidoRequestDTO;
import com.admin_panel.dto.PedidoDetalleDTO;
import com.admin_panel.entity.Pedido;
import com.admin_panel.service.PedidoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin-panel")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    // ✔ ADMIN / CAJERO - Ver todos los pedidos activos
    @GetMapping("/activos")
    public ResponseEntity<List<PedidoDetalleDTO>> listarPedidosActivos() {
        return ResponseEntity.ok(pedidoService.listarPedidosActivos());
    }

    // ✔ CLIENTE - Ver detalle de su pedido
    @GetMapping("/{id}/detalle")
    public ResponseEntity<PedidoDetalleDTO> obtenerDetallePedido(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(pedidoService.obtenerDetallePedido(id));
    }

    // ✔ CLIENTE - Crear pedido
    @PostMapping
    public ResponseEntity<Pedido> crearPedido(@Valid @RequestBody PedidoRequestDTO dto) {
        return ResponseEntity.ok(pedidoService.guardarPedidoConDetalles(dto));
    }

    // ✔ ADMIN / CAJERO - Actualizar estado (Ej. aceptar o rechazar)
    @PutMapping("/{id}/estado")
    public ResponseEntity<Pedido> actualizarEstado(
            @PathVariable("id") Integer id,
            @RequestParam(name = "nuevoEstado") String nuevoEstado,
            @RequestParam(name = "motivoRechazo", required = false) String motivoRechazo
    ) {
        return ResponseEntity.ok(pedidoService.actualizarEstado(id, nuevoEstado, motivoRechazo));
    }

    // ✔ DELIVERY - Ver pedidos en estado "Reparto"
    @GetMapping("delivery/reparto")
    public ResponseEntity<List<PedidoDetalleDTO>> listarPedidosEnReparto() {
        return ResponseEntity.ok(pedidoService.listarPedidosEnReparto());
    }

    // ✔ DELIVERY - Cambiar estado a "Entregado", "No_Recibido" o "Rechazado"
    @PutMapping("/delivery/reparto/{id}/estado")
    public ResponseEntity<Pedido> actualizarDesdeReparto(
            @PathVariable("id") Integer id,
            @RequestParam(name = "nuevoEstado") String nuevoEstado,
            @RequestParam(name = "motivo", required = false) String motivo
    ) {
        // Validar que el estado sea uno permitido
        if (!nuevoEstado.equalsIgnoreCase("Entregado") &&
                !nuevoEstado.equalsIgnoreCase("No_Recibido") &&
                !nuevoEstado.equalsIgnoreCase("Rechazado")) {
            return ResponseEntity.badRequest().build();
        }

        // Actualizar estado usando el servicio
        Pedido pedidoActualizado = pedidoService.actualizarEstado(id, nuevoEstado, motivo);

        // Si no se encuentra el pedido, devolver 404
        if (pedidoActualizado == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(pedidoActualizado);
    }


}
