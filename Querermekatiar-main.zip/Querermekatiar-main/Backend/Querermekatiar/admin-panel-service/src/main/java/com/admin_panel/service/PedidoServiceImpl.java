package com.admin_panel.service;


import com.admin_panel.controller.DeliverySseController;
import com.admin_panel.dto.*;
import com.admin_panel.entity.*;
import com.admin_panel.mapper.AddOnMapper;
import com.admin_panel.mapper.OrderMapper;
import com.admin_panel.mapper.ProductMapper;
import com.admin_panel.messaging.*;
import com.admin_panel.repository.*;
import com.admin_panel.dto.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


@Service
public class PedidoServiceImpl implements PedidoService {


    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private AdicionRepository adicionRepository;

    @Autowired
    private ProductoAdicionPedidoRepository productoAdicionPedidoRepository;

    @Autowired
    private PedidoEventPublisher pedidoEventPublisher;

    @Autowired
    private ReportEventPublisher reportEventPublisher;

    @Autowired
    private DeliverySseController deliverySseController;

    @Autowired
    private PedidoAceptadoPublisher pedidoAceptadoPublisher;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private EmailNotificationPublisher emailNotificationPublisher;

    @Override
    public Pedido actualizarEstado(Integer id, String nuevoEstado, String motivoRechazo) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado con ID: " + id));

        pedido.setEstadoPedido(nuevoEstado);

        if ("Rechazado".equalsIgnoreCase(nuevoEstado) || "No_Recibido".equalsIgnoreCase(nuevoEstado)) {
            pedido.setMotivoRechazo(motivoRechazo);
        }

        Pedido actualizado = pedidoRepository.save(pedido);

        // Notificación general
        pedidoEventPublisher.enviarEvento(new PedidoEventDTO(id, pedido.getIdUsuario(), pedido.getEstadoPedido()));

        if ("Reparto".equalsIgnoreCase(pedido.getEstadoPedido())
                && "Domicilio".equalsIgnoreCase(pedido.getTipoEntrega())) {

            deliverySseController.sendEventWithDelay(
                    new PedidoEventDTO(id, pedido.getIdUsuario(), pedido.getEstadoPedido())
            );
        }

        if ("En_Proceso".equalsIgnoreCase(pedido.getEstadoPedido())) {
            PedidoDetalleDTO detalleDTO = obtenerDetallePedido(id);

            // 🔹 PASA EL OrderDTO DEL ADMIN_PANEL
            OrderDTO order = mapToOrderDTO(detalleDTO);

            pedidoAceptadoPublisher.enviarSiEsAceptado(detalleDTO, order);
        }

        if (List.of("Rechazado", "No_Recibido", "Entregado").contains(nuevoEstado)) {
            PedidoDetalleDTO detalleDTO = obtenerDetallePedido(id);
            reportEventPublisher.enviarDetalleParaReporte(detalleDTO); // Esto envía a Mongo y luego se escucha en el Listener
        }


        // 🔹 SIEMPRE enviar notificación por correo en cualquier cambio de estado
        Usuario usuario = usuarioRepository.findById(pedido.getIdUsuario())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + pedido.getIdUsuario()));

        EmailNotificationDTO notificacion = new EmailNotificationDTO(
                pedido.getNombres() + " " + pedido.getApellidos(),  // clientName
                usuario.getCorreo(),                               // email
                nuevoEstado,                                       // status
                pedido.getId().toString(),                         // orderNumber
                pedido.getMotivoRechazo()                          // rejectionReason (puede venir null)
        );

        emailNotificationPublisher.enviarNotificacion(notificacion);

        return actualizado;
    }

    // ------------------------------------------------------------
    // Método privado dentro de la misma clase PedidoServiceImpl
    private OrderDTO mapToOrderDTO(PedidoDetalleDTO detalle) {
        OrderDTO order = new OrderDTO();
        order.setOrderId(detalle.getId().toString());
        order.setCustomerName(detalle.getNombres() + " " + detalle.getApellidos());

        Usuario usuario = usuarioRepository.findById(detalle.getIdUsuario())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado: " + detalle.getIdUsuario()));
        order.setCustomerDocument(usuario.getDocumento());
        order.setCustomerEmail(usuario.getCorreo());
        order.setCustomerAddress(detalle.getDireccion());
        order.setOrderDate(detalle.getFechaHora());
        order.setCustomerPhone(detalle.getTelefono());
        order.setDeliveryAddress(detalle.getDireccion());
        order.setDeliveryFee(detalle.getDomicilio());
        order.setSubTotal(detalle.getSubtotal());
        order.setTotal(detalle.getTotal());

        order.setProducts(
                detalle.getProductos().stream()
                        .map(p -> {
                            ProductDTO prod = new ProductDTO();
                            prod.setName(p.getNombre());
                            prod.setPrice(BigDecimal.valueOf(p.getPrecio()));
                            prod.setQuantity(p.getCantidad());

                            if (p.getAdiciones() != null) {
                                prod.setAddOns(
                                        p.getAdiciones().stream()
                                                .map(a -> {
                                                    AddOnDTO addOn = new AddOnDTO();
                                                    addOn.setName(a.getNombre());
                                                    addOn.setQuantity(a.getCantidad());
                                                    addOn.setPrice(BigDecimal.valueOf(a.getPrecio()));
                                                    return addOn;
                                                })
                                                .collect(Collectors.toList())
                                );
                            }

                            return prod;
                        })
                        .collect(Collectors.toList())
        );

        return order;
    }


    @Override
    public Pedido guardarPedidoConDetalles(PedidoRequestDTO dto) {
        Pedido pedido = Pedido.builder()
                .idUsuario(dto.getIdUsuario())
                .documento(dto.getDocumento())
                .estadoPedido(dto.getEstado())
                .telefono(dto.getTelefono())
                .documento(dto.getDocumento())
                .direccion(dto.getDireccion())
                .fechaHora(dto.getFechaHora())
                .formaPago(dto.getFormaPago())
                .latitud(dto.getLatitud())
                .longitud(dto.getLongitud())
                .mensajeCliente(dto.getMensajeCliente())
                .motivoRechazo(dto.getMotivoRechazo())
                .tipoEntrega(dto.getTipoEntrega())
                .domicilio(dto.getDomicilio())
                .subtotal(dto.getSubtotal())
                .total(dto.getTotal())
                .build();

        Pedido guardado = pedidoRepository.save(pedido);

        for (ProductoDTO producto : dto.getProductos()) {
            for (AdicionDTO adicion : producto.getAdiciones()) {


                ProductoAdicionPedido detalle = ProductoAdicionPedido.builder()
                        .id(1)
                        .contadorProducto(1)
                        .cantidadAdicion(adicion.getCantidad())
                        .cantidadProducto(producto.getCantidad())
                        .producto(productoRepository.findById(producto.getId()).orElseThrow())
                        .adicion(adicionRepository.findById(adicion.getId()).orElseThrow())
                        .pedido(guardado)
                        .build();

                productoAdicionPedidoRepository.save(detalle);
            }
        }

        return guardado;
    }

    @Override
public PedidoDetalleDTO obtenerDetallePedido(Integer id) {
    Pedido pedido = pedidoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));


    List<ProductoAdicionPedido> detalles = productoAdicionPedidoRepository.findByPedido_Id(id);

    // Usar una clave compuesta para distinguir productos repetidos (idProducto + contadorProducto)
    Map<String, ProductoDTO> productosMap = new LinkedHashMap<>();

    for (ProductoAdicionPedido detalle : detalles) {
        Integer idProducto = detalle.getProducto().getId();
        Integer contador = detalle.getContadorProducto() != null ? detalle.getContadorProducto() : 1;
        String key = idProducto + "_" + contador;

        if (!productosMap.containsKey(key)) {
            productosMap.put(key, ProductoDTO.builder()
                    .id(idProducto)
                    .nombre(detalle.getProducto().getNombre())
                    .descripcion(detalle.getProducto().getDescripcion())
                    .urlImagen(detalle.getProducto().getUrlImagen())
                    .precio(detalle.getProducto().getPrecio())
                    .cantidad(detalle.getCantidadProducto())
                    .adiciones(new ArrayList<>())
                    .build());
        }
        if (detalle.getAdicion() != null) {
            productosMap.get(key).getAdiciones().add(
                    AdicionDTO.builder()
                            .id(detalle.getAdicion().getId())
                            .nombre(detalle.getAdicion().getNombre())
                            .cantidad(detalle.getCantidadAdicion())
                            .precio(detalle.getAdicion().getPrecio())
                            .build()
            );
        }
    }



    return PedidoDetalleDTO.builder()
            .id(pedido.getId())
            .idUsuario(pedido.getIdUsuario())
            .nombres(pedido.getNombres())
            .apellidos(pedido.getApellidos())
            .telefono(pedido.getTelefono())
            .estadoPedido(pedido.getEstadoPedido())
            .direccion(pedido.getDireccion())
            .fechaHora(pedido.getFechaHora())
            .tipoEntrega(pedido.getTipoEntrega())
            .mensajeCliente(pedido.getMensajeCliente())
            .motivoRechazo(pedido.getMotivoRechazo())
            .formaPago(pedido.getFormaPago())
            .longitud(pedido.getLongitud())
            .latitud(pedido.getLatitud())
            .total(pedido.getTotal())
            .subtotal(pedido.getSubtotal())
            .domicilio(pedido.getDomicilio())
            .productos(new ArrayList<>(productosMap.values()))
            .build();
}

    @Override
    public List<PedidoDetalleDTO> listarPedidosActivos() {
        List<String> estados = List.of("Pendiente", "Aceptado", "En_Proceso", "Listo", "Reparto");
        return pedidoRepository.findByEstadoPedidoInIgnoreCase(estados)
                .stream()
                .map(p -> obtenerDetallePedido(p.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public List<PedidoDetalleDTO> listarPedidosEnReparto() {
        return pedidoRepository.findByEstadoPedidoIgnoreCase("Reparto")
                .stream()
                .map(p -> obtenerDetallePedido(p.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public List<PedidoDetalleDTO> listarPedidosPorClienteYEstado(Integer idUsuario, String estadoPedido) {
        List<Pedido> pedidos = pedidoRepository.findByIdUsuarioAndEstadoPedidoIgnoreCase(idUsuario, estadoPedido);
        return pedidos.stream()
                .map(p -> obtenerDetallePedido(p.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public List<PedidoDetalleDTO> listarPedidosActivosPorCliente(Integer idUsuario) {
        List<String> estadosActivos = List.of("Pendiente", "Aceptado", "En_Proceso", "Listo", "Reparto");

        return pedidoRepository.findByIdUsuarioAndEstadoPedidoInIgnoreCase(idUsuario, estadosActivos)
                .stream()
                .map(p -> obtenerDetallePedido(p.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public Pedido obtenerPedidoPorId(Integer id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado: " + id));
    }



}
