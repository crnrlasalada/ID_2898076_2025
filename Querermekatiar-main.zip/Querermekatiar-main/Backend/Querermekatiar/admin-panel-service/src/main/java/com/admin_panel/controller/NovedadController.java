package com.admin_panel.controller;

import com.admin_panel.entity.Novedad;
import com.admin_panel.service.NovedadService;
import com.admin_panel.service.ImagenService;
import com.admin_panel.dto.ImagenUploadResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/admin-panel")
public class NovedadController {

    private final NovedadService service;
    private final ImagenService imagenService;

    public NovedadController(NovedadService service, ImagenService imagenService) {
        this.service = service;
        this.imagenService = imagenService;
    }

    // 📌 1. Listar todas las novedades
    @GetMapping("/novedades")
    public List<Novedad> listar() {
        return service.listar();
    }

    // 📌 2. Listar novedades por negocio
    @GetMapping("/novedades/negocio/{idNegocio}")
    public List<Novedad> listarPorNegocio(@PathVariable Long idNegocio) {
        return service.buscarPorIdNegocio(idNegocio);
    }

    // 📌 3. Subir imagen + registrar novedad
    @PostMapping("/novedades/upload")
    public ResponseEntity<Novedad> upload(
            @RequestParam("file") MultipartFile file,
            @RequestParam("idNegocio") Long idNegocio) {

        try {
            ImagenUploadResponse upload = imagenService.subirImagen(file);

            Novedad n = new Novedad();
            n.setImagenUrl(upload.getSecureUrl());
            n.setPublicId(upload.getPublicId());
            n.setIdNegocio(idNegocio);

            Novedad guardada = service.crear(n);
            return ResponseEntity.ok(guardada);

        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // 📌 4. Eliminar novedad por ID
    @DeleteMapping("/novedades/delete/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        try {
            service.eliminar(id); // ✅ elimina imagen de Cloudinary y la novedad de BD
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
