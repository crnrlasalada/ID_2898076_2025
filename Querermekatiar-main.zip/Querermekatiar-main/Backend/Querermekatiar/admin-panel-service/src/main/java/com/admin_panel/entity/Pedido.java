package com.admin_panel.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pedido")
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NotNull
    @JoinColumn(name = "id_usuario", nullable = false)
    private Integer idUsuario;

    @Size(max = 50)
    @NotNull
    @Column(name = "nombres", nullable = false, length = 50)
    private String nombres;

    @Size(max = 50)
    @NotNull
    @Column(name = "apellidos", nullable = false, length = 50)
    private String apellidos;

    @NotNull
    @ColumnDefault("'Pendiente'")
    @Column(name = "estado_pedido", nullable = false)
    private String estadoPedido;

    @Size(max = 10)
    @NotNull
    @Column(name = "telefono", nullable = false, length = 10)
    private String telefono;

    @Size(max = 10)
    @NotNull
    @Column(name = "documento", nullable = false, length = 10)
    private String documento;

    @NotNull
    @Lob
    @Column(name = "tipo_entrega", nullable = false)
    private String tipoEntrega;

    @Size(max = 150)
    @Column(name = "direccion", length = 150)
    private String direccion;

    @NotNull
    @Column(name = "fecha_hora", nullable = false)
    private java.util.Date fechaHora;

    @NotNull
    @Lob
    @Column(name = "forma_pago", nullable = false)
    private String formaPago;

    @Column(name = "latitud", precision = 10, scale = 8)
    private BigDecimal latitud;

    @Column(name = "longitud", precision = 11, scale = 8)
    private BigDecimal longitud;

    @Lob
    @Column(name = "mensaje_cliente")
    private String mensajeCliente;

    @Lob
    @Column(name = "motivo_rechazo")
    private String motivoRechazo;

    @NotNull
    @Column(name = "domicilio", nullable = false, precision = 10, scale = 2)
    private BigDecimal domicilio;

    @NotNull
    @Column(name = "subtotal", nullable = false, precision = 10, scale = 2)
    private BigDecimal subtotal;

    @NotNull
    @Column(name = "total", nullable = false, precision = 10, scale = 2)
    private BigDecimal total;
}