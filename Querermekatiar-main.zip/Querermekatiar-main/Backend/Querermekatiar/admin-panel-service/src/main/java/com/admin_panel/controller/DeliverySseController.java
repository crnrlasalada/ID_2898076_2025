package com.admin_panel.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class DeliverySseController {

    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();

    @GetMapping(value = "/api/stream/delivery", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamDelivery() {
        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);
        emitters.add(emitter);

        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> emitters.remove(emitter));
        emitter.onError(e -> emitters.remove(emitter));

        System.out.println("Cliente SSE conectado al canal DELIVERY");

        return emitter;
    }

    /**
     * Envía un evento SSE con un pequeño delay para dar tiempo a que el cliente se suscriba correctamente
     */
    public void sendEventWithDelay(Object event) {
        new Thread(() -> {
            try {
                Thread.sleep(500); // medio segundo de espera
                for (SseEmitter emitter : emitters) {
                    try {
                        emitter.send(SseEmitter.event()
                                .name("actualizacion-delivery")
                                .data(event));
                    } catch (IOException e) {
                        emitters.remove(emitter);
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }
}
