package com.admin_panel.service;

import com.admin_panel.entity.Negocio;
import com.admin_panel.repository.NegocioRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class NegocioService {

    private final NegocioRepository negocioRepository;

    public NegocioService(NegocioRepository negocioRepository) {
        this.negocioRepository = negocioRepository;
    }

    public Negocio activarYDesactivar(Long id, boolean activo) {
        Optional<Negocio> negocioOpt = negocioRepository.findById(id);
        if (negocioOpt.isEmpty()) {
            throw new RuntimeException("Negocio no encontrado con id: " + id);
        }

        Negocio negocio = negocioOpt.get();
        negocio.setActivo(activo); // true → activo (1), false → inactivo (0)
        return negocioRepository.save(negocio);
    }

    public Optional<Negocio> obtenerPorId(Long id) {
        return negocioRepository.findById(id);
    }

}
