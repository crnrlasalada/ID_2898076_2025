package com.admin_panel.messaging;

import com.admin_panel.config.RabbitMQConfigOrderInvoice;
import com.admin_panel.dto.OrderDTO;
import com.admin_panel.dto.PedidoDetalleDTO;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class PedidoAceptadoPublisher {

    private final RabbitTemplate rabbitTemplate;

    public PedidoAceptadoPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void enviarSiEsAceptado(PedidoDetalleDTO PedidoDetalle, OrderDTO order) {
        if ("En_Proceso".equalsIgnoreCase(PedidoDetalle.getEstadoPedido())) {
            rabbitTemplate.convertAndSend(
                    RabbitMQConfigOrderInvoice.EXCHANGE,
                    RabbitMQConfigOrderInvoice.ROUTING_KEY,
                    order
            );
            System.out.println("📨 Evento de factura-aceptado enviado : " + order);
        }
    }
}
