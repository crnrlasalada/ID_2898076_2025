package com.admin_panel.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PedidoDetalleDTO {
    private Integer id;
    private Integer idUsuario;
    private String nombres;
    private String apellidos;
    private String telefono;
    private String estadoPedido;
    private String direccion;
    private java.util.Date fechaHora;
    private String tipoEntrega;
    private String formaPago;
    private BigDecimal latitud;
    private BigDecimal longitud;
    private String mensajeCliente;
    private String motivoRechazo;
    private BigDecimal domicilio;
    private BigDecimal subtotal;
    private BigDecimal total;
    private List<ProductoDTO> productos;
}