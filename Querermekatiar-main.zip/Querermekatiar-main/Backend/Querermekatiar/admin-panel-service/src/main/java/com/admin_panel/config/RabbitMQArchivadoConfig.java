package com.admin_panel.config;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQArchivadoConfig {

    public static final String EXCHANGE_NAME = "pedido-archivado-exchange";
    public static final String QUEUE_NAME = "pedido.archivado.queue";
    public static final String ROUTING_KEY = "pedido.archivado";


    @Bean(name = "pedidoArchivadoExchange")
    public TopicExchange archivadoExchange() {
        return new TopicExchange(EXCHANGE_NAME);
    }


    @Bean(name = "pedidoArchivadoQueue")
    public Queue archivadoQueue() {
        return new Queue(QUEUE_NAME, true); // durable
    }

    @Bean
    public Binding archivadoBinding(@Qualifier("pedidoArchivadoQueue") Queue archivadoQueue, @Qualifier("pedidoArchivadoExchange") TopicExchange archivadoExchange) {
        return BindingBuilder
                .bind(archivadoQueue)
                .to(archivadoExchange)
                .with(ROUTING_KEY);
    }
}
