package com.admin_panel.messaging;

import com.admin_panel.config.RabbitMQConfigNotification;
import com.admin_panel.dto.EmailNotificationDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EmailNotificationPublisher {

    private final RabbitTemplate rabbitTemplate;

    public void enviarNotificacion(EmailNotificationDTO dto) {
        rabbitTemplate.convertAndSend(
                RabbitMQConfigNotification.EXCHANGE,
                RabbitMQConfigNotification.ROUTING_KEY,
                dto
        );
        System.out.println("📩 Notificación enviada a la cola de correos cuando cambia estado: " + dto);
    }
}
