package com.admin_panel.messaging;

import com.admin_panel.controller.OrderSseController;
import com.admin_panel.dto.OrderCreateEventDTO;
import com.admin_panel.entity.Pedido;
import com.admin_panel.service.PedidoService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class OrderCreateEventListener {

    private final OrderSseController sseController;
    private final PedidoService pedidoService;
    

    public OrderCreateEventListener(OrderSseController sseController, PedidoService pedidoService) {
        this.sseController = sseController;
        this.pedidoService = pedidoService;
    }

    @RabbitListener(queues = "create.status.queue")
    public void getEvent(OrderCreateEventDTO evento) {
        System.out.println("Evento recibido en create.status.queue: " + evento);

        // Buscar el pedido completo
        Pedido pedidoCompleto = pedidoService.obtenerPedidoPorId(evento.getIdOrder());

        // Enviar el pedido al frontend
        sseController.sendEvent(pedidoCompleto);
    }
}


