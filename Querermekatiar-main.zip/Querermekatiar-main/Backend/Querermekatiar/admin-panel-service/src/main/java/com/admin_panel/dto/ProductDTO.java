package com.admin_panel.dto;

import java.math.BigDecimal;
import java.util.List;
import lombok.Data;

@Data
public class ProductDTO {
    private String name;
    private int quantity;
    private BigDecimal price;
    private List<AddOnDTO> addOns;

    public BigDecimal getTotal() {
        BigDecimal addOnsTotal = BigDecimal.ZERO;
        if (addOns != null) {
            for (AddOnDTO addOn : addOns) {
                addOnsTotal = addOnsTotal.add(addOn.getPrice().multiply(BigDecimal.valueOf(addOn.getQuantity())));
            }
        }
        BigDecimal unitTotal = price.add(addOnsTotal);
        return unitTotal.multiply(BigDecimal.valueOf(quantity));
    }
}