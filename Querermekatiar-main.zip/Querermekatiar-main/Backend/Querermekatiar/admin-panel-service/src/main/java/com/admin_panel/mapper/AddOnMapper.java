package com.admin_panel.mapper;

import com.admin_panel.dto.AddOnDTO;

import java.math.BigDecimal;

public class AddOnMapper {

    public static AddOnDTO toNotificationDTO(
            AddOnDTO source) {

        if (source == null) return null;

        AddOnDTO target = new AddOnDTO();
        target.setName(source.getName());
        target.setQuantity(source.getQuantity());
        target.setPrice(source.getPrice() != null
                ? source.getPrice()
                : BigDecimal.ZERO);

        return target;
    }
}
