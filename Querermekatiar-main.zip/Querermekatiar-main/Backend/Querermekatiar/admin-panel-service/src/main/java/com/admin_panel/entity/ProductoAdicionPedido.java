package com.admin_panel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "producto_adicion_pedido")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductoAdicionPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_pedido", nullable = false)
    private Pedido pedido;

    @ManyToOne
    @JoinColumn(name = "id_producto")
    private Producto producto;

    @ManyToOne
    @JoinColumn(name = "id_adicion")
    private Adicion adicion;

    @Column(name = "contador_prod")
    private Integer contadorProducto;

    @Column(name = "cant_adicion")
    private Integer cantidadAdicion;

    @Column(name = "cant_producto")
    private Integer cantidadProducto;

    // 🛠️ Relación con Pedido (ESTA FALTABA)

}
