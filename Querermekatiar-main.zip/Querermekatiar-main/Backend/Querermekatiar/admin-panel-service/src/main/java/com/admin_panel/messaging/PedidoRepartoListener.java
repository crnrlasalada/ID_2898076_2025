package com.admin_panel.messaging;

import com.admin_panel.config.RabbitConfigReparto;
import com.admin_panel.controller.DeliverySseController;
import com.admin_panel.dto.PedidoEventDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class PedidoRepartoListener {

    private final DeliverySseController deliverySseController;

    public PedidoRepartoListener(DeliverySseController deliverySseController) {
        this.deliverySseController = deliverySseController;
    }


    @RabbitListener(queues = RabbitConfigReparto.QUEUE_REPARTO)
    public void recibirEventoReparto(PedidoEventDTO event) {
        System.out.println("📥 Evento de reparto recibido: " + event);

        // Aquí emitimos el evento SSE a todos los repartidores conectados
        deliverySseController.sendEventWithDelay(event);
    }
}