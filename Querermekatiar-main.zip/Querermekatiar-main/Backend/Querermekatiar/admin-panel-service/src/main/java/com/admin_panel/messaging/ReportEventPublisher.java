package com.admin_panel.messaging;

import com.admin_panel.config.RabbitMQReportConfig;
import com.admin_panel.dto.PedidoDetalleDTO;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

// com.admim_panel.messaging.ReportEventPublisher.java
@Component
public class ReportEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public ReportEventPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void enviarDetalleParaReporte(PedidoDetalleDTO detalle) {
        rabbitTemplate.convertAndSend(
                RabbitMQReportConfig.EXCHANGE_NAME,
                RabbitMQReportConfig.ROUTING_KEY,
                detalle
        );
        System.out.println("📤 Enviado pedido finalizado a Mongo: " + detalle);
    }
}

