package com.admin_panel.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfigReparto {

    public static final String EXCHANGE_REPARTO = "pedido.reparto.exchange";
    public static final String QUEUE_REPARTO = "pedido.reparto.queue";
    public static final String ROUTING_KEY_REPARTO = "pedido.reparto";

    @Bean(name = "pedidoRepartoExchange")
    public DirectExchange repartoExchange() {
        return new DirectExchange(EXCHANGE_REPARTO);
    }

    @Bean(name = "pedidoRepartoQueue")
    public Queue repartoQueue() {
        return new Queue(QUEUE_REPARTO, true); // durable=true
    }

    @Bean
    public Binding repartoBinding(@Qualifier("pedidoRepartoQueue") Queue repartoQueue, @Qualifier("pedidoRepartoExchange") DirectExchange repartoExchange) {
        return BindingBuilder.bind(repartoQueue).to(repartoExchange).with(ROUTING_KEY_REPARTO);
    }
}

