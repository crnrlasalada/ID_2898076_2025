package com.admin_panel.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "adicion")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Adicion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "nom_adicion")
    private String nombre;

    @Column(name = "precio")
    private Long precio;
}

