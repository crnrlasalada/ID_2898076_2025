package com.admin_panel.messaging;

import com.admin_panel.config.RabbitConfigReparto;
import com.admin_panel.dto.PedidoEventDTO;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class PedidoRepartoPublisher {

    private final RabbitTemplate rabbitTemplate;

    public PedidoRepartoPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void enviarSiEsReparto(PedidoEventDTO event) {
        if ("Reparto".equalsIgnoreCase(event.getStatus())) {
            rabbitTemplate.convertAndSend(
                    RabbitConfigReparto.EXCHANGE_REPARTO,
                    RabbitConfigReparto.ROUTING_KEY_REPARTO,
                    event
            );
            System.out.println("📨 Evento de reparto enviado a RabbitMQ: " + event);
        }
    }
}
