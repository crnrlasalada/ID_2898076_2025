package com.admin_panel.controller;

import com.admin_panel.entity.Negocio;
import com.admin_panel.service.NegocioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin-panel")
public class NegocioController {

    private final NegocioService negocioService;

    public NegocioController(NegocioService negocioService) {
        this.negocioService = negocioService;
    }

    // Endpoint para cambiar el estado activo/inactivo
    @PutMapping("/{id}/activo")
    public Negocio cambiarEstado(
            @PathVariable Long id,
            @RequestParam boolean activo
    ) {
        return negocioService.activarYDesactivar(id, activo);
    }

    // Nuevo endpoint para obtener el estado activo
    @GetMapping("/{id}/activo")
    public ResponseEntity<Boolean> obtenerActivo(@PathVariable Long id) {
        return negocioService.obtenerPorId(id)
                .map(negocio -> ResponseEntity.ok(negocio.isActivo()))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
