package com.admin_panel.messaging;

import com.admin_panel.entity.ProductoAdicionPedido;
import com.admin_panel.repository.PedidoRepository;
import com.admin_panel.repository.ProductoAdicionPedidoRepository;
import jakarta.transaction.Transactional;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class PedidoEliminacionListener {

    private final PedidoRepository pedidoRepository;
    private final ProductoAdicionPedidoRepository productoAdicionPedidoRepository;

    public PedidoEliminacionListener(PedidoRepository pedidoRepository,
                                     ProductoAdicionPedidoRepository productoAdicionPedidoRepository) {
        this.pedidoRepository = pedidoRepository;
        this.productoAdicionPedidoRepository = productoAdicionPedidoRepository;
    }

    @Transactional
    @RabbitListener(queues = "pedido.archivado.queue")
    public void recibirPedidoParaEliminar(Map<String, Object> mensaje) {
        Integer pedidoId = (Integer) mensaje.get("pedidoId");

        System.out.println("🗑️ Solicitud recibida para eliminar pedido ID: " + pedidoId);

        try {
            // Paso 1: buscar relaciones en tabla intermedia
            List<ProductoAdicionPedido> relaciones = productoAdicionPedidoRepository.findByPedido_Id(pedidoId);
            System.out.println("🔍 Relaciones encontradas: " + relaciones.size());

            // Paso 2: eliminar relaciones duplicadas manualmente sin romper
            relaciones.stream()
                    .distinct() // elimina duplicados por equals/hashCode
                    .forEach(relacion -> {
                        try {
                            productoAdicionPedidoRepository.delete(relacion);
                        } catch (Exception ex) {
                            System.err.println("⚠️ Error eliminando relación (ignorada): " + ex.getMessage());
                        }
                    });

            System.out.println("✅ Relaciones eliminadas en producto_adicion_pedido.");

            // Paso 3: eliminar el pedido principal
            try {
                pedidoRepository.deleteById(pedidoId);
                System.out.println("✅ Pedido eliminado de MySQL correctamente.");
            } catch (Exception e) {
                System.err.println("⚠️ Error eliminando el pedido (puede no existir): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("❌ Error inesperado en el listener: " + e.getMessage());
            // aquí NO se relanza para que no se rompa el listener de Rabbit
        }
    }
}
