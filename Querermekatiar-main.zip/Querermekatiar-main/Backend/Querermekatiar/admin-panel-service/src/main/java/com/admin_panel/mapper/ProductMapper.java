package com.admin_panel.mapper;

import com.admin_panel.dto.ProductDTO;

import java.util.stream.Collectors;

public class ProductMapper {

    public static ProductDTO toNotificationDTO(
            ProductDTO source) {

        if (source == null) return null;

        ProductDTO target = new ProductDTO();
        target.setName(source.getName());
        target.setQuantity(source.getQuantity());
        target.setPrice(source.getPrice());

        target.setAddOns(
                source.getAddOns() != null
                        ? source.getAddOns().stream()
                        .map(AddOnMapper::toNotificationDTO)
                        .collect(Collectors.toList())
                        : null
        );

        return target;
    }
}
