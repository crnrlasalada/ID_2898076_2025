package com.admin_panel.repository;

import com.admin_panel.entity.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    List<Pedido> findByEstadoPedidoInIgnoreCase(Collection<String> estadoPedido);

    List<Pedido> findByIdUsuario(Integer idUsuario);

    List<Pedido> findByEstadoPedidoAndIdUsuario(String estadoPedido, Integer idUsuario);

    List<Pedido> findByEstadoPedidoIgnoreCase(String estadoPedido);

    List<Pedido> findByIdUsuarioAndEstadoPedidoIgnoreCase(Integer id, String estadoPedido);

    List<Pedido> findByIdUsuarioAndEstadoPedidoInIgnoreCase(Integer id, List<String> estadosActivos);
}
