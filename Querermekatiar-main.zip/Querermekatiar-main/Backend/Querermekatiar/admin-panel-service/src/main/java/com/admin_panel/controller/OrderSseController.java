package com.admin_panel.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class OrderSseController {

    // Lista segura para múltiples hilos
    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();

    /**
     * Endpoint SSE para transmitir pedidos en tiempo real
     */
    @GetMapping(value = "/api/stream/orders", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamOrders() {
        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);

        // Agregar el nuevo emisor a la lista
        emitters.add(emitter);

        // Remover el emisor cuando se complete o se agote el tiempo
        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> emitters.remove(emitter));
        emitter.onError(e -> emitters.remove(emitter));

        System.out.println("Cliente SSE conectado");

        return emitter;
    }

    /**
     * Envía un evento SSE a todos los clientes conectados
     */
    public void sendEvent(Object event) {
        for (SseEmitter emitter : emitters) {
            try {
                emitter.send(SseEmitter.event()
                        .name("nuevo-pedido")
                        .data(event));
            } catch (IOException e) {
                emitters.remove(emitter);
            }
        }
    }
}
