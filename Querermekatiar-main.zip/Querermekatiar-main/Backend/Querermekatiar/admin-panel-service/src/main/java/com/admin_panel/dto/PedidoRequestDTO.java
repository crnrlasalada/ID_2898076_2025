package com.admin_panel.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class PedidoRequestDTO {

    @NotNull(message = "El estado del pedido es obligatorio")
    @Pattern(regexp = "Pendiente|Rechazado|Aceptado|En_Proceso|Reparto|Entregado|No_Recibido",
            message = "Estado inválido")
    private String estado;

    @NotNull(message = "El ID del cliente es obligatorio")
    private Integer idUsuario;

    @NotBlank(message = "El teléfono es obligatorio")
    @Pattern(regexp = "\\d{10}", message = "El teléfono debe tener 10 dígitos")
    private String telefono;

    @NotBlank(message = "El documento es obligatorio")
    @Size(max = 10, message = "El documento no debe exceder los 10 caracteres")
    private String documento;

    @Size(max = 150, message = "La dirección no debe exceder los 150 caracteres")
    private String direccion;

    @NotNull(message = "La fecha y hora son obligatorias")
    private java.util.Date fechaHora;

    @NotBlank(message = "La forma de pago es obligatoria")
    @Pattern(regexp = "Efectivo|Transferencia", message = "Forma de pago inválida")
    private String formaPago;

    @NotNull(message = "La latitud es obligatoria")
    private BigDecimal latitud;

    @NotNull(message = "La longitud es obligatoria")
    private BigDecimal longitud;

    private String mensajeCliente;

    private String motivoRechazo;

    @NotBlank(message = "El tipo de entrega es obligatorio")
    @Pattern(regexp = "local|domicilio", flags = Pattern.Flag.CASE_INSENSITIVE,
            message = "Tipo de entrega inválido")
    private String tipoEntrega;

    @NotNull(message = "El costo del domicilio es obligatorio")
    @DecimalMin(value = "0.0", message = "El costo del domicilio no puede ser negativo")
    private BigDecimal domicilio;

    @NotNull(message = "El subtotal es obligatorio")
    @DecimalMin(value = "0.0", message = "El subtotal no puede ser negativo")
    private BigDecimal subtotal;

    @NotNull(message = "El total es obligatorio")
    @DecimalMin(value = "0.0", message = "El total no puede ser negativo")
    private BigDecimal total;

    @NotEmpty(message = "Debe incluir al menos un producto")
    private List<ProductoDTO> productos;
}
