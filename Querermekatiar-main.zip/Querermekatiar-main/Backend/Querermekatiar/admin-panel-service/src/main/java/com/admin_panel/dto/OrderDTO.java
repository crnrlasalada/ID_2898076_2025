package com.admin_panel.dto;
import com.admin_panel.dto.ProductDTO;
import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data
public class OrderDTO {
    private String orderId;

    private String customerName;

    private String customerDocument;

    private String customerAddress;

    private String customerEmail;

    private java.util.Date orderDate;

    private String customerPhone;

    private String deliveryAddress;

    private BigDecimal deliveryFee;

    private BigDecimal subTotal;

    private BigDecimal total;

    private List<ProductDTO>products;
}