package com.admin_panel.service;

import com.admin_panel.entity.Novedad;
import com.admin_panel.repository.NovedadRepository;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.List;

@Service
public class NovedadService {

    private final NovedadRepository novedadRepository;
    private final ImagenService imagenService;

    public NovedadService(NovedadRepository novedadRepository, ImagenService imagenService) {
        this.novedadRepository = novedadRepository;
        this.imagenService = imagenService;
    }

    public List<Novedad> listar() {
        return novedadRepository.findAll();
    }

    public Novedad crear(Novedad n) {
        return novedadRepository.save(n);
    }

    // ✅ Lógica de eliminación por ID de novedad
    public void eliminar(Long id) {
        novedadRepository.findById(id).ifPresent(n -> {
            String publicId = n.getPublicId();
            if (publicId != null && !publicId.isBlank()) {
                try {
                    imagenService.eliminarImagen(publicId);
                } catch (IOException e) {
                    System.err.println("❌ Error al eliminar en Cloudinary: " + e.getMessage());
                }
            }
            novedadRepository.deleteById(id);
        });
    }

    public List<Novedad> buscarPorIdNegocio(Long idNegocio) {
        return novedadRepository.findByIdNegocio(idNegocio);
    }
}