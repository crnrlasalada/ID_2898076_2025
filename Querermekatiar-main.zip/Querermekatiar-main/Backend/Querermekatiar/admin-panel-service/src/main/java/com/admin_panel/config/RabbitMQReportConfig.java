package com.admin_panel.config;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// com.admim_panel.config.RabbitMQReportConfig.java
@Configuration
public class RabbitMQReportConfig {

    public static final String EXCHANGE_NAME = "report.exchange";
    public static final String QUEUE_NAME = "report.pedido.queue";
    public static final String ROUTING_KEY = "report.pedido.finalizado";

    @Bean(name = "reportExchange")
    public DirectExchange reportExchange() {
        return new DirectExchange(EXCHANGE_NAME);
    }

    @Bean(name = "reportQueue")
    public Queue reportQueue() {
        return new Queue(QUEUE_NAME);
    }

    @Bean
    public Binding reportBinding(@Qualifier("reportQueue")Queue reportQueue, @Qualifier("reportExchange")DirectExchange reportExchange) {
        return BindingBuilder.bind(reportQueue).to(reportExchange).with(ROUTING_KEY);
    }
}
