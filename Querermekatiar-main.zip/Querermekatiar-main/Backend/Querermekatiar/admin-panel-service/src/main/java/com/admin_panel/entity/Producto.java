package com.admin_panel.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "producto")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "nombre_producto")
    private String nombre;

    @Column(name = "url_imagen")
    private String urlImagen;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "precio")
    private Long precio;
}

