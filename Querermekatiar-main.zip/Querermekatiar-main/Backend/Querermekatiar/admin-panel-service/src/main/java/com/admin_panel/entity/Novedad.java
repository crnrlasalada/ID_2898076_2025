package com.admin_panel.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "novedad")
public class Novedad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long idNovedad;

    @Column(name = "id_negocio")
    private Long idNegocio;

    @Column(name = "url_imagen")
    private String imagenUrl;

    @Column(name = "public_id")
    private String publicId;
}
