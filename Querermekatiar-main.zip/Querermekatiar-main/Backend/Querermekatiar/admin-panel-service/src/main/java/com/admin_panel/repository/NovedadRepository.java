package com.admin_panel.repository;

import com.admin_panel.entity.Novedad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NovedadRepository extends JpaRepository<Novedad, Long> {

    // 🔹 Buscar todas las novedades de un negocio específico
    public List<Novedad> findByIdNegocio(Long idNegocio);
}
