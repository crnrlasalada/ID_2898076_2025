package com.admin_panel.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfigNotification {
    public static final String QUEUE = "email.notification.queue";
    public static final String EXCHANGE = "email.notification.exchange";
    public static final String ROUTING_KEY = "email.notification.key";

    @Bean(name = "emailNotificationQueue")
    public Queue queueEmailNotification() {
        return new Queue(QUEUE, true);
    }

    @Bean (name = "emailNotificationExchange")
    public TopicExchange exchangeEmailNotification() {
        return new TopicExchange(EXCHANGE);
    }

    @Bean
    public Binding bindingEmailNotification(@Qualifier("emailNotificationQueue") Queue queue, @Qualifier("emailNotificationExchange") TopicExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(ROUTING_KEY);
    }
}
