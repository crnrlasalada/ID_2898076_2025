package com.admin_panel.repository;

import com.admin_panel.entity.ProductoAdicionPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoAdicionPedidoRepository extends JpaRepository<ProductoAdicionPedido, Integer> {

    // Elimina todas las relaciones por pedido
    void deleteByPedido_Id(Integer idPedido);

    List<ProductoAdicionPedido> findByPedido_Id(Integer id);

    // Nuevo método para encontrar relaciones por producto
    List<ProductoAdicionPedido> findByProducto_Id(Integer productoId);

    // Método para encontrar relaciones por adición
    List<ProductoAdicionPedido> findByAdicion_Id(Integer adicionId);
}
