package com.admin_panel.service;

import com.admin_panel.dto.PedidoRequestDTO;
import com.admin_panel.dto.PedidoDetalleDTO;
import com.admin_panel.entity.Pedido;

import java.util.List;

public interface PedidoService {

    Pedido actualizarEstado(Integer id, String nuevoEstado, String motivoRechazo);

    Pedido guardarPedidoConDetalles(PedidoRequestDTO dto);

    Pedido obtenerPedidoPorId(Integer id);

    PedidoDetalleDTO obtenerDetallePedido(Integer id);

    List<PedidoDetalleDTO> listarPedidosActivos(); // Para ADMIN y CAJERO

    List<PedidoDetalleDTO> listarPedidosEnReparto(); // Para DELIVERY

    List<PedidoDetalleDTO> listarPedidosPorClienteYEstado(Integer idUsuario, String estadoPedido);

    List<PedidoDetalleDTO> listarPedidosActivosPorCliente(Integer idUsuario);
}
