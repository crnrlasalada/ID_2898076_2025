package com.admin_panel.config;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
public class CloudinaryConfig {

    @Bean
    public Cloudinary cloudinary() {
        Map<String, String> config = ObjectUtils.asMap(
                "cloud_name", "dhhkklbrd",
                "api_key", "237752781834115",
                "api_secret", "g7t_tkJlgyG0Dgon0B6sEF2gZA8", //clve secreta de cloud
                "secure", "true"
        );
        return new Cloudinary(config);
    }
}
