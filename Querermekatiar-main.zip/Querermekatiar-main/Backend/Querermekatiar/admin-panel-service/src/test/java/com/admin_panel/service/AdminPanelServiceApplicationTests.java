package com.admin_panel.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminPanelServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
