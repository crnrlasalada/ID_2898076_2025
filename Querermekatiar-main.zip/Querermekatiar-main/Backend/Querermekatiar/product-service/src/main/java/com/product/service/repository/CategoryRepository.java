package com.product.service.repository;

import com.product.service.dto.CategoryDTO;
import com.product.service.entity.Business;
import com.product.service.entity.Category;
import com.product.service.entity.TipoCategoria;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoryRepository extends JpaRepository <Category,Integer> {
    List<CategoryDTO> findByIdBusiness(Business idBusiness);

    List<CategoryDTO> findByIdBusiness_id(Integer idBusinessId);
    
    List<Category> findByTipoCategoria(TipoCategoria tipoCategoria);
    
    List<Category> findByIdBusinessAndTipoCategoria(Business idBusiness, TipoCategoria tipoCategoria);
    
    List<Category> findByIdBusiness_IdAndTipoCategoria(Integer idBusinessId, TipoCategoria tipoCategoria);
}
