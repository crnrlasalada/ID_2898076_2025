package com.product.service.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CategoryCreateDTO {
    private String nombre;
    private String tipo; // "PRODUCTO" o "ADICION"
    private Integer idNegocio;
    private Byte incluido = 0; // 0 = no incluido, 1 = incluido
}
