package com.product.service.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@ToString
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ProductDTO {

    private Integer id;
    private String name;
    private String urlImage;
    private BigDecimal price;
    private String nameCategory;
    private Byte businessActive;
    private String description;
    private Byte active;
    private Integer idCategoriaObligatoria;
    private Integer cantidadAdicionesObligatorias;
    private List<Integer> categoriesIds;

}
