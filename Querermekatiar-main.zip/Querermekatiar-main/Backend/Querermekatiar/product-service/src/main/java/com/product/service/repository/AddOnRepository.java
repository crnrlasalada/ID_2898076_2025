package com.product.service.repository;

import com.product.service.dto.AddOnDTO;
import com.product.service.entity.AddOn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AddOnRepository extends JpaRepository <AddOn, Integer>{
        @Query("""
    SELECT new com.product.service.dto.AddOnDTO(a.id, a.nameAddOn, a.price, c.nameCategory, c.id)
    FROM AddOn a
    JOIN a.idCategory c
    JOIN ProductAddOn pa ON pa.idAddOn = a
    WHERE pa.idProduct.id = :idProduct AND a.active = 1
    """)
    List<AddOnDTO> findAddOnByIdProduct(@Param("idProduct") Integer idProduct);



    // Obtener adicciones por negocio
    @Query("SELECT a FROM AddOn a WHERE a.idCategory.idBusiness.id = :businessId")
    List<AddOn> findByBusinessId(@Param("businessId") Integer businessId);

    // Obtener adicciones activas por negocio
    @Query("SELECT a FROM AddOn a WHERE a.idCategory.idBusiness.id = :businessId AND a.active = :activo")
    List<AddOn> findByBusinessIdAndActivo(@Param("businessId") Integer businessId, @Param("activo") Byte activo);


}
