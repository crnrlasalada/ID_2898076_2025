package com.product.service.service;


import com.product.service.dto.CreateProductDTO;
import com.product.service.dto.ProductDTO;
import com.product.service.dto.ProductUpdateDTO;
import com.product.service.entity.Product;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;


public interface IProductService {

    void CreateProduct(CreateProductDTO productCreateDTO, MultipartFile imagen) throws IOException;

    List<ProductDTO> GetAllProducts(Integer businessId);

    ResponseEntity<Product> UpdateProduct(Integer id, ProductUpdateDTO product);

    void toggleProductStatus (Integer id, boolean active);

    // Método para eliminar un producto de forma permanente de la base de datos
    // PRECAUCIÓN: Esta operación no se puede deshacer
    ResponseEntity<?> deleteProduct(Integer id);

}
