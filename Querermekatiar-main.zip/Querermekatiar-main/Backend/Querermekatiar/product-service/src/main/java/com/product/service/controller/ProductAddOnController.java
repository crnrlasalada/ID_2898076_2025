package com.product.service.controller;

import com.product.service.dto.AddOnDTO;
import com.product.service.service.ProductAddOnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/product")
public class ProductAddOnController {

    @Autowired
    private ProductAddOnService productAddOnService;

    // Obtener adicciones de un producto específico
    @GetMapping("/{productId}/addons")
    public List<AddOnDTO> getProductAddOns(@PathVariable Integer productId) {
        return productAddOnService.getAddOnsByProduct(productId);
    }

    // Asociar una adición a un producto
    @PostMapping("/{productId}/addons/{addOnId}")
    public ResponseEntity<String> associateAddOnToProduct(
            @PathVariable Integer productId, 
            @PathVariable Integer addOnId) {
        try {
            productAddOnService.associateAddOnToProduct(productId, addOnId);
            return ResponseEntity.ok("Adición asociada exitosamente al producto");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Desasociar una adición de un producto
    @DeleteMapping("/{productId}/addons/{addOnId}")
    public ResponseEntity<String> dissociateAddOnFromProduct(
            @PathVariable Integer productId, 
            @PathVariable Integer addOnId) {
        try {
            productAddOnService.dissociateAddOnFromProduct(productId, addOnId);
            return ResponseEntity.ok("Adición desasociada exitosamente del producto");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Asociar múltiples adicciones a un producto
    @PostMapping("/{productId}/addons/bulk")
    public ResponseEntity<String> associateMultipleAddOns(
            @PathVariable Integer productId, 
            @RequestBody Map<String, List<Integer>> payload) {
        try {
            List<Integer> addOnIds = payload.get("addOnIds");
            productAddOnService.associateMultipleAddOnsToProduct(productId, addOnIds);
            return ResponseEntity.ok("Adicciones asociadas exitosamente al producto");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Reemplazar todas las adicciones de un producto
    @PutMapping("/{productId}/addons")
    public ResponseEntity<String> replaceProductAddOns(
            @PathVariable Integer productId, 
            @RequestBody Map<String, List<Integer>> payload) {
        try {
            List<Integer> addOnIds = payload.get("addOnIds");
            productAddOnService.replaceProductAddOns(productId, addOnIds);
            return ResponseEntity.ok("Adicciones del producto actualizadas exitosamente");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Obtener productos que tienen una adición específica
    @GetMapping("/addons/{addOnId}/products")
    public List<Integer> getProductsByAddOn(@PathVariable Integer addOnId) {
        return productAddOnService.getProductsByAddOn(addOnId);
    }
}
