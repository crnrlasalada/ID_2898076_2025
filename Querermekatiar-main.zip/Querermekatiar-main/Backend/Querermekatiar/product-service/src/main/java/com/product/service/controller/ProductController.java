package com.product.service.controller;


import com.product.service.dto.*;
import com.product.service.service.CategoryService;
import com.product.service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@RestController
@RequestMapping("api/product")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private CategoryService categoryService;

    @PostMapping
    public void addProduct(@RequestPart("data") CreateProductDTO productDTO, @RequestParam("imagen") MultipartFile imagen) throws Exception {
        productService.CreateProduct(productDTO, imagen);
    };

    @GetMapping("/quererte")
    public List<ProductDTO> GetAllProducts() {
        return productService.GetAllProducts(2);
    }

    @GetMapping("/amekatiar")
    public List<ProductDTO> getAllProducts() {
        return productService.GetAllProducts(1);
    }

    @GetMapping("/categories/all")
    public ResponseEntity<List<CategoryResponseDTO>> getAllCategories() {
        return categoryService.getAllCategories();
    }

    @GetMapping("/categories/by-type/{tipo}")
    public ResponseEntity<List<CategoryResponseDTO>> getCategoriesByType(@PathVariable String tipo) {
        return categoryService.getCategoriesByType(tipo);
    }

    @GetMapping("/categories/productos")
    public ResponseEntity<List<CategoryResponseDTO>> getProductCategories() {
        return categoryService.getProductCategories();
    }

    @GetMapping("/categories/adiciones")
    public ResponseEntity<List<CategoryResponseDTO>> getAdicionCategories() {
        return categoryService.getAdicionCategories();
    }

    @PostMapping("/categories/create")
    public ResponseEntity<?> createCategory(@RequestBody CategoryCreateDTO dto) {
        return categoryService.createCategory(dto);
    }

    @PutMapping("/{id}")
    public void updateProduct(@PathVariable Integer id, @RequestBody ProductUpdateDTO productUpdate) throws Exception {
        productService.UpdateProduct(id, productUpdate);
    }

    @PatchMapping("/{id}/active")
    public void ActiveOrDisableProduct(@PathVariable Integer id, @RequestParam("active") boolean active) {
        productService.toggleProductStatus(id, active);
    }

    // Endpoint para eliminar un producto de forma permanente
    // PRECAUCIÓN: Esta operación elimina el producto y su imagen de Cloudinary
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Integer id) {
        return productService.deleteProduct(id);
    }

    // ===== ENDPOINTS PARA GESTIÓN DE CATEGORÍAS DE ADICCIONES =====
    
    // Asignar una categoría de adiciones a un producto
    @PostMapping("/{productId}/categories/{categoryId}")
    public ResponseEntity<?> asignarCategoriaAdicion(
            @PathVariable Integer productId, 
            @PathVariable Integer categoryId) {
        return productService.asignarCategoriaAdicion(productId, categoryId);
    }

    // Quitar una categoría de adiciones de un producto
    @DeleteMapping("/{productId}/categories/{categoryId}")
    public ResponseEntity<?> quitarCategoriaAdicion(
            @PathVariable Integer productId, 
            @PathVariable Integer categoryId) {
        return productService.quitarCategoriaAdicion(productId, categoryId);
    }

    // Obtener todas las categorías de adicciones asignadas a un producto
    @GetMapping("/{productId}/categories")
    public ResponseEntity<List<CategoryResponseDTO>> obtenerCategoriasProducto(@PathVariable Integer productId) {
        return productService.obtenerCategoriasProducto(productId);
    }


}
