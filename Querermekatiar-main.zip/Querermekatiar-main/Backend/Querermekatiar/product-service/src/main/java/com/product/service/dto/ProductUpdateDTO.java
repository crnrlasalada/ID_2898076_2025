package com.product.service.dto;

import lombok.*;

import java.math.BigDecimal;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductUpdateDTO {

    private String name;
    private BigDecimal price;
    private String description;

}
