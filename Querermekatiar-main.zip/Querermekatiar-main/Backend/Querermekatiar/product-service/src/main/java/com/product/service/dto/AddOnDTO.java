package com.product.service.dto;

import lombok.*;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class AddOnDTO {

    private Integer id;
    private String name;
    private BigDecimal price;
    private String nameCategory;
    private Integer idCategory; // Agregado para validación de adicciones obligatorias

}
