package com.product.service.dto;

import com.product.service.entity.TipoCategoria;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CategoryResponseDTO {
    private Integer id;
    private String nombre;
    private TipoCategoria tipo;
    private Integer idNegocio;
    private String nombreNegocio;
    private Byte incluido;
}
