package com.product.service.dto;

import com.product.service.entity.TipoCategoria;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CategoriaDTO {

    private Integer id;
    private String nameCategory;
    private TipoCategoria tipoCategoria;

}
