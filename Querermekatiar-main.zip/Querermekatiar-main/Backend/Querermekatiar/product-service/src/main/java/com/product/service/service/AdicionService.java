package com.product.service.service;

import com.product.service.dto.AddOnUpdateDTO;
import com.product.service.dto.AdicionDTO;
import com.product.service.dto.CreateAdicionDTO;
import com.product.service.entity.AddOn;
import com.product.service.entity.Category;
import com.product.service.entity.ProductAddOn;
import com.product.service.repository.AddOnRepository;
import com.product.service.repository.CategoryRepository;
import com.product.service.repository.ProductAddOnOrderRepository;
import com.product.service.repository.ProductAddOnRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Service
public class AdicionService implements IAdicionService {

    @Autowired
    private AddOnRepository addOnRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductAddOnRepository productAddOnRepository;

    @Autowired
    private ProductAddOnOrderRepository productAddOnOrderRepository;

    @Override
    public void createAdicion(CreateAdicionDTO newAdicion) {
        Category category = categoryRepository.findById(newAdicion.getIdCategoria())
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));

        AddOn adicion = new AddOn();
        adicion.setNameAddOn(newAdicion.getNombreAdicion());
        adicion.setPrice(newAdicion.getPrecio());
        adicion.setIdCategory(category);
        adicion.setActive((byte) 1);

        addOnRepository.save(adicion);
    }

    @Override
    public List<AdicionDTO> getAllAdiciones() {
        List<AddOn> adicciones = addOnRepository.findAll();
        return adicciones.stream().map(this::convertToDTO).toList();
    }

    @Override
    public List<AdicionDTO> getAdicionesByBusiness(Integer businessId) {
        List<AddOn> adicciones = addOnRepository.findByBusinessId(businessId);
        return adicciones.stream().map(this::convertToDTO).toList();
    }

    @Override
    public ResponseEntity<AddOn> updateAdicion(Integer id, AddOnUpdateDTO adicionDTO) {
        if (id == null) throw new RuntimeException("Id requerido para actualizar");

        AddOn existing = addOnRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Adición no encontrada"));

        existing.setNameAddOn(adicionDTO.getName());
        existing.setPrice(adicionDTO.getPrice());

        if (adicionDTO.getIdCategory() != null) {
            Category category = categoryRepository.findById(adicionDTO.getIdCategory())
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
            existing.setIdCategory(category);
        }

        AddOn updated = addOnRepository.save(existing);
        return ResponseEntity.ok().build();
    }

    @Override
    public void toggleAdicionStatus(Integer id, boolean active) {
        AddOn existing = addOnRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Adición no encontrada"));

        existing.setActive((byte) (active ? 1 : 0));

        addOnRepository.save(existing);
    }

    public ResponseEntity<?> deleteAdicion(Integer id) {
        try {
            // Verificar que la adición existe
            AddOn adicion = addOnRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Adición no encontrada con ID: " + id));

            // PRIMERA VALIDACIÓN: No permitir eliminar si la adición está en algún pedido
            boolean relacionesPedidos = productAddOnOrderRepository.existsByIdAddOn_Id(id);
            if (relacionesPedidos) {
                return ResponseEntity.status(409)
                        .body(Map.of("error",
                            "No se puede eliminar la adición '" + adicion.getNameAddOn() +
                            "' porque está presente en uno o más pedidos. Debe completar todos los pedidos antes de eliminar la adición."));
            }

            // Verificar que la adición no esté asociada a ningún producto
            List<ProductAddOn> productAddOns = productAddOnRepository.findByIdAddOn_Id(id);
            if (!productAddOns.isEmpty()) {
                productAddOnRepository.deleteAll(productAddOns);
            }

            // Eliminar la adición
            addOnRepository.deleteById(id);

            return ResponseEntity.ok(Map.of(
                "message", "Adición eliminada exitosamente"
            ));

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Error interno del servidor: " + e.getMessage()));
        }
    }

    private AdicionDTO convertToDTO(AddOn adicion) {
        AdicionDTO dto = new AdicionDTO();
        dto.setId(adicion.getId());
        dto.setNombreAdicion(adicion.getNameAddOn());
        dto.setPrecio(adicion.getPrice());
        dto.setActivo(adicion.getActive());
        dto.setIdCategoria(adicion.getIdCategory() != null ? adicion.getIdCategory().getId() : null);
        dto.setNombreCategoria(adicion.getIdCategory() != null ? adicion.getIdCategory().getNameCategory() : null);
        return dto;
    }
}
