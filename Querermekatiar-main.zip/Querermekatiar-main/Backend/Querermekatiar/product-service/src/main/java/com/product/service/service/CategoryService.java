package com.product.service.service;

import com.product.service.dto.CategoryCreateDTO;
import com.product.service.dto.CategoryResponseDTO;
import com.product.service.entity.Business;
import com.product.service.entity.Category;
import com.product.service.entity.TipoCategoria;
import com.product.service.repository.BusinessRepository;
import com.product.service.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio para la gestión de categorías
 * Contiene toda la lógica de negocio, validaciones y manejo de errores
 */
@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepo;
    @Autowired
    private BusinessRepository businessRepo;

    /**
     * Crear una nueva categoría
     * @param categoryCreateDTO Datos de la categoría a crear
     * @return ResponseEntity con la categoría creada o error
     */
    public ResponseEntity<?> createCategory(CategoryCreateDTO categoryCreateDTO) {
        try {
            Business business = businessRepo.findById(categoryCreateDTO.getIdNegocio())
                    .orElse(null);
            if (business == null) {
                return new ResponseEntity<>("Negocio no encontrado", HttpStatus.BAD_REQUEST);
            }

            TipoCategoria tipoCategoria = TipoCategoria.valueOf(categoryCreateDTO.getTipo().toUpperCase());

            Category newCategory = new Category();
            newCategory.setNameCategory(categoryCreateDTO.getNombre().trim());
            newCategory.setIdBusiness(business);
            newCategory.setTipoCategoria(tipoCategoria);
            newCategory.setIncluido(categoryCreateDTO.getIncluido() != null ? categoryCreateDTO.getIncluido() : (byte) 0);

            Category savedCategory = categoryRepo.save(newCategory);
            CategoryResponseDTO response = mapToResponseDTO(savedCategory);
            
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Error al crear categoría: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Obtener todas las categorías
     * @return ResponseEntity con lista de categorías
     */
    public ResponseEntity<List<CategoryResponseDTO>> getAllCategories() {
        try {
            List<Category> categories = categoryRepo.findAll();
            List<CategoryResponseDTO> response = categories.stream()
                    .map(this::mapToResponseDTO)
                    .toList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Obtener categorías por tipo
     * @param tipo Tipo de categoría como String
     * @return ResponseEntity con lista filtrada
     */
    public ResponseEntity<List<CategoryResponseDTO>> getCategoriesByType(String tipo) {
        try {
            TipoCategoria tipoCategoria = TipoCategoria.valueOf(tipo.toUpperCase());
            List<Category> categories = categoryRepo.findByTipoCategoria(tipoCategoria);
            List<CategoryResponseDTO> response = categories.stream()
                    .map(this::mapToResponseDTO)
                    .toList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Obtener categorías por negocio y tipo
     * @param businessId ID del negocio
     * @param tipo Tipo de categoría como String
     * @return ResponseEntity con lista filtrada
     */
    public ResponseEntity<List<CategoryResponseDTO>> getCategoriesByBusinessAndType(Integer businessId, String tipo) {
        try {
            TipoCategoria tipoCategoria = TipoCategoria.valueOf(tipo.toUpperCase());
            List<Category> categories = categoryRepo.findByIdBusiness_IdAndTipoCategoria(businessId, tipoCategoria);
            List<CategoryResponseDTO> response = categories.stream()
                    .map(this::mapToResponseDTO)
                    .toList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * Obtener solo categorías de productos
     * @return ResponseEntity con categorías de productos
     */
    public ResponseEntity<List<CategoryResponseDTO>> getProductCategories() {
        try {
            List<Category> categories = categoryRepo.findByTipoCategoria(TipoCategoria.PRODUCTO);
            List<CategoryResponseDTO> response = categories.stream()
                    .map(this::mapToResponseDTO)
                    .toList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Obtener solo categorías de adiciones
     * @return ResponseEntity con categorías de adiciones
     */
    public ResponseEntity<List<CategoryResponseDTO>> getAdicionCategories() {
        try {
            List<Category> categories = categoryRepo.findByTipoCategoria(TipoCategoria.ADICION);
            List<CategoryResponseDTO> response = categories.stream()
                    .map(this::mapToResponseDTO)
                    .toList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Convierte una entidad Category a CategoryResponseDTO
     * @param category Entidad de categoría
     * @return DTO de respuesta
     */
    private CategoryResponseDTO mapToResponseDTO(Category category) {
        CategoryResponseDTO dto = new CategoryResponseDTO();
        dto.setId(category.getId());
        dto.setNombre(category.getNameCategory());
        dto.setTipo(category.getTipoCategoria());
        dto.setIncluido(category.getIncluido());
        if (category.getIdBusiness() != null) {
            dto.setIdNegocio(category.getIdBusiness().getId());
            dto.setNombreNegocio(category.getIdBusiness().getNameBusiness());
        }
        return dto;
    }
}
