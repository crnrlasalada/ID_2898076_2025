package com.product.service.service;

import com.product.service.entity.*;
import com.product.service.repository.BusinessRepository;
import com.product.service.repository.CategoryRepository;
import com.product.service.repository.ProductRepository;
import com.product.service.repository.RolRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Optional;

@Component
public class DatabaseSeeder {

    @Autowired
    private BusinessRepository businessRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private RolRepository rolRepository;

    @PostConstruct
    public void seedDatabase() {
        // 1. Roles
        if (rolRepository.findById(1).isEmpty()) {
            rolRepository.save(Rol.builder().rol("ADMIN").build());
        }
        if (rolRepository.findById(2).isEmpty()) {
            rolRepository.save(Rol.builder().rol("CLIENT").build());
        }
        if (rolRepository.findById(3).isEmpty()) {
            rolRepository.save(Rol.builder().rol("CASHIER").build());
        }
        if (rolRepository.findById(4).isEmpty()) {
            rolRepository.save(Rol.builder().rol("DELIVERY").build());
        }

        // 2. Negocios
        Business business1 = businessRepository.findById(1).orElseGet(() ->
                businessRepository.save(Business.builder()
                        .nameBusiness("Amekatiar")
                        .active((byte) 1)
                        .build())
        );
        Business business2 = businessRepository.findById(2).orElseGet(() ->
                businessRepository.save(Business.builder()
                        .nameBusiness("quererte")
                        .active((byte) 1)
                        .build())
        );

        // 3. Categoría para productos
        Category category1 = categoryRepository.findById(1).orElseGet(() ->
                categoryRepository.save(Category.builder()
                        .idBusiness(business2)
                        .nameCategory("Personalizados")
                        .incluido((byte) 0)
                        .tipoCategoria(TipoCategoria.PRODUCTO)
                        .build())
        );

        // 4. Producto "Crea tu propio helado"
        Optional<Product> prod1 = productRepository.findById(1);
        if (prod1.isEmpty()) {
            Product product1 = Product.builder()
                    .idCategory(category1)
                    .name("Crea tu propio helado")
                    .urlImage("https://example.com/helado.png")
                    .publicId("custom-icecream")
                    .price(BigDecimal.ZERO)
                    .description("Personaliza tu helado")
                    .active((byte) 1)
                    .build();
            productRepository.save(product1);
        }

        // 5. Producto "Domicilio"
        Optional<Product> prod2 = productRepository.findById(2);
        if (prod2.isEmpty()) {
            Product product2 = Product.builder()
                    .idCategory(category1)
                    .name("Domicilio")
                    .urlImage("https://res.cloudinary.com/dhhkklbrd/image/upload/v1756217736/productos/qhdfxmygzs3cv5vslsyc.png")
                    .publicId("domicilio")
                    .price(new BigDecimal("2000"))
                    .description("Servicio de domicilio")
                    .active((byte) 1)
                    .build();
            productRepository.save(product2);
        }
    }
}