package com.product.service.service;

import com.product.service.dto.CreateProductDTO;
import com.product.service.dto.ProductDTO;
import com.product.service.dto.ProductUpdateDTO;
import com.product.service.dto.CategoryResponseDTO;
import com.product.service.entity.Category;
import com.product.service.entity.Product;
import com.product.service.entity.AddOn;
import com.product.service.entity.ProductAddOn;
import com.product.service.entity.TipoCategoria;
import com.product.service.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


@Service
public class ProductService implements IProductService{

    @Autowired
    private CloudinaryService cloudinaryService;

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ProductAddOnRepository productAddOnRepository;
    @Autowired
    private AddOnRepository addOnRepository;
    @Autowired
    private ProductAddOnOrderRepository  productAddOnOrderRepository;

    @Override
    public void CreateProduct(CreateProductDTO productCreateDTO, MultipartFile imagen) throws IOException {
        Map<String, Object> uploadResult;
        try {
            uploadResult = cloudinaryService.uploadFile(imagen, "productos");
        } catch (Exception e) {
            throw new RuntimeException("Error al subir imagen a Cloudinary");
        }

        String urlImagen = uploadResult.get("secure_url").toString();
        String publicId = uploadResult.get("public_id").toString();

        Product producto = new Product();
        producto.setName(productCreateDTO.getName());
        producto.setPrice(productCreateDTO.getPrice());
        producto.setDescription(productCreateDTO.getDescription());

        Category category = categoryRepository.findById(productCreateDTO.getIdCategory()).orElseThrow(() -> new RuntimeException("Categoría no encontrada"));

        producto.setIdCategory(category);
        producto.setUrlImage(urlImagen);
        producto.setPublicId(publicId);
        producto.setActive((byte) 1);

        // Configurar adiciones obligatorias si se proporcionan
        // Esto permite que un producto tenga categorías de adiciones que el cliente debe seleccionar
        if (productCreateDTO.getIdCategoriaObligatoria() != null) {
            // Buscar la categoría de adición en la base de datos
            Category categoriaAdicion = categoryRepository.findById(productCreateDTO.getIdCategoriaObligatoria())
                    .orElseThrow(() -> new RuntimeException("Categoría de adición obligatoria no encontrada"));
            // Asignar la categoría al producto
            producto.setCategoriaAdicionObligatoria(categoriaAdicion);
        }
        
        // Establecer la cantidad de adiciones obligatorias que el cliente debe seleccionar
        if (productCreateDTO.getCantidadAdicionesObligatorias() != null) {
            producto.setCantidadAdicionesObligatorias(productCreateDTO.getCantidadAdicionesObligatorias());
        }

        productRepository.save(producto);

        // Si tiene categoría de adición obligatoria, crear la relación en producto_adicion
        if (producto.getCategoriaAdicionObligatoria() != null) {
            // Buscar todas las adiciones activas de esa categoría obligatoria
            List<AddOn> adicionesIncluidas = addOnRepository.findAll().stream()
                .filter(a -> a.getIdCategory().getId().equals(producto.getCategoriaAdicionObligatoria().getId()) && a.getActive() == 1)
                .toList();

            // Relacionar todas las adiciones activas de la categoría obligatoria al producto
            for (AddOn adicion : adicionesIncluidas) {
                ProductAddOn rel = new ProductAddOn();
                rel.setIdProduct(producto);
                rel.setIdAddOn(adicion);
                productAddOnRepository.save(rel);
            }
        }
    };

    @Override
    public List<ProductDTO> GetAllProducts(Integer businessId) {
        List<Product> products = productRepository.findByIdCategory_IdBusiness_Id(businessId);

        return products.stream().map(p -> {
            ProductDTO dto = new ProductDTO();
            dto.setId(p.getId());
            dto.setName(p.getName());
            dto.setUrlImage(p.getUrlImage());
            dto.setBusinessActive(p.getIdCategory() != null && p.getIdCategory().getIdBusiness() != null ? p.getIdCategory().getIdBusiness().getActive() : null);
            dto.setDescription(p.getDescription());
            dto.setPrice(BigDecimal.valueOf(p.getPrice() != null ? p.getPrice().doubleValue() : null));
            dto.setNameCategory(p.getIdCategory() != null ? p.getIdCategory().getNameCategory() : null);
            dto.setActive(p.getActive());
            
            // Mapear información de adiciones obligatorias si existen
            // Esto permite al frontend mostrar qué tipo de adiciones debe seleccionar el cliente
            if (p.getCategoriaAdicionObligatoria() != null) {
                dto.setIdCategoriaObligatoria(p.getCategoriaAdicionObligatoria().getId());
            }
            // Establecer la cantidad de adiciones obligatorias que el cliente debe seleccionar
            dto.setCantidadAdicionesObligatorias(p.getCantidadAdicionesObligatorias());
            
            // Obtener las categorías de adicciones asignadas al producto
            // Esto se hace obteniendo las adicciones del producto y luego sus categorías únicas
            List<ProductAddOn> productAddOns = productAddOnRepository.findByIdProduct_Id(p.getId());
            List<Integer> categoriesIds = productAddOns.stream()
                    .map(pa -> pa.getIdAddOn().getIdCategory().getId())
                    .distinct()
                    .toList();
            dto.setCategoriesIds(categoriesIds);
            
            return dto;
        }).toList();

    }



    @Override
    public ResponseEntity<Product> UpdateProduct(Integer id, ProductUpdateDTO product) {
    if (id == null) throw new RuntimeException("Id requerido para actualizar");

    Product existing = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Producto no encontrado"));

    existing.setName(product.getName());
    existing.setPrice(product.getPrice());
    existing.setDescription(product.getDescription());

    Product pUpdate = productRepository.save(existing);

    return ResponseEntity.ok(pUpdate);

    }

    @Override
    public void toggleProductStatus(Integer id, boolean active) {
        Product existing = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        existing.setActive((byte) (active ? 1 : 0));

        productRepository.save(existing);
    }

    @Override
    public ResponseEntity<?> deleteProduct(Integer id) {
        try {
            // Verificar que el producto existe antes de intentar eliminarlo
            Product product = productRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));

            // PRIMERA VALIDACIÓN: No permitir eliminar si el producto está en algún pedido
            boolean relacionesPedidos = productAddOnOrderRepository.existsByIdProduct_Id(product.getId());
            if (relacionesPedidos) {
                return ResponseEntity.status(409)
                    .body(Map.of("error", "No se puede eliminar el producto porque está presente en uno o más pedidos " +
                            "debes de completar todos los pedidos antes de eliminar el producto."));
            }

            // VALIDACIÓN CRÍTICA: No permitir eliminar productos si el negocio está activo
            // Esto previene eliminar productos que podrían estar siendo pedidos por clientes
            if (product.getIdCategory() != null && 
                product.getIdCategory().getIdBusiness() != null && 
                product.getIdCategory().getIdBusiness().getActive() == 1) {
                
                String businessName = product.getIdCategory().getIdBusiness().getNameBusiness();
                return ResponseEntity.status(409)
                    .body(Map.of("error", 
                        "No se puede eliminar el producto. El negocio '" + businessName + 
                        "' está activo. Desactive el negocio primero para poder eliminar productos."));
            }
            
            // Si el producto tiene una imagen en Cloudinary, eliminarla primero
            if (product.getPublicId() != null && !product.getPublicId().isEmpty()) {
                try {
                    cloudinaryService.deleteFile(product.getPublicId());
                } catch (Exception e) {
                    // Log del error pero continúa con la eliminación del producto
                    System.err.println("Error al eliminar imagen de Cloudinary: " + e.getMessage());
                }
            }
            
            // CRÍTICO: Eliminar todas las relaciones del producto en producto_adicion antes de eliminar el producto
            // Esto previene el error de foreign key constraint
            List<ProductAddOn> productAddOns = productAddOnRepository.findByIdProduct_Id(id);
            if (!productAddOns.isEmpty()) {
                productAddOnRepository.deleteAll(productAddOns);
                System.out.println("Eliminadas " + productAddOns.size() + " relaciones de adicciones del producto ID: " + id);
            }
            
            // Eliminar el producto de la base de datos
            productRepository.deleteById(id);
            
            return ResponseEntity.ok(Map.of("message", "Producto eliminado exitosamente"));
            
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Error interno del servidor: " + e.getMessage()));
        }
    }

    // Método para asignar una categoría de adiciones a un producto
    // Esto asigna TODAS las adicciones activas de esa categoría al producto
    public ResponseEntity<?> asignarCategoriaAdicion(Integer productId, Integer categoryId) {
        try {
            // Verificar que el producto existe
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + productId));

            // Verificar que la categoría existe y es de tipo ADICION
            Category category = categoryRepository.findById(categoryId)
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + categoryId));

            if (!TipoCategoria.ADICION.equals(category.getTipoCategoria())) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "La categoría debe ser de tipo ADICION"));
            }

            // Obtener todas las adicciones activas de esta categoría
            List<AddOn> adicionesDeCategoria = addOnRepository.findAll().stream()
                    .filter(addon -> addon.getIdCategory().getId().equals(categoryId) && addon.getActive() == 1)
                    .toList();

            if (adicionesDeCategoria.isEmpty()) {
                // En lugar de retornar error, permitimos la asignación para preparar la categoría
                return ResponseEntity.ok(Map.of(
                    "message", "Categoría preparada para adicciones", 
                    "adicionesAsignadas", 0,
                    "nombreCategoria", category.getNameCategory(),
                    "info", "La categoría se ha preparado pero no tiene adicciones activas actualmente. Puedes agregar adicciones más tarde."
                ));
            }

            // Verificar si ya existen algunas relaciones para evitar duplicados
            List<ProductAddOn> relacionesExistentes = productAddOnRepository.findByIdProduct_Id(productId);
            List<Integer> idsAdicionesExistentes = relacionesExistentes.stream()
                    .map(pa -> pa.getIdAddOn().getId())
                    .toList();

            // Filtrar solo las adicciones que no están ya asignadas
            List<AddOn> adicionesNuevas = adicionesDeCategoria.stream()
                    .filter(addon -> !idsAdicionesExistentes.contains(addon.getId()))
                    .toList();

            if (adicionesNuevas.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Todas las adicciones de esta categoría ya están asignadas al producto"));
            }

            // Crear las nuevas relaciones producto-adicción
            List<ProductAddOn> nuevasRelaciones = adicionesNuevas.stream()
                    .map(addon -> {
                        ProductAddOn productAddOn = new ProductAddOn();
                        productAddOn.setIdProduct(product);
                        productAddOn.setIdAddOn(addon);
                        return productAddOn;
                    })
                    .toList();

            productAddOnRepository.saveAll(nuevasRelaciones);

            return ResponseEntity.ok(Map.of(
                "message", "Categoría asignada exitosamente", 
                "adicionesAsignadas", nuevasRelaciones.size(),
                "nombreCategoria", category.getNameCategory()
            ));

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Error interno del servidor: " + e.getMessage()));
        }
    }

    // Método para quitar una categoría de adiciones de un producto
    // Esto quita TODAS las adicciones de esa categoría del producto
    @Transactional
    public ResponseEntity<?> quitarCategoriaAdicion(Integer productId, Integer categoryId) {
        try {
            // Verificar que el producto existe
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + productId));

            // Verificar que la categoría existe
            Category category = categoryRepository.findById(categoryId)
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada con ID: " + categoryId));

            // Verificar si es la categoría obligatoria (no se puede quitar)
            if (product.getCategoriaAdicionObligatoria() != null && 
                product.getCategoriaAdicionObligatoria().getId().equals(categoryId)) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "No se puede quitar la categoría obligatoria. Debe modificar el producto para cambiar o eliminar la adición obligatoria."));
            }

            // Obtener todas las adicciones de esta categoría que están asignadas al producto
            List<ProductAddOn> relacionesAEliminar = productAddOnRepository.findByIdProduct_Id(productId)
                    .stream()
                    .filter(pa -> pa.getIdAddOn().getIdCategory().getId().equals(categoryId))
                    .toList();

            if (relacionesAEliminar.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "No hay adicciones de esta categoría asignadas al producto"));
            }

            // Eliminar todas las relaciones
            productAddOnRepository.deleteAll(relacionesAEliminar);

            return ResponseEntity.ok(Map.of(
                "message", "Categoría removida exitosamente", 
                "adicionesRemovidas", relacionesAEliminar.size(),
                "nombreCategoria", category.getNameCategory()
            ));

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Error interno del servidor: " + e.getMessage()));
        }
    }

    // Método para obtener las categorías de adicciones asignadas a un producto
    public ResponseEntity<List<CategoryResponseDTO>> obtenerCategoriasProducto(Integer productId) {
        try {
            // Verificar que el producto existe
            productRepository.findById(productId)
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + productId));

            // Obtener todas las relaciones ProductAddOn del producto
            List<ProductAddOn> productAddOns = productAddOnRepository.findByIdProduct_Id(productId);

            // Obtener las categorías únicas de las adicciones
            Set<Integer> categoryIds = productAddOns.stream()
                    .map(pa -> pa.getIdAddOn().getIdCategory().getId())
                    .collect(Collectors.toSet());

            // Obtener la información de las categorías
            List<Category> categories = categoryRepository.findAllById(categoryIds);

            List<CategoryResponseDTO> categoriesDTO = categories.stream()
                    .map(category -> {
                        CategoryResponseDTO dto = new CategoryResponseDTO();
                        dto.setId(category.getId());
                        dto.setNombre(category.getNameCategory());
                        dto.setTipo(category.getTipoCategoria());
                        dto.setIncluido(category.getIncluido());
                        dto.setIdNegocio(category.getIdBusiness() != null ? category.getIdBusiness().getId() : null);
                        dto.setNombreNegocio(category.getIdBusiness() != null ? category.getIdBusiness().getNameBusiness() : null);
                        return dto;
                    })
                    .toList();

            return ResponseEntity.ok(categoriesDTO);

        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

}
