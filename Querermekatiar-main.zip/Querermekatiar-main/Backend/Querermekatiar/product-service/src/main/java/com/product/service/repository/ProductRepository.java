package com.product.service.repository;

import com.product.service.dto.CategoryDTO;
import com.product.service.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ProductRepository extends JpaRepository <Product, Integer>{
    List<Product> findByIdCategory_IdBusiness_IdAndIdNotAndActive(Integer idBusiness, Integer excludedProductId, Byte active);

    // Método para obtener productos por ID de negocio
    List<Product> findByIdCategory_IdBusiness_Id(Integer businessId);

    // Ajustar query para incluir todos los campos del CategoryDTO
    @Query("""
SELECT DISTINCT new com.product.service.dto.CategoryDTO (c.nameCategory, c.idBusiness.nameBusiness, c.tipoCategoria) FROM Category c
            JOIN Product p ON p.idCategory.id = c.id WHERE c.id != 8 and c.idBusiness.id = :businessId
""")
    List<CategoryDTO> findProductCategoriesByBusinessId(@Param("businessId") Integer businessId);
}
