package com.product.service.controller;

import com.product.service.dto.AddOnDTO;
import com.product.service.dto.CategoryDTO;
import com.product.service.dto.ProductDTO;
import com.product.service.service.CatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("api/product/catalogo")
public class CatalogController {
    @Autowired
    CatalogService catalogService;

    @GetMapping("/amekatiar")
    public List<ProductDTO> listCatalogAmekatiar (){
        return catalogService.getCatalog(1);
    }

    @GetMapping("/quererte")
    public List<ProductDTO> listCatalogQuererte (){
        return catalogService.getCatalog(2);
    }

    @GetMapping("/adiciones/{id}")
    public List<AddOnDTO> listAddOn (@PathVariable Integer id){
        return catalogService.addOnsProduct(id);
    }

    @GetMapping("/categorias/amekatiar")
    public List <CategoryDTO> listCategoryAmekatiar (){
        return catalogService.categoryProduct(1);
    }

    @GetMapping("/categorias/quererte")
    public List <CategoryDTO> listCategoryQuererte (){
        return catalogService.categoryProduct(2);
    }


}
