package com.product.service.repository;
import com.product.service.entity.ProductAddOn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductAddOnRepository extends JpaRepository<ProductAddOn, Integer> {
    
    // Buscar relación específica entre producto y adición
    Optional<ProductAddOn> findByIdProduct_IdAndIdAddOn_Id(Integer productId, Integer addOnId);
    
    // Obtener todas las relaciones de un producto
    List<ProductAddOn> findByIdProduct_Id(Integer productId);
    
    // Obtener todas las relaciones de una adición
    List<ProductAddOn> findByIdAddOn_Id(Integer addOnId);
    
    // Verificar si existe una relación
    boolean existsByIdProduct_IdAndIdAddOn_Id(Integer productId, Integer addOnId);
}
