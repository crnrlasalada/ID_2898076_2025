package com.product.service.service;

import com.product.service.dto.AddOnDTO;
import com.product.service.entity.AddOn;
import com.product.service.entity.Product;
import com.product.service.entity.ProductAddOn;
import com.product.service.repository.AddOnRepository;
import com.product.service.repository.ProductAddOnRepository;
import com.product.service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductAddOnService {

    @Autowired
    private ProductAddOnRepository productAddOnRepository;
    
    @Autowired
    private ProductRepository productRepository;
    
    @Autowired
    private AddOnRepository addOnRepository;

    // Obtener todas las adicciones de un producto
    public List<AddOnDTO> getAddOnsByProduct(Integer productId) {
        return addOnRepository.findAddOnByIdProduct(productId);
    }

    // Asociar una adición a un producto
    public void associateAddOnToProduct(Integer productId, Integer addOnId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        
        AddOn addOn = addOnRepository.findById(addOnId)
                .orElseThrow(() -> new RuntimeException("Adición no encontrada"));

        // Verificar si ya existe la relación
        Optional<ProductAddOn> existing = productAddOnRepository
                .findByIdProduct_IdAndIdAddOn_Id(productId, addOnId);
        
        if (existing.isPresent()) {
            throw new RuntimeException("La adición ya está asociada a este producto");
        }

        // Crear nueva relación
        ProductAddOn productAddOn = new ProductAddOn();
        productAddOn.setIdProduct(product);
        productAddOn.setIdAddOn(addOn);
        
        productAddOnRepository.save(productAddOn);
    }

    // Desasociar una adición de un producto
    public void dissociateAddOnFromProduct(Integer productId, Integer addOnId) {
        Optional<ProductAddOn> existing = productAddOnRepository
                .findByIdProduct_IdAndIdAddOn_Id(productId, addOnId);
        
        if (existing.isEmpty()) {
            throw new RuntimeException("La relación no existe");
        }

        productAddOnRepository.delete(existing.get());
    }

    // Obtener todos los productos que tienen una adición específica
    public List<Integer> getProductsByAddOn(Integer addOnId) {
        return productAddOnRepository.findByIdAddOn_Id(addOnId)
                .stream()
                .map(pa -> pa.getIdProduct().getId())
                .toList();
    }

    // Asociar múltiples adicciones a un producto
    public void associateMultipleAddOnsToProduct(Integer productId, List<Integer> addOnIds) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        for (Integer addOnId : addOnIds) {
            AddOn addOn = addOnRepository.findById(addOnId)
                    .orElseThrow(() -> new RuntimeException("Adición con ID " + addOnId + " no encontrada"));

            // Verificar si ya existe la relación
            Optional<ProductAddOn> existing = productAddOnRepository
                    .findByIdProduct_IdAndIdAddOn_Id(productId, addOnId);
            
            if (existing.isEmpty()) {
                ProductAddOn productAddOn = new ProductAddOn();
                productAddOn.setIdProduct(product);
                productAddOn.setIdAddOn(addOn);
                productAddOnRepository.save(productAddOn);
            }
        }
    }

    // Reemplazar todas las adicciones de un producto
    public void replaceProductAddOns(Integer productId, List<Integer> addOnIds) {
        // Eliminar todas las relaciones existentes
        List<ProductAddOn> existingRelations = productAddOnRepository.findByIdProduct_Id(productId);
        productAddOnRepository.deleteAll(existingRelations);

        // Agregar las nuevas relaciones
        if (addOnIds != null && !addOnIds.isEmpty()) {
            associateMultipleAddOnsToProduct(productId, addOnIds);
        }
    }
}
