package com.product.service.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CreateProductDTO {

    private String name;
    private BigDecimal price;
    private String description;
    private Integer idCategory;
    private String urlImage;
    private String publicId;
    private Byte active;
    
    // ID de la categoría que define las adiciones obligatorias para este producto
    // Si no es null, el cliente debe seleccionar adiciones de esta categoría
    private Integer idCategoriaObligatoria;
    
    // Cantidad mínima de adiciones que el cliente debe seleccionar de la categoría obligatoria
    // Ejemplo: 2 significa que debe elegir exactamente 2 adiciones
    private Integer cantidadAdicionesObligatorias;

}