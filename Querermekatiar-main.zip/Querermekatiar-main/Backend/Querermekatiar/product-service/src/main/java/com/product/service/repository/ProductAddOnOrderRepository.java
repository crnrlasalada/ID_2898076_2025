package com.product.service.repository;
import com.product.service.entity.ProductAddOnOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductAddOnOrderRepository extends JpaRepository<ProductAddOnOrder, Integer> {

    boolean existsByIdProduct_Id(Integer idProduct);

    boolean existsByIdAddOn_Id(Integer idAddOnId);

}
