package com.product.service.controller;

import com.product.service.dto.CategoryCreateDTO;
import com.product.service.dto.CategoryResponseDTO;
import com.product.service.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador REST para la gestión de categorías
 * Maneja las peticiones HTTP y delega la lógica de negocio al servicio
 */
@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    /**
     * Crear una nueva categoría
     * @param categoryCreateDTO Datos de la categoría a crear
     * @return Categoría creada
     */
    @PostMapping("/create")
    public ResponseEntity<?> createCategory(@RequestBody CategoryCreateDTO categoryCreateDTO) {
        return categoryService.createCategory(categoryCreateDTO);
    }

    /**
     * Obtener todas las categorías
     * @return Lista de todas las categorías
     */
    @GetMapping("/all")
    public ResponseEntity<List<CategoryResponseDTO>> getAllCategories() {
        return categoryService.getAllCategories();
    }

    /**
     * Obtener categorías por tipo
     * @param tipo Tipo de categoría (PRODUCTO/ADICION)
     * @return Lista de categorías del tipo especificado
     */
    @GetMapping("/by-type/{tipo}")
    public ResponseEntity<List<CategoryResponseDTO>> getCategoriesByType(@PathVariable String tipo) {
        return categoryService.getCategoriesByType(tipo);
    }

    /**
     * Obtener categorías por negocio y tipo
     * @param businessId ID del negocio
     * @param tipo Tipo de categoría
     * @return Lista de categorías filtradas
     */
    @GetMapping("/business/{businessId}/type/{tipo}")
    public ResponseEntity<List<CategoryResponseDTO>> getCategoriesByBusinessAndType(
            @PathVariable Integer businessId, 
            @PathVariable String tipo) {
        return categoryService.getCategoriesByBusinessAndType(businessId, tipo);
    }

    /**
     * Obtener solo categorías de productos
     * @return Lista de categorías de productos
     */
    @GetMapping("/productos")
    public ResponseEntity<List<CategoryResponseDTO>> getProductCategories() {
        return categoryService.getProductCategories();
    }

    /**
     * Obtener solo categorías de adiciones
     * @return Lista de categorías de adiciones
     */
    @GetMapping("/adiciones")
    public ResponseEntity<List<CategoryResponseDTO>> getAdicionCategories() {
        return categoryService.getAdicionCategories();
    }
}
