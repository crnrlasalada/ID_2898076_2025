package com.product.service.dto;

import com.product.service.entity.TipoCategoria;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CategoryDTO {

    private String nameCategory;
    private String nameBusiness;
    private TipoCategoria tipoCategoria;

}
