package com.product.service.entity;


public enum TipoCategoria {
    PRODUCTO,
    ADICION
}
