package com.product.service.controller;

import com.product.service.dto.AddOnUpdateDTO;
import com.product.service.dto.AdicionDTO;
import com.product.service.dto.CreateAdicionDTO;
import com.product.service.entity.AddOn;
import com.product.service.service.AdicionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/product/adicciones")
public class AdicionController {

    @Autowired
    private AdicionService adicionService;

    @PostMapping
    public void createAdicion(@RequestBody CreateAdicionDTO createAdicionDTO) {
        adicionService.createAdicion(createAdicionDTO);
    }

    @GetMapping
    public List<AdicionDTO> getAllAdiciones() {
        return adicionService.getAllAdiciones();
    }

    @GetMapping("/business/{businessId}")
    public List<AdicionDTO> getAdicionesByBusiness(@PathVariable Integer businessId) {
        return adicionService.getAdicionesByBusiness(businessId);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AddOn> updateAdicion(@PathVariable Integer id, @RequestBody AddOnUpdateDTO adicionDTO) {
        return adicionService.updateAdicion(id, adicionDTO);
    }

    @PatchMapping("/{id}/active")
    public void toggleAdicionStatus(@PathVariable Integer id, @RequestParam("active") boolean active) {
        adicionService.toggleAdicionStatus(id, active);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAdicion(@PathVariable Integer id) {
        return adicionService.deleteAdicion(id);
    }

}
