package com.product.service.service;

import com.product.service.dto.AddOnDTO;
import com.product.service.dto.ProductDTO;

import java.util.List;

public interface ICatalogService {
    public List<ProductDTO> getCatalog(Integer idBusiness);
    public List<AddOnDTO> addOnsProduct(Integer idAddOn);
}
