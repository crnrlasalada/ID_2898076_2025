package com.product.service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Table(name = "producto")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_categoria", nullable = false)
    private Category idCategory;

    @Size(max = 100)
    @NotNull
    @Column(name = "nombre_producto", nullable = false, length = 100)
    private String name;

    @Size(max = 255)
    @NotNull
    @Column(name = "url_imagen", nullable = false)
    private String urlImage;

    @Size(max = 255)
    @NotNull
    @Column(name = "public_id", nullable = false)
    private String publicId;

    @NotNull
    @Column(name = "precio", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @NotNull
    @Lob
    @Column(name = "descripcion", nullable = false)
    private String description;

    @Column(name = "activo", nullable = false, columnDefinition = "TINYINT DEFAULT 1")
    private Byte active = 1;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_categoria_obligatoria")
    private Category categoriaAdicionObligatoria;

    // Cantidad de adiciones obligatorias que el cliente debe seleccionar
    // Ejemplo: Si es 2, el cliente debe elegir 2 adiciones de la categoría obligatoria
    @Column(name = "cantidad_adiciones_obligatorias")
    private Integer cantidadAdicionesObligatorias;

}