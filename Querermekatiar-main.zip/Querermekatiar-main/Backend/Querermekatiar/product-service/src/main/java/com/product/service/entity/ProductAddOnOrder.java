package com.product.service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "producto_adicion_pedido")
public class ProductAddOnOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    // 🔄 CAMBIO: Usar Integer en lugar de relación JPA
    @NotNull
    @Column(name = "id_pedido", nullable = false)
    private Integer idOrder;  // Solo el ID, no la entidad completa

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_producto", nullable = false)
    private Product idProduct;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_adicion", nullable = false)
    private AddOn idAddOn;

    @Column(name = "contador_prod")
    private Integer productCounter;

    @Column(name = "cant_adicion")
    private Integer addOnQuantity;

    @Column(name = "cant_producto")
    private Integer productQuantity;
}