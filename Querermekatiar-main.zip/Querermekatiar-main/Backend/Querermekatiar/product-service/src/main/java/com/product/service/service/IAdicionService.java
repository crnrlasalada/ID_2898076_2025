package com.product.service.service;

import com.product.service.dto.AddOnUpdateDTO;
import com.product.service.dto.AdicionDTO;
import com.product.service.dto.CreateAdicionDTO;
import com.product.service.entity.AddOn;
import org.springframework.http.ResponseEntity;

import java.util.List;


public interface IAdicionService {
    
    void createAdicion(CreateAdicionDTO createAdicionDTO);
    
    List<AdicionDTO> getAllAdiciones();
    
    List<AdicionDTO> getAdicionesByBusiness(Integer businessId);
    
    ResponseEntity<AddOn> updateAdicion(Integer id, AddOnUpdateDTO adicionDTO);
    
    void toggleAdicionStatus(Integer id, boolean active);
    

}
