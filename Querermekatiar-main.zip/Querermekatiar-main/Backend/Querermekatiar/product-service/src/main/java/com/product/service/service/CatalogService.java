package com.product.service.service;

import com.product.service.dto.CategoryDTO;
import com.product.service.dto.ProductDTO;
import com.product.service.dto.AddOnDTO;
import com.product.service.repository.*;
import com.product.service.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CatalogService implements ICatalogService{
    @Autowired
    AddOnRepository addOnRepository;
    @Autowired
    BusinessRepository businessRepository;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    CategoryRepository categoryRepository;
    @Autowired
    ProductAddOnRepository productAddOnRepository;


    @Override
    public List<ProductDTO> getCatalog(Integer idBusiness) {
        List<Product> amekatiarProduct = productRepository.findByIdCategory_IdBusiness_IdAndIdNotAndActive(idBusiness, 2,(byte) 1);

        return amekatiarProduct.stream().map(
            p -> new ProductDTO(
                p.getId(),
                p.getName(),
                p.getUrlImage(),
                p.getPrice(),
                p.getIdCategory().getNameCategory(),
                p.getIdCategory().getIdBusiness().getActive(),
                p.getDescription(),
                p.getActive(),
                p.getCategoriaAdicionObligatoria() != null ? p.getCategoriaAdicionObligatoria().getId() : null,
                p.getCantidadAdicionesObligatorias(),
                null
            )
        ).collect(Collectors.toList());

            
    }

    @Override
    public List<AddOnDTO> addOnsProduct(Integer idProduct) {
    List<AddOnDTO> AddOnProduct = addOnRepository.findAddOnByIdProduct(idProduct);
        return AddOnProduct;
    }

    public List<CategoryDTO> categoryProduct (Integer idBussines){
        return productRepository.findProductCategoriesByBusinessId(idBussines);
    }



}
