package com.order.service.repository;

import com.order.service.entity.AddOn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AddOnRepository extends JpaRepository<AddOn,Integer> {

    AddOn findAllById(Integer id);
}
