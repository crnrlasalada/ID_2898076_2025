package com.order.service.service;

import com.order.service.dto.OrderDTO;
import com.order.service.entity.Order;

public interface IOrderService {
    public Order createOrder(OrderDTO dto);
}
