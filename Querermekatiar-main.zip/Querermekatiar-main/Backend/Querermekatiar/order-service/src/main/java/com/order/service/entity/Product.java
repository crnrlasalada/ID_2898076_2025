package com.order.service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "producto")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @Size(max = 100)
    @NotNull
    @Column(name = "nombre_producto", nullable = false, length = 100)
    private String name;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_categoria", nullable = false)
    private Category idCategory;

    @Size(max = 255)
    @NotNull
    @Column(name = "url_imagen", nullable = false)
    private String urlImage;

    @NotNull
    @Column(name = "precio", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @NotNull
    @Lob
    @Column(name = "descripcion", nullable = false)
    private String description;

    @Column(name = "activo", nullable = false, columnDefinition = "TINYINT DEFAULT 1")
    private Byte active = 1;

    @Size(max = 255)
    @NotNull
    @Column(name = "public_id", nullable = false)
    private String publicId;
    
    // Cantidad de adiciones obligatorias que el cliente debe seleccionar para este producto
    // Ejemplo: Si es 2, el cliente debe elegir exactamente 2 adiciones de la categoría obligatoria
    @Column(name = "cantidad_adiciones_obligatorias")
    private Integer cantidadAdicionesObligatorias;

    // Relación con la categoría que define qué tipo de adiciones son obligatorias
    // Permite especificar que el cliente debe seleccionar adiciones de una categoría específica
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_categoria_obligatoria")
    private Category idCategoriaObligatoria;

}