package com.order.service.controller;

import com.order.service.dto.CartProductDTO;
import com.order.service.mongo.document.PedidoDocument;
import com.order.service.service.OrderAgainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order")
public class OrderAgainController {

    @Autowired
    private OrderAgainService orderAgainService;

    // Obtener los 10 últimos pedidos de un usuario
    @GetMapping("/historial-usuario/{idUsuario}")
    public List<PedidoDocument> getLastOrders(@PathVariable("idUsuario") Integer idUsuario) {
        System.out.println("Solicitud hecha");
        List<PedidoDocument> orders = orderAgainService.findLast10OrdersByUsuario(idUsuario);
        System.out.println(orders);
        return orders;
    }

    // Obtener el carrito listo para repetir pedido a partir del id del pedido
    @GetMapping("/volver-a-pedir/{pedidoId}")
    public List<CartProductDTO> getCartForOrderAgain(@PathVariable("pedidoId") Integer pedidoId) {
        return orderAgainService.orderAgain(pedidoId);
    }
}