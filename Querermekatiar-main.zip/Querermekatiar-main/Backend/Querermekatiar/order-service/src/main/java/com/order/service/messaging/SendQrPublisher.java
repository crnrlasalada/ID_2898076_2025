package com.order.service.messaging;

import com.order.service.dto.SendQrDTO;
import com.order.service.entity.User;
import com.order.service.repository.UserRepository;
import com.order.service.config.RabbitMQSendQr;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class SendQrPublisher {

    private final RabbitTemplate rabbitTemplateSendQr;
    private final UserRepository userRepository;

    public SendQrPublisher(@Qualifier("rabbitTemplateSendQr") RabbitTemplate rabbitTemplateSendQr,
                           UserRepository userRepository) {
        this.rabbitTemplateSendQr = rabbitTemplateSendQr;
        this.userRepository = userRepository;
    }

    public void sendQr(Integer userId, String clientName, String orderNumber, BigDecimal total) {
        // Consultar el correo del usuario
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            throw new IllegalArgumentException("Usuario no encontrado para el id: " + userId);
        }
        String email = user.getEmail();

        SendQrDTO dto = new SendQrDTO(clientName, email, orderNumber, total);

        rabbitTemplateSendQr.convertAndSend(
                RabbitMQSendQr.EXCHANGE_NAME,
                RabbitMQSendQr.ROUTING_KEY,
                dto
        );

        System.out.println("Mensaje enviado: " + dto);
    }
}
