package com.order.service.mongo.document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Document(collection = "pedido")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class PedidoDocument {
    @JsonIgnore
    @Id
    private String idMongo;  // ID interno de MongoDB

    private Integer id; // ID original del pedido
    @JsonIgnore
    private Integer idUsuario;
    private String nombres;
    private String apellidos;
    private String telefono;
    private String estadoPedido;
    private String direccion;
    private LocalDateTime fechaHora;
    private String tipoEntrega;
    private String formaPago;
    @JsonIgnore
    private BigDecimal latitud;
    @JsonIgnore
    private BigDecimal longitud;
    private String mensajeCliente;
    private String motivoRechazo;
    private BigDecimal domicilio;
    private BigDecimal subtotal;
    private BigDecimal total;

    private List<ProductoDocument> productos;
}
