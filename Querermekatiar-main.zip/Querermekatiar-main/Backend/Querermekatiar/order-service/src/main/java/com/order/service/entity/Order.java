package com.order.service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "pedido")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NotNull
    @Column(name = "id_usuario", nullable = false)
    private Integer clientId;

    @Size(max = 50)
    @Column(name = "nombres", length = 50)
    private String firstName;

    @Size(max = 150)
    @Column(name = "apellidos", length = 50)
    private String lastName;

    @NotNull
    @ColumnDefault("'Pendiente'")
    @Lob
    @Column(name = "estado_pedido", nullable = false)
    private String status;

    @Size(max = 10)
    @NotNull
    @Column(name = "telefono", nullable = false, length = 10)
    private String phone;

    @Size(max = 10)
    @NotNull
    @Column(name = "documento", nullable = false, length = 10)
    private String idNumber;

    @NotNull
    @Lob
    @Column(name = "tipo_entrega", nullable = false)
    private String deliveryType;

    @Size(max = 150)
    @Column(name = "direccion", length = 150)
    private String address;

    @NotNull
    @Column(name = "fecha_hora", nullable = false)
    private LocalDateTime dateTime;

    @NotNull
    @Lob
    @Column(name = "forma_pago", nullable = false)
    private String paymentMethod;

    @Column(name = "latitud", precision = 10, scale = 8)
    private BigDecimal latitude;

    @Column(name = "longitud", precision = 11, scale = 8)
    private BigDecimal longitude;

    @Lob
    @Column(name = "mensaje_cliente")
    private String customerMessage;

    @Lob
    @Column(name = "motivo_rechazo")
    private String rejectionReason;

    @NotNull
    @Column(name = "domicilio", nullable = false, precision = 10, scale = 2)
    private BigDecimal deliveryFee;

    @NotNull
    @Column(name = "subtotal", nullable = false, precision = 10, scale = 2)
    private BigDecimal subtotal;

    @NotNull
    @Column(name = "total", nullable = false, precision = 10, scale = 2)
    private BigDecimal total;

    @OneToMany(mappedBy = "idOrder", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProductAddOnOrder> productAddOnOrderList = new ArrayList<>();

}