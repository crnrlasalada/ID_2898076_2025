package com.order.service.controller;

import com.order.service.dto.OrderDTO;
import com.order.service.dto.OrderResponseDTO;
import com.order.service.dto.ProductDeliveryDTO;
import com.order.service.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("api/order")
public class OrderServiceController {
 @Autowired
    OrderService orderService;
    @PostMapping
    public ResponseEntity<Void> create(@Valid @RequestBody OrderDTO dto) {
        orderService.createOrder(dto);
        return ResponseEntity.ok().build();
    }
    @GetMapping("/{id}")
    public ResponseEntity<List<OrderResponseDTO>> getClientOrders(@PathVariable("id") Integer id) {
    System.out.println("[OrderServiceController] getClientOrders - id recibido: " + id);
    List<OrderResponseDTO> orders = orderService.getOrdersByClient(id);
    System.out.println("[OrderServiceController] getClientOrders - cantidad de pedidos en respuesta: " + orders.size());
    return ResponseEntity.ok(orders);
    }
    @GetMapping("/domicilio")
    public ProductDeliveryDTO getDelivery(){
        return orderService.getDeliveryPrice();
    }
}
