package com.order.service.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class OrderDTO {
    private String firstName;
    private String lastName;
    private Integer clientId;
    private String phone;
    private String idNumber;
    private String deliveryType;
    private String address;
    private String paymentMethod;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private String customerMessage;
    private String rejectionReason;
    private List<ProductDTO> products;


}
