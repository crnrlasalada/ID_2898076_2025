package com.order.service.service;

import com.order.service.dto.*;
import com.order.service.entity.*;
import com.order.service.messaging.OrderCreateEventPublisher;
import com.order.service.messaging.SendQrPublisher;
import com.order.service.repository.*;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class OrderService implements IOrderService{

    @Autowired
    private SendQrPublisher sendQrPublisher;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductAddOnOrderRepository productAddOnOrderRepository;

    @Autowired
    private AddOnRepository addOnRepository;

    @Autowired
    private ProductAddOnRepository productAddOnRepository;

    @Autowired
    private OrderCreateEventPublisher orderCreateEventPublisher;

    //Este es el metodo que se encarga de crear el pedido en la base de datos
@Override
public Order createOrder(OrderDTO dto) {
    validate(dto);
    Order order = new Order();
    order.setClientId(dto.getClientId());
    order.setFirstName(dto.getFirstName());
    order.setLastName(dto.getLastName());
    order.setDateTime(LocalDateTime.now(ZoneId.of("America/Bogota")));
    order.setIdNumber(dto.getIdNumber());
    order.setPhone(dto.getPhone());
    order.setLatitude(dto.getLatitude());
    order.setLongitude(dto.getLongitude());
    order.setAddress(dto.getAddress());
    order.setDeliveryType(dto.getDeliveryType());
    order.setPaymentMethod(dto.getPaymentMethod());
    order.setStatus("Pendiente");
    order.setRejectionReason(dto.getRejectionReason());
    order.setCustomerMessage(dto.getCustomerMessage());

    int counter = 1;
    BigDecimal subtotal = BigDecimal.ZERO;

    for (ProductDTO p : dto.getProducts()) {
        Product product = productRepository.findAllById(p.getId());
        if (p.getAddOns().isEmpty()) {
            ProductAddOnOrder pap = new ProductAddOnOrder();
            pap.setIdOrder(order);
            pap.setIdProduct(product);
            pap.setProductCounter(counter);
            pap.setProductQuantity(p.getQuantity());
            order.getProductAddOnOrderList().add(pap);
        }
        for (AddOnDTO a : p.getAddOns()) {
            AddOn addOn = addOnRepository.findAllById(a.getId());

            ProductAddOnOrder pap = new ProductAddOnOrder();
            pap.setIdOrder(order);
            pap.setIdProduct(product);
            pap.setIdAddOn(addOn);
            pap.setProductCounter(counter);
            pap.setAddOnQuantity(a.getQuantity());
            pap.setProductQuantity(p.getQuantity());
            BigDecimal priceAddOn = addOn.getPrice()
                .multiply(BigDecimal.valueOf(a.getQuantity()))
                .multiply(BigDecimal.valueOf(p.getQuantity()));
            subtotal = subtotal.add(priceAddOn);
            order.getProductAddOnOrderList().add(pap);
        }
        BigDecimal priceProduct = product.getPrice().multiply(BigDecimal.valueOf(p.getQuantity()));
        subtotal = subtotal.add(priceProduct);
        counter++;
    }

    Product deliveryFee = productRepository.findById(2)
            .orElseThrow(() -> new EntityNotFoundException("Precio del domicilio no encontrado"));

    BigDecimal delivery = deliveryFee.getPrice();
    order.setDeliveryFee(delivery);
    order.setSubtotal(subtotal);
    order.setTotal(subtotal.add(delivery));
    var consultResult = orderRepository.save(order);
    orderCreateEventPublisher.sendEvent(new OrderCreateEventDTO(order.getId()));
    if ("Transferencia".equalsIgnoreCase(order.getPaymentMethod())) {
        sendQrPublisher.sendQr(
                order.getClientId(),
                order.getFirstName() + " " + order.getLastName(),
                String.valueOf(order.getId()),
                order.getTotal()
        );
    }
    return consultResult;
}

    public List<OrderResponseDTO> getOrdersByClient(Integer clientId) { 
        List<String> excluded = List.of("Entregado", "Rechazado", "No_Recibido");
        List<Order> orders = orderRepository.findByClientIdAndStatusNotIn(clientId, excluded);

        return orders.stream()
                .map(this::mapOrderToDTO)
                .collect(Collectors.toList());
    }

    public ProductDeliveryDTO getDeliveryPrice (){
        Product deliveryFee = productRepository.findById(2)
                .orElseThrow(() -> new EntityNotFoundException("Precio del domicilio no encontrado"));
        return new ProductDeliveryDTO(deliveryFee.getPrice());
    }

    private OrderResponseDTO mapOrderToDTO(Order order) {
        List<ProductAddOnOrder> allItems = productAddOnOrderRepository.findAllByIdOrder(order);

        Map<Integer, ProductResponseDTO> groupedProducts = new LinkedHashMap<>();

        for (ProductAddOnOrder item : allItems) {
            int counter = item.getProductCounter();

            groupedProducts.computeIfAbsent(counter, k -> {
                ProductResponseDTO dto = new ProductResponseDTO();
                dto.setId(item.getIdProduct().getId());
                dto.setName(item.getIdProduct().getName());
                dto.setQuantity(item.getProductQuantity());
                dto.setPrice(item.getIdProduct().getPrice());
                dto.setUrlImage(item.getIdProduct().getUrlImage());
                dto.setAddOns(new ArrayList<>());
                return dto;
            });

            if (item.getIdAddOn() != null) {
                AddOnResponseDTO addOnDTO = new AddOnResponseDTO();
                addOnDTO.setId(item.getIdAddOn().getId());
                addOnDTO.setName(item.getIdAddOn().getNameAddOn());
                addOnDTO.setQuantity(item.getAddOnQuantity());
                addOnDTO.setPrice(item.getIdAddOn().getPrice());
                groupedProducts.get(counter).getAddOns().add(addOnDTO);
            }
        }

        OrderResponseDTO dto = new OrderResponseDTO();
        dto.setId(order.getId());
        dto.setFirstName(order.getFirstName());
        dto.setLastName(order.getLastName());
        dto.setIdNumber(order.getIdNumber());
        dto.setPhone(order.getPhone());
        dto.setAddress(order.getAddress());
        dto.setStatus(order.getStatus());
        dto.setLatitude(order.getLatitude());
        dto.setLongitude(order.getLongitude());
        dto.setDateTime(order.getDateTime());
        dto.setPaymentMethod(order.getPaymentMethod());
        dto.setDeliveryType(order.getDeliveryType());
        dto.setCustomerMessage(order.getCustomerMessage());
        dto.setDeliveryFee(order.getDeliveryFee());
        dto.setSubtotal(order.getSubtotal());
        dto.setTotal(order.getTotal());
        dto.setProducts(new ArrayList<>(groupedProducts.values()));

        return dto;
    }




    //Este metodo nos sirve para verificar que los productos y adiciones que se traigan en un pedido
    //estén registrados en la base de datos y sus adiciones sean validas para cada producto
    // ...existing code...
    private void validate(OrderDTO dto) {
        List<Integer> products = dto.getProducts().stream().map(ProductDTO::getId).toList();
        Set<Integer> productSet = new HashSet<>(products);
        List<Product> productsId = productRepository.findAllById(productSet);

        if (productSet.size() != productsId.size()) {
            throw new IllegalArgumentException("Alguno de los productos no existen");
        }

        for (Product product : productsId) {
            // Verifica que el producto esté activo
            if (product.getActive() == null || product.getActive() != 1) {
                throw new IllegalArgumentException("El producto '" + product.getName() + "' no está activo");
            }

            // Verifica que la categoría exista
            Category category = product.getIdCategory();
            if (category == null) {
                throw new IllegalArgumentException("El producto '" + product.getName() + "' no tiene categoría asociada");
            }

            // Verifica que el negocio esté activo
            Business business = category.getIdBusiness();
            if (business == null || business.getActive() == null || business.getActive() != 1) {
                throw new IllegalArgumentException("El negocio asociado al producto '" + product.getName() + "' no está activo");
            }
        }

        for (ProductDTO p : dto.getProducts()) {
            for (AddOnDTO a : p.getAddOns()) {
                Boolean valid = productAddOnRepository.existsByIdAddOn_IdAndIdProduct_Id(a.getId(), p.getId());
                if (!valid) {
                    throw new IllegalArgumentException("La adición con id " + a.getId() + " no es válida al producto con id " + p.getId());
                }
                AddOn addOn = addOnRepository.findAllById(a.getId());
                if (addOn == null || addOn.getActive() == null || addOn.getActive() != 1) {
                    throw new IllegalArgumentException("La adición '" + (addOn != null ? addOn.getNameAddOn() : a.getId()) + "' no está activa");
                }
            }
        }
    }
}
