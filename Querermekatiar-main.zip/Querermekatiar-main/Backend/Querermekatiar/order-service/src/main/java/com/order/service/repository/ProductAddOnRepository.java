package com.order.service.repository;

import com.order.service.entity.AddOn;
import com.order.service.entity.Product;
import com.order.service.entity.ProductAddOn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductAddOnRepository extends JpaRepository<ProductAddOn,Integer> {
    Boolean existsByIdAddOnAndIdProduct(AddOn idAddOn, Product idProduct);

    Boolean existsByIdAddOn_IdAndIdProduct_Id(Integer idAddOn, Integer idProduct);
}
