package com.order.service.mongo.document;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ProductoDocument {
    private Integer id;
    private String nombre;
    @JsonIgnore
    private String urlImagen;
    private Integer cantidad;
    private String descripcion;
    private Long precio;
    private List<AdicionDocument> adiciones;
}
