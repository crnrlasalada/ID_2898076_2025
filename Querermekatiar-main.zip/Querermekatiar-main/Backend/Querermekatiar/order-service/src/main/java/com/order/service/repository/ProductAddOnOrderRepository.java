package com.order.service.repository;

import com.order.service.entity.Order;
import com.order.service.entity.ProductAddOnOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ProductAddOnOrderRepository extends JpaRepository <ProductAddOnOrder, Integer> {
    List<ProductAddOnOrder> findAllByIdOrder(Order idOrder);

}
