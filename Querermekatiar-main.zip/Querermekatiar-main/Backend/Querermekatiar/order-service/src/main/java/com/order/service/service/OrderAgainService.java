package com.order.service.service;


import com.order.service.dto.CartAddOnDTO;
import com.order.service.dto.CartProductDTO;
import com.order.service.entity.AddOn;
import com.order.service.entity.Product;
import com.order.service.mongo.document.AdicionDocument;
import com.order.service.mongo.document.PedidoDocument;
import com.order.service.mongo.document.ProductoDocument;
import com.order.service.mongo.repository.PedidoMongoRepository;
import com.order.service.repository.AddOnRepository;
import com.order.service.repository.ProductAddOnRepository;
import com.order.service.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderAgainService {
    @Autowired
    private PedidoMongoRepository pedidoMongoRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private AddOnRepository addOnRepository;

    @Autowired
    private ProductAddOnRepository productAddOnRepository;



    public List<PedidoDocument> findLast10OrdersByUsuario(Integer idUsuario) {
        return pedidoMongoRepository
                .findByIdUsuarioOrderByFechaHoraDesc(idUsuario, PageRequest.of(0, 10))
                .getContent();
    }

    public List<CartProductDTO> orderAgain(Integer id) {
         PedidoDocument order = pedidoMongoRepository.findById(id)
                .orElse(null);

         return buildCartFromPedido(order);
    }

    public List<CartProductDTO> buildCartFromPedido(PedidoDocument pedido) {

        List<CartProductDTO> cart = new ArrayList<>();

        for (ProductoDocument prodDoc : pedido.getProductos()) {
            // Verifica producto activo
            Product product = productRepository.findAllById(prodDoc.getId());
            if (product == null || product.getActive() == null || product.getActive() != 1) continue;

            // Prepara adiciones válidas
            List<CartAddOnDTO> adicionesValidas = new ArrayList<>();
            if (prodDoc.getAdiciones() != null) {
                for (AdicionDocument addDoc : prodDoc.getAdiciones()) {
                    // Verifica adición activa
                    AddOn addOn = addOnRepository.findAllById(addDoc.getId());
                    if (addOn == null || addOn.getActive() == null || addOn.getActive() != 1) continue;

                    // Verifica relación producto-adición
                    boolean relacionados = productAddOnRepository.existsByIdAddOn_IdAndIdProduct_Id(
                            addDoc.getId(), prodDoc.getId());
                    if (!relacionados) continue;

                    // Arma adición válida
                    CartAddOnDTO adic = new CartAddOnDTO();
                    adic.setId_adicion(addOn.getId());
                    adic.setCantidad(addDoc.getCantidad());
                    adic.setNom_adicion(addOn.getNameAddOn());
                    adic.setPrecio(addOn.getPrice());
                    adicionesValidas.add(adic);
                }
            }

            // Arma producto válido
            CartProductDTO prod = new CartProductDTO();
            prod.setId(product.getId());
            prod.setName(product.getName());
            prod.setUrlImage(product.getUrlImage());
            prod.setPrice(product.getPrice());
            prod.setNameCategory(product.getIdCategory().getNameCategory());
            prod.setBusinessActive(1); // Ajusta según tu lógica de negocio
            prod.setDescription(product.getDescription());
            prod.setAdiciones(adicionesValidas);
            prod.setQuantity(prodDoc.getCantidad());

            cart.add(prod);
        }
        return cart;
    }
}
