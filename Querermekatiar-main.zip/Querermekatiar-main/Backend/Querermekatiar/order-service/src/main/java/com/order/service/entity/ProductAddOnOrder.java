package com.order.service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "producto_adicion_pedido")
public class ProductAddOnOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_pedido", nullable = false)
    private Order idOrder;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_producto", nullable = false)
    private Product idProduct;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_adicion")
    private AddOn idAddOn;

    @NotNull
    @Column(name = "contador_prod", nullable = false)
    private Integer productCounter;

    @Column(name = "cant_adicion")
    private Integer addOnQuantity;

    @NotNull
    @Column(name = "cant_producto", nullable = false)
    private Integer productQuantity;


}