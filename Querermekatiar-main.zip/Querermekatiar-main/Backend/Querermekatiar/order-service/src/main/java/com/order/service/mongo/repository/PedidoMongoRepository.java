package com.order.service.mongo.repository;

import com.order.service.mongo.document.PedidoDocument;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface PedidoMongoRepository extends MongoRepository<PedidoDocument, String> {

    // Listar todos los pedidos por idUsuario (cliente)
    Page<PedidoDocument> findByIdUsuarioOrderByFechaHoraDesc(Integer idUsuario, Pageable pageable);

    // Buscar un pedido específico por id
    Optional<PedidoDocument> findById(Integer id);

}
