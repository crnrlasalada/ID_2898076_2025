package com.order.service.dto;

import lombok.*;

import java.io.Serializable;

@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Setter
public class OrderStatusEventDTO implements Serializable {
    private Integer idOrder;
    private Integer idUser;
    private String status;

}
