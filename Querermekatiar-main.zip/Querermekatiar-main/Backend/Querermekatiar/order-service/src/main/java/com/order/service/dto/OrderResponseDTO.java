package com.order.service.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderResponseDTO {
    private Integer id;
    private String firstName;
    private String lastName;
    private String idNumber;
    private String phone;
    private String address;
    private String status;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private LocalDateTime dateTime;
    private String paymentMethod;
    private String deliveryType;
    private String customerMessage;
    private BigDecimal deliveryFee;
    private BigDecimal subtotal;
    private BigDecimal total;
    private List<ProductResponseDTO> products;
}

