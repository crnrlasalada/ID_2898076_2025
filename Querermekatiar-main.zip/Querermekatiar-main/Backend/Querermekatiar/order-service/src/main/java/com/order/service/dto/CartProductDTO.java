package com.order.service.dto;


import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data
public class CartProductDTO {
    private Integer id;
    private String name;
    private String urlImage;
    private BigDecimal price;
    private String nameCategory;
    private Integer businessActive;
    private String description;
    private List<CartAddOnDTO> adiciones;
    private Integer quantity;
}
