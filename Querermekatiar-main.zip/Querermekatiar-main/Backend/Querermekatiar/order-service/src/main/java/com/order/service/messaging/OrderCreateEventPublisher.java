package com.order.service.messaging;

import com.order.service.config.RabbitMQCreateOrderConfig;
import com.order.service.dto.OrderCreateEventDTO;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@EnableRabbit
public class OrderCreateEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public OrderCreateEventPublisher(@Qualifier("rabbitTemplateCreateOrder") RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendEvent(OrderCreateEventDTO evento) {
        rabbitTemplate.convertAndSend(
                RabbitMQCreateOrderConfig.EXCHANGE_NAME,
                RabbitMQCreateOrderConfig.ROUTING_KEY,
                evento
        );
        System.out.println("Evento de creación de pedido enviado: " + evento);
    }
}