package com.order.service.entity;

/**
 * Enum que define los tipos de categoría disponibles en el sistema
 */
public enum TipoCategoria {
    /**
     * Categoría para productos principales
     */
    PRODUCTO,
    
    /**
     * Categoría para adiciones/complementos
     */
    ADICION
}
