package com.order.service.dto;

import lombok.*;

import java.io.Serializable;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderCreateEventDTO implements Serializable {
    private Integer idOrder;
}