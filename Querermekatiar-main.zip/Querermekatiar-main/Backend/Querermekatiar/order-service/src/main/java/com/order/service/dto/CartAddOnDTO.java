package com.order.service.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class CartAddOnDTO {
    private Integer id_adicion;
    private Integer cantidad;
    private String nom_adicion;
    private BigDecimal precio;
}
