package com.microservice.gateway.security;

import com.microservice.gateway.exception.JwtValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class JwtAuthenticationFilter implements WebFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);
    
    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    // ============= SINCRONIZAR CON SecurityConfig =============
    private static final String[] PUBLIC_PATHS = {
            // Autenticación
            "/api/auth/google",
            "/api/auth/login",
            "/api/auth/signup/user",
            "/api/auth/refresh-token",
            "/api/auth/forgot-password",
            "/api/auth/reset-password",
            "/api/auth/validate-reset-token",
            "/api/auth/verify-email",
            "/api/auth/resend-verification",

            // Catálogo público - AGREGAR ESTAS RUTAS
            "/api/product/catalogo/amekatiar",
            "/api/product/catalogo/quererte", 
            "/api/product/catalogo/adiciones",
            "/api/product/catalogo/categorias/amekatiar",
            "/api/product/catalogo/categorias/quererte",
            "/api/admin-panel/novedades/negocio/**",
            
            // Health checks
            "/actuator/health",
            "/actuator/info"
    };

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getPath().value();
        log.info("[GATEWAY] Petición recibida en ruta: {}", path);

        // Verificar si es una ruta pública
        if (isPublicPath(path)) {
            log.info("[GATEWAY] Ruta pública detectada: {}. No requiere autenticación.", path);
            return chain.filter(exchange);
        }

        String token = null;
        String authHeader = request.getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        log.info("[GATEWAY] Header Authorization recibido: {}", authHeader);

            // Si es la ruta SSE, permite el token por query param
            if (path.startsWith("/api/order/stream") || path.startsWith("/api/stream/delivery") || path.startsWith("/api/stream/orders")) {
                List<String> tokenParams = request.getQueryParams().get("token");
                if (tokenParams != null && !tokenParams.isEmpty()) {
                    token = tokenParams.get(0);
                    log.info("[GATEWAY] Token extraído del query param: {}", token);
                }
            }

        // Si no es SSE o no hay token en query param, usa el header Authorization
        if (token == null) {
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                token = authHeader.substring(7);
                log.info("[GATEWAY] Token extraído del header: {}", token);
            } else {
                log.warn("[GATEWAY] Token JWT no encontrado o mal formado en la ruta protegida: {}", path);
                return handleUnauthorized(exchange, "Token JWT requerido");
            }
        }

        try {
            // Validar token y extraer información
            String username = jwtTokenProvider.getUsernameFromToken(token);
            String email = jwtTokenProvider.getEmailFromToken(token);
            String userId = jwtTokenProvider.getUserIdFromToken(token);
            List<String> roles = jwtTokenProvider.getRolesFromToken(token);

            log.info("[GATEWAY] Token válido. Usuario: {} | Email: {} | UserId: {} | Roles: {}", username, email, userId, roles);

            // Crear authorities de Spring Security
            List<SimpleGrantedAuthority> authorities = roles.stream()
                    .map(role -> new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()))
                    .collect(Collectors.toList());

            // Crear el Authentication object
            UsernamePasswordAuthenticationToken authentication = 
                    new UsernamePasswordAuthenticationToken(username, null, authorities);

            // Agregar información adicional como attributes
            authentication.setDetails(new JwtAuthenticationDetails(userId, email, roles));

            // Agregar headers personalizados para los microservicios
            ServerHttpRequest mutatedRequest = exchange.getRequest().mutate()
                    .header("X-User-Id", userId)
                    .header("X-User-Email", email)
                    .header("X-User-Username", username)
                    .header("X-User-Roles", String.join(",", roles))
                    .build();

            ServerWebExchange mutatedExchange = exchange.mutate().request(mutatedRequest).build();

            log.info("[GATEWAY] Autenticación exitosa. Continuando con la petición protegida.");
            // Continuar con el contexto de seguridad
            return chain.filter(mutatedExchange)
                    .contextWrite(ReactiveSecurityContextHolder.withAuthentication(authentication));

        } catch (JwtValidationException e) {
            log.warn("[GATEWAY] Error validando JWT para ruta {}: {}", path, e.getMessage());
            return handleUnauthorized(exchange, "Token JWT inválido: " + e.getMessage());
        } catch (Exception e) {
            log.error("[GATEWAY] Error inesperado procesando JWT para ruta {}: {}", path, e.getMessage());
            return handleUnauthorized(exchange, "Error interno de autenticación");
        }
    }
    
    /**
     * Verifica si la ruta es pública
     */
    private boolean isPublicPath(String path) {
        for (String publicPath : PUBLIC_PATHS) {
            // Si el patrón termina en /**, verificar prefijo
            if (publicPath.endsWith("/**")) {
                String prefix = publicPath.substring(0, publicPath.length() - 3); // Quitar /**
                if (path.equals(prefix) || path.startsWith(prefix + "/")) {
                    return true;
                }


            }
            // Si el patrón termina en /*, verificar coincidencia de segmento único
            else if (publicPath.endsWith("/*")) {
                String prefix = publicPath.substring(0, publicPath.length() - 2); // Quitar /*
                if (path.startsWith(prefix + "/") && !path.substring(prefix.length() + 1).contains("/")) {
                    return true;
                }
            }
            // Coincidencia exacta
            else if (path.equals(publicPath)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Maneja respuestas no autorizadas
     */
    private Mono<Void> handleUnauthorized(ServerWebExchange exchange, String message) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        response.getHeaders().add("Content-Type", "application/json");
        
        String jsonResponse = String.format(
                "{\"error\":\"Unauthorized\",\"message\":\"%s\",\"timestamp\":\"%s\"}",
                message, 
                java.time.Instant.now().toString()
        );
        
        return response.writeWith(
                Mono.just(response.bufferFactory().wrap(jsonResponse.getBytes()))
        );
    }
    
    /**
     * Clase para detalles adicionales de autenticación
     */
    public static class JwtAuthenticationDetails {
        private final String userId;
        private final String email;
        private final List<String> roles;
        
        public JwtAuthenticationDetails(String userId, String email, List<String> roles) {
            this.userId = userId;
            this.email = email;
            this.roles = roles;
        }
        
        public String getUserId() { return userId; }
        public String getEmail() { return email; }
        public List<String> getRoles() { return roles; }
    }
}
