package com.microservice.gateway.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(JwtValidationException.class)
    public Mono<ResponseEntity<Map<String, Object>>> handleJwtValidationException(
            JwtValidationException ex, ServerWebExchange exchange) {
        
        Map<String, Object> errorResponse = Map.of(
            "error", "Token inválido",
            "message", ex.getMessage(),
            "timestamp", LocalDateTime.now().toString(),
            "path", exchange.getRequest().getPath().value(),
            "status", HttpStatus.UNAUTHORIZED.value()
        );
        
        return Mono.just(ResponseEntity
            .status(HttpStatus.UNAUTHORIZED)
            .contentType(MediaType.APPLICATION_JSON)
            .body(errorResponse));
    }

    @ExceptionHandler(Exception.class)
    public Mono<ResponseEntity<Map<String, Object>>> handleGenericException(
            Exception ex, ServerWebExchange exchange) {
        
        Map<String, Object> errorResponse = Map.of(
            "error", "Error interno del servidor",
            "message", "Ha ocurrido un error inesperado",
            "timestamp", LocalDateTime.now().toString(),
            "path", exchange.getRequest().getPath().value(),
            "status", HttpStatus.INTERNAL_SERVER_ERROR.value()
        );
        
        return Mono.just(ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .contentType(MediaType.APPLICATION_JSON)
            .body(errorResponse));
    }
}
