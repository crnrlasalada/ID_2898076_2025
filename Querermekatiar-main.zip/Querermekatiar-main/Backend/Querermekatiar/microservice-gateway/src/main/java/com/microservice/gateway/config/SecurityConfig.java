package com.microservice.gateway.config;

import com.microservice.gateway.security.JwtAuthenticationFilter;
import com.microservice.gateway.security.JwtAuthEntryPoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsConfigurationSource;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Autowired
    private JwtAuthEntryPoint jwtAuthEntryPoint;

    @Value("${app.security.enabled:true}")
    private boolean securityEnabled;

    @Value("${app.cors.allowed-origins:http://localhost:5173,http://localhost:3000}")
    private String allowedOrigins;

    @Value("${app.cors.allowed-methods:GET,POST,PUT,DELETE,OPTIONS,PATCH}")
    private String allowedMethods;

    @Value("${app.cors.allowed-headers:*}")
    private String allowedHeaders;

    @Value("${app.cors.allow-credentials:true}")
    private boolean allowCredentials;

    // ============= RUTAS PÚBLICAS =============
    private static final String[] PUBLIC_PATHS = {
            // Autenticación
            "/api/auth/google",
            "/api/auth/login",
            "/api/auth/signup/user",
            "/api/auth/refresh-token",
            "/api/auth/forgot-password",
            "/api/auth/reset-password",
            "/api/auth/validate-reset-token",
            "/api/auth/verify-email",
            "/api/auth/resend-verification",

            // Catálogo público
            "/api/product/catalogo/amekatiar",
            "/api/product/catalogo/quererte",
            "/api/product/catalogo/adiciones/*",
            "/api/product/catalogo/categorias/amekatiar",
            "/api/product/catalogo/categorias/quererte",
            "/api/admin-panel/novedades/negocio/**",
            
            // Health checks
            "/actuator/health",
            "/actuator/info"
    };

    // ============= RUTAS ADMIN =============
    private static final String[] ADMIN_PATHS = {
            "/api/auth/signup/special-user",
            "/api/admin/**",

            //Canal sse
            "/api/stream/orders"
    };

    // ============= RUTAS CLIENT =============
    private static final String[] CLIENT_PATHS = {
            "/api/order",
            "/api/order/stream",
    };

    // ============= RUTAS CASHIER =============
    private static final String[] CASHIER_PATHS = {
            //canal sse
            "/api/stream/orders",

    };

    // ============= RUTAS DELIVERY =============
    private static final String[] DELIVERY_PATHS = {
            "/api/delivery/**",
            "/api/routes/**"
    };

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {

        // Si la seguridad está deshabilitada (desarrollo), permitir todo
        if (!securityEnabled) {
            return http
                    .csrf(ServerHttpSecurity.CsrfSpec::disable)
                    .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                    .authorizeExchange(auth -> auth.anyExchange().permitAll())
                    .build();
        }

        // Configuración de seguridad por roles
        return http
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .exceptionHandling(exceptions -> exceptions
                        .authenticationEntryPoint(jwtAuthEntryPoint)
                )
                .authorizeExchange(exchanges -> exchanges
                        // ========== ENDPOINTS PÚBLICOS ========== 
                        .pathMatchers(PUBLIC_PATHS).permitAll()

                        // ========== RUTAS POR ROL (Solo si hay contenido) ========== 
                        .pathMatchers(ADMIN_PATHS).hasRole("ADMIN")
                        .pathMatchers(CLIENT_PATHS).hasRole("CLIENT")
                        .pathMatchers(CASHIER_PATHS).hasRole("CASHIER")
                        .pathMatchers(DELIVERY_PATHS).hasRole("DELIVERY")

                        // ========== RUTAS COMPARTIDAS ========== 
                        // Productos: todos los métodos menos DELETE para ADMIN y CASHIER
                        .pathMatchers("/api/product/**").hasAnyRole("ADMIN", "CASHIER")
                        // Solo ADMIN puede eliminar productos
                        .pathMatchers(org.springframework.http.HttpMethod.DELETE, "/api/product/**").hasRole("ADMIN")

                        .pathMatchers("/api/categories/**").hasAnyRole("ADMIN", "CASHIER")
                

                        // ========== CUALQUIER OTRA RUTA ========== 
                        .anyExchange().authenticated()
                )
                .addFilterBefore(jwtAuthenticationFilter, SecurityWebFiltersOrder.AUTHENTICATION)
                .build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        
        // Configuración de orígenes permitidos
        List<String> origins = Arrays.asList(allowedOrigins.split(","));
        config.setAllowedOrigins(origins);
        
        // Configuración de métodos permitidos
        List<String> methods = Arrays.asList(allowedMethods.split(","));
        config.setAllowedMethods(methods);
        
        // Configuración de headers permitidos
        if ("*".equals(allowedHeaders)) {
            config.addAllowedHeader("*");
        } else {
            List<String> headers = Arrays.asList(allowedHeaders.split(","));
            config.setAllowedHeaders(headers);
        }
        
        // Headers expuestos (para que el frontend pueda leerlos)
        config.setExposedHeaders(Arrays.asList(
                "Authorization",
                "X-User-Id",
                "X-User-Email",
                "X-User-Username",
                "X-User-Roles",
                "X-Total-Count",
                "X-Total-Pages"
        ));
        
        config.setAllowCredentials(allowCredentials);
        config.setMaxAge(3600L); // Cache preflight por 1 hora

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
