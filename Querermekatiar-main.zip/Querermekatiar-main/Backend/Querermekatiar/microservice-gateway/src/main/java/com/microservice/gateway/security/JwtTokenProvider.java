package com.microservice.gateway.security;

import com.microservice.gateway.exception.JwtValidationException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;  

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service  
public class JwtTokenProvider {

    private static final Logger log = LoggerFactory.getLogger(JwtTokenProvider.class);

    @Value("${token.secret-key}")
    private String jwtSecret;

    /**
     * Valida el token JWT y devuelve los claims
     */
    public Claims validateTokenAndGetClaims(String token) {
        if (token == null || token.trim().isEmpty()) {
            throw new JwtValidationException("Token vacío o nulo");
        }

        SecretKey accessKey = Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));

        try {
            Claims claims = Jwts.parser()
                    .verifyWith(accessKey)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            
            log.debug("Token validado exitosamente para usuario: {}", claims.getSubject());
            return claims;

        } catch (io.jsonwebtoken.security.SecurityException e) {
            log.warn("Firma JWT inválida: {}", e.getMessage());
            throw new JwtValidationException("Firma JWT inválida", e);
        } catch (io.jsonwebtoken.ExpiredJwtException e) {
            log.warn("Token expirado: {}", e.getMessage());
            throw new JwtValidationException("Token expirado", e);
        } catch (io.jsonwebtoken.MalformedJwtException e) {
            log.warn("Token mal formado: {}", e.getMessage());
            throw new JwtValidationException("Token mal formado", e);
        } catch (io.jsonwebtoken.UnsupportedJwtException e) {
            log.warn("Token no soportado: {}", e.getMessage());
            throw new JwtValidationException("Token no soportado", e);
        } catch (IllegalArgumentException e) {
            log.warn("Token inválido (argumento ilegal): {}", e.getMessage());
            throw new JwtValidationException("Token vacío o nulo", e);
        } catch (Exception e) {
            log.error("Error inesperado validando token: {}", e.getMessage());
            throw new JwtValidationException("Token inválido", e);
        }
    }

    /**
     * Extrae el username del token
     */
    public String getUsernameFromToken(String token) {
        Claims claims = validateTokenAndGetClaims(token);
        return claims.getSubject();
    }

    /**
     * Extrae los roles del token
     */
    @SuppressWarnings("unchecked")
    public List<String> getRolesFromToken(String token) {
        Claims claims = validateTokenAndGetClaims(token);
        List<String> roles = (List<String>) claims.get("roles");
        
        if (roles == null || roles.isEmpty()) {
            log.warn("Token sin roles para usuario: {}", claims.getSubject());
            return List.of();
        }
        
        return roles;
    }

    /**
     * Extrae el email del token
     */
    public String getEmailFromToken(String token) {
        Claims claims = validateTokenAndGetClaims(token);
        return (String) claims.get("email");
    }

    /**
     * Extrae el ID del usuario del token
     */
    public String getUserIdFromToken(String token) {
        Claims claims = validateTokenAndGetClaims(token);
        return (String) claims.get("userId");
    }

    /**
     * Valida solo el token sin devolver claims (método legacy)
     */
    public void valideteAccessToken(String token) {
        validateTokenAndGetClaims(token);
    }
}
