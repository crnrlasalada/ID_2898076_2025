package com.microservice.gateway.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Map;

@Component
public class JwtAuthEntryPoint implements ServerAuthenticationEntryPoint {
    
    private static final Logger log = LoggerFactory.getLogger(JwtAuthEntryPoint.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    @Override
    public Mono<Void> commence(ServerWebExchange exchange, AuthenticationException ex) {
        log.warn("Intento de acceso no autorizado desde: {} a ruta: {}", 
                getClientIP(exchange), 
                exchange.getRequest().getPath().value());
        
        return exchange.getResponse().writeWith(
                Mono.fromSupplier(() -> {
                    // Configurar respuesta
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    exchange.getResponse().getHeaders().add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
                    
                    // Crear respuesta de error
                    Map<String, Object> errorResponse = Map.of(
                            "error", "Unauthorized",
                            "message", "Acceso denegado. Token JWT requerido o inválido.",
                            "path", exchange.getRequest().getPath().value(),
                            "timestamp", Instant.now().toString(),
                            "status", HttpStatus.UNAUTHORIZED.value()
                    );
                    
                    try {
                        String jsonResponse = objectMapper.writeValueAsString(errorResponse);
                        return exchange.getResponse().bufferFactory().wrap(jsonResponse.getBytes());
                    } catch (JsonProcessingException e) {
                        log.error("Error creando respuesta JSON", e);
                        String fallbackResponse = "{\"error\":\"Unauthorized\",\"message\":\"Acceso denegado\"}";
                        return exchange.getResponse().bufferFactory().wrap(fallbackResponse.getBytes());
                    }
                })
        );
    }
    
    /**
     * Obtiene la IP del cliente
     */
    private String getClientIP(ServerWebExchange exchange) {
        String xForwardedFor = exchange.getRequest().getHeaders().getFirst("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIP = exchange.getRequest().getHeaders().getFirst("X-Real-IP");
        if (xRealIP != null && !xRealIP.isEmpty()) {
            return xRealIP;
        }
        
        return exchange.getRequest().getRemoteAddress() != null 
                ? exchange.getRequest().getRemoteAddress().getAddress().getHostAddress()
                : "unknown";
    }
}