package com.notification.service.service;

import com.notification.service.dto.EmailVerificationRecoverDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.HashMap;
import java.util.Map;

@Service
public class EmailRecoverService implements IEmailRecoverService{
    private final JavaMailSender javaMailSender;
    private final TemplateEngine templateEngine;

    public EmailRecoverService(JavaMailSender javaMailSender, TemplateEngine templateEngine) {
        this.javaMailSender = javaMailSender;
        this.templateEngine = templateEngine;
    }

    @Override
    public void sendRecoverEmail (EmailVerificationRecoverDTO email) throws MessagingException {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(email.getEmail());
            helper.setSubject("Restablece tu contraseña para tu cuenta en Querermekatiar");
            Context context = new Context();
            Map<String, Object> variables = new HashMap<>();
            variables.put("userName", email.getUserName());
            variables.put("verificationLink", email.getLink());
            context.setVariables(variables);
            String contentHTML = templateEngine.process("EmailRecover", context);
            helper.setText(contentHTML, true);
            javaMailSender.send(message);
        } catch (Exception e){
            throw new RuntimeException("Error al enviar el correo de verificación " + e);
        }
    }
}
