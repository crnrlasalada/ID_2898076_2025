package com.notification.service.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class EmailNotificationDTO {
    private String clientName;
    private String email;
    private String status;
    private String orderNumber;
    private String rejectionReason;
}