package com.notification.service.messaging;

import com.notification.service.config.RabbitMQConfigOrderInvoice;
import com.notification.service.dto.OrderDTO;
import com.notification.service.service.GenerateInvoiceService;
import com.notification.service.service.EmailInvoiceService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;

@Component
public class OrderInvoiceListener {

    @Autowired
    private GenerateInvoiceService generateInvoiceService;

    @Autowired
    private EmailInvoiceService emailInvoiceService;

    @RabbitListener(queues = RabbitMQConfigOrderInvoice.QUEUE)
    public void receiveOrderInvoice(OrderDTO order) {
        try {
            byte[] pdfBytes = generateInvoiceService.generateInvoice(order);

            // Envía el correo con el PDF adjunto
            emailInvoiceService.sendInvoiceEmail(
                    order.getCustomerEmail(), // destinatario
                    "Factura de tu pedido #" + order.getOrderId(),
                    order.getCustomerName(),
                    order.getOrderId(),
                    order.getOrderDate(),
                    order.getTotal().toString(),
                    pdfBytes
            );
            System.out.println("Factura enviada por correo a: " + order.getCustomerEmail());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}