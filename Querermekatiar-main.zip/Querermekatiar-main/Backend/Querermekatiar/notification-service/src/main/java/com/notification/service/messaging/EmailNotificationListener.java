package com.notification.service.messaging;

import com.notification.service.dto.EmailNotificationDTO;
import com.notification.service.service.EmailNotificationService;
import jakarta.mail.MessagingException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class EmailNotificationListener {

    private final EmailNotificationService emailNotificationService;

    public EmailNotificationListener(EmailNotificationService emailNotificationService) {
        this.emailNotificationService = emailNotificationService;
    }

    @RabbitListener(queues = "email.notification.queue")
    public void handleEmailNotification(EmailNotificationDTO dto) throws MessagingException {
        emailNotificationService.sendEmailNotification(dto);
        System.out.println("Notificación recibida:");
        System.out.println("Cliente: " + dto.getClientName());
        System.out.println("Estado: " + dto.getStatus());
        System.out.println("Pedido: " + dto.getOrderNumber());
        System.out.println("Motivo rechazo: " + dto.getRejectionReason());
    }
}