package com.notification.service.service;


import com.notification.service.dto.SendQrDTO;
import jakarta.mail.MessagingException;

public interface IEmailQrService {
    public void sendEmailQr (SendQrDTO email) throws MessagingException;
}
