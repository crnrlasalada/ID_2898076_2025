package com.notification.service.messaging;

import com.notification.service.dto.EmailVerificationRecoverDTO;

import com.notification.service.service.IEmailRecoverService;
import jakarta.mail.MessagingException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class EmailRecoverListener {
    private final IEmailRecoverService emailRecoverService;

    public EmailRecoverListener(IEmailRecoverService emailRecoverService) {
        this.emailRecoverService = emailRecoverService;
    }

    @RabbitListener(queues = "email.recover.queue")
    public void handleEmailVerification(EmailVerificationRecoverDTO dto) throws MessagingException {
        emailRecoverService.sendRecoverEmail(dto);
        System.out.println("Mensaje recibido");
    }
}
