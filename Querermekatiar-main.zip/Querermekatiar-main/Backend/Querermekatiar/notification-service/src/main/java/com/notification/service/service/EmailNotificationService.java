package com.notification.service.service;

import com.notification.service.dto.EmailNotificationDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
@RequiredArgsConstructor
public class EmailNotificationService implements IEmailNotificationService{

    private final JavaMailSender mailSender;
    private final TemplateEngine templateEngine;

    @Value("${spring.mail.username}")
    private String from;

    @Override
    public void sendEmailNotification(EmailNotificationDTO dto) throws MessagingException {
        String templateName = getTemplateName(dto.getStatus());
        Context context = new Context();
        context.setVariable("userName", dto.getClientName());
        context.setVariable("orderNumber", dto.getOrderNumber());
        context.setVariable("rejectionReason", dto.getRejectionReason());

        String htmlContent = templateEngine.process(templateName, context);

        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
        helper.setFrom(from);
        helper.setTo(dto.getEmail());
        helper.setSubject(getSubject(dto.getStatus(), dto.getOrderNumber()));
        helper.setText(htmlContent, true);

        mailSender.send(message);
    }

    private String getTemplateName(String status) {
        if (status == null) return "EmailNotificationAcepted";
        return switch (status.trim().toLowerCase()) {
            case "en_proceso" -> "EmailNotificationAcepted";
            case "rechazado" -> "EmailNotificationRejected";
            case "no_recibido" -> "EmailNotificationNoReceived";
            case "reparto" -> "EmailNotificationDistribution";
            case "entregado" -> "EmailNotificationDelivered";
            default -> "EmailNotificationAcepted";
        };
    }

    private String getSubject(String status, String orderNumber) {
        return switch (status.trim().toLowerCase()) {
            case "en_proceso" -> "Tu pedido #" + orderNumber + " ha sido aceptado";
            case "rechazado" -> "Tu pedido #" + orderNumber + " ha sido rechazado";
            case "no_recibido" -> "Tu pedido #" + orderNumber + " no fue recibido";
            case "reparto" -> "Tu pedido #" + orderNumber + " está en reparto";
            case "entregado" -> "Tu pedido #" + orderNumber + " ha sido entregado";
            default -> "Actualización de tu pedido #" + orderNumber;
        };
    }
}