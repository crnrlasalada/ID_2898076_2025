package com.notification.service.dto;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class SendQrDTO {
    private String clientName;
    private String email;
    private String orderNumber;
    private BigDecimal total;
}