package com.notification.service.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class    RabbitMQConfigOrderInvoice {

    public static final String QUEUE = "order.invoice.queue";
    public static final String EXCHANGE = "order.invoice.exchange";
    public static final String ROUTING_KEY = "order.invoice.key";

    @Bean(name = "orderInvoiceQueue")
    public Queue orderInvoiceQueue() {
        return new Queue(QUEUE, true);
    }

    @Bean(name = "orderInvoiceExchange")
    public TopicExchange orderInvoiceExchange() {
        return new TopicExchange(EXCHANGE);
    }

    @Bean
    public Binding orderInvoiceBinding(@Qualifier("orderInvoiceQueue") Queue orderInvoiceQueue,@Qualifier("orderInvoiceExchange") TopicExchange orderInvoiceExchange) {
        return BindingBuilder.bind(orderInvoiceQueue).to(orderInvoiceExchange).with(ROUTING_KEY);
    }
}