package com.notification.service.service;

import com.notification.service.dto.EmailNotificationDTO;
import jakarta.mail.MessagingException;

public interface IEmailNotificationService {
    public void sendEmailNotification(EmailNotificationDTO dto) throws MessagingException;

}
