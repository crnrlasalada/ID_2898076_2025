package com.notification.service.service;


import com.notification.service.dto.SendQrDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.HashMap;
import java.util.Map;
@Service
public class EmailQrService implements IEmailQrService{
    private final JavaMailSender javaMailSender;
    private final TemplateEngine templateEngine;

    public EmailQrService(JavaMailSender javaMailSender, TemplateEngine templateEngine) {
        this.javaMailSender = javaMailSender;
        this.templateEngine = templateEngine;
    }

    @Override
    public void sendEmailQr (SendQrDTO email) throws MessagingException {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(email.getEmail());
            helper.setSubject("QR de pago disponible para tu pedido #" + email.getOrderNumber() );
            Context context = new Context();
            Map<String, Object> variables = new HashMap<>();
            variables.put("clientName", email.getClientName());
            variables.put("orderNumber", email.getOrderNumber());
            variables.put("total", email.getTotal());
            context.setVariables(variables);
            String contentHTML = templateEngine.process("EmailQr", context);
            helper.setText(contentHTML, true);
            helper.addAttachment( "qr.jpg", new ClassPathResource("static/qr.jpg"));
            javaMailSender.send(message);
        } catch (Exception e){
            throw new RuntimeException("Error al enviar el correo con el qr " + e);
        }
    }
}
