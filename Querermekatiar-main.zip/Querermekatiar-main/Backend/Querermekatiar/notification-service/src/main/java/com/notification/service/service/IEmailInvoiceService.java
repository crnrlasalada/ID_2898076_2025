package com.notification.service.service;

import java.time.LocalDate;
import java.util.Date;

public interface IEmailInvoiceService {
    public void sendInvoiceEmail(String to, String subject, String customerName, String orderId, Date orderDate, String total, byte[] pdfBytes) throws Exception;
}
