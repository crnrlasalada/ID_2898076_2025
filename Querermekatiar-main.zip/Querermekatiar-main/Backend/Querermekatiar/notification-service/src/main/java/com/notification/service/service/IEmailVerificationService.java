package com.notification.service.service;

import com.notification.service.dto.EmailVerificationRecoverDTO;
import jakarta.mail.MessagingException;

public interface IEmailVerificationService {
    public void sendVerificationEmail (EmailVerificationRecoverDTO emailVerificationRecoverDTO) throws MessagingException;
}
