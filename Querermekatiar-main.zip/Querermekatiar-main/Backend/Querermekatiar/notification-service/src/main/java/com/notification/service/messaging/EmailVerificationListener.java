package com.notification.service.messaging;

import com.notification.service.dto.EmailVerificationRecoverDTO;
import com.notification.service.service.IEmailVerificationService;
import jakarta.mail.MessagingException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class EmailVerificationListener {

    private final IEmailVerificationService mailVerificationService;

    public EmailVerificationListener(IEmailVerificationService emailVerificationService) {
        this.mailVerificationService = emailVerificationService;
    }

    @RabbitListener(queues = "email.verification.queue")
    public void handleEmailVerification(EmailVerificationRecoverDTO dto) throws MessagingException {
        mailVerificationService.sendVerificationEmail(dto);
        System.out.println("Mensaje recibido" + dto );
    }
}