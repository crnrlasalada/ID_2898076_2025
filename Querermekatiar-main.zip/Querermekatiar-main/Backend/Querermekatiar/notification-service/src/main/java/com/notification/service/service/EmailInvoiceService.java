package com.notification.service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import jakarta.mail.internet.MimeMessage;

import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class EmailInvoiceService implements IEmailInvoiceService{

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine templateEngine;

    @Override
    public void sendInvoiceEmail(String to, String subject, String customerName, String orderId, Date orderDate, String total, byte[] pdfBytes) throws Exception {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        String formattedDate = sdf.format(orderDate);

        // Prepara el contexto para Thymeleaf
        Context context = new Context();
        context.setVariable("customerName", customerName);
        context.setVariable("orderId", orderId);
        context.setVariable("orderDate", formattedDate);
        context.setVariable("total", total);

        // Procesa la plantilla HTML
        String htmlContent = templateEngine.process("EmailInvoice.html", context);

        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(htmlContent, true);

        // Adjunta el PDF
        helper.addAttachment("Factura_" + orderId + ".pdf", new ByteArrayResource(pdfBytes));

        mailSender.send(message);
    }
}