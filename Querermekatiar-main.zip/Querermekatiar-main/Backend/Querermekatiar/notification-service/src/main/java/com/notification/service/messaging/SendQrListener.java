package com.notification.service.messaging;

import com.notification.service.dto.SendQrDTO;
import com.notification.service.service.EmailQrService;
import jakarta.mail.MessagingException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SendQrListener {
    @Autowired
    private EmailQrService emailQrService;

    @RabbitListener(queues = "sendqr.email.queue")
    public void receiveQrEmail(SendQrDTO dto) throws MessagingException {

        emailQrService.sendEmailQr(dto);
        System.out.println("Recibido para enviar QR por correo: " + dto);

    }
}