package com.notification.service.service;

import com.notification.service.dto.OrderDTO;
import net.sf.jasperreports.engine.JRException;

public interface IGenerateInvoiceService {
    public byte[] generateInvoice(OrderDTO order) throws JRException;
}
