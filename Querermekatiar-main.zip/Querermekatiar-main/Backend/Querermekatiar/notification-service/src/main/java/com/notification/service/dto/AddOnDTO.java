package com.notification.service.dto;

import java.math.BigDecimal;
import lombok.Data;

@Data
public class AddOnDTO {
    private String name;
    private int quantity;
    private BigDecimal price;
}