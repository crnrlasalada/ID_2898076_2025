package com.notification.service.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQSendQrConfig {
    public static final String EXCHANGE_NAME = "sendqr.exchange";
    public static final String QUEUE_NAME = "sendqr.email.queue";
    public static final String ROUTING_KEY = "sendqr.email";

    @Bean(name="sendQrExchange")
    public DirectExchange sendQrExchange() {
        return new DirectExchange(EXCHANGE_NAME);
    }

    @Bean(name="sendQrQueue")
    public Queue sendQrQueue() {
        return new Queue(QUEUE_NAME);
    }

    @Bean
    public Binding sendQrBinding(@Qualifier("sendQrQueue") Queue sendQrQueue, @Qualifier("sendQrExchange") DirectExchange sendQrExchange) {
        return BindingBuilder
                .bind(sendQrQueue)
                .to(sendQrExchange)
                .with(ROUTING_KEY);
    }


}