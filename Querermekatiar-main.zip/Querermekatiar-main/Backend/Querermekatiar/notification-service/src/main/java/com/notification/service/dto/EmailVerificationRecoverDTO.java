package com.notification.service.dto;

import lombok.*;
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class EmailVerificationRecoverDTO {
    private String email;
    private String userName;
    private String Link;
}
