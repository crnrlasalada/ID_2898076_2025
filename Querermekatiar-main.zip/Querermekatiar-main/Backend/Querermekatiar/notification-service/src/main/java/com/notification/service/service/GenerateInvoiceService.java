package com.notification.service.service;

import com.notification.service.dto.OrderDTO;
import net.sf.jasperreports.engine.*;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Service
public class GenerateInvoiceService implements IGenerateInvoiceService{

    public byte[] generateInvoice(OrderDTO order) throws JRException {
        Map<String, Object> params = new HashMap<>();
        params.put("customerName", order.getCustomerName());
        params.put("customerDocument", order.getCustomerDocument());
        params.put("customerAddress", order.getCustomerAddress());
        params.put("customerEmail", order.getCustomerEmail());
        params.put("customerPhone", order.getCustomerPhone());
        params.put("orderDate", order.getOrderDate());
        params.put("orderId", order.getOrderId());
        params.put("subTotal", order.getSubTotal());
        params.put("total", order.getTotal());
        params.put("deliveryFee", order.getDeliveryFee());
        params.put("products", order.getProducts());

        String logoPath = getClass().getResource("/images/logotype_both.png").toString();
        if (logoPath == null) throw new RuntimeException("No se encontró logotype_both.png");
        params.put("logotype_both", logoPath);

        String headerPath = getClass().getResource("/images/waves_design.png").toString();
        if (headerPath == null) throw new RuntimeException("No se encontró waves_design.png");
        params.put("headerImage", headerPath);

        InputStream reportStream = getClass().getResourceAsStream("/reports/factura.jrxml");
        JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, new JREmptyDataSource());
        return JasperExportManager.exportReportToPdf(jasperPrint);
    }
}