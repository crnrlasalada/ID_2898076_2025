package com.notification.service.service;

import com.notification.service.dto.EmailVerificationRecoverDTO;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.util.HashMap;
import java.util.Map;

@Service
public class EmailVeriificationService implements IEmailVerificationService {
    private final JavaMailSender javaMailSender;
    private final TemplateEngine templateEngine;

    public EmailVeriificationService(JavaMailSender javaMailSender, TemplateEngine templateEngine) {
        this.javaMailSender = javaMailSender;
        this.templateEngine = templateEngine;
    }

    @Override
    public void sendVerificationEmail (EmailVerificationRecoverDTO email) throws MessagingException {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setTo(email.getEmail());
            helper.setSubject("Verifica tu correo para activar tu cuenta en Heladería Quererte & Restaurante Amekatiar");
            Context context = new Context();
            Map<String, Object> variables = new HashMap<>();
            variables.put("userName", email.getUserName());
            variables.put("verificationLink", email.getLink());
            context.setVariables(variables);
            String contentHTML = templateEngine.process("EmailVerification", context);
            helper.setText(contentHTML, true);
            javaMailSender.send(message);
        } catch (Exception e){
            throw new RuntimeException("Error al enviar el correo de verificación " + e);
        }
    }
}
