package com.notification.service.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfigVerification {

    public static final String QUEUE = "email.verification.queue";
    public static final String EXCHANGE = "email.verification.exchange";
    public static final String ROUTING_KEY = "email.verification.key";

    @Bean(name = "emailVerificationQueue")
    public Queue queueVerification() {
        return new Queue(QUEUE, true);
    }

    @Bean (name = "emailVerificationExchange")
    public TopicExchange exchangeVerification() {
        return new TopicExchange(EXCHANGE);
    }

    @Bean
    public Binding bindingVerification(@Qualifier ("emailVerificationQueue") Queue queue,@Qualifier("emailVerificationExchange") TopicExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(ROUTING_KEY);
    }

}