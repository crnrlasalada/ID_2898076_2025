package com.auth.service.services;

import com.auth.service.dto.ChangePasswordDTO;
import com.auth.service.dto.UsuarioDTO;
import com.auth.service.entity.Usuario;
import com.auth.service.entity.Rol;
import com.auth.service.exceptions.CustomAuthException;
import com.auth.service.repository.UsuarioRepository;
import com.auth.service.repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private com.auth.service.repository.TokensRepository tokensRepository;

    @Autowired
    private com.auth.service.repository.RefreshTokenRepository refreshTokenRepository;
    

    public List<UsuarioDTO> GetAllSpecialUser () {

    List<Usuario> usuarios = usuarioRepository.findByRolNombre(Arrays.asList("CASHIER", "DELIVERY"));

    return usuarios.stream()
        .map(u -> new UsuarioDTO(
            u.getId(),
            u.getNombres(),
            u.getApellidos(),
            u.getCorreo(),
            u.getCedula(),
            u.getTelefono(),
            u.getIdRol() != null ? u.getIdRol().getRol() : null
        ))
        .toList();
    }

    public void changePassword(Integer id, ChangePasswordDTO dto) {
        Usuario usuario = usuarioRepository.findUsuarioById(id);
        if (usuario == null) throw new CustomAuthException("Usuario no encontrado");
        if (dto.getActualPassword() == null || dto.getActualPassword().trim().isEmpty()) {
            throw new CustomAuthException("La contraseña actual no puede estar vacía");
        }
        // Verifica la contraseña actual
        if (!passwordEncoder.matches(dto.getActualPassword(), usuario.getContrasena())) {
            throw new CustomAuthException("La contraseña actual es incorrecta");
        }
        // Valida que la nueva contraseña no esté vacía
        if (dto.getNewPassword() == null || dto.getNewPassword().trim().isEmpty()) {
            throw new CustomAuthException("La nueva contraseña no puede estar vacía");
        }
        usuario.setContrasena(passwordEncoder.encode(dto.getNewPassword()));
        usuarioRepository.save(usuario);
    }

    public UsuarioDTO updateUser(Integer id, UsuarioDTO dto) {
        Usuario user = usuarioRepository.findUsuarioById(id);
        if (user == null) return null;

        user.setNombres(dto.getNombres());
        user.setApellidos(dto.getApellidos());
        user.setTelefono(dto.getTelefono());

        if (dto.getCedula() != null) {
            user.setCedula(dto.getCedula());
        }

        if (dto.getRol() != null) {
            Rol rol = rolRepository.findRolByRol(dto.getRol());
            if (rol != null) user.setIdRol(rol);
        }

        usuarioRepository.save(user);

        return new UsuarioDTO(user.getId(), user.getNombres(), user.getApellidos(), user.getCorreo(), user.getCedula(), user.getTelefono(), user.getIdRol() != null ? user.getIdRol().getRol() : null);
    }

    @Transactional
    public void deleteUser(String correo) {
        Usuario usuario = usuarioRepository.findUsuarioByCorreo(correo);
        if (usuario == null) {
            throw new CustomAuthException("Usuario no encontrado");
        }
        // Eliminar todos los tokens asociados al usuario
        tokensRepository.deleteAllByIdUsuario(usuario.getId());
        // Eliminar todos los refresh tokens asociados al usuario
        refreshTokenRepository.deleteAllByIdUsuario(usuario.getId());
        // Finalmente eliminar el usuario
        usuarioRepository.delete(usuario);
    }

    // Obtener el perfil del usuario autenticado por id
    public UsuarioDTO getProfileById(Integer id) {
        Usuario user = usuarioRepository.findUsuarioById(id);
        if (user == null) return null;
        return new UsuarioDTO(
            user.getId(),
            user.getNombres(),
            user.getApellidos(),
            user.getCorreo(),
            user.getCedula(),
            user.getTelefono(),
            user.getIdRol() != null ? user.getIdRol().getRol() : null
        );
    }

}
