package com.auth.service.repository;

import com.auth.service.entity.RefreshToken;
import com.auth.service.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Integer> {

    Optional<RefreshToken> findByIdUsuarioIdAndActivo(Integer id, byte isActive);

    Optional<Object> findRefreshTokenByToken(String token);

    boolean existsRefreshTokenByIdUsuarioAndActivo(Usuario idUsuario, Byte activo);

    // Eliminar todos los refresh tokens por id_usuario (entero)
    @jakarta.transaction.Transactional
    @org.springframework.data.jpa.repository.Modifying
    @org.springframework.data.jpa.repository.Query("DELETE FROM RefreshToken r WHERE r.idUsuario.id = :idUsuario")
    void deleteAllByIdUsuario(Integer idUsuario);
}
