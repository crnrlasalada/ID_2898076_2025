package com.auth.service.controller;

import com.auth.service.dto.ChangePasswordDTO;
import com.auth.service.dto.EmailDTO;
import com.auth.service.dto.UsuarioDTO;
import com.auth.service.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth/user")
public class UserControler {

    @Autowired
    private UserService userService;


    @GetMapping("/super")
    public List<UsuarioDTO> getAllSuperUsers(){
         return userService.GetAllSpecialUser();
    }


    @GetMapping("/{id}")
    public UsuarioDTO getProfile(@PathVariable Integer id) {
        return userService.getProfileById(id);
    }


    @PostMapping("/{id}/change-password")
    public void changePassword(@PathVariable Integer id, @RequestBody ChangePasswordDTO dto) {
        userService.changePassword(id, dto);
    }

    @PutMapping("/{id}")
    public UsuarioDTO updateUser(@PathVariable Integer id, @RequestBody UsuarioDTO usuario) {
        return userService.updateUser(id, usuario);
    }

    @DeleteMapping
    public void deleteUser(@RequestBody EmailDTO email) {
        userService.deleteUser(email.getEmail());
    }

}
