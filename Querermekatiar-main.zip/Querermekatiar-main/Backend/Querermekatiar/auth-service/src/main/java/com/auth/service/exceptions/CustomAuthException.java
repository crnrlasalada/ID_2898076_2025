package com.auth.service.exceptions;

public class CustomAuthException extends RuntimeException {

    public CustomAuthException(String message) {
        super(message);
    }

}
