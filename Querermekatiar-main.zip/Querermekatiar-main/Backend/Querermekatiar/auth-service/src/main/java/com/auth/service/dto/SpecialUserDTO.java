package com.auth.service.dto;

import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SpecialUserDTO {

    @Email
    private String correo;
    private String nombres ;
    private String apellidos;
    private String rol;
    private String password;
    private String cedula;
    private String telefono;

}
