package com.auth.service.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UsuarioDTO {
    private Integer id;
    private String nombres;
    private String apellidos;
    private String correo;
    private String cedula;
    private String telefono;
    private String rol;
}
