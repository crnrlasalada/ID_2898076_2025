package com.auth.service.services;

import com.auth.service.entity.RefreshToken;
import com.auth.service.entity.Token;
import com.auth.service.entity.Usuario;
import com.auth.service.repository.RefreshTokenRepository;
import com.auth.service.repository.TokensRepository;
import com.auth.service.repository.UsuarioRepository;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Service

public class JwtService implements IJwtService {

    @Autowired
    private RefreshTokenRepository refreshTokenRepo;
    @Autowired
    private UsuarioRepository usuarioRepo;
    @Autowired
    private TokensRepository tokensRepo;

    @Value("${token.secret-key}")
    private String jwtSecret;

    @Getter
    @Value("${token.expiration}")
    private long jwtExpirationInSeconds;

    @Value("${refreshToken.secret-key}")
    private String refreshTokenSecret;

    @Value("${refreshToken.expiration}")
    private Long refreshExpirationInSeconds;

    @Override
    public String generateJwtToken(Usuario usuario) {
    Instant now = Instant.now();
    Instant expiration = now.plus(jwtExpirationInSeconds, ChronoUnit.SECONDS);

    SecretKey key = accessTokenKey();

    // Claims compatibles con el gateway y frontend
    return Jwts.builder()
        .subject(String.valueOf(usuario.getId()))
        .claim("userId", String.valueOf(usuario.getId()))
        .claim("email", usuario.getCorreo())
        .claim("roles", java.util.Collections.singletonList(usuario.getIdRol().getRol()))
        .claim("nombre", usuario.getNombres())
        .claim("apellidos", usuario.getApellidos())
        .claim("authType", usuario.getTipoAutent() != null ? usuario.getTipoAutent().toUpperCase() : "LOCAL")
        .issuedAt(Date.from(now))
        .expiration(Date.from(expiration))
        .signWith(key)
        .compact();
    }

    public String generateRefreshToken(Integer userId) {
        Instant now = Instant.now();
        Instant expiration = now.plus(refreshExpirationInSeconds, ChronoUnit.SECONDS);

        SecretKey key = refreshTokenKey();

        String token = Jwts.builder()
                .subject(String.valueOf(userId))
                .claim("jti", UUID.randomUUID().toString())
                .issuedAt(Date.from(now))
                .expiration(Date.from(expiration))
                .signWith(key)
                .compact();

        // Persistencia (se corrige fechaExpiracion que antes se guardaba = ahora)
        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setIdUsuario(usuarioRepo.findUsuarioById(userId));
        refreshToken.setToken(token);
        refreshToken.setFechaCreacion(now);
        refreshToken.setFechaExpiracion(expiration);
        refreshToken.setActivo((byte) 1);
        refreshTokenRepo.save(refreshToken);

        return token;
    }

    public void saveCookieRefreshToken(String refreshToken, HttpServletResponse response) {
        Cookie cookie = new Cookie("refresh_token", refreshToken);
        cookie.setHttpOnly(true);
        cookie.setSecure(false); // TODO: cambiar a true en producción sobre HTTPS
        cookie.setPath("/");
        cookie.setMaxAge((int) (refreshExpirationInSeconds != null ? refreshExpirationInSeconds : 7 * 24 * 60 * 60));

        response.addCookie(cookie);
    }

    public String generateResetPasswordToken(String email) {
        SecretKey key = refreshTokenKey();
        Instant now = Instant.now();
        Instant expiration = now.plus(1, ChronoUnit.HOURS);

        Usuario user = usuarioRepo.findUsuarioByCorreo(email);
        String subject = (user != null) ? email : "invalid";

        String token = Jwts.builder()
                .subject(subject)
                .id(UUID.randomUUID().toString())
                .issuedAt(Date.from(now))
                .expiration(Date.from(expiration))
                .signWith(key)
                .compact();

        return "http://localhost:5173/reset-password?token=" + token;
    }

    public String generateVerificationEmailToken(String email) {
        SecretKey key = refreshTokenKey();
        Instant now = Instant.now();
        Instant expiration = now.plus(1, ChronoUnit.HOURS);

        return Jwts.builder()
                .subject(email)
                .id(UUID.randomUUID().toString())
                .issuedAt(Date.from(now))
                .expiration(Date.from(expiration))
                .signWith(key)
                .compact();

    };

    private SecretKey accessTokenKey() {
        return Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
    };

    private SecretKey refreshTokenKey() {
        return Keys.hmacShaKeyFor(refreshTokenSecret.getBytes(StandardCharsets.UTF_8));
    };

    public String refreshAccessToken(String refreshToken) {

        if (refreshToken == null || refreshToken.isBlank()) {
            throw new IllegalArgumentException("Refresh token vacío");
        }

        SecretKey key = refreshTokenKey();

        try {
            var claimsJws = Jwts.parser()
                    .verifyWith(key)
                    .build()
                    .parseSignedClaims(refreshToken);

            var claims = claimsJws.getPayload();

            String userIdStr = claims.getSubject();

            if (userIdStr == null) {
                throw new RuntimeException("Refresh token inválido (sin subject)");
            }

            Integer userId = Integer.valueOf(userIdStr);

            // Verificar que exista en BD y esté activo
            Optional<Object> storedOpt = refreshTokenRepo.findRefreshTokenByToken((refreshToken));

            RefreshToken stored = (RefreshToken) storedOpt.orElseThrow(() -> new RuntimeException("Refresh token no encontrado"));

                if (stored.getActivo() == null || stored.getActivo() == 0) {
                    throw new RuntimeException("Refresh token inactivo");
                }


                if (stored.getFechaExpiracion().isBefore(Instant.now())) {
                    stored.setActivo((byte) 0);
                    refreshTokenRepo.save(stored);
                    throw new RuntimeException("Refresh token expirado");
                }

            Usuario usuario = usuarioRepo.findUsuarioById(userId);

            if (usuario == null) {
                throw new RuntimeException("Usuario no encontrado");
            }

            return generateJwtToken(usuario);

        } catch (io.jsonwebtoken.ExpiredJwtException e) {
            throw new RuntimeException("Refresh token expirado", e);
        } catch (io.jsonwebtoken.JwtException e) {
            throw new RuntimeException("Refresh token inválido", e);
        }
    }

    // Método para validar token de recuperación de contraseña
    public boolean validateResetPasswordToken(String token) {
        try {
            // Buscar el token en la base de datos
            Optional<Token> tokenEntity = tokensRepo.findByTokenAndActivoAndTipoToken(token, (byte) 1, "RECUPERACION");
            
            if (!tokenEntity.isPresent()) {
                return false;
            }
            
            Token dbToken = tokenEntity.get();
            
            // Verificar si no ha expirado
            if (dbToken.getFechaExpiracion().isBefore(Instant.now())) {
                // Desactivar el token expirado
                dbToken.setActivo((byte) 0);
                tokensRepo.save(dbToken);
                return false;
            }
            
            return true;
            
        } catch (Exception e) {
            return false;
        }
    }

    // Método para obtener el usuario del token de recuperación
    public Usuario getUserFromResetToken(String token) {
        Optional<Token> tokenEntity = tokensRepo.findByTokenAndActivoAndTipoToken(token, (byte) 1, "RECUPERACION");
        
        if (tokenEntity.isPresent()) {
            return tokenEntity.get().getIdUsuario();
        }
        
        return null;
    }


    public boolean validateEmailVerificationToken(String token) {
        try {

            Optional<Token> tokenEntity = tokensRepo.findByTokenAndActivoAndTipoToken(token, (byte) 1, "VERIFICACION");
            
            if (!tokenEntity.isPresent()) {
                return false;
            }
            
            Token dbToken = tokenEntity.get();

            if (dbToken.getFechaExpiracion().isBefore(Instant.now())) {
                dbToken.setActivo((byte) 0);
                tokensRepo.save(dbToken);
                return false;
            }
            
            return true;
            
        } catch (Exception e) {
            return false;
        }
    }

    // Método para obtener el usuario del token de verificación
    public Usuario getUserFromVerificationToken(String token) {
        Optional<Token> tokenEntity = tokensRepo.findByTokenAndActivoAndTipoToken(token, (byte) 1, "VERIFICACION");
        
        if (tokenEntity.isPresent()) {
            return tokenEntity.get().getIdUsuario();
        }
        
        return null;
    }

    // Método para invalidar token de verificación después de su uso
    public void invalidateVerificationToken(String token) {
        Optional<Token> tokenEntity = tokensRepo.findByTokenAndActivoAndTipoToken(token, (byte) 1, "VERIFICACION");
        
        if (tokenEntity.isPresent()) {
            Token dbToken = tokenEntity.get();
            dbToken.setActivo((byte) 0);
            tokensRepo.save(dbToken);
        }
    }

    // Método para invalidar un token después de su uso
    public void invalidateToken(String token) {
        Optional<Token> tokenEntity = tokensRepo.findByTokenAndActivoAndTipoToken(token, (byte) 1, "RECUPERACION");
        
        if (tokenEntity.isPresent()) {
            Token dbToken = tokenEntity.get();
            dbToken.setActivo((byte) 0);
            tokensRepo.save(dbToken);
        }
    }
};
