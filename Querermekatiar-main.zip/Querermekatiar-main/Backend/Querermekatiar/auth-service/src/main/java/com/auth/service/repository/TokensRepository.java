package com.auth.service.repository;

import com.auth.service.entity.Token;
import com.auth.service.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface TokensRepository extends JpaRepository<Token, Integer> {

    Optional<Token> findByTokenAndActivoAndTipoToken(String token, Byte activo, String tipoToken);
    
    @Query("SELECT t FROM Token t WHERE t.idUsuario = :usuario AND t.tipoToken = :tipoToken AND t.activo = 1")
    Optional<Token> findActiveTokenByUserAndType(@Param("usuario") Usuario usuario, @Param("tipoToken") String tipoToken);

    // Eliminar todos los tokens por id_usuario (entero)
    @jakarta.transaction.Transactional
    @org.springframework.data.jpa.repository.Modifying
    @org.springframework.data.jpa.repository.Query("DELETE FROM Token t WHERE t.idUsuario.id = :idUsuario")
    void deleteAllByIdUsuario(Integer idUsuario);
}
