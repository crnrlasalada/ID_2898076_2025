package com.auth.service.dto;

import jakarta.validation.constraints.Email;
import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class EmailVerificationRecoverDTO {
    private String email;
    private String userName;
    private String Link;
}
