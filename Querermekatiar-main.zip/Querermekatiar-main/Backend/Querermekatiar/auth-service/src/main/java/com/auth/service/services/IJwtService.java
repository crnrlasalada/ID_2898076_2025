package com.auth.service.services;

import com.auth.service.entity.Usuario;

public interface IJwtService {

    String generateJwtToken(Usuario usuario);

}
