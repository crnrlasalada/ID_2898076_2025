package com.auth.service.repository;

import com.auth.service.entity.Rol;
import com.auth.service.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario,Integer> {
    List<Usuario> findUsuarioByIdRol(Rol idRol);
    Usuario findUsuarioById(Integer id);
    void deleteUsuarioById(Integer id);
    boolean existsUsuarioByCorreo(String correo);
    Usuario findUsuarioByCorreo(String correo);

    @Query("SELECT u FROM Usuario u WHERE u.idRol.rol IN (:roles)")
    List<Usuario> findByRolNombre(@Param("roles") List<String> roles);;

}
