package com.auth.service.controller;

import com.auth.service.exceptions.CustomAuthException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;


import com.auth.service.dto.*;
import com.auth.service.entity.Usuario;
import com.auth.service.services.AuthService;
import com.auth.service.services.JwtService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService auth;
    @Autowired
    private JwtService jwt;


    @PostMapping("/google")
    public TokenDTO logionOrRegisterGoogle(@RequestBody TokenDTO token, HttpServletResponse response) throws Exception {
        TokenPairDTO tokens = auth.loginOrRegisterWithGoogle(token);

        jwt.saveCookieRefreshToken(tokens.getRefreshToken(), response);

        return new TokenDTO(tokens.getAccesToken());
    };

    @PostMapping("/login")
    public TokenDTO login(@RequestBody UserDTO user, HttpServletResponse response) {

        TokenPairDTO tokens = auth.LoginUser(user);

        jwt.saveCookieRefreshToken(tokens.getRefreshToken(), response);

        return new TokenDTO(tokens.getAccesToken());

    };

    @PostMapping("/signup/user")
    public void signup(@RequestBody UserDTO user) {
            auth.signupUser(user);
    };

    @PostMapping("/signup/special-user")
    public void signupSpecial(@RequestBody SpecialUserDTO user) {
        auth.createSpecialUser(user);
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<?> refreshToken(@CookieValue(value = "refresh_token") String refreshToken) {
        try {

            String newAccessToken = jwt.refreshAccessToken(refreshToken);
            return ResponseEntity.ok(new TokenDTO(newAccessToken));
        } catch (Exception e) {
            // Retornar el mensaje de error en el cuerpo
            return ResponseEntity.badRequest().body(new ErrorResponse(e.getMessage()));
        }
    }

    // Endpoint para solicitar recuperación de contraseña
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody EmailDTO emailDTO) {
        try {
            auth.sendPasswordResetToken(emailDTO.getEmail());
            return ResponseEntity.ok("Si el correo existe, se ha enviado un token de recuperación");
        } catch (Exception e) {
            return ResponseEntity.ok("Si el correo existe, se ha enviado un token de recuperación");
        }
    }

    // Endpoint para restablecer contraseña con token
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordDTO resetPasswordDTO) {
        try {
            auth.resetPassword(resetPasswordDTO);
            return ResponseEntity.ok("Contraseña restablecida exitosamente");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    // Endpoint para validar token de verificación
    @PostMapping("/validate-reset-token")
    public ResponseEntity<String> validateResetToken(@RequestBody TokenDTO tokenDTO) {
        try {
            boolean isValid = jwt.validateResetPasswordToken(tokenDTO.getToken());
            if (isValid) {
                return ResponseEntity.ok("Token válido");
            } else {
                return ResponseEntity.badRequest().body("Token inválido o expirado");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error validando token: " + e.getMessage());
        }
    }

    // Endpoint para verificar email con token
    @PostMapping("/verify-email")
    public ResponseEntity<String> verifyEmail(@RequestBody TokenDTO tokenDTO) {
        try {
            boolean isValid = jwt.validateEmailVerificationToken(tokenDTO.getToken());
            if (isValid) {
                // Obtener usuario del token
                Usuario usuario = jwt.getUserFromVerificationToken(tokenDTO.getToken());
                if (usuario != null) {
                    // Marcar usuario como verificado
                    usuario.setVerificado((byte) 1);
                    auth.updateUser(usuario);
                    
                    // Invalidar el token
                    jwt.invalidateVerificationToken(tokenDTO.getToken());
                    
                    return ResponseEntity.ok("Email verificado exitosamente");
                } else {
                    return ResponseEntity.badRequest().body("Usuario no encontrado");
                }
            } else {
                return ResponseEntity.badRequest().body("Token inválido o expirado");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error verificando email: " + e.getMessage());
        }
    }

    // Endpoint para reenviar correo de verificación
    @PostMapping("/resend-verification")
    public ResponseEntity<String> resendVerification(@RequestBody EmailDTO emailDTO) {
        try {
            auth.resendVerificationEmail(emailDTO.getEmail());
            return ResponseEntity.ok("Correo de verificación reenviado");
        } catch (Exception e) {
            return ResponseEntity.ok("Si el correo existe y no está verificado, se ha enviado un nuevo enlace");
        }
    }


    // Manejo global de errores de autenticación personalizados
    @ExceptionHandler(CustomAuthException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handleCustomAuthException(CustomAuthException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ErrorResponse(ex.getMessage()));
    }

    // DTO para respuesta de error
    static class ErrorResponse {
        public String message;
        public ErrorResponse(String message) {
            this.message = message;
        }
    }
}
