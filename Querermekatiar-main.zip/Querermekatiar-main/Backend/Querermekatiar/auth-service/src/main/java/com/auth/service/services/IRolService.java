package com.auth.service.services;

import com.auth.service.entity.Rol;

public interface IRolService {

    Rol findRolByID(Integer id);



}
