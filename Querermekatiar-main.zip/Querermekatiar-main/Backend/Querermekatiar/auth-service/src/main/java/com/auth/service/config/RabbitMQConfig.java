package com.auth.service.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    
    // ============= EMAIL VERIFICATION =============
    public static final String EMAIL_VERIFICATION_QUEUE = "email.verification.queue";
    public static final String EMAIL_VERIFICATION_EXCHANGE = "email.verification.exchange";
    public static final String EMAIL_VERIFICATION_ROUTING_KEY = "email.verification.key";
    
    // ============= EMAIL RECOVERY =============
    public static final String EMAIL_RECOVER_QUEUE = "email.recover.queue";
    public static final String EMAIL_RECOVER_EXCHANGE = "email.recover.exchange";
    public static final String EMAIL_RECOVER_ROUTING_KEY = "email.recover.key";

    // ============= BEANS PARA VERIFICATION =============
    @Bean
    public Queue emailVerificationQueue() {
        return new Queue(EMAIL_VERIFICATION_QUEUE, true);
    }

    @Bean
    public TopicExchange emailVerificationExchange() {
        return new TopicExchange(EMAIL_VERIFICATION_EXCHANGE);
    }

    @Bean
    public Binding emailVerificationBinding() {
        return BindingBuilder
                .bind(emailVerificationQueue())
                .to(emailVerificationExchange())
                .with(EMAIL_VERIFICATION_ROUTING_KEY);
    }

    // ============= BEANS PARA RECOVERY =============
    @Bean
    public Queue emailRecoverQueue() {
        return new Queue(EMAIL_RECOVER_QUEUE, true);
    }

    @Bean
    public TopicExchange emailRecoverExchange() {
        return new TopicExchange(EMAIL_RECOVER_EXCHANGE);
    }

    @Bean
    public Binding emailRecoverBinding() {
        return BindingBuilder
                .bind(emailRecoverQueue())
                .to(emailRecoverExchange())
                .with(EMAIL_RECOVER_ROUTING_KEY);
    }

    // ============= CONVERTER Y TEMPLATE =============
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter());
        return template;
    }
}
