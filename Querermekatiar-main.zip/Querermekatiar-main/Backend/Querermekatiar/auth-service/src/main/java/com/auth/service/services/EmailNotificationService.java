package com.auth.service.services;

import com.auth.service.config.RabbitMQConfig;
import com.auth.service.dto.EmailVerificationRecoverDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailNotificationService {

    private final RabbitTemplate rabbitTemplate;

    @Value("${app.frontend.url:http://localhost:3000}")
    private String frontendUrl;


    public void SendVerificationEmail(EmailVerificationRecoverDTO emailData) {
        try {
            rabbitTemplate.convertAndSend(
                    RabbitMQConfig.EMAIL_VERIFICATION_EXCHANGE,
                    RabbitMQConfig.EMAIL_VERIFICATION_ROUTING_KEY,
                    emailData
            );
            
        } catch (Exception e) {
            log.error("Error enviando email de verificación para {}: {}", 
                    emailData.getEmail(), e.getMessage(), e);
        }
    }


    public void SendRecoverEmail(EmailVerificationRecoverDTO emailData) {
        try {
            rabbitTemplate.convertAndSend(
                RabbitMQConfig.EMAIL_RECOVER_EXCHANGE,
                RabbitMQConfig.EMAIL_RECOVER_ROUTING_KEY,
                emailData
            );
        
        } catch (Exception e) {
            log.error("Error enviando email de recuperación para {}: {}", 
                emailData.getEmail(), e.getMessage(), e);
        }
    }
}
