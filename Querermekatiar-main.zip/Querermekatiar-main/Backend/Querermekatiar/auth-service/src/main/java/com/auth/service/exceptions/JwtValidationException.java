package com.auth.service.exceptions;

/**
 * Excepción personalizada para errores de validación de JWT
 */
public class JwtValidationException extends RuntimeException {
    
    public JwtValidationException(String message) {
        super(message);
    }
    
    public JwtValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
