package com.auth.service.services;

import com.auth.service.dto.ChangePasswordDTO;
import com.auth.service.dto.TokenDTO;
import com.auth.service.dto.TokenPairDTO;
import com.auth.service.dto.UserDTO;

public interface IAuthService {

    void signupUser(UserDTO user) ;

    TokenPairDTO LoginUser (UserDTO user) ;

    TokenPairDTO  loginOrRegisterWithGoogle (TokenDTO token)throws Exception;

}
