package com.auth.service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "usuario")
public class    Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Integer id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_rol", nullable = false)
    private Rol idRol;

    @Size(max = 150)
    @NotNull
    @Column(name = "correo", nullable = false, length = 150)
    private String correo;

    @Size(max = 100)
    @Column(name = "contrasena", length = 100)
    private String contrasena;

    @Size(max = 50)
    @Column(name = "nombres", length = 50)
    private String nombres;

    @Size(max = 50)
    @Column(name = "apellidos", length = 50)
    private String apellidos;

    @Size(max = 20)
    @Column(name = "telefono", length = 20)
    private String telefono;

    @Size(max = 255)
    @Column(name = "id_google")
    private String idGoogle;

    @NotNull
    @Lob
    @Column(name = "tipo_autent", nullable = false)
    private String tipoAutent;

    @NotNull
    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro;

    @NotNull
    @ColumnDefault("0")
    @Column(name = "verificado", nullable = false)
    private Byte verificado;

    @Size(max = 15)
    @Column(name = "cedula", nullable = false, length = 15)
    private String cedula;

}