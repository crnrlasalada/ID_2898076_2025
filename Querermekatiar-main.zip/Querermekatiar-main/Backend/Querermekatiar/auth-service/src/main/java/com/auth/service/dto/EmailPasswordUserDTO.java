package com.auth.service.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmailPasswordUserDTO {

    private String title;
    private String to;
    private String password;


}
