package com.auth.service.services;

import com.auth.service.dto.TokenDTO;
import com.auth.service.entity.Rol;
import com.auth.service.entity.Usuario;
import com.auth.service.exceptions.CustomAuthException;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Collections;

@Service
public class GoogleTokenVerifyService {

    @Autowired
    private com.auth.service.repository.RolRepository rolRepository;

    @Value("${google.google-id}")
    private String CLIENT_ID;

    public Usuario verifytoken(TokenDTO token) throws Exception {

        GoogleIdTokenVerifier tokenverify = new GoogleIdTokenVerifier.Builder(
                new NetHttpTransport(),
                new GsonFactory()
        ).setAudience(Collections.singletonList(CLIENT_ID)).build();

        Usuario usuario = new Usuario();

        GoogleIdToken idToken = tokenverify.verify(token.getToken());


        if (idToken != null) {
            GoogleIdToken.Payload payload = idToken.getPayload();

            Boolean emailVerified = payload.getEmailVerified();
            if(!emailVerified){
                throw new CustomAuthException("El correo de google no esta verificado");
            }

            usuario.setCorreo(payload.getEmail());
            usuario.setIdGoogle(payload.getSubject());

            usuario.setNombres((String) payload.get("given_name"));
            usuario.setApellidos((String) payload.get("family_name"));
            usuario.setTipoAutent("GOOGLE");
            usuario.setFechaRegistro(LocalDate.now());

            // Asignar rol por defecto (CLIENT) si existe
            Rol rol = rolRepository.findRolByRol("CLIENT");
            if (rol == null) {
                throw new CustomAuthException("Rol CLIENT no configurado en base de datos");
            }
            usuario.setIdRol(rol);
            usuario.setVerificado((byte) 1);

        } else {
            throw new Exception("No se pudo iniciar sesion. Intentalo de nuevo con tu cuenta de google");
        }

        return usuario;
    };

}
