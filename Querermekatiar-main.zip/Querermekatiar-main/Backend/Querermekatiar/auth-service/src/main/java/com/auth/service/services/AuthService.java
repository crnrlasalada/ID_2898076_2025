package com.auth.service.services;


import com.auth.service.dto.*;
import com.auth.service.entity.RefreshToken;
import com.auth.service.entity.Rol;
import com.auth.service.entity.Token;
import com.auth.service.entity.Usuario;
import com.auth.service.exceptions.CustomAuthException;
import com.auth.service.repository.RefreshTokenRepository;
import com.auth.service.repository.RolRepository;
import com.auth.service.repository.TokensRepository;
import com.auth.service.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;


@Service
public class AuthService implements IAuthService {
    @Autowired
    private RefreshTokenRepository refreshTokenRepo;
    @Autowired
    private UsuarioRepository userRepository;
    @Autowired
    private RolRepository rolRepository;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private GoogleTokenVerifyService googleTokenVerifyService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private EmailNotificationService emailRMqService;
    @Autowired
    private TokensRepository tokensRepository;


    @Override
    public void signupUser(UserDTO user) {
        // Normalizar email a minúsculas
        String normalizedEmail = user.getCorreo().toLowerCase().trim();

        boolean usuarioExist = userRepository.existsUsuarioByCorreo(normalizedEmail);

        if (usuarioExist) {
            throw new CustomAuthException("Este correo ya esta registrado");
        }

        Usuario usuario = new Usuario();

        usuario.setCorreo(normalizedEmail);

        usuario.setContrasena(passwordEncoder.encode(user.getPassword()));
        usuario.setFechaRegistro(LocalDate.now());

        Rol rol = rolRepository.findRolById(2);
        usuario.setIdRol(rol);
        usuario.setVerificado((byte) 0);

        usuario.setTipoAutent("CORREO");

        // Guardar usuario primero
        Usuario savedUser = userRepository.save(usuario);
        
        // Generar token de verificación
        String verificationToken = UUID.randomUUID().toString();
        
        // Crear entidad Token para verificación
        Token emailToken = new Token();
        emailToken.setIdUsuario(savedUser);
        emailToken.setToken(verificationToken);
        emailToken.setTipoToken("VERIFICACION");
        emailToken.setFechaCreacion(Instant.now());
        emailToken.setFechaExpiracion(Instant.now().plus(24, ChronoUnit.HOURS)); // 24 horas
        emailToken.setActivo((byte) 1);
        
        tokensRepository.save(emailToken);
        
        // Crear link de verificación
        String verificationLink = "http://localhost:5173/verify-email?token=" + verificationToken;
        
        // Crear DTO para enviar por correo
        EmailVerificationRecoverDTO emailData = new EmailVerificationRecoverDTO();
        emailData.setEmail(normalizedEmail);
        emailData.setUserName(normalizedEmail);
        emailData.setLink(verificationLink);
        
        // Enviar correo através de RabbitMQ
        emailRMqService.SendVerificationEmail(emailData);
    }

    public void createSpecialUser(SpecialUserDTO user) {
        // Normalizar email a minúsculas
        String normalizedEmail = user.getCorreo().toLowerCase().trim();
        
        boolean usuarioExist = userRepository.existsUsuarioByCorreo(normalizedEmail);
        if (usuarioExist) {
            throw new CustomAuthException("Este Correo ya esta registrado");
        }

        // Validación de roles permitidos (ajustar si se agregan más)
        String rolInput = user.getRol();
        if (rolInput == null || !(rolInput.equals("ADMIN") || rolInput.equals("CASHIER") || rolInput.equals("DELIVERY"))) {
            throw new CustomAuthException("Rol inválido (permitidos: ADMIN, CASHIER, DELIVERY)");
        }

        Rol rol = rolRepository.findRolByRol(user.getRol());
        if (rol == null) {
            throw new CustomAuthException("Rol inválido");
        }

        Usuario sUser = new Usuario();
        sUser.setCorreo(normalizedEmail);
        sUser.setContrasena(passwordEncoder.encode(user.getPassword()));
        sUser.setIdRol(rol);
        sUser.setNombres(user.getNombres());
        sUser.setApellidos(user.getApellidos());
        sUser.setTelefono(user.getTelefono());
        sUser.setCedula(user.getCedula());
        sUser.setVerificado((byte) 1);
        sUser.setFechaRegistro(LocalDate.now());
        sUser.setTipoAutent("CORREO");

        userRepository.save(sUser);
    }

    private TokenPairDTO buildTokenPair(Usuario userFinal) {
        //Verificacion de que el usuario tenga un refresh token
        String refreshToken;
        Optional<RefreshToken> existingToken = refreshTokenRepo.findByIdUsuarioIdAndActivo(
                userFinal.getId(), (byte) 1);

        if (existingToken.isPresent()) {
            refreshToken = existingToken.get().getToken();
        } else {
            refreshToken = jwtService.generateRefreshToken(userFinal.getId());
        }
        String accessToken = jwtService.generateJwtToken(userFinal);

        return new TokenPairDTO(accessToken, refreshToken);
    }

    public TokenPairDTO   LoginUser (UserDTO usuario){
        // Normalizar email a minúsculas
        String normalizedEmail = usuario.getCorreo().toLowerCase().trim();

        boolean usuarioExist = userRepository.existsUsuarioByCorreo(normalizedEmail);

        if (!usuarioExist) {
            throw new CustomAuthException("Este correo no esta registrado");
        }

        Usuario userFinal = userRepository.findUsuarioByCorreo(normalizedEmail);

        System.out.println(userFinal.getTipoAutent());

        if (userFinal.getTipoAutent().equals("Google")) {
            throw new CustomAuthException("Usuario registrado con otro método auth");
        }

        // Verificar que el usuario haya verificado su email
        if (userFinal.getVerificado() == 0) {
            throw new CustomAuthException("Debes verificar tu correo electrónico antes de iniciar sesión. Revisa tu bandeja de entrada.");
        }

        if (!passwordEncoder.matches(usuario.getPassword(), userFinal.getContrasena())) {
            throw new CustomAuthException("Contraseña incorrecta");
        }

        return buildTokenPair(userFinal);
    }

    public TokenPairDTO loginOrRegisterWithGoogle (TokenDTO token) throws Exception {

        Usuario usuario = googleTokenVerifyService.verifytoken(token);

        boolean userExist = userRepository.existsUsuarioByCorreo(usuario.getCorreo());

        Usuario userFinal;

        if (!userExist) {
            userFinal =  userRepository.save(usuario);
        } else {
            userFinal = userRepository.findUsuarioByCorreo(usuario.getCorreo());
        }

        return buildTokenPair(userFinal);

    }




    // Método para enviar token de recuperación de contraseña
    public void sendPasswordResetToken(String email) {
        // Verificar que el usuario existe
        Usuario usuario = userRepository.findUsuarioByCorreo(email.toLowerCase());
        if (usuario == null) {
            throw new CustomAuthException("No existe usuario con ese correo electrónico");
        }

        // Desactivar cualquier token anterior del usuario para RECUPERACION
    Optional<Token> existingToken = tokensRepository.findActiveTokenByUserAndType(usuario, "RECUPERACION");
        if (existingToken.isPresent()) {
            Token token = existingToken.get();
            token.setActivo((byte) 0);
            tokensRepository.save(token);
        }

        // Generar nuevo token
        String tokenValue = UUID.randomUUID().toString();

        // Crear entidad Token
        Token resetToken = new Token();
        resetToken.setIdUsuario(usuario);
        resetToken.setToken(tokenValue);
    resetToken.setTipoToken("RECUPERACION");
        resetToken.setFechaCreacion(Instant.now());
        resetToken.setFechaExpiracion(Instant.now().plus(1, ChronoUnit.HOURS)); // 1 hora de validez
        resetToken.setActivo((byte) 1);

        tokensRepository.save(resetToken);

        // Crear DTO para enviar por correo
        EmailVerificationRecoverDTO emailData = new EmailVerificationRecoverDTO();
        emailData.setEmail(email);
        emailData.setUserName(usuario.getNombres() != null ? usuario.getNombres() : email);
        emailData.setLink("http://localhost:5173//reset-password?token=" + tokenValue);

        // Enviar correo através de RabbitMQ
        emailRMqService.SendRecoverEmail(emailData);
    }

    // Método para restablecer contraseña con token
    public void resetPassword(ResetPasswordDTO resetPasswordDTO) {
        String tokenValue = resetPasswordDTO.getToken();
        String newPassword = resetPasswordDTO.getPassword();

        // Buscar el token en la base de datos
    Optional<Token> tokenOpt = tokensRepository.findByTokenAndActivoAndTipoToken(tokenValue, (byte) 1, "RECUPERACION");
        if (!tokenOpt.isPresent()) {
            throw new CustomAuthException("Token inválido o expirado");
        }
        Token token = tokenOpt.get();

        // Verificar expiración
        if (token.getFechaExpiracion().isBefore(Instant.now())) {
            token.setActivo((byte) 0);
            tokensRepository.save(token);
            throw new CustomAuthException("Token expirado");
        }

        Usuario usuario = token.getIdUsuario();
        if (usuario == null) {
            throw new CustomAuthException("Usuario no encontrado para el token");
        }

        if (newPassword == null || newPassword.trim().isEmpty()) {
            throw new CustomAuthException("La contraseña no puede estar vacía");
        }

        usuario.setContrasena(passwordEncoder.encode(newPassword));
        userRepository.save(usuario);

        // Invalidar el token después del uso
        token.setActivo((byte) 0);
        tokensRepository.save(token);

        // Opcional: Invalidar refresh token activo del usuario por seguridad
        Optional<RefreshToken> activeRefreshToken = refreshTokenRepo.findByIdUsuarioIdAndActivo(usuario.getId(), (byte) 1);
        if (activeRefreshToken.isPresent()) {
            RefreshToken refreshToken = activeRefreshToken.get();
            refreshToken.setActivo((byte) 0);
            refreshTokenRepo.save(refreshToken);
        }
    }

    // Método para actualizar usuario
    public Usuario updateUser(Usuario usuario) {
        return userRepository.save(usuario);
    }

    // Método para reenviar correo de verificación
    public void resendVerificationEmail(String email) {
        // Normalizar email
        String normalizedEmail = email.toLowerCase().trim();
        
        // Verificar que el usuario existe
        Usuario usuario = userRepository.findUsuarioByCorreo(normalizedEmail);
        
        if (usuario == null || usuario.getVerificado() == 1) {
            // No hacer nada si no existe o ya está verificado
            return;
        }

        // Desactivar cualquier token anterior del usuario para VERIFICACION
        Optional<Token> existingToken = tokensRepository.findActiveTokenByUserAndType(usuario, "VERIFICACION");
        if (existingToken.isPresent()) {
            Token token = existingToken.get();
            token.setActivo((byte) 0);
            tokensRepository.save(token);
        }

        // Generar nuevo token de verificación
        String verificationToken = UUID.randomUUID().toString();
        
        // Crear entidad Token para verificación
        Token emailToken = new Token();
        emailToken.setIdUsuario(usuario);
        emailToken.setToken(verificationToken);
        emailToken.setTipoToken("VERIFICACION");
        emailToken.setFechaCreacion(Instant.now());
        emailToken.setFechaExpiracion(Instant.now().plus(24, ChronoUnit.HOURS)); // 24 horas
        emailToken.setActivo((byte) 1);
        
        tokensRepository.save(emailToken);
        
        // Crear link de verificación
        String verificationLink = "http://localhost:5173/verify-email?token=" + verificationToken;
        
        // Crear DTO para enviar por correo
        EmailVerificationRecoverDTO emailData = new EmailVerificationRecoverDTO();
        emailData.setEmail(normalizedEmail);
        emailData.setUserName(normalizedEmail);
        emailData.setLink(verificationLink);
        
        // Enviar correo através de RabbitMQ
        emailRMqService.SendVerificationEmail(emailData);
    }

}
