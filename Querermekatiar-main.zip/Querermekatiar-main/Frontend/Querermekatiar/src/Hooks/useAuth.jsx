import { useState, useEffect } from 'react';
import { AuthService } from '../api/services/AuthService';

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Siempre autenticado para pruebas
  const [isLoading, setIsLoading] = useState(false); // Sin loading para pruebas
  const [user, setUser] = useState({ authenticated: true, test: true }); // Usuario mock para pruebas

  useEffect(() => {
    // AUTENTICACIÓN DESACTIVADA PARA PRUEBAS
    // TODO: Reactivar validación de autenticación al final del proyecto
    checkAuthStatus();
  }, []);

  const checkAuthStatus = () => {
    // Durante las pruebas, siempre considerar autenticado
    setIsAuthenticated(true);
    setUser({ authenticated: true, test: true });
    setIsLoading(false);
  };

  const login = async (email, password) => {
    try {
      const response = await AuthService.login(email, password);
      setIsAuthenticated(true);
      setUser({ authenticated: true, ...response });
      return response;
    } catch (error) {
      // Durante pruebas, no fallar el login
      setIsAuthenticated(true);
      setUser({ authenticated: true, test: true });
      return { success: true, test: true };
    }
  };

  const logout = () => {
    // Durante pruebas, mantener autenticado
    // AuthService.logout();
    // setIsAuthenticated(false);
    // setUser(null);
  };

  return {
    isAuthenticated,
    isLoading,
    user,
    login,
    logout,
    checkAuthStatus
  };
};

export default useAuth;
