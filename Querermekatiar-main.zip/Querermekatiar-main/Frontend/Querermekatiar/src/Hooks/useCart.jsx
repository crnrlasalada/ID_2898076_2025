import { useContext } from 'react';
import { CartContext } from '../Context/CartContext'; // Ajusta el path si es necesario

export const useCart = () => useContext(CartContext);