import { Navigate } from 'react-router-dom';
import { AuthService } from '../api/services/AuthService';

export const ProtectedRoute = ({ children, requiredRole = null }) => {
  // PROTECCIÓN DE RUTAS DESACTIVADA PARA PRUEBAS
  // TODO: Reactivar protección de rutas al final del proyecto
  
  // Durante las pruebas, permitir acceso a todas las rutas
  return children;
  
  // const isAuthenticated = AuthService.isAuthenticated();
  // 
  // if (!isAuthenticated) {
  //   return <Navigate to="/login" replace />;
  // }
  // 
  // return children;
};

export default ProtectedRoute;
