import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import styles from "../../assets/Styles/Quererte/User/asideCategoryQuererte.module.css";
import logotype from "../../assets/images/Quererte/User/logo_quererte_black.webp";
import amekatiarLogo from "../../assets/images/Amekatiar/User/amekatiar-logo.webp";

export const AsideCategoryQuererte = ({ categories = [], products = [] }) => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const selectedCategoria = searchParams.get("categoria");
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 900);
  const [open, setOpen] = useState(!isMobile);
  const [showAmekatiar, setShowAmekatiar] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 900);
      if (window.innerWidth > 900) setOpen(true);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleLogoClick = () => {
    navigate("/usuario/menu-amekatiar");
  };

  // Filtra categorías: solo muestra si tiene productos distintos a "Crea tu propio helado"
  const filteredCategories = categories.filter(cat => {
    const prods = products.filter(p => p.nameCategory === cat.nameCategory);
    // Si no hay productos, no mostrar la categoría
    if (prods.length === 0) return false;
    // Si solo hay un producto y es "Crea tu propio helado", no mostrar la categoría
    if (prods.length === 1 && prods[0].name === "Crea tu propio helado") return false;
    // Si todos los productos son "Crea tu propio helado", no mostrar la categoría
    if (prods.every(p => p.name === "Crea tu propio helado")) return false;
    return true;
  });

  return (
    <>
      {isMobile && (
        <button
          className={styles.toggleBtn}
          onClick={() => setOpen((prev) => !prev)}
          aria-label={open ? "Cerrar menú" : "Abrir menú"}
        >
          <span className={`${open ? styles.arrowLeft : styles.arrowRight} ${!open ? styles.whiteArrow : ""}`}></span>
        </button>
      )}
      <aside
        className={`${styles.asidebarcategory} ${isMobile && !open ? styles.closed : ""}`}
      >
        <figure
          className={styles.containerImg}
          onMouseEnter={() => setShowAmekatiar(true)}
          onMouseLeave={() => setShowAmekatiar(false)}
          onClick={handleLogoClick}
          style={{
            cursor: "pointer",
            position: "relative",
            overflow: "hidden",
            height: "120px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          <img
            className={styles.logotype}
            src={logotype}
            alt="Logotype"
            style={{
              position: "relative",
              zIndex: 1,
              height: "100px",
              width: "auto",
              margin: "0 auto",
              opacity: showAmekatiar ? 0 : 1,
              transition: "opacity 0.4s cubic-bezier(.7,.2,.3,1)"
            }}
          />
          <img
            src={amekatiarLogo}
            alt="Amekatiar Logo"
            className={styles.amekatiarLogoFull}
            style={{
              position: "absolute",
              top: 0,
              left: showAmekatiar ? "0%" : "100%",
              height: "100%",
              width: "100%",
              objectFit: "contain",
              pointerEvents: "none",
              opacity: showAmekatiar ? 1 : 0,
              transition: "left 0.4s cubic-bezier(.7,.2,.3,1), opacity 0.3s",
              zIndex: 2
            }}
          />
        </figure>
        <div className={styles.categoryContent}>
          {categories.length === 0 ? (
            <p style={{ textAlign: "center", color: "#888" }}>No hay categorías disponibles.</p>
          ) : (
            <ul className={styles.categoryList}>
              <li
                key="todos"
                className={`${styles.category} ${!selectedCategoria ? styles.active : ""}`}
                onClick={() => navigate("/usuario/menu-quererte")}
                style={{ cursor: "pointer" }}
              >
                Todos
              </li>
              {filteredCategories.map((cat) => (
                <li
                  key={cat.id}
                  className={`${styles.category} ${selectedCategoria === String(cat.nameCategory) ? styles.active : ""}`}
                  onClick={() => navigate(`/usuario/menu-quererte?categoria=${cat.nameCategory}`)}
                  style={{ cursor: "pointer" }}
                >
                  {cat.nameCategory}
                </li>
              ))}
            </ul>
          )}
        </div>
      </aside>
      {isMobile && open && (
        <div className={styles.backdrop} onClick={() => setOpen(false)} />
      )}
    </>
  );
};