import React, { useEffect, useState, useRef } from "react";
import styles from "../../assets/Styles/product-modal.module.css";
import { useCart } from "../../Hooks/useCart";
import { useLocation } from "react-router-dom";
import { CatalogService } from "../../api/services/CatalogService";
import Swal from "sweetalert2";

export const ProductModal = ({
  product,
  onClose,
  isOpen,
  initialQuantity = 1,
  initialExtras = [],
  onConfirmEdit
}) => {
  console.log("PRODUCTO EN MODAL:", product); // <-- Agregado para depuración
  const [selectedExtras, setSelectedExtras] = useState([]);
  const [quantity, setQuantity] = useState(initialQuantity);
  const [addons, setAddons] = useState([]);
  const [mandatoryValidationError, setMandatoryValidationError] = useState("");
  const mandatoryCategoryRef = useRef(null);
  const { addToCart } = useCart();
  const location = useLocation();
  const isQuererte = location.pathname.includes("menu-quererte") || location.pathname.includes("home-quererte");

  // Fetch addons from backend when modal opens
  useEffect(() => {
    if (isOpen && product?.id) {
      CatalogService.getAddOns(product.id)
        .then(res => {
          setAddons(Array.isArray(res.data) ? res.data : []);
        })
        .catch(() => setAddons([]));
    }
  }, [isOpen, product?.id]);

  // Inicializa extras y cantidad solo cuando el modal se abre
  useEffect(() => {
    if (isOpen) {
      setSelectedExtras(initialExtras || []);
      setQuantity(initialQuantity);
      setMandatoryValidationError(""); // Limpiar errores al abrir
    }
    // Solo depende de isOpen para evitar ciclos infinitos
    // eslint-disable-next-line
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isOpen]);

  // Agrupa addons por categoría
  const groupedAddons = addons.reduce((acc, addon) => {
    const cat = addon.nameCategory || "Otros";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(addon);
    return acc;
  }, {});

  // Función para verificar si una adición está seleccionada
  const isChecked = (addonId) => {
    return selectedExtras.some(e => e.id === addonId);
  };

  // Función para obtener la cantidad de una adición específica
  const getCantidad = (addonId) => {
    const extra = selectedExtras.find(e => e.id === addonId);
    return extra ? extra.cantidad : 0;
  };

  // Función para verificar si una categoría es obligatoria
  const isMandatoryCategory = (categoryName) => {
    if (!product.idCategoriaObligatoria) return false;
    const categoryAddons = addons.filter(a => a.nameCategory === categoryName);
    return categoryAddons.some(a => a.idCategory === product.idCategoriaObligatoria);
  };

  // Obtiene la suma total de adiciones obligatorias seleccionadas
  const getTotalMandatorySelected = () => {
    if (!product.idCategoriaObligatoria) return 0;
    return selectedExtras.reduce((total, extra) => {
      const addon = addons.find(a => a.id === extra.id);
      if (addon && addon.idCategory === product.idCategoriaObligatoria) {
        return total + extra.cantidad;
      }
      return total;
    }, 0);
  };


  // Validación: solo se permite la cantidad exacta de adiciones obligatorias
  const validateMandatoryAddons = () => {
    if (!product.idCategoriaObligatoria || !product.cantidadAdicionesObligatorias) return true;
    const requiredQuantity = product.cantidadAdicionesObligatorias;
    const selectedFromMandatoryCategory = getTotalMandatorySelected();
    if (selectedFromMandatoryCategory !== requiredQuantity) {
      setMandatoryValidationError(`Debes seleccionar exactamente ${requiredQuantity} adición(es) de la categoría obligatoria`);
  setTimeout(() => setMandatoryValidationError("") , 2500);
      // Focus en la categoría obligatoria
      if (mandatoryCategoryRef.current) {
        mandatoryCategoryRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
        mandatoryCategoryRef.current.focus();
      }
      return false;
    }
    return true;
  };

  // Maneja el cambio de checkbox para adiciones
  const handleCheckboxChange = (addonId) => {
    const addon = addons.find(a => a.id === addonId);
    const isFromMandatoryCategory = addon && addon.idCategory === product.idCategoriaObligatoria;
    
    setSelectedExtras((prev) => {
      const found = prev.find(e => e.id === addonId);
      
      if (found) {
        // Si está deseleccionando, siempre permitir
        return prev.filter(e => e.id !== addonId);
      } else {
        // Si está seleccionando, verificar límites
        if (isFromMandatoryCategory && product.cantidadAdicionesObligatorias) {
          const currentMandatoryCount = getTotalMandatorySelected();
          if (currentMandatoryCount >= product.cantidadAdicionesObligatorias) {

            return prev; // No permitir seleccionar más
          }
        }
        return [...prev, { id: addonId, cantidad: 1 }];
      }
    });
  };

  // Maneja el cambio de cantidad de una adición específica
  const handleAddonCantidad = (addonId, delta) => {
    const addon = addons.find(a => a.id === addonId);
    const isFromMandatoryCategory = addon && addon.idCategory === product.idCategoriaObligatoria;
    
    setSelectedExtras(prev => {
      return prev.map(extra => {
        if (extra.id === addonId) {
          const newCantidad = extra.cantidad + delta;
          
          // No permitir cantidad menor a 1
          if (newCantidad < 1) {
            return extra;
          }
          
          // Si es de categoría obligatoria y está incrementando, verificar límite
          if (isFromMandatoryCategory && delta > 0 && product.cantidadAdicionesObligatorias) {
            const currentMandatoryCount = getTotalMandatorySelected();
            if (currentMandatoryCount >= product.cantidadAdicionesObligatorias) {

              return extra; // No permitir incrementar más
            }
          }
          
          return { ...extra, cantidad: newCantidad };
        }
        return extra;
      });
    });
  };

  // Función para confirmar la selección
  const handleConfirm = () => {
    // Validar adiciones obligatorias antes de proceder
    if (!validateMandatoryAddons()) {
      return; // No proceder si la validación falla
    }

    // Solo addons seleccionados, con cantidad
    const extras = addons
      .filter(a => isChecked(a.id))
      .map(a => ({
        id_adicion: a.id,
        cantidad: getCantidad(a.id),
        nom_adicion: a.name,
        precio: a.price
      }));
    const item = {
      ...product,
      adiciones: extras,
      quantity,
    };
    if (onConfirmEdit) {
      onConfirmEdit(item);
    } else {
      addToCart(item);
    }
    onClose();
  };

  // El componente debe retornar JSX solo en el cuerpo principal
  if (!isOpen) {
    return null;
  }

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <button className={styles.closeButton} onClick={onClose}>X</button>
        <div className={styles.header}>
          <img src={product.urlImage} alt={product.name} className={styles.image} />
          <h2 className={styles.title}>{product.name}</h2>
          <p className={styles.description}>{product.description}</p>
        </div>
        <hr />
        <div className={styles.content}>
          {/* Agrupa y muestra addons por categoría */}
          {addons.length === 0 ? (
            <p style={{ textAlign: "center", color: "#888" }}>No hay adiciones disponibles.</p>
          ) : (
            Object.entries(groupedAddons).map(([cat, list]) => (
              <div className={styles.section} key={cat}>
                <h3
                  ref={isMandatoryCategory(cat) ? mandatoryCategoryRef : undefined}
                  className={isMandatoryCategory(cat) && mandatoryValidationError ? styles.mandatoryCategoryTitle : undefined}
                  tabIndex={isMandatoryCategory(cat) ? -1 : undefined}
                >
                  {cat}
                  {isMandatoryCategory(cat) && (
                    <span className={styles.mandatoryCategory}>
                      Selecciona {product.cantidadAdicionesObligatorias} adiciones aquí
                    </span>
                  )}
                </h3>
                {list.map((a) => (
                  <div key={a.id} className={styles.adicionRow}>
                    <label className={styles.checkboxLabel}>
                      <input
                        type="checkbox"
                        checked={isChecked(a.id)}
                        onChange={() => handleCheckboxChange(a.id)}
                      />
                      {a.name} (+${a.price})
                    </label>
                    {isChecked(a.id) && (
                      <div className={styles.adicionCantidad}>
                        <button
                          className={isQuererte ? styles.quantityBtnBlack : styles.quantityBtnYellow}
                          onClick={() => handleAddonCantidad(a.id, -1)}
                          type="button"
                        >-</button>
                        <span>{getCantidad(a.id)}</span>
                        <button
                          className={isQuererte ? styles.quantityBtnBlack : styles.quantityBtnYellow}
                          onClick={() => handleAddonCantidad(a.id, 1)}
                          type="button"
                        >+</button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ))
          )}
          {/* Mensaje de error de validación */}
          {mandatoryValidationError && (
            <div className={styles.mandatoryValidationError}>
              {mandatoryValidationError}
            </div>
          )}
        </div>
        {/* Botones de cantidad y confirmar juntos */}
        <div className={styles.quantityConfirmRow}>
          <button
            className={isQuererte ? styles.quantityBtnBlack : styles.quantityBtnYellow}
            onClick={() => setQuantity(q => Math.max(1, q - 1))}
          >-</button>
          <span className={styles.quantityValue}>{quantity}</span>
          <button
            className={isQuererte ? styles.quantityBtnBlack : styles.quantityBtnYellow}
            onClick={() => setQuantity(q => q + 1)}
          >+</button>
          <button className={styles.confirmButton} onClick={handleConfirm}>
            CONFIRMAR
          </button>
        </div>
      </div>
    </div>
  );
};