import { GoogleLogin } from '@react-oauth/google';
import { api } from '../../api/axios';
import style from '../../assets/Styles/GoogleButton.module.css';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { decodeJwt } from '../../utils/jwtDecode';
import { validateUserProfile } from '../../utils/profileValidation';

export const GoogleButton = () => {
  const navigate = useNavigate();

  const sendIdTokenToBackend = async (idToken) => {
    try {
      const response = await api.post('http://localhost:8080/api/auth/google', {
        token: idToken
      }, {
        withCredentials: true
      });


      localStorage.setItem('token', response.data.token);

      // Decodificar el token y redirigir según el rol
      const userData = decodeJwt(response.data.token);
      let role = '';
      if (Array.isArray(userData?.roles) && userData.roles.length > 0) {
        role = userData.roles[0];
      } else {
        role = userData?.rol || userData?.role || '';
      }
      if (role === 'CLIENT') {
        const { UserService } = await import('../../api/services/UserService');
        const valid = await validateUserProfile(UserService, navigate);
        if (!valid) return;
        navigate('/');
      } else if (role === 'ADMIN' || role === 'CASHIER') {
        navigate('/admin/pedidos');
      } else if (role === 'DELIVERY') {
        navigate('/delivery/pedidos');
      } else {
        navigate('/');
      }

    } catch (error) {
      const mensajeError = error.response?.data?.error || "Error desconocido";

      Swal.fire({
        icon: "error",
        title: "Error al iniciar sesión",
        text: mensajeError
      });
    }
  };

  const handleGoogleLoginSuccess = (credentialResponse) => {
    sendIdTokenToBackend(credentialResponse.credential);
  };

  const handleGoogleLoginError = () => {
    console.error('Fallo el login con Google');
  };

  return (
    <div className={style.googleContainer}>
      <GoogleLogin
        onSuccess={handleGoogleLoginSuccess}
        onError={handleGoogleLoginError}
        useOneTap
      />
    </div>
  );
};
