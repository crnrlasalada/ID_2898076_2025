import React, { useState, useEffect, useContext } from "react";
import styles from "../../assets/Styles/order-history.module.css";
import cardStyles from "../../assets/Styles/order-card-history.module.css";
import bgstyles from '../../assets/Styles/bg.module.css';
import { OrderAgainService } from "../../api/services/OrderAgainService";
import { CartContext } from "../../Context/CartContext";
import { useLocation, useNavigate } from "react-router-dom";
import { OrderService } from '../../api/services/OrderService';

export const OrderHistory = () => {
  const [orders, setOrders] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [orderDetails, setOrderDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedOrderId, setExpandedOrderId] = useState(null);
  const [confirmOrderAgain, setConfirmOrderAgain] = useState(false);
  const [pendingOrderId, setPendingOrderId] = useState(null);
  const { clearCart, addToCart } = useContext(CartContext);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    document.body.className = bgstyles.bg;
    
    document.body.style.backgroundSize = "cover";
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const userId = payload.id || payload.userId || payload.sub;
      if (userId) {
        OrderAgainService.getLastOrders(userId)
          .then(res => {
            setOrders(res || []);
            setLoading(false);
          })
          .catch(() => {
            setError('No se pudo cargar el historial de pedidos');
            setLoading(false);
          });
      } else {
        setError('No se encontró el id de usuario en el JWT');
        setLoading(false);
      }
    } catch (e) {
      setError('Error al decodificar el token');
      setLoading(false);
    }
    return () => {
      document.body.className = '';
      document.body.style.backgroundSize = "";
    };
  }, [navigate]);

  const handleShowDetails = (order) => {
    setOrderDetails(order);
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
    setOrderDetails(null);
  };

  const handleExpand = (orderId) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId);
  };

  // Nuevo: Mostrar modal de confirmación antes de volver a pedir
  const handleOrderAgain = (pedidoId) => {
    setPendingOrderId(pedidoId);
    setConfirmOrderAgain(true);
  };

  const handleConfirmOrderAgain = async () => {
    setConfirmOrderAgain(false);
    if (!pendingOrderId) return;
    try {
      const cartProducts = await OrderAgainService.getCartForOrderAgain(pendingOrderId);
      clearCart();
      cartProducts.forEach(product => {
        addToCart(product);
      });
      if (location.pathname.includes("quererte")) {
        navigate("/usuario/menu-quererte/resumen-pedido");
      } else {
        navigate("/usuario/menu-amekatiar/resumen-pedido");
      }
    } catch (error) {
      alert("No se pudo volver a cargar el pedido. Intenta nuevamente.");
    }
    setPendingOrderId(null);
  };

  const handleCancelOrderAgain = () => {
    setConfirmOrderAgain(false);
    setPendingOrderId(null);
  };

  const formatDate = (iso) => {
    const date = new Date(iso);
    return date.toLocaleDateString();
  };

  const formatTime = (iso) => {
    const date = new Date(iso);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) return <div>Cargando...</div>;
  if (error) return <div style={{color:'red'}}>{error}</div>;

  return (
    <>
      {/* Fondo amarillo fijo, no interfiere con el contenido */}
      <div className={styles.fullBg}></div>
  <h2 className={styles.title}>Historial de pedidos</h2>
      {orders.length === 0 ? (
        <div>No tienes pedidos registrados.</div>
      ) : (
        orders.map((order) => (
          <section className={cardStyles.card} key={order.id}>
            <div className={cardStyles.header}>
              <h3>Pedido #{order.id}</h3>
              <span>{formatDate(order.fechaHora || order.dateTime)} {formatTime(order.fechaHora || order.dateTime)}</span>
            </div>
            <p><strong>Cliente:</strong> {order.nombres || order.name || order.cliente || ''} {order.apellidos || ''}</p>
            <p><strong>Dirección:</strong> {order.direccion || order.address || "Sin dirección"}</p>
            <p><strong>Teléfono:</strong> {order.telefono  || "No registrado"}</p>
            <p><strong>Estado:</strong> {order.estadoPedido || order.status || "Desconocido"}</p>
            <p><strong>Total:</strong> ${order.total ? order.total.toLocaleString() : "0"}</p>

            <div className={cardStyles.actions}>
              <button
                className={cardStyles.detailButton}
                onClick={() => handleExpand(order.id)}
              >
                {expandedOrderId === order.id ? "Ocultar detalle" : "Ver detalle"}
              </button>
              <button
                className={cardStyles.detailButton}
                onClick={() => handleOrderAgain(order.id)}
              >
                Volver a pedir
              </button>
            </div>
            {expandedOrderId === order.id && (
              <div className={styles.orderDetails}>
                <p><strong>Tipo de entrega:</strong> {order.tipoEntrega || order.deliveryType || ''}</p>
                <p><strong>Tipo de pago:</strong> {order.formaPago || order.paymentMethod || ''}</p>
                <p><strong>Mensaje del cliente:</strong> {order.mensajeCliente || order.customerMessage || "Sin mensaje"}</p>
                <p><strong>Subtotal:</strong> ${order.subtotal ? order.subtotal.toLocaleString() : "0"}</p>
                <p><strong>Precio domicilio:</strong> ${order.domicilio ? order.domicilio.toLocaleString() : "0"}</p>
                {order.estadoPedido === "Rechazado" && (
                  <p style={{ color: "#c00", fontWeight: "bold" }}>
                    <strong>Motivo de rechazo:</strong> {order.motivoRechazo}
                  </p>
                )}
                <strong>Productos:</strong>
                <ul className={cardStyles.productList}>
                  {(order.productos || order.products || []).map((prod, idx) => (
                    <li key={idx} className={cardStyles.productItem}>
                      <span className={cardStyles.productName}>{prod.nombre || prod.name}</span>
                      <span className={cardStyles.productInfo}>
                        Cantidad: {prod.cantidad || prod.quantity} | Precio: ${prod.precio || prod.price}
                      </span>
                      {(prod.adiciones || prod.addOns) && (prod.adiciones || prod.addOns).length > 0 && (
                        <ul className={cardStyles.adicionesList}>
                          {(prod.adiciones || prod.addOns).map((a, i) => (
                            <li key={i} className={cardStyles.adicionItem}>
                              {(a.nombre || a.name)} (x{a.cantidad || 1}) ${a.precio || a.price}
                            </li>
                          ))}
                        </ul>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        ))
      )}

      {/* Modal de detalles clásico */}
      {modalOpen && orderDetails && (
        <div className={styles.modalOverlay} onClick={handleCloseModal}>
          <div
            className={styles.modal}
            onClick={(e) => e.stopPropagation()}
          >
            <button className={styles.closeModal} onClick={handleCloseModal}>X</button>
            <h3>Detalles del pedido #{orderDetails.id}</h3>
            <p><strong>Dirección:</strong> {orderDetails.address}</p>
            <p><strong>Fecha y hora:</strong> {orderDetails.dateTime ? new Date(orderDetails.dateTime).toLocaleString() : ''}</p>
            <strong>Productos:</strong>
            <ul>
              {(orderDetails.products || []).map((prod, idx) => (
                <li key={idx}>
                  {prod.name} <br />
                  Cantidad: {prod.quantity} <br />
                  Precio: ${prod.price} <br />
                  {prod.addOns && prod.addOns.length > 0 && (
                    <>Adiciones: {prod.addOns.map(a => a.name).join(", ")}</>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

{/* Modal de confirmación para volver a pedir */}
{confirmOrderAgain && (
  <div className={styles.modalOverlay} onClick={handleCancelOrderAgain}>
    <div
      className={styles.modal}
      onClick={(e) => e.stopPropagation()}
    >
      <button
        className={styles.closeModal}
        onClick={handleCancelOrderAgain}
        aria-label="Cerrar"
        title="Cerrar"
      >
        ×
      </button>
      <h3>¿Volver a pedir?</h3>
      <p>
        <b>Se borrarán los productos que tienes actualmente en el carrito.</b><br />
        Si algún producto o adición de este pedido no se agrega es porque en estos momentos no está disponible.
      </p>
      <div className={styles.modalActions}>
        <button className={styles.modalButton} onClick={handleConfirmOrderAgain}>Aceptar</button>
        <button className={styles.modalButton} onClick={handleCancelOrderAgain}>Cancelar</button>
      </div>
    </div>
  </div>
)}
  </>
  );
};