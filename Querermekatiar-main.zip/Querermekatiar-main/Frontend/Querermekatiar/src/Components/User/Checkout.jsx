import React, { useState, useEffect, useRef } from 'react';
import styles from '../../assets/Styles/Checkout.module.css';
import { useCart } from '../../Hooks/useCart';
import bgstyles from '../../assets/Styles/bg.module.css';
import { MapClient } from './MapClient';
import { useNavigate, useLocation } from 'react-router-dom';
import { OrderService } from '../../api/services/OrderService.js';
import { idUserToken } from '../../api/utils/jwtDecode.js';
import { UserService } from '../../api/services/UserService.js';
import { usePopup } from "../../Context/PopupProvider.jsx";

// Datos 
const direccionPre = {
  address: "Concordia, Antioquia, Colombia",
  lat: 6.0477,
  lng: -75.9186
};

export const Checkout = () => {
  const [deliveryType, setDeliveryType] = useState('Domicilio');
  const [paymentMethod, setPaymentMethod] = useState('Efectivo');
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [idNumber, setDocument] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState(direccionPre.address);
  const [addressInput, setAddressInput] = useState(direccionPre.address);
  const [lat, setLat] = useState(direccionPre.lat);
  const [lng, setLng] = useState(direccionPre.lng);
  const [customerMessage, setCustomerMessage] = useState("");
  const addressFromMap = useRef(false);

  const { showPopup } = usePopup();

  const { cartItems, clearCart } = useCart();
  const navigate = useNavigate();
  const location = useLocation();
  const isQuererte = location.pathname.includes("quererte");

  // Estado para el precio del domicilio
  const [deliveryFee, setDeliveryFee] = useState(0);

  // Guardar/restaurar dirección y coordenadas al cambiar tipo de entrega
  const [savedLocation, setSavedLocation] = useState({
    address: direccionPre.address,
    addressInput: direccionPre.address,
    lat: direccionPre.lat,
    lng: direccionPre.lng,
  });

  // Validaciones de campos
  const nameRegex = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/;
  const phoneRegex = /^[0-9]{10}$/;
  const idNumberRegex = /^[0-9]{6,10}$/;

  const [nameError, setNameError] = useState("");
  const [lastNameError, setLastNameError] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [idNumberError, setIdNumberError] = useState("");

  useEffect(() => {
    document.body.className = bgstyles.bg;
    return () => {
      document.body.className = '';
    };
  }, []);

  //Cargar datos del usuario 
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const { data } = await UserService.getProfile();
        setFirstName(data.nombres || "");
        setLastName(data.apellidos || "");
        setDocument(data.cedula || "");
        setPhone(data.telefono || "");
      } catch (error) {
        console.error("Error cargando perfil:", error);
      }
    };

    fetchUser();
  }, []);

  useEffect(() => {
    if (deliveryType === "Local") {
      // Guarda la ubicación antes de limpiar
      setSavedLocation({
        address,
        addressInput,
        lat,
        lng,
      });
      setAddress("");
      setAddressInput("");
      setLat(null);
      setLng(null);
      setDeliveryFee(0);
    } else if (deliveryType === "Domicilio") {
      // Restaura la ubicación guardada
      setAddress(savedLocation.address);
      setAddressInput(savedLocation.addressInput);
      setLat(savedLocation.lat);
      setLng(savedLocation.lng);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deliveryType]);

  // Solicita el precio del domicilio al backend cuando el tipo de entrega es "Domicilio"
  useEffect(() => {
    if (deliveryType === "Domicilio") {
      OrderService.getDeliveryPrice()
        .then(res => {
          setDeliveryFee(res.price || 0);
        })
        .catch(() => setDeliveryFee(0));
    } else {
      setDeliveryFee(0);
    }
  }, [deliveryType]);

  // Cuando el usuario edita la dirección manualmente (solo cambia el input)
  const handleAddressInputChange = (e) => {
    setAddressInput(e.target.value);
  };

  // Cuando el usuario pulsa el botón para asignar la dirección al mapa
  const handleAssignAddress = () => {
    setAddress(addressInput);
    addressFromMap.current = false;
  };

  // Cuando el usuario mueve el marcador en el mapa
  const handleMapChange = (newLat, newLng, newAddress) => {
    setLat(newLat);
    setLng(newLng);
    setAddress(newAddress);
    setAddressInput(newAddress); // Sincroniza el input con la dirección del mapa
    addressFromMap.current = true;
  };

  // Si la dirección cambia desde el mapa, actualiza el input
  useEffect(() => {
    if (addressFromMap.current) {
      setAddressInput(address);
      addressFromMap.current = false;
    }
  }, [address]);

  // Handlers con validación
  const handleFirstNameChange = (e) => {
    const value = e.target.value;
    if (!nameRegex.test(value) && value !== "") {
      setNameError("Solo letras y espacios.");
    } else {
      setNameError("");
    }
    setFirstName(value);
  };

  const handleLastNameChange = (e) => {
    const value = e.target.value;
    if (!nameRegex.test(value) && value !== "") {
      setLastNameError("Solo letras y espacios.");
    } else {
      setLastNameError("");
    }
    setLastName(value);
  };

  const handlePhoneChange = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    if (!phoneRegex.test(value) && value.length > 0) {
      setPhoneError("Debe tener exactamente 10 dígitos.");
    } else {
      setPhoneError("");
    }
    setPhone(value);
  };

  const handleIdNumberChange = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    if (!idNumberRegex.test(value) && value.length > 0) {
      setIdNumberError("Debe tener entre 6 y 10 dígitos.");
    } else {
      setIdNumberError("");
    }
    setDocument(value);
  };

  // Calcula el total de un producto (precio base + adiciones) * cantidad
  const getItemTotal = (item) => {
    const base = item.price || item.precio || 0;
    const addOnsTotal = (item.adiciones || []).reduce((sum, a) => sum + ((a.precio || 0) * (a.cantidad || 1)), 0);
    return (base + addOnsTotal) * item.quantity;
  };

  // Total de todos los productos
  const getCartTotal = () => {
    return cartItems.reduce((sum, item) => sum + getItemTotal(item), 0);
  };

  // Calcula el total sumando el domicilio si aplica
  const total = getCartTotal() + deliveryFee;

  // Ruta de regreso según el negocio
  const menuPath = isQuererte
    ? "/usuario/menu-quererte"
    : "/usuario/menu-amekatiar";

  // Enviar pedido
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validación final antes de enviar
    if (
      nameError || lastNameError || phoneError || idNumberError ||
      !firstName || !lastName || !phone || !idNumber
    ) {
      showPopup('Por favor corrige los campos del formulario.', false);
      return;
    }

    const clientId = idUserToken();

    const order = {
      firstName,
      lastName,
      clientId,
      idNumber,
      phone,
      address,
      latitude: lat,
      longitude: lng,
      deliveryType,
      paymentMethod,
      customerMessage,
      products: cartItems.map((product, idx) => ({
        id: product.id,
        quantity: product.quantity,
        addOns: (product.adiciones || []).map(addOn => ({
          id: addOn.id_adicion,
          quantity: addOn.cantidad
        }))
      }))
    };
    try {
      const response = await OrderService.create(order);
      if (response.status === 200) {
        showPopup('¡Pedido realizado con éxito!', true);
        clearCart();
        navigate(menuPath); // Navega inmediatamente
      } else {
        showPopup('No se pudo realizar el pedido', false);
        navigate(menuPath);
      }
    } catch (error) {
      showPopup('No se pudo realizar el pedido', false);
    }
  };

  return (
    <div className={styles.container}>
      {/* Flecha hacia atrás */}
      <button
        className={styles.backButton}
        onClick={() => navigate(menuPath)}
        title="Volver al menú"
      >
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
          <circle cx="16" cy="16" r="16" fill="#F0B617" />
          <path d="M19.5 23L13 16.5L19.5 10" stroke="#23272f" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>

      <form className={styles.formSection} onSubmit={handleSubmit}>
        <h1>Información de pago</h1>
        <div className={styles.formRowDouble}>
          <div>
            <label>Nombre</label>
            <input
              type="text"
              placeholder="Nombre"
              value={firstName}
              onChange={handleFirstNameChange}
              required
              maxLength={30}
              autoComplete="off"
            />
            {nameError && <span className={styles.inputError}>{nameError}</span>}
          </div>
          <div>
            <label>Apellido</label>
            <input
              type="text"
              placeholder="Apellido"
              value={lastName}
              onChange={handleLastNameChange}
              required
              maxLength={30}
              autoComplete="off"
            />
            {lastNameError && <span className={styles.inputError}>{lastNameError}</span>}
          </div>
        </div>
        <div className={styles.formRow}>
          <label>Cédula</label>
          <input
            type="text"
            placeholder="Cédula"
            value={idNumber}
            onChange={handleIdNumberChange}
            required
            maxLength={10}
            minLength={6}
            autoComplete="off"
          />
          {idNumberError && <span className={styles.inputError}>{idNumberError}</span>}
        </div>
        <div className={styles.formRow}>
          <label>Celular</label>
          <input
            type="text"
            placeholder="Celular"
            value={phone}
            onChange={handlePhoneChange}
            required
            maxLength={10}
            minLength={10}
            autoComplete="off"
          />
          {phoneError && <span className={styles.inputError}>{phoneError}</span>}
        </div>
        {deliveryType === 'Domicilio' && (
          <div className={styles.formRow} style={{ display: 'flex', gap: 8 }}>
            <div style={{ flex: 1 }}>
              <label>Dirección</label>
              <input
                type="text"
                placeholder="Dirección"
                value={addressInput}
                onChange={handleAddressInputChange}
                required
              />
            </div>
            <button
              type="button"
              className={styles.iconButton}
              title="Asignar en el mapa"
              onClick={handleAssignAddress}
              style={{ alignSelf: 'end', marginTop: 22 }}
            >
              {/* SVG lupa */}
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="9" cy="9" r="7" stroke="#23272f" strokeWidth="2" />
                <line x1="14.4142" y1="14" x2="18" y2="17.5858" stroke="#23272f" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        )}
        <div className={styles.selectsRow}>
          <div>
            <label>Opciones de entrega</label>
            <select value={deliveryType} onChange={e => setDeliveryType(e.target.value)}>
              <option value="Domicilio">Domicilio</option>
              <option value="Local">Local</option>
            </select>
          </div>
          <div>
            <label>Método de pago</label>
            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
              <option value="Efectivo">Efectivo</option>
              <option value="Transferencia">Transferencia</option>
            </select>
          </div>
        </div>
        {/* Comentario del cliente */}
        <div className={styles.formRow}>
          <label htmlFor="customerMessage">Comentario para tu pedido</label>
          <textarea
            id="customerMessage"
            placeholder="¿Cómo quieres que te preparen algo? ¿Alguna indicación especial?"
            value={customerMessage}
            onChange={e => setCustomerMessage(e.target.value)}
            rows={3}
          />
        </div>
        {/* Mapa solo si es delivery */}
        {deliveryType === 'Domicilio' && (
          <MapClient
            lat={lat}
            lng={lng}
            direccion={address}
            onLocationChange={handleMapChange}
          />
        )}
        <button type="submit" className={styles.payButton}>Hacer pedido</button>
      </form>

      <div className={styles.summarySection}>
        <h2>Tu pedido</h2>
        <p>
          <strong>Nombre:</strong> {firstName} {lastName}
        </p>
        <p>
          <strong>Documento:</strong> {idNumber}
        </p>
        <p>
          <strong>Teléfono:</strong> {phone}
        </p>
        <p>
          <strong>Dirección:</strong>{" "}
          {deliveryType === 'Domicilio'
            ? (address ? address : <span style={{ color: '#888' }}>No ingresada</span>)
            : 'Recoge en local'}
        </p>
        <div className={styles.productListScroll}>
          {cartItems.length === 0 ? (
            <p>No hay productos en el carrito.</p>
          ) : (
            cartItems.map((item, idx) => {
              const addOnsKey = (item.adiciones || [])
                .map(a => `${a.id_adicion}-${a.cantidad}`)
                .join("_");
              const key = `${item.id_producto || item.id}_${addOnsKey}_${idx}`;
              return (
                <div className={styles.item} key={key}>
                  <h3>
                    {item.nombre_producto || item.name}{" "}
                    <span>
                      ${getItemTotal(item).toLocaleString()}
                      {item.quantity > 1 && ` x${item.quantity}`}
                    </span>
                  </h3>
                  <p><strong>Adiciones:</strong></p>
                  <ul style={{ listStyle: "none", paddingLeft: 0, margin: 0 }}>
                    {(item.adiciones && item.adiciones.length > 0) ? (
                      item.adiciones.map((a, i) => (
                        <li key={a.id_adicion || i}>
                          {a.nom_adicion} (x{a.cantidad || 1}) - ${a.precio} c/u
                        </li>
                      ))
                    ) : (
                      <li>Ninguna</li>
                    )}
                  </ul>
                </div>
              );
            })
          )}
        </div>
        <p><strong>Subtotal:</strong> ${(total - deliveryFee).toLocaleString()}</p>
        {deliveryType === 'Domicilio' && (
          <p><strong>Domicilio:</strong> ${deliveryFee.toLocaleString()}</p>
        )}
        <h3><strong>Total:</strong> {total.toLocaleString()}</h3>
      </div>
    </div>
  );
};