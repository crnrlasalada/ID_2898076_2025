import React from 'react'
import { Carousel } from './Carousel'
import styles from "../../assets/Styles/Home.module.css";
import stylesbg from "../../assets/Styles/Quererte/User/global-quererte.module.css";
import { useEffect } from 'react';

export const HomeQuererte = () => {
      useEffect(() => {
    document.body.className = stylesbg.bgQuererte
    return () => {
      document.body.className = ''
    }
  })
  return (
    <>
    <main>
      <Carousel />
      <section className={styles.cajaMision}>
        <div className={styles.mision}>
          <h2>Misión</h2>
          <p>
            En Quererte, nos dedicamos a crear momentos dulces e inolvidables a través de helados artesanales elaborados con ingredientes naturales y de alta calidad. Nuestro propósito es brindar experiencias únicas que conecten emociones con sabores, en un ambiente cálido, familiar y lleno de amor por lo que hacemos.
          </p>
        </div>
      </section>
    </main>
    </>
  );
}
