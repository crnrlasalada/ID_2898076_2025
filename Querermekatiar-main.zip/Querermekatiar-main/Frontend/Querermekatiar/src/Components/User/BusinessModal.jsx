import React from "react";

export const BusinessModal = ({
  isOpen,
  onClose,
  nombreNegocio = "El negocio",
  titulo = "",
  mensaje = "",
  color = "#d35400",
  fondoBoton = "#f0b617",
  colorBoton = "#23272f"
}) => {
  if (!isOpen) return null;

  return (
    <div style={{
      position: "fixed",
      top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,0.3)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{
        background: "#fff",
        borderRadius: "12px",
        padding: "32px 24px",
        boxShadow: "0 4px 16px rgba(0,0,0,0.15)",
        textAlign: "center",
        maxWidth: "350px"
      }}>
        <h2 style={{ marginBottom: "16px", color }}>
          {titulo || `${nombreNegocio} no se encuentra en servicio`}
        </h2>
        <p style={{ marginBottom: "24px" }}>
          {mensaje || "Por el momento no puedes realizar pedidos. Por favor intenta más tarde."}
        </p>
        <button
          style={{
            background: fondoBoton,
            color: colorBoton,
            border: "none",
            borderRadius: "8px",
            padding: "10px 24px",
            fontWeight: "bold",
            cursor: "pointer"
          }}
          onClick={onClose}
        >
          Cerrar
        </button>
      </div>
    </div>
  );
};