import React, { useState } from "react";
import styles from '../../assets/Styles/profile.module.css';
import { UserService } from '../../api/services/UserService';

export const ChangePasswordModal = ({ onClose }) => {
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
  const [msg, setMsg] = useState('');

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setMsg('');
    if (form.newPassword !== form.confirmNewPassword) {
      setMsg('Las contraseñas no coinciden');
      return;
    }
    try {
      await UserService.changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword });
      setMsg('Contraseña cambiada correctamente');
      setForm({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
    } catch {
      setMsg('Error al cambiar la contraseña');
    }
  };

  return (
    <div style={{position:'fixed',top:0,left:0,width:'100vw',height:'100vh',background:'rgba(0,0,0,0.4)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000}}>
      <div style={{background:'#fff',padding:'32px',borderRadius:'12px',minWidth:'320px',boxShadow:'0 2px 16px rgba(0,0,0,0.15)',position:'relative'}}>
        <h3 style={{marginBottom:'16px'}}>Cambiar contraseña</h3>
        <form onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label>Contraseña actual</label>
            <input type="password" name="currentPassword" value={form.currentPassword} onChange={handleChange} required />
          </div>
          <div className={styles.formGroup}>
            <label>Nueva contraseña</label>
            <input type="password" name="newPassword" value={form.newPassword} onChange={handleChange} required />
          </div>
          <div className={styles.formGroup}>
            <label>Confirmar nueva contraseña</label>
            <input type="password" name="confirmNewPassword" value={form.confirmNewPassword} onChange={handleChange} required />
          </div>
          <div style={{display:'flex',gap:'10px',marginTop:'18px'}}>
            <button type="submit" className={styles.btnSave}>Cambiar contraseña</button>
            <button type="button" className={styles.btnSave} style={{background:'#888'}} onClick={onClose}>Cerrar</button>
          </div>
          {msg && <div style={{color:'red', marginTop:'10px'}}>{msg}</div>}
        </form>
      </div>
    </div>
  );
};