import React, { useEffect, useState } from "react";
import Swal from 'sweetalert2';
import styles from '../../assets/Styles/profile.module.css';
import singupStyle from '../../assets/Styles/singup.module.css';
import modalStyle from '../../assets/Styles/product-modal.module.css';
import bgstyles from '../../assets/Styles/bg.module.css';
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { UserService } from '../../api/services/UserService';
import { decodeJwt } from '../../utils/jwtDecode';
import { useNavigate } from 'react-router-dom';
export const ProfileInfo = () => {
  const [profile, setProfile] = useState(null);
  const [form, setForm] = useState({
    nombres: '',
    apellidos: '',
    correo: '',
    documento: '',
    telefono: ''
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [inputErrors, setInputErrors] = useState({ documento: '', telefono: '', nombres: '', apellidos: '' });
  // Estado para modal de cambiar contraseña
  // ...existing code...
  // Detectar si el usuario es Google
  const token = localStorage.getItem('token');
  const jwtPayload = decodeJwt(token);
  const isGoogleUser = jwtPayload?.authType === 'GOOGLE';
  const navigate = useNavigate();

  // Proteger acceso: si no hay token, redirige al login
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
    }
  }, [navigate]);

  // Cargar datos del usuario al montar
  useEffect(() => {
    document.body.className = bgstyles.bg;
    UserService.getProfile()
      .then(res => {
        const data = res.data;
        setProfile(data);
        setForm({
          nombres: data.nombres || '',
          apellidos: data.apellidos || '',
          correo: data.correo || '',
          documento: data.cedula || '',
          telefono: data.telefono || ''
        });
        setLoading(false);
      })
      .catch(() => {
        setError('No se pudo cargar el perfil');
        setLoading(false);
      });
    return () => {
      document.body.className = '';
    };
  }, []);

  // Manejar cambios en el formulario
  const handleChange = e => {
    const { name, value } = e.target;
    // Only allow numbers for documento and telefono, max 10 digits
    if (name === 'documento' || name === 'telefono') {
      let newValue = value.replace(/[^0-9]/g, '');
      if (newValue.length > 10) newValue = newValue.slice(0, 10);
      setForm(prev => ({ ...prev, [name]: newValue }));
      if (newValue.length !== 10 && newValue.length !== 0) {
        setInputErrors(prev => ({ ...prev, [name]: 'Debe tener exactamente 10 dígitos' }));
      } else {
        setInputErrors(prev => ({ ...prev, [name]: '' }));
      }
    } else if (name === 'nombres' || name === 'apellidos') {
      // Prevent numbers in names
      if (/\d/.test(value)) {
        setInputErrors(prev => ({ ...prev, [name]: 'No puede contener números' }));
      } else {
        setInputErrors(prev => ({ ...prev, [name]: '' }));
      }
      setForm(prev => ({ ...prev, [name]: value }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
  };

  // Guardar cambios (excepto email)
  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    // Validate cedula and telefono
    if (form.documento.length !== 10) {
      setInputErrors(prev => ({ ...prev, documento: 'La cédula debe tener exactamente 10 dígitos' }));
      setError('La cédula debe tener exactamente 10 dígitos');
      return;
    }
    if (form.telefono.length !== 10) {
      setInputErrors(prev => ({ ...prev, telefono: 'El teléfono debe tener exactamente 10 dígitos' }));
      setError('El teléfono debe tener exactamente 10 dígitos');
      return;
    }
    if (/\d/.test(form.nombres)) {
      setInputErrors(prev => ({ ...prev, nombres: 'No puede contener números' }));
      setError('El campo nombres no puede contener números');
      return;
    }
    if (/\d/.test(form.apellidos)) {
      setInputErrors(prev => ({ ...prev, apellidos: 'No puede contener números' }));
      setError('El campo apellidos no puede contener números');
      return;
    }
    try {
      const { nombres, apellidos, correo, documento, telefono } = form;
      await UserService.updateProfile({
        nombres,
        apellidos,
        telefono,
        cedula: documento
      });
      Swal.fire({
        icon: 'success',
        title: '¡Datos actualizados correctamente!',
        showConfirmButton: false,
        timer: 2000
      });
    } catch {
      setError('Error al actualizar los datos');
    }
  };

  if (loading) return <div>Cargando...</div>;

  return (
    <>
      <section className={styles.profileInfo}>
        <form className={styles.formGrid} onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label>Nombres</label>
            <input required type="text" name="nombres" value={form.nombres} onChange={handleChange} />
            {inputErrors.nombres && <span style={{ color: 'red', fontSize: '0.9em' }}>{inputErrors.nombres}</span>}
          </div>
          <div className={styles.formGroup}>
            <label>Apellidos</label>
            <input required type="text" name="apellidos" value={form.apellidos} onChange={handleChange} />
            {inputErrors.apellidos && <span style={{ color: 'red', fontSize: '0.9em' }}>{inputErrors.apellidos}</span>}
          </div>
          <div className={styles.formGroup}>
            <label>Correo</label>
            <input type="email" name="correo" value={form.correo} disabled />
          </div>
          <div className={styles.formGroup}>
            <label>Número de documento</label>
            <input required type="text" name="documento" value={form.documento} onChange={handleChange} maxLength={10} pattern="[0-9]{10}" inputMode="numeric" />
            {inputErrors.documento && <span style={{ color: 'red', fontSize: '0.9em' }}>{inputErrors.documento}</span>}
          </div>
          <div className={styles.formGroup}>
            <label>Teléfono</label>
            <input required type="text" name="telefono" value={form.telefono} onChange={handleChange} maxLength={10} pattern="[0-9]{10}" inputMode="numeric" />
            {inputErrors.telefono && <span style={{ color: 'red', fontSize: '0.9em' }}>{inputErrors.telefono}</span>}
          </div>
          <div className={styles.formGroupBtn} style={{ display: 'flex', gap: '10px' }}>
            {!isGoogleUser && (
              <button
                type="button"
                className={styles.btnSave}
                style={{ order: 0 }}
                onClick={() => setShowModal(true)}
              >
                Cambiar contraseña
              </button>
            )}
            <button type="submit" className={styles.btnSave} style={{ order: 1 }}>
              Guardar
            </button>
            <button
              type="button"
              className={styles.btnDelete}
              style={{ order: 2 }}
              onClick={async () => {
                const result = await Swal.fire({
                  title: '¿Eliminar cuenta?',
                  text: 'Esta acción no se puede deshacer. ¿Seguro que deseas eliminar tu cuenta?',
                  icon: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#e53935',
                  cancelButtonColor: '#888',
                  confirmButtonText: 'Sí, eliminar',
                  cancelButtonText: 'Cancelar'
                });
                if (result.isConfirmed) {
                  try {
                    const correo = form.correo || (profile && profile.correo);
                    await UserService.deleteUserByEmail(correo);
                    localStorage.removeItem('token');
                    await Swal.fire({
                      icon: 'success',
                      title: 'Cuenta eliminada',
                      text: 'Tu cuenta ha sido eliminada correctamente.',
                      confirmButtonText: 'Entendido'
                    });
                    navigate('/');
                  } catch (err) {
                    await Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: 'No se pudo eliminar la cuenta. Intenta de nuevo.',
                      confirmButtonText: 'Entendido'
                    });
                  }
                }
              }}
            >
              Eliminar cuenta
            </button>
          </div>
          {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}
        </form>
        {/* Modal para cambiar contraseña */}
        {showModal && <ChangePasswordModal onClose={() => setShowModal(false)} />}
      </section>
    </>
  );
};

// MODAL CAMBIAR CONTRASEÑA (al final del archivo)
const ChangePasswordModal = ({ onClose }) => {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [triedSubmit, setTriedSubmit] = useState(false);
  const [msg, setMsg] = useState("");

  // Validaciones de la nueva contraseña
  const hasMinLength = newPassword.length >= 8;
  const hasUppercase = /[A-Z]/.test(newPassword);
  const hasLowercase = /[a-z]/.test(newPassword);
  const hasNumber = /\d/.test(newPassword);
  const passwordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber;
  const confirmValid = confirmNewPassword === newPassword && confirmNewPassword.length > 0;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setTriedSubmit(true);
    setMsg("");
    if (!passwordValid || !confirmValid) return;
    try {
      await UserService.changePassword({ actualPassword: currentPassword, newPassword });
      Swal.fire({
        icon: "success",
        title: "Contraseña cambiada correctamente",
        confirmButtonText: "Entendido"
      });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
      setTriedSubmit(false);
      onClose();
    } catch (error) {
      let errorMsg = "Error al cambiar la contraseña";
      if (error?.response?.data) {
        errorMsg = error.response.data;
      }
      Swal.fire({
        icon: "error",
        title: "Error",
        text: errorMsg,
        confirmButtonText: "Cerrar"
      });
    }
  };

  return (
    <div className={modalStyle.overlay}>
      <div
        className={modalStyle.modal}
        style={{
          maxWidth: 340,
          minWidth: 260,
          width: '100%',
          background: '#fff',
          color: '#23272f',
          borderRadius: '14px',
          boxShadow: '0 2px 16px rgba(0,0,0,0.15)',
          padding: 0,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: 'auto',
          minHeight: 'unset',
        }}
      >
        <button
          className={modalStyle.closeButton}
          onClick={onClose}
          aria-label="Cerrar modal"
          style={{
            color: '#888',
            fontSize: '1.5rem',
            fontWeight: 400,
            top: 10,
            right: 10,
            background: 'none',
            border: 'none',
            position: 'absolute',
            padding: '0 6px',
            lineHeight: 1
          }}
        >
          ×
        </button>
        <div style={{ width: '100%', padding: '22px 16px 10px 16px', boxSizing: 'border-box' }}>
          <h3 style={{ color: '#23272f', marginBottom: '18px', textAlign: 'center', fontWeight: 700, fontSize: '1.15rem', letterSpacing: '0.5px' }}>Cambiar contraseña</h3>
          <form onSubmit={handleSubmit}>
            <div className={singupStyle["password-container"]} style={{ marginBottom: 16 }}>
              <input
                className={singupStyle["user-date"]}
                type={showCurrent ? "text" : "password"}
                placeholder="Contraseña actual"
                value={currentPassword}
                onChange={e => setCurrentPassword(e.target.value)}
                required
                style={{ paddingRight: "40px", background: '#fff', color: '#23272f', border: '1px solid #bbb' }}
                autoComplete="current-password"
              />
              <button
                type="button"
                className={singupStyle["show-password-btn"]}
                onClick={() => setShowCurrent((prev) => !prev)}
                aria-label={showCurrent ? "Ocultar contraseña" : "Mostrar contraseña"}
                tabIndex={-1}
              >
                {showCurrent ? (
                  <FaEyeSlash className={singupStyle["eye-icon"]} style={{ color: '#23272f' }} />
                ) : (
                  <FaEye className={singupStyle["eye-icon"]} style={{ color: '#23272f' }} />
                )}
              </button>
            </div>

            <div className={singupStyle["password-container"]} style={{ marginBottom: 16 }}>
              <input
                className={`${singupStyle["user-date"]} ${triedSubmit && (!passwordValid || newPassword.length === 0) ? singupStyle.input_error : ''}`}
                type={showNew ? "text" : "password"}
                placeholder="Nueva contraseña"
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                required
                minLength={8}
                style={{ paddingRight: "40px", background: '#fff', color: '#23272f', border: '1px solid #bbb' }}
                autoComplete="new-password"
              />
              <button
                type="button"
                className={singupStyle["show-password-btn"]}
                onClick={() => setShowNew((prev) => !prev)}
                aria-label={showNew ? "Ocultar contraseña" : "Mostrar contraseña"}
                tabIndex={-1}
              >
                {showNew ? (
                  <FaEyeSlash className={singupStyle["eye-icon"]} style={{ color: '#23272f' }} />
                ) : (
                  <FaEye className={singupStyle["eye-icon"]} style={{ color: '#23272f' }} />
                )}
              </button>
            </div>

            {newPassword.length > 0 && (
              <div className={singupStyle.password_rules_box} style={{ background: 'rgba(0,0,0,0.07)', border: '1px solid #bbb', color: '#23272f' }}>
                <ul className={singupStyle.password_rules}>
                  <li className={hasMinLength ? singupStyle.rule_ok : singupStyle.rule_error}>Mínimo 8 caracteres</li>
                  <li className={hasUppercase ? singupStyle.rule_ok : singupStyle.rule_error}>Al menos una mayúscula</li>
                  <li className={hasLowercase ? singupStyle.rule_ok : singupStyle.rule_error}>Al menos una minúscula</li>
                  <li className={hasNumber ? singupStyle.rule_ok : singupStyle.rule_error}>Al menos un número</li>
                </ul>
              </div>
            )}
            {triedSubmit && newPassword.length === 0 && <div className={singupStyle.field_error}>La nueva contraseña es obligatoria.</div>}
            {triedSubmit && newPassword.length > 0 && !passwordValid && <div className={singupStyle.field_error}>La nueva contraseña no cumple los requisitos.</div>}

            <input
              className={`${singupStyle["user-date"]} ${triedSubmit && (confirmNewPassword.length === 0 || confirmNewPassword !== newPassword) ? singupStyle.input_error : ''}`}
              type="password"
              placeholder="Confirmar nueva contraseña"
              value={confirmNewPassword}
              onChange={e => setConfirmNewPassword(e.target.value)}
              required
              minLength={6}
              autoComplete="new-password"
              style={{ background: '#fff', color: '#23272f', border: '1px solid #bbb' }}
            />
            {triedSubmit && confirmNewPassword.length === 0 && <div className={singupStyle.field_error}>Debes confirmar la nueva contraseña.</div>}
            {triedSubmit && confirmNewPassword.length > 0 && confirmNewPassword !== newPassword && <div className={singupStyle.field_error}>Las contraseñas no coinciden.</div>}

            <div style={{ display: "flex", gap: "10px", marginTop: "18px", justifyContent: 'center' }}>
              <button type="submit" className={modalStyle.confirmButton} style={{ background: '#1db954', color: 'white', borderRadius: '10px', fontWeight: 600, fontSize: '1rem', padding: '12px 20px', border: 'none', width: 'auto' }}>
                Cambiar contraseña
              </button>
            </div>
            {msg && <div style={{ color: "#f87171", marginTop: "10px" }}>{msg}</div>}
          </form>
        </div>
      </div>
    </div>
  );
};


