import React, { useState } from "react";
import styles from '../../assets/Styles/Cart.module.css';
import { useCart } from '../../Hooks/useCart';
import { ProductModal } from "./ProductModal";
import { EditCartItemModal } from "./EditCartItemModal";
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";

// Importa la imagen por defecto para "Crea tu propio helado"
import customIceCreamImg from "../../assets/Icons/CustomIceCream.png";
// Imagen por defecto para cualquier producto sin imagen
import defaultImg from "../../assets/Icons/defaultImage.webp";

export const Cart = ({ onClose }) => {
  const { cartItems, addToCart, removeFromCart, clearCart, removeItem, updateItem } = useCart();
  const [editItem, setEditItem] = useState(null);
  const location = useLocation();
  const isQuererte = location.pathname.includes("menu-quererte") || location.pathname.includes("home-quererte");

  const getItemTotal = (item) => {
    const base = item.precio || item.price || 0;
    const adicionesTotal = (item.adiciones || []).reduce(
      (sum, a) => sum + ((a.precio || 0) * (a.cantidad || 1)),
      0
    );
    return (base + adicionesTotal) * item.quantity;
  };

  const getCartTotal = () => {
    return cartItems.reduce((sum, item) => sum + getItemTotal(item), 0);
  };

  // Función para obtener la imagen correcta del producto
  const getProductImage = (item) => {
    // Si es "Crea tu propio helado"
    if (
      (item.nombre_producto || item.name || "").toLowerCase().includes("crea tu propio helado")
    ) {
      return customIceCreamImg;
    }
    // Si tiene url_imagen o urlImage
    if (item.url_imagen) return item.url_imagen;
    if (item.urlImage) return item.urlImage;
    // Si tiene image
    if (item.image) return item.image;
    // Si no tiene ninguna, retorna imagen por defecto
    return defaultImg;
  };

  return (
    <div className={styles.cartContainer}>
      <div className={styles.cartTitle}>
        Carrito de compras
        {onClose && (
          <button className={styles.closeCart} onClick={onClose} aria-label="Cerrar carrito">
            ×
          </button>
        )}
      </div>
      <div className={styles.cartItemsScroll}>
        {(cartItems && cartItems.length > 0) ? (
          cartItems.map((item, idx) => {
            const adicionesKey = (item.adiciones || [])
              .map(a => `${a.id_adicion}-${a.cantidad}`)
              .join("_");
            const key = `${item.id_producto || item.id}_${adicionesKey}_${idx}`;
            return (
              <div className={styles.cartItem} key={key}>
                <img
                  src={getProductImage(item)}
                  alt={item.nombre_producto || item.name}
                  onError={e => { e.target.src = defaultImg; }}
                />
                <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
                  <div className={styles.itemInfo}>
                    <div>{item.nombre_producto || item.name}</div>
                    <div className={styles.price}>
                      ${item.precio ? item.precio.toLocaleString() : item.price.toLocaleString()}
                    </div>
                  </div>
                  {(item.adiciones && item.adiciones.length > 0) && (
                    <div className={styles.adicionesDesc}>
                      {item.adiciones.map((a, i) => (
                        <div key={a.id_adicion || i} style={{ fontSize: "0.9em", color: "#666" }}>
                          + {a.nom_adicion} (x{a.cantidad || 1}) ${a.precio} c/u
                        </div>
                      ))}
                    </div>
                  )}
                  <div className={styles.cartActions}>
                    <div className={styles.quantityControl}>
                      <button
                        className={isQuererte ? styles.quantityBtnBlack : styles.quantityBtnYellow}
                        onClick={() => removeFromCart(item)}
                      >-</button>
                      <span>{item.quantity}</span>
                      <button
                        className={isQuererte ? styles.quantityBtnBlack : styles.quantityBtnYellow}
                        onClick={() => addToCart({ ...item, quantity: 1 })}
                      >+</button>
                    </div>
                    <button className={styles.editButton} onClick={() => setEditItem(item)}>Editar</button>
                    <button className={styles.deleteButton} onClick={() => removeItem(item)}>Eliminar</button>
                    <div className={styles.itemTotal}>
                      ${getItemTotal(item).toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className={styles.emptyCart}>El carrito está vacío.</div>
        )}
      </div>
      <div>
        <div className={styles.totalSection}>
          <span>Total:</span>
          <span>${getCartTotal().toLocaleString()}</span>
        </div>
        <Link to={isQuererte ? "/usuario/menu-quererte/resumen-pedido" : "/usuario/menu-amekatiar/resumen-pedido"}>
          <button className={styles.button}>Ir a pagar</button>
        </Link>
        <button className={`${styles.button} ${styles.clearButton}`} onClick={clearCart}>
          Vaciar carrito
        </button>
      </div>
      {editItem && (
        <EditCartItemModal
          item={editItem}
          adiciones={editItem.adicionesDisponibles || []}
          isOpen={!!editItem}
          onClose={() => setEditItem(null)}
          onSave={(updatedProduct) => {
            updateItem(editItem, updatedProduct);
            setEditItem(null);
          }}
        />
      )}
    </div>
  );
};