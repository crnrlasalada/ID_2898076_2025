import React, { useEffect, useState } from "react";
import bgstyles from "../../assets/Styles/bg2.module.css";
import { idUserToken } from '../../api/utils/jwtDecode';
import styles from "../../assets/Styles/Order-status.module.css";
import cardStyles from "../../assets/Styles/OrderCard.module.css";
import { OrderService } from "../../api/services/OrderService";
import { OrderStatusBar } from "./OrderStatusBar";
import { OrderDetail } from "./OrderDetail";

const formatDate = (iso) => {
  const date = new Date(iso);
  return date.toLocaleString();
};

const FINAL_STATUSES = ["Entregado", "Rechazado"];

export const OrderStatus = () => {
  const [orders, setOrders] = useState([]);
  const [expandedOrderId, setExpandedOrderId] = useState(null);

  useEffect(() => {
    document.body.className = bgstyles.bg;
    const clienteId = idUserToken();
    OrderService.getOrderStatus(clienteId)
      .then(data => setOrders(Array.isArray(data) ? data : []))
      .catch(() => setOrders([]));

    // --- SSE: Actualización en tiempo real ---
    const token = localStorage.getItem('token');
    const eventSource = new EventSource(`http://localhost:8080/api/order/stream?token=${token}`);
    eventSource.addEventListener("order-status", (event) => {
      const data = JSON.parse(event.data);
      // Si el pedido está en estado final, elimínalo del listado
      if (FINAL_STATUSES.includes(data.status)) {
        setOrders(prevOrders => prevOrders.filter(order => order.id !== data.idOrder));
      } else {
        setOrders(prevOrders =>
          prevOrders.map(order =>
            order.id === data.idOrder
              ? { ...order, status: data.status }
              : order
          )
        );
      }
    });
    eventSource.onerror = () => eventSource.close();

    return () => {
      document.body.className = "";
      eventSource.close();
    };
  }, []);

  const handleExpand = (orderId) => {
    setExpandedOrderId(expandedOrderId === orderId ? null : orderId);
  };

  // Filtra los pedidos que no están en estado final al renderizar
  const visibleOrders = orders.filter(order => !FINAL_STATUSES.includes(order.status));

  return (
    <div className={styles.pageContainer}>
      <h2 className={styles.title}>Mis pedidos</h2>
      {visibleOrders.length === 0 ? (
        <p className={styles.noPedidos}>No hay pedidos.</p>
      ) : (
        visibleOrders.map(order => (
          <div
            key={order.id}
            className={cardStyles.card}
          >
            <div className={cardStyles.header}>
              <h3>Pedido #{order.id}</h3>
              <span>{formatDate(order.dateTime)}</span>
            </div>
            <p><strong>Para:</strong> {order.firstName} {order.lastName}</p>
            <p><strong>Dirección:</strong> {order.address || "Sin dirección"}</p>
            <OrderStatusBar estadoActual={order.status} />
            <p><strong>Total:</strong> ${order.total.toLocaleString()}</p>
            <button
              className={cardStyles.detailButton}
              onClick={() => handleExpand(order.id)}
            >
              {expandedOrderId === order.id ? "Ocultar detalle" : "Ver detalle"}
            </button>
            {expandedOrderId === order.id && (
              <OrderDetail order={order} />
            )}
          </div>
        ))
      )}
    </div>
  );
};