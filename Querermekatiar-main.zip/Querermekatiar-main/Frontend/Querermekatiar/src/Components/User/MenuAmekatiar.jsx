import { ProductCardAmekatiar } from "./ProductCardAmekatiar";
import stylesbg from "../../assets/Styles/Amekatiar/User/global-amekatiar.module.css";
import { useEffect, useState } from "react";
import { CatalogService } from "../../api/services/CatalogService";
import { useSearchParams } from "react-router-dom";
import { BusinessModal } from "./BusinessModal";
import style from "../../assets/Styles/menu.module.css";
import LoaderHamburguesa from "../ui/LoaderHamburguesa";

export const MenuAmekatiar = () => {
  const [amekatiarProducts, setAmekatiarProducts] = useState([]);
  const [businessActive, setBusinessActive] = useState(1);
  const [searchParams] = useSearchParams();
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const nameCategory = searchParams.get("categoria");

  useEffect(() => {
    CatalogService.getCatalogAmekatiar()
      .then((response) => {
        const data = Array.isArray(response.data) ? response.data : [];
        setAmekatiarProducts(data);
        if (data.length > 0 && typeof data[0].businessActive !== "undefined") {
          setBusinessActive(data[0].businessActive);
        }
        // Espera 1 segundo antes de quitar el loader
        setTimeout(() => setLoading(false), 500);
      })
      .catch(() => {
        setAmekatiarProducts([]);
        setTimeout(() => setLoading(false), 500);
      });
  }, []);

  useEffect(() => {
    document.body.className = stylesbg.bgAmekatiar;
    return () => {
      document.body.className = '';
    };
  }, []);

  useEffect(() => {
    if (businessActive === 0) setShowModal(true);
    else setShowModal(false);
  }, [businessActive]);

  const filteredProducts = nameCategory
    ? amekatiarProducts.filter(p => String(p.nameCategory) === String(nameCategory))
    : amekatiarProducts;

  return (
    <>
      <BusinessModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        nombreNegocio="Amekatiar"
        titulo="Amekatiar no está disponible"
        mensaje="Por el momento Amekatiar no está en servicio. Vuelve pronto para disfrutar nuestros productos."
        color="#d35400"
        fondoBoton="#f0b617"
        colorBoton="#23272f"
      />
      <div className={style.productsContainer}>
        {loading ? (
          <LoaderHamburguesa message="Cargando productos de Amekatiar..." />
        ) : filteredProducts.length === 0 ? (
          <p>No hay productos en esta categoría.</p>
        ) : (
          filteredProducts.map(p => (
            <ProductCardAmekatiar
              key={p.id}
              product={p}
              businessActive={businessActive}
            />
          ))
        )}
      </div>
    </>
  );
};