import React, { useEffect, useState } from 'react';
import styles from '../../assets/Styles/order-summary.module.css';
import { useCart } from '../../Hooks/useCart';
import bgstyles from '../../assets/Styles/bg.module.css';
import { useLocation, Link } from 'react-router-dom';
import { EditCartItemModal } from './EditCartItemModal';

// Importa las imágenes por defecto
import customIceCreamImg from "../../assets/Icons/CustomIceCream.png";
import defaultImg from "../../assets/Icons/defaultImage.webp";

export const OrderSummary = () => {
  const { cartItems, addToCart, removeFromCart, removeItem, updateItem } = useCart();
  const location = useLocation();
  const isQuererte = location.pathname.includes("quererte");
  const [editItem, setEditItem] = useState(null);

  useEffect(() => {
    document.body.className = bgstyles.bg;
    return () => {
      document.body.className = '';
    };
  }, []);

  const getItemTotal = (product) => {
    const base = product.precio || product.price || 0;
    const adicionesTotal = (product.adiciones || []).reduce(
      (sum, a) => sum + ((a.precio || 0) * (a.cantidad || 1)),
      0
    );
    return (base + adicionesTotal) * product.quantity;
  };

  const getCartTotal = () => {
    return cartItems.reduce((sum, item) => sum + getItemTotal(item), 0);
  };

  // Función para obtener la imagen correcta del producto
  const getProductImage = (product) => {
    if (
      (product.nombre_producto || product.name || "")
        .toLowerCase()
        .includes("crea tu propio helado")
    ) {
      return customIceCreamImg;
    }
    if (product.url_imagen) return product.url_imagen;
    if (product.urlImage) return product.urlImage;
    if (product.image) return product.image;
    return defaultImg;
  };

  const checkoutPath = isQuererte
    ? "/usuario/menu-quererte/resumen-pedido/validacion"
    : "/usuario/menu-amekatiar/resumen-pedido/validacion";

  return (
    <main className={styles.container}>
      <div className={styles.card}>
        <h2 className={styles.title}>Resumen del pedido</h2>
        {cartItems.length === 0 ? (
          <div className={styles.empty}>El carrito está vacío.</div>
        ) : (
          <div className={styles.itemsScroll}>
            {cartItems.map((product, idx) => {
              const adicionesKey = (product.adiciones || [])
                .map(a => `${a.id_adicion}-${a.cantidad}`)
                .join("_");
              const key = `${product.id_producto || product.id}_${adicionesKey}_${idx}`;
              return (
                <div key={key} className={styles.item}>
                  <img
                    src={getProductImage(product)}
                    alt={product.nombre_producto || product.name}
                    className={styles.image}
                    onError={e => { e.target.src = defaultImg; }}
                  />
                  <div className={styles.details}>
                    <h3 className={styles.name}>{product.nombre_producto || product.name}</h3>
                    {(product.adiciones && product.adiciones.length > 0) && (
                      <div className={styles.desc}>
                        {product.adiciones.map((a, i) => (
                          <div key={a.id_adicion || i} style={{ fontSize: "0.95em", color: "#666" }}>
                            + {a.nom_adicion} (x{a.cantidad || 1}) ${a.precio} c/u
                          </div>
                        ))}
                      </div>
                    )}
                    <p className={styles.price}>
                      ${((product.precio || product.price || 0) +
                        (product.adiciones || []).reduce((sum, a) => sum + ((a.precio || 0) * (a.cantidad || 1)), 0)
                      ).toLocaleString()} x {product.quantity}
                    </p>
                  </div>
                  <div className={styles.actions}>
                    <div className={styles.counter}>
                      <button onClick={() => removeFromCart(product)}>-</button>
                      <span>{product.quantity}</span>
                      <button onClick={() => addToCart({ ...product, quantity: 1 })}>+</button>
                    </div>
                    <button
                      className={styles.editButton}
                      onClick={() => setEditItem(product)}
                    >
                      Editar
                    </button>
                    <button
                      className={styles.deleteButton}
                      onClick={() => removeItem(product)}
                    >
                      Eliminar
                    </button>
                  </div>
                  <div className={styles.itemTotal}>
                    ${getItemTotal(product).toLocaleString()}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className={styles.sidebar}>
        <Link to={checkoutPath}>
          <button className={styles.button} disabled={cartItems.length === 0}>
            Realizar pedido
          </button>
        </Link>
        <Link to={isQuererte ? "/usuario/menu-quererte" : "/usuario/menu-amekatiar"}>
          <button className={styles.buttonSecondary}>Seguir comprando</button>
        </Link>
        <div className={styles.total}>
          <span>Total:</span>
          <strong>
            ${cartItems.length === 0 ? "0" : getCartTotal().toLocaleString()}
          </strong>
        </div>
      </div>

      {editItem && (
        <EditCartItemModal
          item={editItem}
          adiciones={editItem.adicionesDisponibles || []}
          isOpen={!!editItem}
          onClose={() => setEditItem(null)}
          onSave={(updatedProduct) => {
            updateItem(editItem, updatedProduct);
            setEditItem(null);
          }}
        />
      )}
    </main>
  );
};