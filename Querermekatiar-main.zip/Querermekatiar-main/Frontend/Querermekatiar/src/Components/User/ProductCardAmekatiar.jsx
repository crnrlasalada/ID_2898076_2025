import React, { useState } from "react";
import styles from "../../assets/Styles/Amekatiar/User/productCardAmekatiar.module.css";
import { ProductModal } from "./ProductModal";

export const ProductCardAmekatiar = ({ product, businessActive }) => {
  const [openModal, setOpenModal] = useState(false);

  const handleOpenModal = () => setOpenModal(true);
  const handleCloseModal = () => setOpenModal(false);

  return (
    <>
      <div className={styles.card}>
        <img
          src={product.urlImage}
          alt={product.name}
          className={styles.image}
        />

        <h3 className={styles.name}>
          {product.name.toUpperCase()}
        </h3>

        <p className={styles.price}>
          Precio: ${product.price.toLocaleString("es-CO", { minimumFractionDigits: 0 })}
        </p>

        <p className={styles.description}>
          {product.description}
        </p>

        <div className={styles.controls}>
          {businessActive !== 0 && (
            <button onClick={handleOpenModal} className={styles.addButton}>
              Agregar al carrito
            </button>
          )}
        </div>
      </div>

      {openModal && (
        <ProductModal
          product={product}
          onClose={handleCloseModal}
          isOpen={openModal}
        />
      )}
    </>
  );
};