import React, { useState, useEffect } from "react";
import logotype from '../../assets/images/logotype_both.webp';
import styles from "../../assets/Styles/sidebar.module.css";
import { Link } from "react-router-dom";

export const AsideBarProfile = () => {
    const isQuererte = location.pathname.includes("home-quererte")
    return (
        <aside className={styles.asidebar}>
      <figure className={styles.containerImg}>
        <img className={styles.logotype} src={logotype} alt="Logotype_both" />
      </figure>
      <nav className={styles.navAsidebar}>
        <ul>
          <li>
            <Link to={isQuererte ? "/usuario/home-quererte/perfil" : "/usuario/home-amekatiar/perfil"}>
              <div className={styles.profileDiv}>
                <svg
                  className={styles.profileIcon}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="1.5"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.5 20.25a8.25 8.25 0 1115 0H4.5z"
                  />
                </svg>
                <span>Perfil</span>
              </div>
            </Link>
          </li>
          <li>
            <Link
              to={
                isQuererte
                  ? "/usuario/home-quererte/perfil/historial-compras"
                  : "/usuario/home-amekatiar/perfil/historial-compras"
              }
            >
              <div className={styles.historyDiv}>
                <svg
                  className={styles.historyIcon}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth="1.5"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 6v6l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                <span>Historial pedidos</span>
              </div>
            </Link>
          </li>
        </ul>
      </nav>
    </aside>
    );
};