import React, { useState, useRef, useEffect } from 'react';
import shoping_cart from "../../assets/Icons/Shoping_cart.webp";
import cartsvg from "../../assets/Icons/cart-svgrepo-com.svg"
import exit from "../../assets/Icons/exit.webp";
import profile from "../../assets/Icons/profile.webp";
import styles from "../../assets/Styles/NavBar.module.css";
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { Cart } from './Cart';
import { useCart } from '../../Hooks/useCart';

export const NavBar = () => {
  const [open, setOpen] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const cartIconRef = useRef(null);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    Swal.fire({
      title: '¿Cerrar sesión?',
      text: '¿Estás seguro que deseas salir de tu cuenta?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#16a34a',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, cerrar sesión',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {

        navigate('/');

        localStorage.removeItem('token');
        Swal.fire({
          toast: true,
          position: 'top-end',
          title: 'HASTA LA PROXIMA',
          showConfirmButton: false,
          timer: 1500,
          background: '#d35400',
          color: '#fff'
        });
      }
    });
  };
  const isQuererte = ["home-quererte", "menu-quererte"].some(str => location.pathname.includes(str));
  const isPerfil = location.pathname.includes("/perfil");
  const isOrderSummary = location.pathname.includes("resumen-pedido");
  const { cartItems } = useCart();

  // Cierra el carrito si se hace click fuera
  useEffect(() => {
    function handleClickOutside(event) {
      if (
        cartIconRef.current &&
        !cartIconRef.current.contains(event.target) &&
        !event.target.closest(`.${styles.cartPanel}`)
      ) {
        setShowCart(false);
      }
    }
    if (showCart) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [showCart]);

  // Cierra el carrito automáticamente al cambiar de ruta
  useEffect(() => {
    setShowCart(false);
  }, [location.pathname]);

  // Desactiva el scroll del body cuando el carrito está abierto
  useEffect(() => {
    if (showCart) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [showCart]);

  // Calcula la cantidad total de productos
  const totalQuantity = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <header className={`${styles.containerMenu} ${isPerfil ? styles.containerMenuPerfil : ""}`}>
        <nav className={styles.menu}>
          <Link to={isQuererte ? "/usuario/home-quererte/perfil" : "/usuario/home-amekatiar/perfil"}>
            <img className={styles.img1} src={profile} alt="perfil-logo" />
          </Link>
          <button
            className={styles.hamburger}
            onClick={() => setOpen(true)}
            aria-label="Abrir menú"
          >
            <span className={styles.bar}></span>
            <span className={styles.bar}></span>
            <span className={styles.bar}></span>
          </button>
          <div className={`${styles.linksHome} ${open ? styles.linksHomeOpen : ""}`}>
            <Link
              to={isQuererte ? "/usuario/home-quererte" : "/usuario/home-amekatiar"}
              onClick={() => setOpen(false)}
            >
              Home
            </Link>
            <Link
              to={isQuererte ? "/usuario/menu-quererte" : "/usuario/menu-amekatiar"}
              onClick={() => setOpen(false)}
            >Menú
            </Link>

            <Link
              to={
                isQuererte
                  ? "/usuario/home-quererte/estado-pedido"
                  : "/usuario/home-amekatiar/estado-pedido"
              }
              onClick={() => setOpen(false)}
            >
              Mis pedidos
            </Link>
          </div>
          {/* Icono del carrito con contador, pero deshabilitado en resumen-pedido */}
          <span ref={cartIconRef} style={{ position: "relative" }}>
            <img
              className={styles.img1}
              src={shoping_cart}
              alt="shoping_cart"
              style={{
                cursor: isOrderSummary ? "not-allowed" : "pointer",
                opacity: isOrderSummary ? 0.6 : 1
              }}
              onClick={
                isOrderSummary
                  ? undefined
                  : () => setShowCart((prev) => !prev)
              }
              tabIndex={isOrderSummary ? -1 : 0}
              aria-disabled={isOrderSummary}
            />
            {totalQuantity > 0 && (
              <span
                style={{
                  position: "absolute",
                  top: 0,
                  right: 0,
                  background: "#ff6600",
                  color: "#fff",
                  borderRadius: "50%",
                  padding: "2px 7px",
                  fontSize: "0.8rem",
                  fontWeight: "bold",
                  zIndex: 10,
                }}
              >
                {totalQuantity}
              </span>
            )}
          </span>
          {localStorage.getItem('token') && (
            <img
              className={styles.img1}
              src={exit}
              alt="logo-salir"
              style={{ cursor: 'pointer' }}
              onClick={handleLogout}
            />
          )}
        </nav>
      </header>
      {open && (
        <div
          className={styles.headerOverlay}
          onClick={() => setOpen(false)}
        ></div>
      )}

      {/* Panel flotante del carrito fuera del header/nav */}
      {!isOrderSummary && showCart && (
        <div className={styles.cartPanel}>
          <Cart onClose={() => setShowCart(false)} />
        </div>
      )}
    </>
  );
}
