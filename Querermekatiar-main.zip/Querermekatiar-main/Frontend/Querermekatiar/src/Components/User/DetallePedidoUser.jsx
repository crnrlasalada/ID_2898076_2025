import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import styles from "../../assets/Styles/DetallePedido.module.css";
import bgstyles from "../../assets/Styles/bg.module.css";

//eliminar a la hora del backend 
const pedidosEjemplo = [
  {
    idPedido: "0001",
    fecha: "2025-11-03T13:34:00",
    cliente: "Isabel Gutiérrez",
    metodoPago: "Efectivo",
    ubicacion: "Cra 20 #45-67, Bogotá",
    totalPedido: 45000,
    productos: [
      { nombre: "Hamburguesa", cantidad: 1, precio: 25000 },
      { nombre: "Gaseosa", cantidad: 2, precio: 10000 },
    ],
  },
  {
    idPedido: "0002",
    fecha: "2025-11-04T14:10:00",
    cliente: "Carlos Pérez",
    metodoPago: "Nequi",
    ubicacion: "Cl 10 #22-33, Medellín",
    totalPedido: 60000,
    productos: [
      { nombre: "Pizza", cantidad: 2, precio: 30000 },
    ],
  },
  {
  idPedido: "0003",
  fecha: "2025-11-05T12:30:00",
  cliente: "Laura Martínez",
  metodoPago: "Tarjeta",
  ubicacion: "Cl 15 #34-12, Cali",
  totalPedido: 42000,
  productos: [
    { nombre: "Arepa rellena", cantidad: 2, precio: 20000 },
    { nombre: "Jugo natural", cantidad: 1, precio: 22000 },
  ],
}

];



const DetallePedidoUsuario = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // ✅ Aplicar fondo
  useEffect(() => {
    document.body.className = bgstyles.bg;
    return () => {
      document.body.className = "";
    };
  }, []);

  const pedido = pedidosEjemplo.find((p) => p.idPedido === id);

  if (!pedido) {
    return <div className={styles.mensaje}>Pedido no encontrado</div>;
  }

  const date = new Date(pedido.fecha);
  const fechaFormateada = date.toLocaleDateString("es-CO");
  const horaFormateada = date.toLocaleTimeString("es-CO", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <div className={styles.detalleCard}>
      <button className={styles.backButton} onClick={() => navigate(-1)}>← Volver a pedidos</button>

      <div className={styles.timeline}>
        <h3>Pedido #{pedido.idPedido}</h3>
        <p><strong>Cliente:</strong> {pedido.cliente}</p>
        <p><strong>Fecha:</strong> {fechaFormateada}, {horaFormateada}</p>
        <p><strong>Método de pago:</strong> {pedido.metodoPago}</p>
        <p><strong>Ubicación:</strong> {pedido.ubicacion}</p>
      </div>

      <div className={styles.productos}>
        <h4>Productos</h4>
        {pedido.productos.map((prod, idx) => (
          <div key={idx} className={styles.productoItem}>
            <p><strong>{prod.nombre}</strong> x{prod.cantidad}</p>
            <p>Subtotal: ${prod.precio.toLocaleString("es-CO")}</p>
          </div>
        ))}
      </div>

      <div className={styles.total}>
        Total pedido: <strong>${pedido.totalPedido.toLocaleString("es-CO")}</strong>
      </div>
    </div>
  );
};

export default DetallePedidoUsuario;
