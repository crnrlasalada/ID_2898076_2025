import styles from "../../assets/Styles/Footer.module.css";
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";

export const Footer = () => {
  const location = useLocation();
  const isPerfil = location.pathname.includes("/perfil");
  const isQuererte = ["home-quererte", "menu-quererte"].some(str => location.pathname.includes(str));

  return (
    <>
      <footer className={`${styles.footer} ${isPerfil ? styles.footerPerfil : ""}`}>
        <div className={styles.footerSection}>
          <h3>Sobre nosotros</h3>
          <p className={styles.contenido}>
            Amekatiar y Quererte ofrecen lo mejor de la gastronomía local en Concordia: un restaurante de comida típica con auténtico sabor casero y una heladería artesanal con productos frescos y deliciosos, ideales para compartir en familia o con amigos.
          </p>
        </div>
        <div className={`${styles.footerSection} ${styles.rapidos}`}>
          <h3>Enlaces rápidos</h3>
          <ul className={styles.footerLinks}>
            <li><a href="#pedidos">Pedidos</a></li>
            <li>
              <Link to={isQuererte ? "/usuario/menu-quererte" : "/usuario/menu-amekatiar"}>
                Menú
              </Link>
            </li>
            <li>
              <Link to={isQuererte ? "/usuario/home-quererte/perfil" : "/usuario/home-amekatiar/perfil"}>
                Perfil
              </Link>
            </li>
            <li><a href="#carrito">Carrito</a></li>
          </ul>
        </div>
        <div className={styles.footerSection}>
          <h3>Contáctanos</h3>
          <p>Centro comercial la terraza, Concordia, Antioquia</p>
          <p>Tel: +57 3225555575</p>
          <p>Correo: contacto@querermekatiar.com</p>
          <p>Horario: Lunes a Domingo 3:00 p.m. - 10:00 p.m.</p>
          <p>
            Síguenos:{" "}
            <a href="https://facebook.com/amekatiarquererte" target="_blank" rel="noopener noreferrer">Facebook</a> |{" "}
            <a href="https://instagram.com/amekatiarquererte" target="_blank" rel="noopener noreferrer">Instagram</a>
          </p>
        </div>
      </footer>
    </>
  );
};