// src/components/Carousel.jsx

import React, { useEffect, useMemo, useState } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import styles from "../../assets/Styles/carousel.module.css";
import { OrderService } from "../../api/services/OrderService";

export const Carousel = ({ idNegocioProp }) => {
  // Detecta negocio por prop o por ruta
  const idNegocio = useMemo(() => {
    if (Number(idNegocioProp) === 1 || Number(idNegocioProp) === 2) return Number(idNegocioProp);
    return window.location.pathname.includes("home-quererte") ? 2 : 1;
  }, [idNegocioProp]);

  const [imgs, setImgs] = useState([]);
  const [loading, setLoading] = useState(true);


  const fetchImages = async (negId = idNegocio) => {
    setLoading(true);
    try {
      const list = await OrderService.getNovedadesByNegocio(negId);
      const urls = Array.isArray(list)
        ? list.map(n => n.imagenUrl || n.urlImagen).filter(Boolean)
        : [];
      setImgs(urls);
    } catch (e) {
      console.error("Carousel: error cargando novedades", e);
      setImgs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchImages(); }, [idNegocio]);

  // Auto-refresh cuando el Admin sube/borra para el mismo negocio
  useEffect(() => {
    const handler = (ev) => {
      const changedId = ev?.detail?.idNegocio;
      if (Number(changedId) === Number(idNegocio)) fetchImages(idNegocio);
    };
    window.addEventListener("novedades:changed", handler);
    return () => window.removeEventListener("novedades:changed", handler);
  }, [idNegocio]);

  const settings = {
    dots: true,
    infinite: (imgs.length || 0) > 1,
    centerMode: true,
    centerPadding: "0px",
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: (imgs.length || 0) > 1,
    autoplaySpeed: 2000,
    speed: 600,
    arrows: false,
    swipe: true,
    draggable: true,
    pauseOnHover: true,
    cssEase: "cubic-bezier(0.77, 0, 0.18, 1)",
  };

return (
    <section className={styles.wrapper}>
      <div className={styles.carruselContainer}>
        {loading ? (
          <div className={styles.skeleton} />
        ) : imgs.length === 0 ? (
          <div className={styles.empty}>Sin novedades aún para este negocio.</div>
        ) : (
          <Slider {...settings}>
            {imgs.map((src, i) => (
              <div key={`${i}-${src}`} className={styles.slide}>
                <img src={src} alt={`novedad-${i}`} className={styles.slideImg} />
              </div>
            ))}
          </Slider>
        )}
      </div>
    </section>
  );
};


export default Carousel;