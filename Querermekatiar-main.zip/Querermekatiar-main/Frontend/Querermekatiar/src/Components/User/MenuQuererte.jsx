import { ProductCardQuererte } from "./ProductCardQuererte";
import stylesbg from "../../assets/Styles/Quererte/User/global-quererte.module.css";
import { useEffect, useState } from "react";
import { CustomProductCard } from "./CustomProductCard";
import { CatalogService } from "../../api/services/CatalogService";
import { useSearchParams } from "react-router-dom";
import { BusinessModal } from "./BusinessModal";
import style from "../../assets/Styles/menu.module.css";
import LoaderQuererte from "../ui/LoaderQuererte";

export const MenuQuererte = () => {
  const [quererteProducts, setquererteProducts] = useState([]);
  const [businessActive, setBusinessActive] = useState(1);
  const [searchParams] = useSearchParams();
  const nameCategory = searchParams.get("categoria");
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    CatalogService.getCatalogQuererte()
      .then((response) => {
        const data = Array.isArray(response.data) ? response.data : [];
        setquererteProducts(data);
        if (data.length > 0 && typeof data[0].businessActive !== "undefined") {
          setBusinessActive(data[0].businessActive);
        }
        setTimeout(() => setLoading(false), 1000); // Espera 1s para mostrar el loader
      })
      .catch((error) => {
        console.error("Error cargando productos:", error);
        setTimeout(() => setLoading(false), 1000);
      });
  }, []);

  useEffect(() => {
    document.body.className = stylesbg.bgQuererte;
    return () => {
      document.body.className = '';
    };
  }, []);

  useEffect(() => {
    if (businessActive === 0) setShowModal(true);
    else setShowModal(false);
  }, [businessActive]);

  // Producto custom
  const customProduct = quererteProducts.find(p => p.id === 1);

  // Filtrar productos por categoría seleccionada (excluyendo el custom)
  const filteredProducts = nameCategory
    ? quererteProducts.filter(p => String(p.nameCategory) === String(nameCategory) && p.id !== 1)
    : quererteProducts.filter(p => p.id !== 1);

  // ¿El custom pertenece a la categoría seleccionada?
  const showCustom =
    customProduct &&
    (
      !nameCategory ||
      String(customProduct.nameCategory) === String(nameCategory)
    );

  // Mostrar mensaje solo si no hay productos ni custom en la categoría
  const showNoProducts =
    filteredProducts.length === 0 && !showCustom;

  return (
    <>
      <BusinessModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        nombreNegocio="Quererte"
        titulo="Quererte no está disponible"
        mensaje="Por el momento Quererte no está en servicio. Vuelve pronto para disfrutar nuestros productos."
        color="#000000ff"
        fondoBoton="#000000ff"
        colorBoton="#ffffffff"
      />
      <div className={style.productsContainer}>
        {loading ? (
          <LoaderQuererte message="Cargando productos de Quererte..." />
        ) : (
          <>
            {showCustom && <CustomProductCard businessActive={businessActive} />}
            {showNoProducts ? (
              <p>No hay productos en esta categoría.</p>
            ) : (
              filteredProducts.map(p => (
                <ProductCardQuererte
                  key={p.id}
                  product={p}
                  businessActive={businessActive}
                />
              ))
            )}
          </>
        )}
      </div>
    </>
  );
};