import React, { useState, useEffect } from "react";
import styles from "../../assets/Styles/product-modal.module.css";
import { CatalogService } from "../../api/services/CatalogService";

export const EditCartItemModal = ({
  item,
  isOpen,
  onClose,
  onSave
}) => {
  const [addons, setAddons] = useState([]);
  const [selectedExtras, setSelectedExtras] = useState([]);
  const [quantity, setQuantity] = useState(1);

  // Solicita adiciones al backend cada vez que se abre el modal
  useEffect(() => {
    if (isOpen && item?.id) {
      CatalogService.getAddOns(item.id)
        .then(res => {
          setAddons(res.data || []);
        })
        .catch(() => setAddons([]));
    }
  }, [isOpen, item?.id]);

  // Inicializa los extras seleccionados y cantidad según el carrito
  useEffect(() => {
    if (isOpen) {
      setQuantity(item.quantity || 1);
      setSelectedExtras(
        item.adiciones
          ? item.adiciones.map(a => ({
              id: a.id_adicion,
              cantidad: a.cantidad || 1
            }))
          : []
      );
    }
  }, [isOpen, item]);

  // Agrupa addons por categoría
  const groupedAddons = addons.reduce((acc, addon) => {
    const cat = addon.nameCategory || "Otros";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(addon);
    return acc;
  }, {});

  // Maneja check y cantidad
  const handleCheckboxChange = (addonId) => {
    setSelectedExtras((prev) => {
      const found = prev.find(e => e.id === addonId);
      if (found) {
        return prev.filter(e => e.id !== addonId);
      } else {
        return [...prev, { id: addonId, cantidad: 1 }];
      }
    });
  };

  const handleAddonCantidad = (addonId, delta) => {
    setSelectedExtras((prev) =>
      prev.map(e =>
        e.id === addonId
          ? { ...e, cantidad: Math.max(1, e.cantidad + delta) }
          : e
      )
    );
  };

  const isChecked = (addonId) =>
    selectedExtras.some(e => e.id === addonId);

  const getCantidad = (addonId) => {
    const found = selectedExtras.find(e => e.id === addonId);
    return found ? found.cantidad : 1;
  };

  const handleSave = () => {
    // Solo addons seleccionados, con cantidad
    const extras = addons
      .filter(a => isChecked(a.id))
      .map(a => ({
        id_adicion: a.id,
        cantidad: getCantidad(a.id),
        nom_adicion: a.name,
        precio: a.price
      }));
    onSave({ ...item, adiciones: extras, quantity });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <button className={styles.closeButton} onClick={onClose}>X</button>
        <div className={styles.header}>
          <img
            src={item.urlImage}
            alt={item.name}
            className={styles.image}
          />
          <h2 className={styles.title}>{item.name}</h2>
          <p className={styles.description}>{item.description}</p>
        </div>
        <hr />
        <div className={styles.content}>
          {/* Agrupa y muestra addons por categoría */}
          {Object.entries(groupedAddons).map(([cat, list]) => (
            <div className={styles.section} key={cat}>
              <h3>{cat}</h3>
              {list.map((a) => (
                <div key={a.id} className={styles.adicionRow}>
                  <label className={styles.checkboxLabel}>
                    <input
                      type="checkbox"
                      checked={isChecked(a.id)}
                      onChange={() => handleCheckboxChange(a.id)}
                    />
                    {a.name} (+${a.price})
                  </label>
                  {isChecked(a.id) && (
                    <div className={styles.adicionCantidad}>
                      <button
                        className={styles.quantityBtnYellow}
                        onClick={() => handleAddonCantidad(a.id, -1)}
                        type="button"
                      >-</button>
                      <span>{getCantidad(a.id)}</span>
                      <button
                        className={styles.quantityBtnYellow}
                        onClick={() => handleAddonCantidad(a.id, 1)}
                        type="button"
                      >+</button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
        <div className={styles.section}>
          <h3>Cantidad</h3>
          <button
            className={styles.quantityBtnYellow}
            onClick={() => setQuantity(q => Math.max(1, q - 1))}
          >-</button>
          <span>{quantity}</span>
          <button
            className={styles.quantityBtnYellow}
            onClick={() => setQuantity(q => q + 1)}
          >+</button>
        </div>
        <button className={styles.confirmButton} onClick={handleSave}>
          Guardar cambios
        </button>
      </div>
    </div>
  );
};