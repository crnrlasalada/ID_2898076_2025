import React from "react";
import cardStyles from "../../assets/Styles/OrderDetail.module.css";

export const OrderDetail = ({ order }) => (
  <div className={cardStyles.details}>
    <p><strong>Nombre:</strong> {order.firstName} {order.lastName}</p>
    <p><strong>Teléfono:</strong> {order.phone}</p>
    <p><strong>Dirección:</strong> {order.address || "Sin dirección"}</p>
    <p><strong>Método de pago:</strong> {order.paymentMethod}</p>
    <p><strong>Tipo de entrega:</strong> {order.deliveryType}</p>
    {order.customerMessage && (
      <p><strong>Mensaje del cliente:</strong> {order.customerMessage}</p>
    )}
    <p><strong>Costo de envío:</strong> ${order.deliveryFee.toLocaleString()}</p>
    <p><strong>Subtotal:</strong> ${order.subtotal.toLocaleString()}</p>
    <h4>Productos:</h4>
    <ul className={cardStyles.productListScroll}>
      {order.products.map(product => (
        <li key={product.id} className={cardStyles.productItem}>
          <div className={cardStyles.productMain}>
            <img
              src={product.urlImage}
              alt={product.name}
              className={cardStyles.productImage}
            />
            <div>
              <p><strong>{product.name}</strong></p>
              <p>Cantidad: {product.quantity}</p>
              <p>Precio: ${product.price.toLocaleString()}</p>
            </div>
          </div>
          {product.addOns && product.addOns.length > 0 && (
            <div className={cardStyles.addOns}>
              <p><strong>Adiciones:</strong></p>
              <ul>
                {product.addOns.map(addOn => (
                  <li key={addOn.id}>
                    {addOn.name} (x{addOn.quantity}) - ${addOn.price.toLocaleString()}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </li>
      ))}
    </ul>
  </div>
);