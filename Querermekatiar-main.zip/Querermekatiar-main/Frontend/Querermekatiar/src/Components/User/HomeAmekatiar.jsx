import React from 'react'
import { Carousel } from './Carousel'
import styles from"../../assets/Styles/Home.module.css";
import stylesame from "../../assets/Styles/Amekatiar/User/global-amekatiar.module.css";
import { useEffect } from 'react';
export const HomeAmekatiar = () => {
      useEffect(() => {
    document.body.className=stylesame.bgAmekatiar
    return () => {
      document.body.className = ''
    }
  })
  return (
    <>
    <main >
      <Carousel />
      <section className={styles.cajaMision}>
        <div className={styles.mision}>
          <h2>Misión</h2>
          <p>
            En Amekatiar, combinamos tradición y rapidez para ofrecer comidas que reconfortan el alma y satisfacen el paladar. Nuestra misión es brindar un servicio ágil, sabroso y accesible, donde cada plato represente el cariño por nuestras raíces y el compromiso con la calidad y la atención al cliente.
          </p>
        </div>
      </section>
    </main>
    </>
  );
}
