import React, { useEffect, useState, useCallback } from 'react';
import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api';

const containerStyle = {
  width: '100%',
  height: '300px',
  borderRadius: '10px',
  marginTop: '20px',
};

export const MapClient = ({ lat, lng, direccion, onLocationChange }) => {
  const [marker, setMarker] = useState({ lat, lng });
  const [address, setAddress] = useState(direccion);

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: 'AIzaSyCWVBPQpiUtlwI5Iqew5w0eY0M6FERjIKA',
  });

  // Actualiza el marcador si cambian las props lat/lng
  useEffect(() => {
    setMarker({ lat: parseFloat(lat), lng: parseFloat(lng) });
  }, [lat, lng]);

  // Actualiza la dirección si cambia la prop direccion
  useEffect(() => {
    setAddress(direccion);
  }, [direccion]);

  // Reverse geocoding: obtiene dirección al mover el marcador
  const getAddressFromLatLng = useCallback((lat, lng) => {
    if (window.google && window.google.maps) {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === 'OK' && results[0]) {
          setAddress(results[0].formatted_address);
          if (onLocationChange) {
            onLocationChange(lat, lng, results[0].formatted_address);
          }
        }
      });
    }
  }, [onLocationChange]);

  // Geocoding: obtiene lat/lng al cambiar la dirección manualmente
  useEffect(() => {
    if (isLoaded && direccion) {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ address: direccion }, (results, status) => {
        if (status === 'OK' && results[0]) {
          const location = results[0].geometry.location;
          setMarker({ lat: location.lat(), lng: location.lng() });
          setAddress(results[0].formatted_address);
          if (onLocationChange) {
            onLocationChange(location.lat(), location.lng(), results[0].formatted_address);
          }
        }
      });
    }
    // eslint-disable-next-line
  }, [direccion, isLoaded]);

  if (!isLoaded) return <p>Cargando mapa...</p>;

  return (
    <div>
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={marker}
        zoom={17}
        onClick={e => {
          const newLat = e.latLng.lat();
          const newLng = e.latLng.lng();
          setMarker({ lat: newLat, lng: newLng });
          getAddressFromLatLng(newLat, newLng);
        }}
      >
        <Marker
          position={marker}
          draggable={true}
          onDragEnd={e => {
            const newLat = e.latLng.lat();
            const newLng = e.latLng.lng();
            setMarker({ lat: newLat, lng: newLng });
            getAddressFromLatLng(newLat, newLng);
          }}
        />
      </GoogleMap>
      <p style={{ marginTop: '10px', fontWeight: 'bold' }}>
        Dirección: {address}
      </p>
    </div>
  );
};