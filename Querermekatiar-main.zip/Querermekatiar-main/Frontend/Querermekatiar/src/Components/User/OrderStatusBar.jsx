import React from "react";
import styles from "../../assets/Styles/OrderStatusBar.module.css";

const estados = [
  "Pendiente",
  "Aceptado",
  "En_Proceso",
  "Reparto"
];

const estadoLabels = {
  Pendiente: "Pendiente",
  Aceptado: "Aceptado",
  En_Proceso: "En proceso",
  Reparto: "Reparto"
};

export const OrderStatusBar = ({ estadoActual }) => {
  // Encuentra el índice del estado actual
  const actualIndex = estados.indexOf(estadoActual);

  return (
    <div className={styles.bar}>
      {estados.map((estado, idx) => (
        <div key={estado} className={styles.status}>
          <div className={`${styles.circle} ${idx <= actualIndex ? styles.activeCircle : ""}`}></div>
          <span className={styles.name}>{estadoLabels[estado]}</span>
          <div className={`${styles.line} ${idx < actualIndex ? styles.activeLine : ""}`}></div>
        </div>
      ))}
    </div>
  );
};