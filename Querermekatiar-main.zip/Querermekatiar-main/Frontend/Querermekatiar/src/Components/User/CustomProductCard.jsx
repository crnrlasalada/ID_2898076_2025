import React, { useState } from "react";
import styles from "../../assets/Styles/Quererte/User/customProductCard.module.css";
import iceCreamIcon from "../../assets/Icons/CustomIceCream.png";
import { ProductModal } from "./ProductModal";
import { CatalogService } from "../../api/services/CatalogService";

export const CustomProductCard = ({ businessActive }) => {
  const [openModal, setOpenModal] = useState(false);
  const [customProduct, setCustomProduct] = useState(null);

  const handleOpenModal = async () => {
    if (businessActive === 0) return;
    try {
      const response = await CatalogService.getCatalogQuererte();
      const product = Array.isArray(response.data)
        ? response.data.find(p => p.id === 1)
        : null;
      setCustomProduct(product);
      setOpenModal(true);
    } catch (error) {
      setCustomProduct(null);
      setOpenModal(true);
    }
  };

  const handleCloseModal = () => setOpenModal(false);

  return (
    <>
      <div
        className={styles.card}
        onClick={handleOpenModal}
        style={{
          cursor: businessActive === 0 ? "not-allowed" : "pointer",
        }}
      >
        <img
          src={iceCreamIcon}
          alt="Crea tu propio helado"
          className={styles.icon}
        />
        <h3 className={styles.title}>Crea tu propio helado</h3>
        <p className={styles.description}>
          Diseña tu sabor soñado: elige cada ingrediente y haz tu combinación perfecta. ¡Tu helado, tus reglas!
        </p>
      </div>
      {openModal && customProduct && (
        <ProductModal
          product={customProduct}
          onClose={handleCloseModal}
          isOpen={openModal}
        />
      )}
    </>
  );
};