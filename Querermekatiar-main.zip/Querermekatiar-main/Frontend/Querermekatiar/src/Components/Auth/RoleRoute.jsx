import React from "react";
import { Navigate, Outlet } from "react-router-dom";

const getUserRole = () => {
  const token = localStorage.getItem("token");
  if (!token) return null;
  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    if (Array.isArray(payload?.roles) && payload.roles.length > 0) {
      return payload.roles[0];
    }
    return payload.role || payload.rol || null;
  } catch {
    return null;
  }
};

export const RoleRoute = ({ allowedRoles, redirectTo = "/", notFound = false }) => {
  const userRole = getUserRole();

  if (!userRole || !allowedRoles.includes(userRole)) {
    // Si no tiene rol permitido, redirige según el rol
    if (notFound) return <div>404 - No tienes acceso a esta página</div>;
    if (userRole === "CASHIER") return <Navigate to="/admin/pedidos" replace />;
    if (userRole === "DELIVERY") return <Navigate to="/delivery/pedidos" replace />;
    return <Navigate to={redirectTo} replace />;
  }
  // Si tiene el rol, renderiza la ruta
  return <Outlet />;
};

export default RoleRoute;
