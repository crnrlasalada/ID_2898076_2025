import React from "react";
import { Navigate, Outlet } from "react-router-dom";

// Componente para proteger rutas solo para usuarios autenticados
// Uso: <PrivateRoute> <RutaProtegida /> </PrivateRoute>
// Si el usuario no está logueado, redirige al login

const isAuthenticated = () => {
  // Verifica si existe un token JWT en localStorage
  const token = localStorage.getItem("token");
  return !!token;
};

export const PrivateRoute = ({ redirectTo = "/login" }) => {
  if (!isAuthenticated()) {
    return <Navigate to={redirectTo} replace />;
  }
  return <Outlet />;
};

export default PrivateRoute;
