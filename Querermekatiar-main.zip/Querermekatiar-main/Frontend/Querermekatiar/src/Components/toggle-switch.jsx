import style from '../assets/Styles/toggle-switch.module.css'

export const ToggleSwitch = ({ checked = false, onChange = () => {}, title }) => {
  return (
    <label className={style.switch} title={title}>
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
      />
      <span className={style.slider}></span>
    </label>
  );
};