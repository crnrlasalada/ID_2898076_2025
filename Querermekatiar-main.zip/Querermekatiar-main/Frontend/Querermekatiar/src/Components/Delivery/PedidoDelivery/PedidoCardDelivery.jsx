import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import EstadoBarra from './EstadoBarraDelivery';
import styles from './PedidoCardDelivery.module.css';
import btnStyles from './EstadoBotonesDelivery.module.css';
import { OrderService } from '../../../api/services/OrderService';

const estadosFinales = ['Entregado', 'Rechazado', 'No_Recibido'];

const formatearEstado = (estado) =>
    estado.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());


// Componente exclusivo para delivery
const PedidoCardDelivery = ({ pedido, onFinalizar }) => {
    const navigate = useNavigate();
    const [estadoActual, setEstadoActual] = useState(pedido.estadoPedido);
    const [ocultar, setOcultar] = useState(false);
    const [estadoPendiente, setEstadoPendiente] = useState('');
    const [mostrarModal, setMostrarModal] = useState(false);
    const [motivo, setMotivo] = useState('');
    const [mensajeExito, setMensajeExito] = useState('');
    const [mostrarConfirmacion, setMostrarConfirmacion] = useState(false);
    const [mostrarPopupFinal, setMostrarPopupFinal] = useState(false);

    const tipoEntrega = pedido.tipoEntrega;
    const esFinalizado = estadosFinales.includes(estadoActual);


    // Cambiar estado para delivery
    const cambiarEstado = (nuevoEstado) => {
        if (esFinalizado) {
            alert("Este pedido ya fue finalizado y no puede modificarse.");
            return;
        }
        if (estadoActual !== 'Reparto') {
            alert('Solo puedes cambiar el estado desde "Reparto".');
            return;
        }
        setEstadoPendiente(nuevoEstado);
        setMotivo('');
        if (nuevoEstado === 'Rechazado' || nuevoEstado === 'No_Recibido') {
            setMostrarModal(true);
        } else {
            setMostrarConfirmacion(true);
        }
    };



    // Confirmar cambio de estado (solo delivery)
    const confirmarCambio = async (nuevoEstado, motivoText = null) => {
        if ((nuevoEstado === 'Rechazado' || nuevoEstado === 'No_Recibido') && !motivoText?.trim()) {
            alert("Debes ingresar un motivo.");
            return;
        }
        try {
            await OrderService.updateDesdeReparto(pedido.id, nuevoEstado, motivoText);
            setEstadoActual(nuevoEstado);
            setMensajeExito(`Estado actualizado a ${formatearEstado(nuevoEstado)} correctamente.`);
            setTimeout(() => setMensajeExito(''), 1200);
            if (["Entregado", "Rechazado", "No_Recibido"].includes(nuevoEstado)) {
                if (onFinalizar) onFinalizar(pedido.id, nuevoEstado);
                setTimeout(() => {
                    setOcultar(true);
                }, 1200);
            }
        } catch (err) {
            console.error('Error actualizando estado:', err);
        } finally {
            setMostrarModal(false);
            setMostrarConfirmacion(false);
            setMotivo('');
        }
    };

    const irDetalle = () => {
        navigate(`/delivery/pedidos/${pedido.id}`);
    };


    // Siempre mostrar la card para delivery
    if (ocultar) return null;

    return (
        <div className={styles.card + ' ' + (ocultar ? styles.ocultando : '')}>
            <div onClick={irDetalle} className={styles.cardContent}>
                <div className={styles.header}>
                    <h3>Pedido #{pedido.id}</h3>
                    <span>{
                        new Date(pedido.fechaHora).toLocaleString('es-CO', {
                            hour: 'numeric',
                            minute: '2-digit',
                            hour12: true,
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            timeZone: 'America/Bogota'
                        })
                    }</span>
                </div>

                <p><strong>Entrega:</strong> {pedido.tipoEntrega}</p>
                <p><strong>Total:</strong> ${pedido.total}</p>

                {/* Barra de estados visual para delivery */}

                <EstadoBarra
                    estadoActual={estadoActual}
                    setEstadoActual={() => {}}
                    tipoEntrega={pedido.tipoEntrega}
                />

                {/* Espacio extra entre barra de estado y botones */}
                <div style={{ marginBottom: 22 }} />

                {mensajeExito && (
                    <div className={styles.alertaExito}>
                        ✅ {mensajeExito}
                    </div>
                )}
            </div>


            {/* Botones de cambio de estado para delivery solo si está en Reparto */}
            {estadoActual === 'Reparto' && (
                <div className={btnStyles.botonesContainer}>
                    <button
                        className={`${btnStyles.boton} ${btnStyles.verde}`}
                        onClick={() => cambiarEstado('Entregado')}
                    >Entregado</button>
                    <button
                        className={`${btnStyles.boton}`}
                        style={{ backgroundColor: '#ffc107', color: '#fff' }}
                        onClick={() => cambiarEstado('No_Recibido')}
                    >No recibido</button>
                    <button
                        className={`${btnStyles.boton} ${btnStyles.rojo}`}
                        onClick={e => { e.stopPropagation(); cambiarEstado('Rechazado'); }}
                    >Rechazado</button>
                </div>
            )}

            {/* Modal para motivo de rechazo/no recibido (estilo unificado) */}
            {mostrarModal && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modal} style={{ minWidth: 320, maxWidth: 420, textAlign: 'left', padding: 32 }}>
                        <h3 style={{ color: '#fb8d08', marginBottom: 16 }}>Motivo para marcar como {formatearEstado(estadoPendiente)}</h3>
                        <textarea
                            rows="4"
                            value={motivo}
                            onChange={(e) => setMotivo(e.target.value)}
                            placeholder="Escribe el motivo..."
                            style={{ width: '100%', fontSize: 15, padding: 10, borderRadius: 8, border: '1px solid #ccc', marginBottom: 12 }}
                        />
                        <div className={btnStyles.botonesContainer}>
                            <button
                                className={btnStyles.boton}
                                onClick={() => confirmarCambio(estadoPendiente, motivo)}
                            >Confirmar</button>
                            <button
                                className={btnStyles.boton}
                                onClick={() => setMostrarModal(false)}
                            >Cancelar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal de confirmación para entregado (estilo unificado) */}
            {mostrarConfirmacion && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modalConfirmacion}>
                        <h3 style={{ color: '#fb8d08', marginBottom: 16, textAlign: 'center' }}>¿Confirmar que el pedido fue entregado?</h3>
                        <div className={btnStyles.botonesContainer}>
                            <button
                                className={btnStyles.boton}
                                onClick={() => confirmarCambio(estadoPendiente)}
                            >Sí, confirmar</button>
                            <button
                                className={btnStyles.boton}
                                onClick={() => setMostrarConfirmacion(false)}
                            >Cancelar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Popup de proceso finalizado */}
            {mostrarPopupFinal && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modal}>
                        <h3>El pedido finalizó su proceso</h3>
                        <div className={btnStyles.botonesContainer}>
                            <button
                                className={btnStyles.boton}
                                onClick={() => setMostrarPopupFinal(false)}
                            >Cerrar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Las modales de confirmación y finalización ya están implementadas arriba. */}
        </div>
    );
};

export default PedidoCardDelivery;
