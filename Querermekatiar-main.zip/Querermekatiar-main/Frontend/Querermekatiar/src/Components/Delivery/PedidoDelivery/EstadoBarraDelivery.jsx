import React from 'react';
import styles from './EstadoBarraDelivery.module.css';

const getEstados = (tipoEntrega, estadoActual) => {
    const isLocal = (tipoEntrega || '').toLowerCase().includes('local');
    const baseEstados = [
        { key: "Pendiente", label: "Pendiente" },
        { key: "Aceptado", label: "Aceptado" },
        { key: "En_Proceso", label: "En Proceso" },
        isLocal
            ? { key: "Reparto", label: "Preparado" }
            : { key: "Reparto", label: "Reparto" }
    ];

    const estadoFinal = estadoActual === "Entregado" || estadoActual === "No_Recibido" || estadoActual === "Rechazado";

    // Solo mostrar Entregado / No Recibido / Rechazado si YA es el estado actual
    if (estadoFinal) {
        baseEstados.push({
            key: estadoActual,
            label:
                estadoActual === "Entregado"
                    ? "Entregado"
                    : estadoActual === "No_Recibido"
                    ? "No Recibido"
                    : "Rechazado"
        });
    }

    return baseEstados;
};

const EstadoBarra = ({ estadoActual, setEstadoActual, tipoEntrega }) => {
    const estados = getEstados(tipoEntrega, estadoActual);
    const currentIndex = estados.findIndex(e => e.key === estadoActual);

    const manejarClick = (index, estadoKey) => {
        if (estados[currentIndex]?.key === 'Pendiente') {
            alert('Debes aceptar el pedido primero para poder cambiar de estado.');
            return;
        }
        if (index <= currentIndex) {
            alert("No puedes regresar a un estado anterior.");
            return;
        }
        if (index === currentIndex + 1) {
            setEstadoActual(estadoKey);
        } else {
            alert("Debes seguir el flujo del pedido paso a paso.");
        }
    };

    return (
        <div className={styles.barra}>
            {estados.map((estado, index) => {
                const esActual = index === currentIndex;
                const estaCompleto = index <= currentIndex;

                return (
                    <div
                        key={estado.key}
                        className={`${styles.estado} ${esActual ? styles.activo : ''}`}
                        onClick={(e) => {
                            e.stopPropagation();
                            manejarClick(index, estado.key);
                        }}
                    >
                        <div className={`${styles.circulo} ${estaCompleto ? styles.activoCirculo : ''}`}></div>
                        <span className={styles.nombre}>
                          {(estado.key === 'Reparto' && (tipoEntrega || '').toLowerCase().includes('local')) ? 'Preparado' : estado.label}
                        </span>
                        {index < estados.length - 1 && (
                            <div className={`${styles.linea} ${index < currentIndex ? styles.activoLinea : ''}`}></div>
                        )}
                    </div>
                );
            })}
        </div>
    );
};

export default EstadoBarra;
