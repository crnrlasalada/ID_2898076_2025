import React from "react";
import quererteImg from "../../assets/loaders/iceCream.png"; // Cambia el nombre/ruta si tu imagen es diferente

const LoaderQuererte = ({ message = "Cargando productos..." }) => (
  <div style={{
    position: "fixed",
    inset: 0,
    zIndex: 9999,
    background: "#fff",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    minHeight: "100vh",
    width: "100vw",
    padding: "2rem 0"
  }}>
    <img
      src={quererteImg}
      alt="Cargando Quererte"
      style={{
        width: 110,
        height: 110,
        marginBottom: 20,
        objectFit: "contain",
        filter: "drop-shadow(0 4px 16px #0002)"
      }}
    />
    <h2 style={{ color: "#000", marginBottom: 8, fontWeight: 700, fontSize: "1.3rem" }}>
      ¡Estamos preparando tus antojos!
    </h2>
    <p style={{ color: "#444", fontSize: "1.1rem" }}>{message}</p>
  </div>
);

export default LoaderQuererte;