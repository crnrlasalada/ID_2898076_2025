import React from "react";
import { useNavigate } from "react-router-dom";
import { decodeJwt } from "../../utils/jwtDecode";
import styles from "./NotFound.module.css";
import notFound from '../../assets/images/404-not-found.webp'// Cambia la ruta si tu imagen está en otra carpeta


const NotFound = () => {
  const navigate = useNavigate();
  let role = "";
  try {
    const token = localStorage.getItem("token");
    const payload = decodeJwt(token);
    if (Array.isArray(payload?.roles) && payload.roles.length > 0) {
      role = payload.roles[0];
    } else {
      role = payload?.rol || payload?.role || "";
    }
  } catch {}

  const handleGoHome = () => {
    if (role === "ADMIN" || role === "CASHIER") {
      navigate("/admin/pedidos");
    } else if (role === "DELIVERY") {
      navigate("/delivery/pedidos");
    } else if (role === "CLIENT") {
      navigate("/menu-quererte");
    } else {
      navigate("/");
    }
  };

  return (
    <div className={styles.notFoundContainer}>
  <img src={notFound} alt="Página no encontrada" className={styles.notFoundImage} />
      <h1 className={styles.notFoundTitle}>404 - Página no encontrada</h1>
      <p className={styles.notFoundText}>La página que buscas no existe o fue movida.</p>
      <button className={styles.notFoundButton} onClick={handleGoHome}>
        Volver a tu panel
      </button>
    </div>
  );
};

export default NotFound;
