import style from './AddonStats.module.css';

export const AddonStats = ({ adicciones }) => {
    const stats = {
        total: adicciones.length,
        active: adicciones.filter(a => a.activo === 1).length,
        inactive: adicciones.filter(a => a.activo === 0).length,
        avgPrice: adicciones.length > 0 
            ? adicciones.reduce((sum, a) => sum + Number(a.precio), 0) / adicciones.length 
            : 0
    };

    const formatPrice = (price) => {
        if (!price) return '0';
        return Number(price).toLocaleString('es-CO');
    };

    return (
        <div className={style.statsGrid}>
            <div className={style.statCard}>
                <span className={style.statNumber}>{stats.total}</span>
                <span className={style.statLabel}>Total Adicciones</span>
            </div>
            <div className={style.statCard}>
                <span className={style.statNumber}>{stats.active}</span>
                <span className={style.statLabel}>Activas</span>
            </div>
            <div className={style.statCard}>
                <span className={style.statNumber}>{stats.inactive}</span>
                <span className={style.statLabel}>Inactivas</span>
            </div>
            <div className={style.statCard}>
                <span className={style.statNumber}>${formatPrice(stats.avgPrice)}</span>
                <span className={style.statLabel}>Precio Promedio</span>
            </div>
        </div>
    );
};
