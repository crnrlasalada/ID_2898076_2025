import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    ResponsiveContainer,
    Legend,
} from "recharts";
import styles from "./GraficaEstados.module.css";

const COLORS = {
    Aceptado: "#43e97b",       // Verde moderno
    Rechazado: "#e53935",      // Rojo fuerte
    No_Recibido: "#f59e42",    // Naranja suave
};

const ESTADO_MAP = {
    Aceptado: "Aceptado",
    Rechazado: "Rechazado",
    No_Recibido: "No Recibido",
};

const GraficaEstados = ({ pedidos }) => {
    const estadoCount = {
        Aceptado: 0,
        Rechazado: 0,
        No_Recibido: 0,
    };


    pedidos.forEach((pedido) => {
        let estado = pedido.estadoPedido?.toString().trim().toLowerCase().replace(/\s+/g, '_');
        if (estado === "aceptado" || estado === "entregado") estadoCount.Aceptado += 1;
        else if (estado === "rechazado") estadoCount.Rechazado += 1;
        else if (estado === "no_recibido" || estado === "no_recibido" || estado === "no recibido" || estado === "no_recibido_admin" || estado === "no_recibido_cliente") estadoCount.No_Recibido += 1;
    });

    // Siempre mostrar los tres estados aunque tengan valor 0
    const data = Object.entries(estadoCount)
        .map(([estado, count]) => ({
            name: ESTADO_MAP[estado],
            value: count,
            color: COLORS[estado],
        }));

    return (
        <div className={styles.container} style={{ background: 'white', borderRadius: '1.2rem', boxShadow: '0 2px 8px rgba(0,0,0,0.07)', padding: '1.2rem', width: 240, height: 220, maxWidth: 260, minWidth: 220, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <h3 className={styles.title} style={{ fontSize: '1.1rem', marginBottom: 8 }}>Pedidos por estado</h3>
            <div className={styles.estadosChartWrapper}>
                <ResponsiveContainer width={90} height={90}>
                    <PieChart>
                        <Pie
                            data={data}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={20}
                            outerRadius={40}
                            label={false}
                        >
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
                <div className={styles.legendContainer}>
                    {/* Leyenda personalizada para mostrar cada estado y cantidad */}
                    {data.length > 0 && (
                        <ul style={{ listStyle: 'none', padding: 0, margin: '1rem 0 0 0', width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
                            {data.map((item, idx) => (
                                <li key={item.name} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.93rem' }}>
                                    <span style={{ display: 'inline-block', width: 13, height: 13, borderRadius: '50%', background: item.color, border: '1px solid #ccc' }}></span>
                                    <span style={{ fontWeight: 500, color: '#1e293b' }}>{item.name}: <span style={{ color: '#64748b', fontWeight: 400 }}>{item.value}</span></span>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

export default GraficaEstados;
