import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { FaClock } from "react-icons/fa";

function getHourLabel(h) {
    return h.toString().padStart(2, '0') + ':00';
}

const GraficaPedidosPorHora = ({ pedidos }) => {
  // Contar pedidos por hora
    const horas = Array(24).fill(0);
    pedidos.forEach(p => {
        if (p.fechaHora) {
        const date = new Date(p.fechaHora);
        const h = date.getHours();
        horas[h]++;
        }
    });
    const data = horas.map((v, h) => ({ hora: getHourLabel(h), pedidos: v }));
    // Solo mostrar horas con pedidos o las 6 más altas
    const dataFiltrada = data.filter(d => d.pedidos > 0);
    const dataFinal = dataFiltrada.length > 0 ? dataFiltrada : data.slice(8, 20); // Horas típicas

    return (
        <div style={{ background: 'white', borderRadius: '1.2rem', boxShadow: '0 2px 8px rgba(0,0,0,0.07)', padding: '1.2rem', width: 240, height: 220, maxWidth: 260, minWidth: 220, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <h4 style={{ fontWeight: 700, color: '#1e293b', marginBottom: 10, fontSize: '1.08rem', display: 'flex', alignItems: 'center', gap: 6 }}>
            <FaClock style={{ color: '#6366f1', fontSize: '1.1rem' }} /> Pedidos por hora
        </h4>
        <ResponsiveContainer width={180} height={140}>
            <BarChart data={dataFinal}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="hora" fontSize={11} />
            <YAxis allowDecimals={false} fontSize={11} />
            <Tooltip />
            <Bar dataKey="pedidos" fill="#43e97b" radius={[8, 8, 0, 0]} />
            </BarChart>
        </ResponsiveContainer>
        </div>
    );
};

export default GraficaPedidosPorHora;
