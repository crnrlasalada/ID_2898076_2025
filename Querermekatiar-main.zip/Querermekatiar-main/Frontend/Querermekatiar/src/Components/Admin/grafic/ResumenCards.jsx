
import styles from "./ResumenCards.module.css";
import { FaBoxOpen, FaDollarSign, FaShoppingCart, FaArrowUp, FaChartLine, FaCalendarDay, FaMotorcycle, FaStore } from "react-icons/fa";

const ResumenCards = ({ resumen, grande, compacta }) => {
    const fechaHoy = new Date().toLocaleDateString('es-CO', { day: '2-digit', month: '2-digit', year: 'numeric' });
    // Estilos dinámicos para tamaño y compactación
    const cardStyle = grande ? {
        minWidth: 260, maxWidth: 260, width: 260, fontSize: '1.13rem', padding: '1.7rem 1.2rem',
    } : {};
    const containerStyle = compacta ? {
        gap: '1.1rem',
        maxWidth: 1200,
    } : {};
    return (
        <div className={styles.imagenesContainer} style={containerStyle}>
            <div className={styles.card} style={cardStyle}>
                <FaShoppingCart className={styles.cardIcon} />
                <div className={styles.cardTitle}>
                    Total de Pedidos
                    <FaChartLine className={styles.cardSubIcon} />
                </div>
                <div className={styles.cardValue}>{resumen.totalPedidos}</div>
            </div>
            <div className={styles.card} style={cardStyle}>
                <FaDollarSign className={styles.cardIcon} />
                <div className={styles.cardTitle}>
                    Total Ganancias
                    <FaArrowUp className={styles.cardSubIcon} />
                </div>
                <div className={styles.cardValue}>${resumen.totalGanancias.toLocaleString('es-CO', {minimumFractionDigits: 2})}</div>
                <div className={styles.cardDate}>{fechaHoy}</div>
            </div>
            <div className={styles.card} style={cardStyle}>
                <FaBoxOpen className={styles.cardIcon} />
                <div className={styles.cardTitle}>
                    Total Productos Vendidos
                    <FaCalendarDay className={styles.cardSubIcon} />
                </div>
                <div className={styles.cardValue}>{resumen.totalProductosVendidos}</div>
            </div>
            <div className={styles.card} style={cardStyle}>
                <FaMotorcycle className={styles.cardIcon} />
                <div className={styles.cardTitle}>
                    Domicilio / Local
                </div>
                <div className={styles.cardValue}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                        <FaMotorcycle style={{ fontSize: '1.1em', color: '#2563eb', marginRight: 2 }} /> {resumen.totalDomicilio}
                        <FaStore style={{ fontSize: '1.1em', color: '#22c55e', margin: '0 0 0 10px' }} /> {resumen.totalLocal}
                    </span>
                </div>
            </div>
        </div>
    );
};

export default ResumenCards;
