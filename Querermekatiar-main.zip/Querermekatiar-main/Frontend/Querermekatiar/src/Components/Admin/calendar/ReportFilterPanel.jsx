import GraficaProductos from "../grafic/GraficaProductos";
import React, { useState, useEffect, useMemo } from "react";
import DateFilterSelector from "./DateFilterSelector";
import DateRangePicker from "./DateRangePicker";
import MonthYearSelector from "./MonthYearSelector";
import FilterButton from "./FilterButton";
import PedidoProductosTable from "./PedidoProductosTable";
import ProductosMasVendidos from "./ProductosMasVendidos";
import ExportExcelButton from "./ExportExcelButton";
import GraficaPastel from "../grafic/GraficaPastel";
import GraficaMetodoPago from "../grafic/GraficaMetodoPago";
import GraficaPedidosPorHora from "../grafic/GraficaPedidosPorHora";
import GraficaEstados from "../grafic/GraficaEstados";
import ResumenCards from "../grafic/ResumenCards";

import ReportService from "../../../api/services/ReportService";

import {
    startOfDay,
    endOfDay,
    startOfWeek,
    endOfWeek,
    endOfMonth,
    startOfYear,
    endOfYear,
    differenceInCalendarDays,
} from "date-fns";

import styles from "./ReportFilterPanel.module.css";

const ReportFilterPanel = () => {
    const [filterType, setFilterType] = useState("personalizado");
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [paginado, setPaginado] = useState({
        content: [],
        totalPages: 0,
        totalElements: 0,
        page: 0,
        size: 10,
        paginacionActiva: false
    });
    const [tipoReporte, setTipoReporte] = useState("ventas");
    const [month, setMonth] = useState("");
    const [year, setYear] = useState("");

    useEffect(() => {
        const today = new Date();

        switch (filterType) {
            case "día":
                setStartDate(startOfDay(today).toISOString().slice(0, 10));
                setEndDate(endOfDay(today).toISOString().slice(0, 10));
                break;
            case "semana":
                setStartDate(startOfWeek(today).toISOString().slice(0, 10));
                setEndDate(endOfWeek(today).toISOString().slice(0, 10));
                break;
            case "mes":
                if (month && year) {
                    const start = new Date(year, parseInt(month) - 1, 1);
                    const end = endOfMonth(start);
                    setStartDate(start.toISOString().slice(0, 10));
                    setEndDate(end.toISOString().slice(0, 10));
                }
                break;
            case "año":
                if (year) {
                    const start = startOfYear(new Date(year, 0));
                    const end = endOfYear(start);
                    setStartDate(start.toISOString().slice(0, 10));
                    setEndDate(end.toISOString().slice(0, 10));
                }
                break;
            case "personalizado":
                setStartDate(null);
                setEndDate(null);
                break;
            default:
                break;
        }
    }, [filterType, month, year]);

    const filtrarPedidos = async (_page = 0, _size = 10) => {
        // Asegura que page y size sean números
        const page = typeof _page === 'number' ? _page : 0;
        const size = typeof _size === 'number' ? _size : 10;
        try {
            let pedidos = [];
            if (tipoReporte === "masVendidos") {
                pedidos = await ReportService.getUltimosPedidos();
                setPaginado({ content: pedidos, totalPages: 1, totalElements: pedidos.length, page: 0, size: pedidos.length, paginacionActiva: false });
                return;
            } else if (filterType === "mes" && month && year) {
                pedidos = await ReportService.getPedidosPorMesYAnio(parseInt(year), parseInt(month));
                setPaginado({ content: pedidos, totalPages: 1, totalElements: pedidos.length, page: 0, size: pedidos.length, paginacionActiva: false });
                return;
            } else if (filterType === "año" && year) {
                pedidos = await ReportService.getPedidosPorAnio(parseInt(year));
                setPaginado({ content: pedidos, totalPages: 1, totalElements: pedidos.length, page: 0, size: pedidos.length, paginacionActiva: false });
                return;
            } else if (startDate && endDate) {
                const diff = differenceInCalendarDays(new Date(endDate), new Date(startDate));
                if (filterType === "semana" && diff > 6) {
                    alert("El rango para semana no puede ser mayor a 7 días");
                    return;
                }
                const page0 = await ReportService.getPedidosPorRangoPaginado(startDate, endDate, page, size);
                if (page0.totalElements > 10) {
                    setPaginado({ ...page0, paginacionActiva: true });
                } else {
                    setPaginado({ content: page0.content, totalPages: 1, totalElements: page0.totalElements, page: 0, size: page0.totalElements, paginacionActiva: false });
                }
                return;
            } else {
                alert("Por favor selecciona las fechas");
                return;
            }
        } catch (error) {
            console.error("Error al filtrar pedidos:", error);
            alert("Hubo un problema al obtener los reportes. Intenta de nuevo.");
        }
    };

    // generar reporte
    const handleGenerarFactura = async () => {
        try {
            // Validar selección de fechas
            if (!startDate || !endDate) {
                alert("Por favor selecciona las fechas");
                return;
            }

            // Obtener pedidos según el filtro
            let pedidosFiltrados;
            if (tipoReporte === "masVendidos") {
                pedidosFiltrados = await ReportService.getUltimosPedidos();
            } else if (filterType === "mes" && month && year) {
                pedidosFiltrados = await ReportService.getPedidosPorMesYAnio(parseInt(year), parseInt(month));
            } else if (filterType === "año" && year) {
                pedidosFiltrados = await ReportService.getPedidosPorAnio(parseInt(year));
            } else {
                pedidosFiltrados = await ReportService.getPedidosPorRango(startDate, endDate);
            }

            // Mapear pedidos al formato requerido
            const cleanNumber = value => isNaN(parseFloat(value)) ? 0 : parseFloat(value);
            const pedidosMapeados = pedidosFiltrados.map(p => {
                // mapear productos y normalizar add-ons/adiciones
                const products = (p.productos || []).map(prod => {
                    const cantidad = parseInt(prod.cantidad || 0);
                    const price = cleanNumber(prod.precio);
                    const prodTotal = price * (isNaN(cantidad) ? 0 : cantidad);
                    // Mapear adiciones a formato backend
                    const adicionesRaw = prod.adiciones || prod.addOns || [];
                    const adiciones = adicionesRaw.map(a => ({
                        name: a.nombre || a.name || '',
                        quantity: a.cantidad ?? a.quantity ?? 0,
                        price: a.precio ?? a.price ?? 0
                    }));
                    return {
                        productName: prod.nombre || '',
                        cant: isNaN(cantidad) ? 0 : cantidad,
                        price,
                        total: prodTotal,
                        Field_1: "",
                        adiciones,
                        addOns: adiciones
                    };
                });

                // usar total provisto por el pedido o calcularlo desde los productos
                const orderTotalFromPayload = cleanNumber(p.total);
                const computedOrderTotal = products.reduce((sum, pr) => sum + (pr.total || 0), 0);
                const orderTotal = orderTotalFromPayload || computedOrderTotal;

                return {
                    orderId: p.id?.toString() || '',
                    nombreCompleto: `${p.nombres || ''} ${p.apellidos || ''}`,
                    customerName: p.customerName || p.nombres || '',
                    customerLastName: p.customerLastName || p.apellidos || '',
                    fechaHora: p.fechaHora ? new Date(p.fechaHora) : new Date(),
                    products,
                    orderTotal
                };
            });

            // Generar y descargar PDF
            const pdfBlob = await ReportService.generarReporteVentasPdf(pedidosMapeados);
            const url = window.URL.createObjectURL(pdfBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'reporte_ventas.pdf';
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Error al generar factura:', error);
            alert(error.message || 'Error al generar el reporte. Por favor, intente nuevamente.');
        }
    };

    const resumen = useMemo(() => {
        let totalPedidos = paginado.content.length;
        let totalGanancias = 0;
        let totalProductosVendidos = 0;
        let totalDomicilio = 0;
        let totalLocal = 0;

        paginado.content.forEach((pedido) => {
            totalGanancias += parseFloat(pedido.total || 0);
            if ((pedido.tipoEntrega || '').toLowerCase().includes('domicilio')) totalDomicilio++;
            else totalLocal++;
            pedido.productos.forEach((producto) => {
                totalProductosVendidos += producto.cantidad || 0;
            });
        });

        return { totalPedidos, totalGanancias, totalProductosVendidos, totalDomicilio, totalLocal };
    }, [paginado]);

    return (
        <div className={styles.panel}>
            <div className={styles.reportTypeSelector}>
                <label htmlFor="tipoReporte" style={{ fontSize: "1.5rem", fontFamily: "Roboto, sans-serif" }}>
                    Tipo de reporte:
                </label>
                <select id="tipoReporte" value={tipoReporte} onChange={(e) => setTipoReporte(e.target.value)}>
                    <option value="ventas">Reporte de ventas</option>
                    <option value="masVendidos">Productos más vendidos</option>
                </select>
            </div>

            <DateFilterSelector filterType={filterType} setFilterType={setFilterType} />

            {(filterType === "mes" || filterType === "año") ? (
                <MonthYearSelector
                    filterType={filterType}
                    month={month}
                    setMonth={setMonth}
                    year={year}
                    setYear={setYear}
                />
            ) : (
                <DateRangePicker
                    filterType={filterType}
                    startDate={startDate}
                    endDate={endDate}
                    setStartDate={setStartDate}
                    setEndDate={setEndDate}
                />
            )}


            {/* Botones de filtrar, exportar y factura juntos alineados a la izquierda */}
            <div className={styles.responsiveButtonRow}>
                <button
                    onClick={() => filtrarPedidos(0, paginado.size)}
                    className={styles.responsiveActionButton}
                    style={{
                        background: '#2563eb',
                        color: '#fff',
                        border: 'none',
                        fontWeight: 700,
                        cursor: 'pointer',
                        boxShadow: '0 2px 8px rgba(44,62,80,0.10)',
                        transition: 'background 0.2s',
                        letterSpacing: '0.5px',
                    }}
                >Filtrar</button>
                {tipoReporte === "ventas" && paginado.content.length > 0 && (
                    <>
                        <ExportExcelButton pedidos={paginado.content} />
                        <button
                            className={styles.responsiveActionButton}
                            style={{
                                background: '#2563eb',
                                color: '#fff',
                                border: 'none',
                                fontWeight: 700,
                                cursor: 'pointer',
                                boxShadow: '0 2px 8px rgba(44,62,80,0.08)',
                                transition: 'background 0.2s',
                            }}
                            onClick={handleGenerarFactura}
                        >
                            Generar factura
                        </button>
                    </>
                )}
            </div>

            {/* ResumenCards solo si hay datos filtrados */}
            {paginado.content.length > 0 && (
                <div className={styles.responsiveResumenCards}>
                    <ResumenCards resumen={resumen} grande compacta />
                </div>
            )}

            {/* Tabla o productos más vendidos */}
            {tipoReporte === "ventas" ? (
                <>
                    <PedidoProductosTable pedidos={paginado.content} />
                    {paginado.paginacionActiva && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 16, margin: '1rem 0' }}>
                            <button onClick={() => filtrarPedidos(Math.max(0, paginado.page - 1), paginado.size)} disabled={paginado.page === 0}>
                                Anterior
                            </button>
                            <span>Página {paginado.page + 1} de {paginado.totalPages}</span>
                            <button onClick={() => filtrarPedidos(Math.min(paginado.totalPages - 1, paginado.page + 1), paginado.size)} disabled={paginado.page === paginado.totalPages - 1}>
                                Siguiente
                            </button>
                            <span>Pedidos por página:</span>
                            <select value={paginado.size} onChange={e => filtrarPedidos(0, parseInt(e.target.value))}>
                                <option value={5}>5</option>
                                <option value={10}>10</option>
                                <option value={20}>20</option>
                            </select>
                        </div>
                    )}
                </>
            ) : (
                <ProductosMasVendidos pedidos={paginado.content} />
            )}

            {/* Gráficas organizadas y compactas */}
            {paginado.content.length > 0 && (
                <div style={{ width: '100%', maxWidth: 1100, margin: '2.5rem auto 0 auto', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                    {/* Gráfico principal de barras solo en desktop */}
                    <div className={styles.responsiveMainChart} style={{ background: 'white', borderRadius: 18, boxShadow: '0 8px 24px rgba(44,62,80,0.13)', padding: '1.5rem', minHeight: 320 }}>
                        <GraficaProductos pedidos={paginado.content} />
                    </div>
                    {/* Grid de gráficas compactas */}
                    <div className={styles.responsiveChartsGrid} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 24, justifyContent: 'flex-start', width: '100%' }}>
                        <div className={styles.responsiveChartCard} style={{ background: 'white', borderRadius: 16, boxShadow: '0 4px 16px rgba(44,62,80,0.10)', padding: '1.2rem', minHeight: 220, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <GraficaPastel pedidos={paginado.content} />
                        </div>
                        <div className={styles.responsiveChartCard} style={{ background: 'white', borderRadius: 16, boxShadow: '0 4px 16px rgba(44,62,80,0.10)', padding: '1.2rem', minHeight: 220, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <GraficaMetodoPago pedidos={paginado.content} />
                        </div>
                        <div className={styles.responsiveChartCard} style={{ background: 'white', borderRadius: 16, boxShadow: '0 4px 16px rgba(44,62,80,0.10)', padding: '1.2rem', minHeight: 220, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <GraficaEstados pedidos={paginado.content} />
                        </div>
                        <div className={styles.responsiveChartCard} style={{ background: 'white', borderRadius: 16, boxShadow: '0 4px 16px rgba(44,62,80,0.10)', padding: '1.2rem', minHeight: 220, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <GraficaPedidosPorHora pedidos={paginado.content} />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ReportFilterPanel;