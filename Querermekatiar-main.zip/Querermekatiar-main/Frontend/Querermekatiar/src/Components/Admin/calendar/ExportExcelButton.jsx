
import React from "react";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import stylesExcel from "./ExportExcelButton.module.css";

const ExportExcelButton = ({ pedidos, customColor }) => {
    const exportToExcel = () => {
        if (!pedidos || pedidos.length === 0) {
            alert("No hay pedidos para exportar.");
            return;
        }

        const rows = [];

        pedidos.forEach((pedido) => {
            pedido.productos.forEach((producto) => {
                const adiciones = producto.adiciones?.map(a => `${a.nombre} ($${a.precio})`).join(", ") || "N/A";
                const totalAdiciones = producto.adiciones?.reduce((acc, a) => acc + parseFloat(a.precio), 0) || 0;

                rows.push({
                    "ID Pedido": pedido.id,
                    "Fecha": new Date(pedido.fechaHora).toLocaleString(),
                    "Cliente": `${pedido.nombres} ${pedido.apellidos}`,
                    "Teléfono": pedido.telefono,
                    "Dirección": pedido.direccion || "N/A",
                    "Tipo Entrega": pedido.tipoEntrega,
                    "Estado": pedido.estadoPedido,
                    "Producto": producto.nombreProducto,
                    "Cantidad": producto.cantidad,
                    "Precio Unitario": `$${producto.precio}`,
                    "Adiciones": adiciones,
                    "Total Adiciones": `$${totalAdiciones.toFixed(2)}`,
                    "Subtotal Producto": `$${(producto.precio * producto.cantidad + totalAdiciones).toFixed(2)}`,
                    "Subtotal Pedido": `$${pedido.subtotal}`,
                    "Total Pedido": `$${pedido.total}`,
                });
            });
        });

        const worksheet = XLSX.utils.json_to_sheet(rows);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "ReportePedidos");

        const excelBuffer = XLSX.write(workbook, {
            bookType: "xlsx",
            type: "array",
        });

        const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
        saveAs(blob, "Reporte_Pedidos.xlsx");
    };

    return (
        <button
            onClick={exportToExcel}
            className={stylesExcel.exportButton}
        >
            <span role="img" aria-label="excel">📊</span> Exportar a Excel
        </button>
    );
};

export default ExportExcelButton;
