import styles from "./DateFilterSelector.module.css";

const DateFilterSelector = ({ filterType, setFilterType }) => {
    const opciones = ["día", "semana", "mes", "año", "personalizado"];

    return (
        <div className={styles.selectorContainer}>
        <label className={styles.label}>Tipo de Filtro:</label>
        <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className={styles.select}
        >
            {opciones.map((opcion) => (
            <option key={opcion} value={opcion}>
                {opcion.charAt(0).toUpperCase() + opcion.slice(1)}
            </option>
            ))}
        </select>
        </div>
    );
};

export default DateFilterSelector;
