import styles from "./FilterButton.module.css";

const FilterButton = ({ onClick }) => {
    return (
        <button className={styles.btn} onClick={onClick} type="button">
        Filtrar
        </button>
    );
};

export default FilterButton;
