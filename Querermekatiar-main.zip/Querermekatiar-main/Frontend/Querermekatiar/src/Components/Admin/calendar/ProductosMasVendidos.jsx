// ProductosMasVendidos.jsx
import React, { useState, useMemo } from "react";
import styles from "./ProductosMasVendidos.module.css";

const ProductosMasVendidos = ({ pedidos }) => {
    const [cantidadMostrar, setCantidadMostrar] = useState(5); // Top 5 por defecto

    // No renderizar nada si no hay productos filtrados
    const productos = useMemo(() => {
        if (!Array.isArray(pedidos) || pedidos.length === 0) return [];
        const conteo = {};
        pedidos.forEach((pedido) => {
            (pedido.productos || pedido.products || []).forEach((producto) => {
                // Soportar ambos nombres de campo
                const id = producto.id || producto.idProducto;
                const nombre = producto.nombre || producto.nombreProducto || "Sin nombre";
                const img = producto.urlImagen || producto.img || "https://via.placeholder.com/80";
                const cantidad = producto.cantidad || 0;
                if (!conteo[id]) {
                    conteo[id] = {
                        idProducto: id,
                        nombre,
                        img,
                        cantidad: 0,
                    };
                }
                conteo[id].cantidad += cantidad;
            });
        });
        const lista = Object.values(conteo);
        lista.sort((a, b) => b.cantidad - a.cantidad);
        return lista;
    }, [pedidos]);

    if (!productos.length) return null;

    return (
        <div className={styles.container}>
            <div className={styles.topSelector}>
                <label htmlFor="cantidad">Mostrar top:</label>
                <select
                    id="cantidad"
                    value={cantidadMostrar}
                    onChange={(e) => setCantidadMostrar(Number(e.target.value))}
                >
                    {[...Array(10)].map((_, i) => (
                        <option key={i} value={i + 1}>
                            {i + 1}
                        </option>
                    ))}
                </select>
            </div>

            <div className={styles.grid}>
                {productos.slice(0, cantidadMostrar).map((producto, idx) => (
                    <div key={producto.idProducto} className={styles.card} style={{ animationDelay: `${idx * 40}ms` }}>
                        <img src={producto.img} alt={producto.nombre} style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 12, marginBottom: 8, background: '#f3f4f6' }} />
                        <h4 style={{ margin: 0, fontSize: '1.05rem', color: '#1e293b' }}>{producto.nombre}</h4>
                        <p style={{ margin: 0, color: '#64748b', fontWeight: 500 }}>{producto.cantidad} unidades vendidas</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ProductosMasVendidos;
