import React, { useState } from "react";
import styles from "./PedidoProductosTable.module.css";


const PedidoProductosTable = ({ pedidos }) => {
    const [expanded, setExpanded] = useState({});
    // Agrupar pedidos por id
    const pedidosAgrupados = pedidos.reduce((acc, pedido) => {
        if (!acc[pedido.id]) acc[pedido.id] = [];
        acc[pedido.id].push(pedido);
        return acc;
    }, {});
    const pedidosUnicos = Object.values(pedidosAgrupados).map(arr => arr[0]);

    // Paginado local a partir de 5 pedidos únicos
    const [page, setPage] = useState(0);
    const size = 5;
    const totalPages = Math.ceil(pedidosUnicos.length / size);
    const pagedPedidos = pedidosUnicos.slice(page * size, (page + 1) * size);

    if (!pedidosUnicos.length) {
        return <p className={styles.noData}>No hay productos para mostrar.</p>;
    }

    return (
        <div className={styles.tableContainer}>
            <div className={styles.girarMensaje}>
                Para ver la tabla completa, gira tu celular a modo horizontal (landscape).
            </div>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>ID Pedido</th>
                        <th>Fecha</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Total</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    {pagedPedidos.map((pedido) => {
                        const fechaFormateada = new Date(pedido.fechaHora).toLocaleString("es-CO");
                        return (
                            <React.Fragment key={pedido.id}>
                                <tr>
                                    <td>{pedido.id}</td>
                                    <td>{fechaFormateada}</td>
                                    <td>{pedido.nombres}</td>
                                    <td>{pedido.apellidos}</td>
                                    <td>{formatCurrency(pedido.total)}</td>
                                    <td>
                                        <button className={styles.verMasBtn} onClick={() => setExpanded(e => ({ ...e, [pedido.id]: !e[pedido.id] }))}>
                                            {expanded[pedido.id] ? "Ocultar" : "Ver más"}
                                        </button>
                                    </td>
                                </tr>
                                {expanded[pedido.id] && (
                                    <tr>
                                        <td colSpan={6}>
                                            <div style={{ maxHeight: 350, overflowY: 'auto', borderRadius: 10, boxShadow: '0 1px 6px rgba(44,62,80,0.08)', background: '#f9fafb', padding: '0.5rem 0.2rem' }}>
                                                <DetallePedido pedido={pedido} pedidosAgrupados={pedidosAgrupados[pedido.id]} />
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </React.Fragment>
                        );
                    })}
                </tbody>
            </table>
            {totalPages > 1 && (
                <div className={styles.paginacion}>
                    <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}>Anterior</button>
                    <span>Página {page + 1} de {totalPages}</span>
                    <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page === totalPages - 1}>Siguiente</button>
                </div>
            )}
        </div>
    );
};


const DetallePedido = ({ pedido, pedidosAgrupados }) => {
    const [expandedAdiciones, setExpandedAdiciones] = useState({});
    return (
        <table className={styles.detalleTable} style={{ margin: '1rem auto', width: '95%' }}>
            <thead>
                <tr>
                    <th>Teléfono</th>
                    <th>Estado</th>
                    <th>Tipo Entrega</th>
                    <th>Dirección</th>
                    <th>Forma de Pago</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Adiciones</th>
                    <th>Total Adiciones</th>
                    <th>Subtotal Producto</th>
                </tr>
            </thead>
            <tbody>
                {pedidosAgrupados.map((p, i) =>
                    p.productos.map((producto, productoIndex) => {
                        const totalAdiciones = producto.adiciones?.reduce((sum, a) => sum + (a.precio * a.cantidad), 0) ?? 0;
                        const subtotal = (producto.precio * producto.cantidad) + totalAdiciones;
                        const tieneAdiciones = producto.adiciones && producto.adiciones.length > 0;
                        return (
                            <React.Fragment key={`${p.id}-${productoIndex}-main`}>
                                <tr>
                                    <td>{p.telefono}</td>
                                    <td>{p.estadoPedido}</td>
                                    <td>{p.tipoEntrega}</td>
                                    <td>{p.direccion}</td>
                                    <td>{p.formaPago}</td>
                                    <td>{producto.nombre}</td>
                                    <td>{producto.cantidad}</td>
                                    <td>{formatCurrency(producto.precio)}</td>
                                    <td>
                                        {tieneAdiciones ? (
                                            <>
                                                Adiciones ({producto.adiciones.length})
                                                <button
                                                    className={styles.verMasBtn}
                                                    style={{ marginLeft: 8, fontSize: 13, padding: '2px 10px' }}
                                                    onClick={() => setExpandedAdiciones(e => ({ ...e, [`${p.id}-${productoIndex}`]: !e[`${p.id}-${productoIndex}`] }))}
                                                >
                                                    {expandedAdiciones[`${p.id}-${productoIndex}`] ? 'Ocultar' : 'Ver más'}
                                                </button>
                                            </>
                                        ) : (
                                            <span style={{ color: '#aaa' }}>-</span>
                                        )}
                                    </td>
                                    <td>{formatCurrency(totalAdiciones)}</td>
                                    <td>{formatCurrency(subtotal)}</td>
                                </tr>
                                {tieneAdiciones && expandedAdiciones[`${p.id}-${productoIndex}`] && (
                                    <tr>
                                        <td colSpan={11}>
                                            <div style={{ maxHeight: 180, overflowY: 'auto', borderRadius: 8, boxShadow: '0 1px 6px rgba(44,62,80,0.08)', background: '#f3f4f6', padding: '0.5rem 0.2rem', margin: '0.5rem 0' }}>
                                                <table className={styles.adicionesTable}>
                                                    <thead>
                                                        <tr>
                                                            <th>Nombre</th>
                                                            <th>Cantidad</th>
                                                            <th>Precio</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {producto.adiciones.map((adicion, adicionIndex) => (
                                                            <tr key={`${p.id}-${productoIndex}-adicion-${adicionIndex}`}>
                                                                <td>{adicion.nombre}</td>
                                                                <td>{adicion.cantidad}</td>
                                                                <td>{formatCurrency(adicion.precio)}</td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </React.Fragment>
                        );
                    })
                )}
            </tbody>
        </table>
    );
};

const formatCurrency = (value) => {
    return value?.toLocaleString("es-CO", {
        style: "currency",
        currency: "COP",
    }) ?? "$0";
};

export default PedidoProductosTable;
