    import styles from "./DateRangePicker.module.css";

    const DateRangePicker = ({
        filterType,
        startDate,
        endDate,
        setStartDate,
        setEndDate,
        }) => {
        const handleStartChange = (e) => {
            const newStart = e.target.value;
            setStartDate(newStart);

            // Si el filtro es "día", sincroniza ambas fechas
            if (filterType === "día") {
            setEndDate(newStart);
            }
        };

        const handleEndChange = (e) => {
            setEndDate(e.target.value);
        };

        const isDisabled = (campo) => {
            if (filterType === "mes" || filterType === "año") return true;
            if (filterType === "día" && campo === "hasta") return true;
            return false;
        };

        return (
            <div className={styles.dateContainer}>
            <div className={styles.inputGroup}>
                <label className={styles.label}>Desde:</label>
                <input
                type="date"
                value={startDate || ""}
                onChange={handleStartChange}
                className={styles.input}
                disabled={isDisabled("desde")}
                />
            </div>

            <div className={styles.inputGroup}>
                <label className={styles.label}>Hasta:</label>
                <input
                type="date"
                value={endDate || ""}
                onChange={handleEndChange}
                className={styles.input}
                disabled={isDisabled("hasta")}
                />
            </div>
            </div>
        );
    };

    export default DateRangePicker;
