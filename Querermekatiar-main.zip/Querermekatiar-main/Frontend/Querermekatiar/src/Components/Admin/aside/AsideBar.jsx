import {useState,useEffect } from "react";
import style from "./AsideBar.module.css";
import logo from "../../../assets/images/logotype_both.webp";
import { Link, useLocation } from "react-router-dom";
import { decodeJwt } from "../../../utils/jwtDecode";
import exit from '../../../assets/Icons/exit.webp';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';

// React Icons
import { FaHome, FaClipboardList, FaBoxOpen, FaNewspaper, FaChartBar, FaPowerOff, FaUser, FaPlus } from "react-icons/fa";

export const AsideBar = () => {
    // Obtener el rol del usuario desde el token
    let role = '';
    try {
        const token = localStorage.getItem('token');
        const payload = decodeJwt(token);
        if (Array.isArray(payload?.roles) && payload.roles.length > 0) {
            role = payload.roles[0];
        } else {
            role = payload?.rol || payload?.role || '';
        }
    } catch (e) { }
    const [openMenu, setOpenMenu] = useState(false);
    const location = useLocation();
    const navigate = useNavigate();

    const toggleMenu = () => {
        setOpenMenu(!openMenu);
    };

    useEffect(() => {
        setOpenMenu(false);
    }, [location]);

    const handleLogout = () => {
        Swal.fire({
            title: '¿Cerrar sesión?',
            text: '¿Estás seguro que deseas salir de tu cuenta?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#16a34a',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, cerrar sesión',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                localStorage.removeItem('token');
                navigate('/');
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    title: 'HASTA LA PROXIMA',
                    showConfirmButton: false,
                    timer: 1500,
                    background: '#d35400',
                    color: '#fff'
                });
            }
        });
    };

    return (
        <>
            <button className={style.hamburger} onClick={toggleMenu}>
                ☰
            </button>

            {/* Overlay para cerrar el menú al hacer clic fuera */}
            {openMenu && (
                <div
                    style={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100vw",
                        height: "100vh",
                        zIndex: 999,
                        background: "rgba(0,0,0,0.01)",
                    }}
                    onClick={() => setOpenMenu(false)}
                />
            )}

            <div className={`${style.sidebar} ${openMenu ? style.activo : ""}`}
                onClick={e => e.stopPropagation()}>
                <div className={style.barLogo}>
                    <img src={logo} alt="Logo" />
                </div>

                <nav>
                    <ul className={style.menuList}>
                        {role === 'ADMIN' && (
                            <li className={style.menuItem}>
                                <Link to="/admin/home" className={style.menuLink}>
                                    <FaHome className={style.icon} /> Home
                                </Link>
                            </li>
                        )}
                        <li className={style.menuItem}>
                            <Link to="/admin/catalogos" className={style.menuLink}>
                                <FaClipboardList className={style.icon} /> Catálogo
                            </Link>
                        </li>
                        <li className={style.menuItem}>
                            <Link to="/admin/adicciones" className={style.menuLink}>
                                <FaPlus className={style.icon} /> Adiciones
                            </Link>
                        </li>
                        <li className={style.menuItem}>
                            <Link to="/admin/pedidos" className={style.menuLink}>
                                <FaBoxOpen className={style.icon} /> Pedidos
                            </Link>
                        </li>
                        <li className={style.menuItem}>
                            <Link to="/admin/novedades" className={style.menuLink}>
                                <FaNewspaper className={style.icon} /> Novedades
                            </Link>
                        </li>
                        {role === 'ADMIN' && (
                            <li className={style.menuItem}>
                                <Link to="/admin/reportes" className={style.menuLink}>
                                    <FaChartBar className={style.icon} /> Reportes
                                </Link>
                            </li>
                        )}
                        <li className={style.menuItem}>
                            <Link to="/admin/activar" className={style.menuLink}>
                                <FaPowerOff className={style.icon} /> Activar/desactivar
                            </Link>
                        </li>
                        {role === 'ADMIN' && (
                            <li className={style.menuItem}>
                                <Link to="/admin/perfiles" className={style.menuLink}>
                                    <FaUser className={style.icon} /> Perfiles
                                </Link>
                            </li>
                        )}
                    </ul>
                </nav>
                {/* Botón de cerrar sesión al final del aside */}
                <div className={style.logoutContainer}>
                    <button
                        className={style.logoutButton}
                        onClick={handleLogout}
                    >
                        Cerrar sesión
                    </button>
                </div>
            </div>
        </>
    );
};
