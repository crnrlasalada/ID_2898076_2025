import React, { useState } from "react";
import styles from "./ReportProducts.module.css";

export const ReportProducts = () => {
    const [isModalOpen, setModalOpen] = useState(false);

    const openModal = () => setModalOpen(true);
    const closeModal = () => setModalOpen(false);

    const handleGenerate = (type) => {
        // Aquí iría la lógica para generar PDF o Excel
        alert(`Generando reporte en formato ${type.toUpperCase()}`);
        closeModal();
    };

    return (
        <div>
        <button className={styles.button} onClick={openModal}>
            Generar Reporte
        </button>

        {isModalOpen && (
            <div className={styles.modalOverlay}>
            <div className={styles.modal}>
                <h2>Generar Reporte</h2>
                <p>Selecciona el formato:</p>
                <div className={styles.options}>
                <button onClick={() => handleGenerate("pdf")}>📄 PDF</button>
                <button onClick={() => handleGenerate("excel")}>📊 Excel</button>
                </div>
                <button className={styles.closeBtn} onClick={closeModal}>
                Cerrar
                </button>
            </div>
            </div>
        )}
        </div>
    );
};
