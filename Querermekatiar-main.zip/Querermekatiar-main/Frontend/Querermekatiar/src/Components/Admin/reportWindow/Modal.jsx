import style from "./Modal.module.css";

export const Modal = ({ isOpen, onClose, children }) => {
    if (!isOpen) return null;

    return (
        <div className={style.modalOverlay}>
            <div className={style.modalContent}>
                <button className={style.modalClose} onClick={onClose}>✖</button>
                {children}
            </div>
        </div>
    );
};
