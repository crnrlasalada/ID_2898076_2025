import { useState, useEffect } from "react";
import { FaTrash, FaFileUpload } from "react-icons/fa";
import styles from "./ImageUploadSection.module.css";
import { OrderService } from '../../../api/services/OrderService';


const ModalConfirmacion = ({ isOpen, onClose, onConfirm }) => {
    if (!isOpen) return null;
    return (
        <div className={styles.confirmModalOverlay}>
            <div className={styles.confirmModal}>
                <h3 className={styles.confirmModalTitle}>
                    ¿Seguro que quieres eliminar esta imagen?
                </h3>
                <div className={styles.confirmModalBtns}>
                    <button className={styles.confirmDeleteBtn} onClick={onConfirm}>
                        Sí, eliminar
                    </button>
                    <button className={styles.confirmCancelBtn} onClick={onClose}>
                        Cancelar
                    </button>
                </div>
            </div>
        </div>
    );
};

    const ImageUploadSection = ({ negocioId }) => {
    const [imagenes, setImagenes] = useState([]);
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [imagenAEliminar, setImagenAEliminar] = useState(null);
    const [subiendo, setSubiendo] = useState(false);
    const [progreso, setProgreso] = useState(0);

    // Cargar imágenes según negocio
    useEffect(() => {
        if (!negocioId) return;
        OrderService.getNovedadesByNegocio(negocioId)
        .then((data) => setImagenes(data))
        .catch((err) => console.error("Error al cargar novedades", err));
    }, [negocioId]);

    // Subir imagen
    const handleUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setSubiendo(true);
        setProgreso(0);

        const formData = new FormData();
        formData.append("file", file);
        formData.append("idNegocio", negocioId);

        try {
        // No se puede usar onUploadProgress con fetch, solo con axios directamente
        const data = await OrderService.uploadNovedadImagen(formData);
        setImagenes([...imagenes, data]);
        } catch (error) {
        console.error("Error al subir imagen:", error);
        } finally {
        setSubiendo(false);
        setProgreso(0);
        }
    };

    // Eliminar imagen
    const confirmarEliminar = (img) => {
        setImagenAEliminar(img);
        setConfirmOpen(true);
    };

    const eliminarImagen = async () => {
        if (!imagenAEliminar) return;
        try {
        await OrderService.deleteNovedadImagen(imagenAEliminar.idNovedad);
        setImagenes(imagenes.filter((img) => img.idNovedad !== imagenAEliminar.idNovedad));
        } catch (error) {
        console.error("Error al eliminar imagen:", error);
        } finally {
        setConfirmOpen(false);
        setImagenAEliminar(null);
        }
    };

    return (
        <div className={styles.imageUploadSection}>
        <label className={styles.uploadBtn}>
            <FaFileUpload /> Subir imagen
            <input type="file" hidden onChange={handleUpload} />
        </label>

        <div className={styles.imageGallery}>
            {imagenes.map((img) => (
            <div key={img.idNovedad} className={styles.imageCard}>
                <img src={img.imagenUrl} alt="novedad" />
                <button
                className={styles.deleteButton}
                onClick={() => confirmarEliminar(img)}
                >
                <FaTrash />
                </button>

                {subiendo && (
                <div className={styles.uploadOverlay}>
                    <div className={styles.progressTrack}>
                    <div
                        className={styles.progressFill}
                        style={{ width: `${progreso}%` }}
                    ></div>
                    </div>
                    {progreso}%
                </div>
                )}
            </div>
            ))}
        </div>

        <ModalConfirmacion
            isOpen={confirmOpen}
            onClose={() => setConfirmOpen(false)}
            onConfirm={eliminarImagen}
        />
        </div>
    );
};

export default ImageUploadSection;
