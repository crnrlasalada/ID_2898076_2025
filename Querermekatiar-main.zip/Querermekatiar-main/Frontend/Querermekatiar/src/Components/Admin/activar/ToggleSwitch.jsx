import React, { useState } from 'react';
import styles from './ToggleSwitch.module.css';


import { useEffect } from 'react';

const ToggleSwitch = ({ initial = false, onToggle, disabled }) => {
    const [isOn, setIsOn] = useState(initial);

    // Sincroniza el estado interno si cambia el prop initial
    useEffect(() => {
        setIsOn(initial);
    }, [initial]);

    const handleClick = () => {
        if (disabled) return;
        const nuevoEstado = !isOn;
        setIsOn(nuevoEstado);
        if (onToggle) onToggle(nuevoEstado);
    };

    return (
        <div className={styles.switchContainer} onClick={handleClick} style={{ opacity: disabled ? 0.5 : 1, pointerEvents: disabled ? 'none' : 'auto' }}>
            <div className={`${styles.switch} ${isOn ? styles.on : styles.off}`}>
                <div className={styles.knob} />
            </div>
        </div>
    );
};

export default ToggleSwitch;
