import amekatiarLogo from "../../../assets/images/Amekatiar/Admin/amekatiar-logo.png";
import quererteLogo from "../../../assets/images/Quererte/User/logo_quererte.webp";
import style from "./ActivarDesactivar.module.css";
import ToggleSwitch from "./ToggleSwitch";
import bgstyles from "../../../assets/Styles/bg.module.css";

import { OrderService } from "../../../api/services/OrderService";
import { useEffect, useState } from 'react';


export const ActivarDesactivar = () => {
    const [estadoQuererte, setEstadoQuererte] = useState(null);
    const [estadoAmekatiar, setEstadoAmekatiar] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [updating, setUpdating] = useState({}); // {1: false, 2: false}

    useEffect(() => {
        document.body.className = bgstyles.bg;
        return () => { document.body.className = ""; };
    }, []);

    useEffect(() => {
        const fetchEstados = async () => {
            setLoading(true);
            setError(null);
            try {
                const [activoAmekatiar, activoQuererte] = await Promise.all([
                    OrderService.getActivo(1),
                    OrderService.getActivo(2)
                ]);
                setEstadoAmekatiar(!!activoAmekatiar);
                setEstadoQuererte(!!activoQuererte);
            } catch (err) {
                setError("Error al cargar estados de los negocios");
            } finally {
                setLoading(false);
            }
        };
        fetchEstados();
    }, []);

    const handleToggle = async (idNegocio, nuevoEstado) => {
        setUpdating(u => ({ ...u, [idNegocio]: true }));
        setError(null);
        try {
            const activo = nuevoEstado ? 1 : 0;
            await OrderService.putActivo(idNegocio, activo);
            if (idNegocio === 1) setEstadoAmekatiar(nuevoEstado);
            if (idNegocio === 2) setEstadoQuererte(nuevoEstado);
        } catch (err) {
            setError("Error actualizando estado del negocio");
        } finally {
            setUpdating(u => ({ ...u, [idNegocio]: false }));
        }
    };

    return (
        <section className={style.container}>
            {loading ? (
                <div>Cargando estados...</div>
            ) : error ? (
                <div style={{color: 'red', margin: 16}}>{error}</div>
            ) : (
                <div className={style["logos-row"]}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                        <img src={quererteLogo} alt="Logo Quererte" className={style["logo-quererte"]} />
                        <div className={style["switch-quererte-mobile"]}>
                            <ToggleSwitch
                                initial={estadoQuererte}
                                disabled={updating[2]}
                                onToggle={(nuevo) => handleToggle(2, nuevo)}
                            />
                        </div>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                        <img src={amekatiarLogo} alt="Logo Amekatiar" className={style["logo-amekatiar"]} />
                        <div className={style["switch-amekatiar-mobile"]}></div>
                        <ToggleSwitch
                            initial={estadoAmekatiar}
                            disabled={updating[1]}
                            onToggle={(nuevo) => handleToggle(1, nuevo)}
                        />
                        </div>
                </div>
            )}
        </section>
    );
};
