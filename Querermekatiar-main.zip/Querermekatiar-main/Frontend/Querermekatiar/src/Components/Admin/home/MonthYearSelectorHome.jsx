import React from "react";
import styles from "./MonthYearSelectorHome.module.css";

const MonthYearSelectorHome = ({ filterType, month, setMonth, year, setYear }) => {
    const meses = [
        { value: "01", label: "Enero" },
        { value: "02", label: "Febrero" },
        { value: "03", label: "Marzo" },
        { value: "04", label: "Abril" },
        { value: "05", label: "Mayo" },
        { value: "06", label: "Junio" },
        { value: "07", label: "Julio" },
        { value: "08", label: "Agosto" },
        { value: "09", label: "Septiembre" },
        { value: "10", label: "Octubre" },
        { value: "11", label: "Noviembre" },
        { value: "12", label: "Diciembre" },
    ];

    const currentYear = new Date().getFullYear();
    const years = [];
    for (let y = 2020; y <= currentYear + 5; y++) {
        years.push(y);
    }

    return (
        <div className={styles.container}>
            {filterType === "mes" && (
                <>
                    <label className={styles.label}>Mes:</label>
                    <select
                        value={month}
                        onChange={e => setMonth(e.target.value)}
                        className={styles.select}
                    >
                        <option value="">Selecciona mes</option>
                        {meses.map(m => (
                            <option key={m.value} value={m.value}>
                                {m.label}
                            </option>
                        ))}
                    </select>
                </>
            )}

            {(filterType === "mes" || filterType === "año") && (
                <>
                    <label className={styles.label}>Año:</label>
                    <select
                        value={year}
                        onChange={e => setYear(e.target.value)}
                        className={styles.select}
                    >
                        <option value="">Selecciona año</option>
                        {years.map(y => (
                            <option key={y} value={y}>
                                {y}
                            </option>
                        ))}
                    </select>
                </>
            )}
        </div>
    );
};

export default MonthYearSelectorHome;
