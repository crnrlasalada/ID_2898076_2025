import React, { useState, useEffect, useMemo } from "react";
import MonthYearSelectorHome from "./MonthYearSelectorHome";
import GraficaProductosHome from "./GraficaProductosHome";
import GraficaPastelHome from "./GraficaPastelHome";
import GraficaMetodoPagoHome from "./GraficaMetodoPagoHome";
import GraficaPedidosPorHoraHome from "./GraficaPedidosPorHoraHome";
import GraficaEstadosHome from "./GraficaEstadosHome";
import ResumenCardsHome from "./ResumenCardsHome";
import ReportService from "../../../api/services/ReportService";
import styles from "./ReportFilterPanelHome.module.css";
import bgstyles from "../../../assets/Styles/bg2.module.css";

const HomeComponent = () => {
        useEffect(() => {
            document.body.className = bgstyles.bg;
            return () => {
                document.body.className = "";
            };
        }, []);

    // Siempre usar mes y año actual
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const year = String(today.getFullYear());
    const [pedidos, setPedidos] = useState([]);

    // Cargar datos solo una vez al montar (siempre mes/año actual)
    useEffect(() => {
        filtrarPedidos();
        // eslint-disable-next-line
    }, []);

    const filtrarPedidos = async () => {
        try {
            const data = await ReportService.getPedidosPorMesYAnio(parseInt(year), parseInt(month));
            setPedidos(data || []);
        } catch (error) {
            console.error("Error al obtener pedidos:", error);
            alert("Hubo un problema al cargar los datos");
        }
    };

    const resumen = useMemo(() => {
        let totalPedidos = pedidos.length;
        let totalGanancias = 0;
        let totalProductosVendidos = 0;
        let totalDomicilio = 0;
        let totalLocal = 0;

        pedidos.forEach((pedido) => {
            totalGanancias += parseFloat(pedido.total || 0);
            if ((pedido.tipoEntrega || "").toLowerCase().includes("domicilio")) totalDomicilio++;
            else totalLocal++;
            pedido.productos.forEach((producto) => {
                totalProductosVendidos += producto.cantidad || 0;
            });
        });

        return { totalPedidos, totalGanancias, totalProductosVendidos, totalDomicilio, totalLocal };
    }, [pedidos]);

    return (
        <div className={styles.panel}>
            <h1 className={styles.title}>📊 <span>Panel Administrativo</span></h1>
            {/* Filtro eliminado, siempre datos del mes actual */}

            {/* Resumen */}
            {pedidos.length > 0 && (
                <div className={styles.responsiveResumenCards}>
                    <ResumenCardsHome resumen={resumen} grande compacta />
                </div>
            )}

            {/* Gráficas */}
            {pedidos.length > 0 && (
                <div className={styles.graficasContainer}>
                    {/* Productos */}
                    <div className={styles.responsiveMainChart}>
                        <GraficaProductosHome pedidos={pedidos} />
                    </div>

                    {/* Estados y pedidos por hora */}
                    <div className={styles.responsiveChartsGrid}>
                        <div className={styles.responsiveChartCard}>
                            <GraficaEstadosHome pedidos={pedidos} />
                        </div>
                        <div className={styles.responsiveChartCard}>
                            <GraficaPedidosPorHoraHome pedidos={pedidos} />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default HomeComponent;
