import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { FaCreditCard, FaMoneyBillWave, FaUniversity } from "react-icons/fa";

const COLORS = ["#43e97b", "#f59e42", "#6366f1", "#eab308", "#e53935"];
const ICONS = {
  efectivo: <FaMoneyBillWave style={{ color: '#43e97b', fontSize: '1.2rem', marginRight: 6 }} />, 
  transferencia: <FaUniversity style={{ color: '#f59e42', fontSize: '1.2rem', marginRight: 6 }} />
};

function normalizaMetodo(metodo) {
  if (!metodo) return '';
  const m = metodo.toLowerCase();
  if (m.includes('efectivo')) return 'efectivo';
  if (m.includes('transfer')) return 'transferencia';
  return '';
}

const GraficaMetodoPagoHome = ({ pedidos }) => {
  let efectivo = 0;
  let transferencia = 0;
  pedidos.forEach(p => {
    const metodo = normalizaMetodo(p.forma_pago || p.formaPago || p.metodoPago);
    if (metodo === 'efectivo') efectivo++;
    if (metodo === 'transferencia') transferencia++;
  });
  const data = [
    { name: 'efectivo', value: efectivo, color: COLORS[0], icon: ICONS['efectivo'] },
    { name: 'transferencia', value: transferencia, color: COLORS[1], icon: ICONS['transferencia'] }
  ];
  const total = efectivo + transferencia;

  return (
    <div style={{ background: '#fff', borderRadius: 14, boxShadow: '0 2px 8px #0001', padding: 10, minWidth: 160, minHeight: 160, maxWidth: 200, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <h4 style={{ fontWeight: 700, color: '#1e293b', marginBottom: 8, fontSize: '1.02rem' }}>Método de pago más usado</h4>
      {total === 0 ? (
        <div style={{ color: '#64748b', fontWeight: 500, marginTop: 18, fontSize: '0.98rem' }}>No hay datos de métodos de pago</div>
      ) : (
        <>
          <ResponsiveContainer width={100} height={100}>
            <PieChart>
              <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={38} innerRadius={18} label>
                {data.map((entry, idx) => (
                  <Cell key={entry.name} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <ul style={{ listStyle: 'none', margin: 0, marginTop: 8, padding: 0, fontSize: '0.93rem', color: '#475569', width: '100%' }}>
            {data.map((item, idx) => (
              <li key={item.name} style={{ display: 'flex', alignItems: 'center', marginBottom: 2 }}>
                {item.icon}
                <span style={{ fontWeight: 500, marginRight: 4 }}>{item.name.charAt(0).toUpperCase() + item.name.slice(1)}</span>
                <span style={{ color: '#64748b', fontWeight: 400, marginLeft: 'auto' }}>{item.value}</span>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};

export default GraficaMetodoPagoHome;
