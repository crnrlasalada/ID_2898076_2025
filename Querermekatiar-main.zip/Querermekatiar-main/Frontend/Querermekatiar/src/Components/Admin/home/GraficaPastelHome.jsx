
import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    ResponsiveContainer,
    Legend,
} from "recharts";

import styles from "./GraficaPastelHome.module.css";

const COLORS = [
    "#43e97b", // verde principal
    "#6366f1", // azul
    "#f59e42", // naranja
    "#38f9d7", // verde agua
    "#eab308", // dorado
    "#4f46e5", // azul oscuro
    "#22c55e", // verde secundario
    "#ffb347", // naranja claro
    "#a29bfe", // lila
    "#ff6b6b"  // rojo suave
];

const GraficaPastelHome = ({ pedidos }) => {
    const productosMap = {};

    pedidos.forEach((pedido) => {
        pedido.productos.forEach((producto) => {
        const nombre = producto.nombre || "Sin nombre";
        const total = (producto.cantidad || 0) * (producto.precio || 0);
        productosMap[nombre] = (productosMap[nombre] || 0) + total;
        });
    });

    const data = Object.entries(productosMap).map(([nombre, total]) => ({
        name: nombre,
        value: total,
    }));

    return (
        <div className={styles.container} style={{ background: 'white', borderRadius: '1.2rem', boxShadow: '0 2px 8px rgba(0,0,0,0.07)', padding: '1.2rem', width: 240, height: 220, maxWidth: 260, minWidth: 220, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <h3 className={styles.title} style={{ fontSize: '1.05rem', marginBottom: 8 }}>Ingresos por producto</h3>
            <div className={styles.pastelChartWrapper}>
                <ResponsiveContainer width={160} height={120}>
                    <PieChart>
                        <Pie dataKey="value" data={data} cx="50%" cy="50%" outerRadius={48} innerRadius={22} label={false}>
                            {data.map((_, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
                <div className={styles.legendContainer}>
                    {/* Leyenda personalizada para mostrar qué representa cada color */}
                    {data.length > 0 && (
                        <ul style={{ listStyle: 'none', padding: 0, margin: '1rem 0 0 0', width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
                            {data.map((item, idx) => (
                                <li key={item.name} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.93rem' }}>
                                    <span style={{ display: 'inline-block', width: 13, height: 13, borderRadius: '50%', background: COLORS[idx % COLORS.length], border: '1px solid #ccc' }}></span>
                                    <span style={{ fontWeight: 500, color: '#1e293b' }}>{item.name}: <span style={{ color: '#64748b', fontWeight: 400 }}>${item.value.toLocaleString('es-CO')}</span></span>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

export default GraficaPastelHome;
