import React from "react";
import styles from "./ResumenCardsHome.module.css";
import { FaBoxOpen, FaMoneyBillWave, FaShoppingCart, FaStore } from "react-icons/fa";



const ResumenCardsHome = ({ resumen, soloColumnaPequenas }) => {
  // Desestructurar los datos del resumen
  const {
  totalPedidos = 0,
  totalProductosVendidos = 0,
  totalGanancias = 0,
  totalDomicilio = 0,
  totalLocal = 0,
  totalL = totalDomicilio + totalLocal,
  } = resumen || {};

  // Formatear valores
  const formatNumber = (n) => n?.toLocaleString("es-CO") || 0;

  if (soloColumnaPequenas) {
    // Todas las cards en una columna, todas pequeñas
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem', width: '100%', alignItems: 'flex-end' }}>
        <div className={`${styles.card} ${styles.cardPequena}`}>
          <FaBoxOpen className={styles.cardIcon} />
          <div className={styles.cardTitle}>Total Pedidos</div>
          <div className={styles.cardValue}>{formatNumber(totalPedidos)}</div>
          <div className={styles.cardDate}>Actualizado: Hoy</div>
        </div>
        <div className={`${styles.card} ${styles.cardPequena}`}>
          <FaShoppingCart className={styles.cardIcon} />
          <div className={styles.cardTitle}>Productos Vendidos</div>
          <div className={styles.cardValue}>{formatNumber(totalProductosVendidos)}</div>
          <div className={styles.cardDate}>Últimos 30 días</div>
        </div>
        <div className={`${styles.card} ${styles.cardPequena}`}>
          <FaMoneyBillWave className={styles.cardIcon} />
          <div className={styles.cardTitle}>Ganancias</div>
          <div className={styles.cardValue}>$25,430</div>
          <div className={styles.cardDate}>Mes actual</div>
        </div>
        <div className={`${styles.card} ${styles.cardPequena}`}>
          <FaStore className={styles.cardIcon} />
          <div className={styles.cardTitle}>Ventas Local/Domicilio</div>
          <div className={styles.cardValue}>
            {totalL > 0 ? `${Math.round(totalLocal/totalL*100)}% / ${Math.round(totalDomicilio/totalL*100)}%` : '0% / 0%'}
          </div>
          <div className={styles.cardDate}>Mes actual</div>
        </div>
      </div>
    );
  }

  // Layout original (no usado en el nuevo dashboard)
  return (
    <div className={styles.imagenesContainer}>
      {/* Contenedor izquierdo - Tarjetas grandes */}
      <div className={styles.grandesContainer}>
        <div className={`${styles.card} ${styles.cardGrande}`}>
          <FaBoxOpen className={styles.cardIcon} />
          <div className={styles.cardTitle}>Total Pedidos</div>
          <div className={styles.cardValue}>{formatNumber(totalPedidos)}</div>
          <div className={styles.cardDate}>Actualizado: Hoy</div>
        </div>

        <div className={`${styles.card} ${styles.cardGrande}`}>
          <FaShoppingCart className={styles.cardIcon} />
          <div className={styles.cardTitle}>Productos Vendidos</div>
          <div className={styles.cardValue}>{formatNumber(totalProductosVendidos)}</div>
          <div className={styles.cardDate}>Últimos 30 días</div>
        </div>
      </div>

      {/* Contenedor derecho - Tarjetas pequeñas (sin cambios) */}
      <div className={styles.pequenasContainer}>
        <div className={`${styles.card} ${styles.cardPequena}`}>
          <FaMoneyBillWave className={styles.cardIcon} />
          <div className={styles.cardTitle}>Ganancias</div>
          <div className={styles.cardValue}>${formatNumber(totalGanancias)}</div>
          <div className={styles.cardDate}>Mes actual</div>
        </div>

        <div className={`${styles.card} ${styles.cardPequena}`}>
          <FaStore className={styles.cardIcon} />
          <div className={styles.cardTitle}>Ventas Local/Domicilio</div>
          <div className={styles.cardValue}>
            {totalL > 0 ? `${Math.round(totalLocal/totalL*100)}% / ${Math.round(totalDomicilio/totalL*100)}%` : '0% / 0%'}
          </div>
          <div className={styles.cardDate}>Mes actual</div>
        </div>
      </div>

    </div>
  );
};

export default ResumenCardsHome;
