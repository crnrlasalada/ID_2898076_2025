
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    CartesianGrid,
    Legend,
} from "recharts";


import styles from "./GraficaProductosHome.module.css";
import { useEffect, useState } from "react";

const GraficaProductosHome = ({ pedidos }) => {
    const productosVendidos = {};

    pedidos.forEach((pedido) => {
        pedido.productos.forEach((producto) => {
        const nombre = producto.nombre || "Sin nombre";
        productosVendidos[nombre] = (productosVendidos[nombre] || 0) + producto.cantidad;
        });
    });

    const data = Object.entries(productosVendidos).map(([nombre, cantidad]) => ({
        nombre,
        cantidad,
    }));

    // Responsive height for the chart
    const [chartHeight, setChartHeight] = useState(400);

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth <= 600) {
                setChartHeight(120);
            } else if (window.innerWidth <= 900) {
                setChartHeight(220);
            } else {
                setChartHeight(400);
            }
        };
        handleResize();
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    return (
        <div className={styles.container}>
            <h3 className={styles.title}>Productos más vendidos</h3>
            <ResponsiveContainer width="100%" height={chartHeight}>
                <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="nombre" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="cantidad" fill="#6366f1" name="Cantidad vendida" radius={[8,8,0,0]} />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default GraficaProductosHome;
