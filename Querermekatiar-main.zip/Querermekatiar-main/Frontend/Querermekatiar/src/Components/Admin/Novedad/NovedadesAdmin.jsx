


import ImageUploadSection from "../../../components/Admin/imagenesConBoton/ImageUploadSection";
import styles from "./NovedadesAdmin.module.css";
import amekatiarBg from "../../../assets/images/Amekatiar/User/amekatiar-logo.webp";
import quererteBg from "../../../assets/images/Quererte/User/logo_quererte.webp";

const NovedadesAdmin = ({ selectedNegocio }) => {
  // Determinar fondo, color y estilos según negocio
  const isAmekatiar = selectedNegocio === 1;
  const bgColor = isAmekatiar ? "#F0B617" : "#18181b";
  const titleColor = isAmekatiar ? "#F0B617" : "#fff";
  const logo = isAmekatiar ? amekatiarBg : quererteBg;

  return (
    <div
      className={styles.adminWrapper}
      style={{
        background: bgColor,
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "flex-start",
        position: "relative",
        overflow: "hidden",
        transition: "background 0.4s"
      }}
    >
      {/* Logo de fondo centrado, sin fondo extra, opacidad baja */}
      <img
        src={logo}
        alt="logo fondo"
        className={styles.responsiveLogo}
        style={{
          position: "absolute",
          top: "calc(50% - 170px)",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: isAmekatiar ? "38vw" : "30vw",
          minWidth: isAmekatiar ? "220px" : "150px",
          maxWidth: isAmekatiar ? "744px" : "556px",
          height: "auto",
          opacity: isAmekatiar ? 0.8 : 1,
          zIndex: 0,
          pointerEvents: "none",
          filter: isAmekatiar ? "none" : "grayscale(0.2)",
          transition: "width 0.3s, min-width 0.3s, max-width 0.3s"
        }}
      />
  {/* Título eliminado, solo se muestra en el padre */}
      <div style={{ width: "100%", zIndex: 2 }}>
        <ImageUploadSection negocioId={selectedNegocio} />
      </div>
    </div>
  );
};

export default NovedadesAdmin;
