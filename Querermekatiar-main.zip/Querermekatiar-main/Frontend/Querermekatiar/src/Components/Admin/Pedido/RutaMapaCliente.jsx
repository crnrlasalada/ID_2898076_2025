import React, { useEffect, useState, useRef } from 'react';
import {
    GoogleMap,
    useJsApiLoader,
    DirectionsRenderer,
    Marker,
} from '@react-google-maps/api';

// Estilo del contenedor del mapa
const containerStyle = {
    width: '100%',
    height: '300px',
    borderRadius: '10px',
    marginTop: '20px',
};

// Coordenadas del negocio
const NEGOCIO_COORDS = {
    lat: 6.0463011700597145,
    lng: -75.9077093606381,
};

// Librerías para evitar el warning
const LIBRARIES = ['marker'];


export const RutaMapaCliente = ({ lat, lng }) => {
    const mapRef = useRef(null);
    const [directions, setDirections] = useState(null);

    const clienteCoords = {
        lat: parseFloat(lat),
        lng: parseFloat(lng),
    };

    const { isLoaded } = useJsApiLoader({
        googleMapsApiKey: 'AIzaSyCWVBPQpiUtlwI5Iqew5w0eY0M6FERjIKA',
    });

    useEffect(() => {
        if (
        isLoaded &&
        clienteCoords.lat &&
        clienteCoords.lng &&
        !isNaN(clienteCoords.lat) &&
        !isNaN(clienteCoords.lng)
        ) {
        const directionsService = new window.google.maps.DirectionsService();

        directionsService.route(
            {
            origin: NEGOCIO_COORDS,
            destination: clienteCoords,
            travelMode: window.google.maps.TravelMode.DRIVING,
            },
            (result, status) => {
            if (status === 'OK') {
                setDirections(result);
            } else {
                console.error('Error obteniendo la ruta:', status);
            }
            }
        );
        }
    }, [isLoaded, lat, lng]);

    const handleDoubleClick = () => {
        const url = `https://www.google.com/maps/dir/?api=1&origin=${NEGOCIO_COORDS.lat},${NEGOCIO_COORDS.lng}&destination=${clienteCoords.lat},${clienteCoords.lng}&travelmode=driving`;
        window.open(url, '_blank');
    };

    if (!isLoaded) return <p>Cargando mapa...</p>;

    return (
        <GoogleMap
        mapContainerStyle={containerStyle}
        center={NEGOCIO_COORDS}
        zoom={14}
        onLoad={(map) => (mapRef.current = map)}
        onDblClick={handleDoubleClick}
        >
        {/* Mostrar ruta pero sin marcadores A y B */}
        {directions && (
            <DirectionsRenderer
            directions={directions}
            options={{ suppressMarkers: true }}
            />
        )}

        <Marker
            position={NEGOCIO_COORDS}
            icon={{
                url: 'https://api.iconify.design/mdi/store.svg?color=%23000000',
                scaledSize: new window.google.maps.Size(40, 40),
            }}
            label={{
                color: 'black',
                fontWeight: 'bold',
                fontSize: '12px',
            }}
            />

            <Marker
            position={clienteCoords}
            icon={{
                url: 'https://api.iconify.design/mdi/account.svg?color=%23000000',
                scaledSize: new window.google.maps.Size(40, 40),
            }}
            label={{
                color: 'black',
                fontWeight: 'bold',
                fontSize: '12px',
            }}
            />
        </GoogleMap>
    );
};
