import React from 'react';
import styles from './EstadoBotones.module.css';

const transiciones = {
    pendiente: [
        { label: "Aceptar", estado: "en_proceso", color: "verde" },
        { label: "Rechazar", estado: "rechazado_admin", color: "rojo" }
    ],
    en_proceso: [
        { label: "Cambiar a Preparando", estado: "preparando" }
    ],
    preparando: [
        { label: "Cambiar a Listo", estado: "listo_para_despacho" }
    ],
    listo_para_despacho: [
        { label: "Despachar", estado: "despachado" },
        { label: "Entregar en local", estado: "entregado" }
    ],
    despachado: [
        { label: "Confirmar entrega", estado: "entregado" },
        { label: "No recibido", estado: "no_recibido" }
    ]
};

const EstadoBotones = ({ estadoActual, setEstadoActual }) => {
    const opciones = transiciones[estadoActual.toLowerCase()] || [];

    if (opciones.length === 0) return null;

    return (
        <div className={styles.botonesContainer}>
            {opciones.map((opcion, index) => (
                <button
                    key={index}
                    onClick={() => setEstadoActual(opcion.estado)}
                    className={`${styles.boton} ${opcion.color === "verde" ? styles.verde : ""} ${opcion.color === "rojo" ? styles.rojo : ""}`}
                >
                    {opcion.label}
                </button>
            ))}
        </div>
    );
};

export default EstadoBotones;
