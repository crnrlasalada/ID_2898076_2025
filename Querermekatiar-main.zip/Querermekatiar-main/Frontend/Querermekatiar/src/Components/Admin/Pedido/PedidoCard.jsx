import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import EstadoBarra from './EstadoBarra';
import styles from './PedidoCard.module.css';
import { OrderService } from '../../../api/services/OrderService';

const estadosFinales = ['Entregado', 'Rechazado', 'No_Recibido'];

const formatearEstado = (estado) =>
    estado.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());


const PedidoCard = ({ pedido, onAsignadoRepartidor, onFinalizado, ocultando }) => {
    const navigate = useNavigate();
    const [estadoActual, setEstadoActual] = useState(pedido.estadoPedido);
    const [estadoPendiente, setEstadoPendiente] = useState('');
    const [mostrarModal, setMostrarModal] = useState(false);
    const [motivo, setMotivo] = useState('');
    const [mensajeExito, setMensajeExito] = useState('');
    const [mostrarConfirmacionReparto, setMostrarConfirmacionReparto] = useState(false);
    const [mostrarPopupAsignado, setMostrarPopupAsignado] = useState(false);

    const tipoEntrega = pedido.tipoEntrega;
    const esFinalizado = estadosFinales.includes(estadoActual);

    const cambiarEstado = (nuevoEstado) => {
        if (esFinalizado) {
            alert("Este pedido ya fue finalizado y no puede modificarse.");
            return;
        }

        if (estadoActual === 'Pendiente') {
            alert('Debes aceptar el pedido desde el detalle para poder cambiar de estado.');
            return;
        }

        if (nuevoEstado === estadoActual) return;

        // Confirmación especial para Domicilio -> Reparto
        if (nuevoEstado === 'Reparto' && tipoEntrega === 'Domicilio') {
            setMostrarConfirmacionReparto(true);
            return;
        }

        if (
            (estadoActual === 'Reparto' && tipoEntrega === 'Local') &&
            (nuevoEstado === 'Entregado' || nuevoEstado === 'No_Recibido')
        ) {
            setEstadoPendiente(nuevoEstado);
            if (nuevoEstado === 'No_Recibido') {
                setMostrarModal(true);
            } else {
                confirmarCambio(nuevoEstado);
            }
            return;
        }

        // Si es estado final desde cualquier barra, mostrar modal de finalización
        if (["Entregado", "Rechazado", "No_Recibido"].includes(nuevoEstado)) {
            confirmarCambio(nuevoEstado);
            return;
        }

        alert("Este estado solo se puede gestionar desde el detalle o no es válido para cambiar desde aquí.");
    };


    const confirmarCambio = async (nuevoEstado, motivoText = null, redirigir = false) => {
        try {
            await OrderService.updateEstado(pedido.id, nuevoEstado, motivoText);
            setEstadoActual(nuevoEstado);
            setMensajeExito(`Estado actualizado a ${formatearEstado(nuevoEstado)} correctamente.`);
            setTimeout(() => setMensajeExito(''), 3000);
            if (redirigir) {
                if (onAsignadoRepartidor && tipoEntrega === 'Domicilio' && nuevoEstado === 'Reparto') {
                    onAsignadoRepartidor(pedido.id);
                } else {
                    setTimeout(() => navigate('/admin/pedidos'), 1200);
                }
            }
            // Si es estado final, mostrar popup de finalización y animar salida
            if (onFinalizado && ["Entregado", "Rechazado", "No_Recibido"].includes(nuevoEstado)) {
                onFinalizado(pedido.id, nuevoEstado);
            }
        } catch (err) {
            console.error('Error actualizando estado:', err);
        } finally {
            setMostrarModal(false);
            setMotivo('');
        }
    };

    const irDetalle = () => {
        navigate(`/admin/pedidos/${pedido.id}`);
    };

    // Si es Domicilio y está en Reparto, ocultar
    if (estadoActual === 'Reparto' && tipoEntrega === 'Domicilio') return null;


    return (
        <div className={styles.card + (ocultando ? ' ' + styles.ocultando : '')}>
            <div onClick={irDetalle} className={styles.cardContent}>
                <div className={styles.header}>
                    <h3>Pedido #{pedido.id}</h3>
                    <span>{
                        new Date(pedido.fechaHora).toLocaleString('es-CO', {
                            hour: 'numeric',
                            minute: '2-digit',
                            hour12: true,
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            timeZone: 'America/Bogota'
                        })
                    }</span>
                </div>

                <p><strong>Entrega:</strong> {pedido.tipoEntrega}</p>
                <p><strong>Total:</strong> ${pedido.total}</p>

                <EstadoBarra
                    estadoActual={estadoActual}
                    setEstadoActual={cambiarEstado}
                    tipoEntrega={tipoEntrega}
                />

                {mensajeExito && (
                    <div className={styles.alertaExito}>
                        ✅ {mensajeExito}
                    </div>
                )}
            </div>
            {/* Botón Ver Detalle color mostaza, pequeño y abajo a la derecha */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', margin: '8px 8px 4px 0' }}>
                <button
                    className={styles.botonMostaza}
                    style={{ minWidth: 70, fontWeight: 600, fontSize: '0.85rem', padding: '8px 10px' }}
                    onClick={e => { e.stopPropagation(); irDetalle(); }}
                >
                    Ver detalle
                </button>
            </div>

            {estadoActual === 'Pendiente' && (
                <div className={styles.alertaAdvertencia}>
                    ⚠️ Este pedido debe gestionarse desde el detalle.
                </div>
            )}

            {/* Modal para No Recibido y para Local */}
            {mostrarModal && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modal}>
                        <h3>
                          {(estadoPendiente === 'Reparto' && (tipoEntrega || '').toLowerCase().includes('local'))
                            ? 'Motivo para marcar como Preparado'
                            : 'Motivo para marcar como No Recibido'}
                        </h3>
                        <textarea
                            rows="4"
                            value={motivo}
                            onChange={(e) => setMotivo(e.target.value)}
                            placeholder="Escribe el motivo..."
                        />
                        <div className={styles.botonesTransicion}>
                            <button
                                className={styles.botonEstado}
                                onClick={() => {
                                    if (!motivo.trim()) {
                                        alert("Debes ingresar un motivo.");
                                        return;
                                    }
                                    confirmarCambio(estadoPendiente, motivo);
                                }}
                            >
                                {(estadoPendiente === 'Reparto' && (tipoEntrega || '').toLowerCase().includes('local')) ? 'Preparado' : 'Confirmar'}
                            </button>
                            <button className={styles.botonEstado} onClick={() => setMostrarModal(false)}>
                                Cancelar
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Confirmación para pasar a Reparto en Domicilio */}
            {mostrarConfirmacionReparto && (
                <div className={styles.modalOverlay}>
                    <div className={styles.modalConfirmacionReparto}>
                        <h3>¿Deseas asignar este pedido al repartidor?</h3>
                        <div className={styles.mensaje}>
                          El pedido será entregado por un repartidor a domicilio.
                        </div>
                        <div className={styles.botonesConfirmacion}>
                            <button
                                className={styles.botonMostaza}
                                onClick={async () => {
                                    setMostrarConfirmacionReparto(false);
                                    setMostrarPopupAsignado(true);
                                    setTimeout(async () => {
                                        setMostrarPopupAsignado(false);
                                        await confirmarCambio('Reparto', null, true);
                                    }, 1000);
                                }}
                            >
                                Sí, asignar
                            </button>
                            <button className={styles.botonBlanco} onClick={() => setMostrarConfirmacionReparto(false)}>
                                Cancelar
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Popup de asignado al repartidor y botón Preparando */}
            {mostrarPopupAsignado && (
                                <div className={styles.modalOverlay}>
                                        <div className={styles.popupAsignado}>
                                                <span className={styles.iconoRepartidor} role="img" aria-label="Repartidor">🛵</span>
                                                <h3>¡Pedido asignado al repartidor!</h3>
                                                <div style={{ color: '#ff9800', fontWeight: 500, marginBottom: 10, textAlign: 'center', fontSize: '1.08rem' }}>
                                                    El pedido está en manos del repartidor para su entrega a domicilio.
                                                </div>
                                        </div>
                                </div>
            )}
        </div>
    );
};

export default PedidoCard;
