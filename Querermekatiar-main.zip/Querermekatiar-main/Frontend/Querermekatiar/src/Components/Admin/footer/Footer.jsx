import { Link } from "react-router-dom";
import styles from "./Footer.module.css";

export const Foother = () => {
    return (
        <footer className={styles.footer}>
        <div className={styles.section}>
            <h3 className={styles.title}>Sobre nosotros</h3>
            <p className={styles.text}>
            Amekatiar y Quererte son dos establecimientos líderes en Concordia,
            ofreciendo lo mejor en gastronomía y helados artesanales desde 2010.
            </p>
        </div>

        <div className={styles.section}>
            <h3 className={styles.title}>Enlaces rápidos</h3>
            <ul className={styles.links}>
            <li><Link to="/pedidos">Pedidos</Link></li>
            <li><Link to="/catalogos">Catálogos</Link></li>
            <li><Link to="/novedades">Novedades</Link></li>
            <li><Link to="/reportes">Reporte y análisis</Link></li>
            </ul>
        </div>

        <div className={styles.section}>
            <h3 className={styles.title}>Contáctanos</h3>
            <p className={styles.text}>Av. Principal 123, Concordia</p>
        </div>
        </footer>
    );
};
