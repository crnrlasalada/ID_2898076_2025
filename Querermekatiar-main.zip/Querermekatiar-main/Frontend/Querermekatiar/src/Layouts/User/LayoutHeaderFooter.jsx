import React from 'react';
import { NavBar } from '../../Components/User/NavBar';
import { Footer } from '../../Components/User/Footer';
import { Outlet } from 'react-router-dom';

export const LayoutHeaderFooter = () => {
  return (
    <>
      <NavBar />
      <Outlet />
      <Footer />
    </>
  );
};