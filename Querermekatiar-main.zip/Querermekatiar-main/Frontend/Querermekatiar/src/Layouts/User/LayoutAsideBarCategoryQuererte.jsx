import { useEffect, useState } from "react";
import { AsideCategoryQuererte } from '../../Components/User/AsideCategoryQuererte';
import { Outlet } from 'react-router-dom';
import styles from '../../assets/Styles/layout-asidebar.module.css';
import { CatalogService } from '../../api/services/CatalogService';

export const LayoutAsideBarCategoryQuererte = () => {
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);

  useEffect(() => {
    CatalogService.getCategoriesQuererte()
      .then(res => setCategories(Array.isArray(res.data) ? res.data : []))
      .catch(() => setCategories([]));
    CatalogService.getCatalogQuererte()
      .then(res => setProducts(Array.isArray(res.data) ? res.data : []))
      .catch(() => setProducts([]));
  }, []);

  return (
    <main className={styles.layoutMain}>
      <AsideCategoryQuererte categories={categories} products={products} />
      <div className={styles.layoutContent}>
        <Outlet />
      </div>
    </main>
  );
};