import { AsideCategoryAmekatiar } from '../../Components/User/AsideCategoryAmekatiar';
import { Outlet } from 'react-router-dom';
import styles from '../../assets/Styles/layout-asidebar.module.css'
import { useEffect, useState } from 'react';
import { CatalogService } from '../../api/services/CatalogService';

export const LayoutAsideBarCategoryAmekatiar = () => {
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);

  useEffect(() => {
    CatalogService.getCategoriesAmekatiar()
      .then(res => setCategories(Array.isArray(res.data) ? res.data : []))
      .catch(() => setCategories([]));
    CatalogService.getCatalogAmekatiar()
      .then(res => setProducts(Array.isArray(res.data) ? res.data : []))
      .catch(() => setProducts([]));
  }, []);

  return (
    <main className={styles.layoutMain}>
      <AsideCategoryAmekatiar categories={categories} products={products} />
      <div className={styles.layoutContent}>
        <Outlet />
      </div>
    </main>
  );
};