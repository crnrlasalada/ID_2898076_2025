
import { AsideBarProfile } from '../../Components/User/AsideBarProfile';
import styles from '../../assets/Styles/layout-asidebar.module.css'

import { Outlet } from 'react-router-dom';

export const LayoutWithAsidebar = () => {

  
  return (
  <>
     <main className={styles.layoutMain}>
      <AsideBarProfile />
      <div className={styles.layoutContent}>
        <Outlet />
      </div>
    </main>
  </>
  );
};
