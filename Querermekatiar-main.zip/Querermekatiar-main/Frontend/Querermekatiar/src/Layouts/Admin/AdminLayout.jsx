import { Outlet } from 'react-router-dom';
import { Foother } from '../../components/Admin/footer/Footer';
import style from './AdminLayout.module.css';
import { AsideBar } from '../../Components/Admin/aside/AsideBar.jsx';

export const AdminLayout = () => {
    return (
        <>
        <main className={style.layoutContent}>
            <AsideBar/>
            <div className={style.Main}>
                <Outlet />
            </div>
        </main>
        <footer className={style.layoutFooter}>
            <Foother />
        </footer>
        </>
    );
};


