import axios from 'axios';
import Swal from 'sweetalert2';

export const api = axios.create({
    baseURL: 'http://localhost:8080',
    timeout: 10000,
    withCredentials: true,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Variables para controlar el refresco
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
    failedQueue.forEach(prom => {
        if (error) {
            prom.reject(error);
        } else {
            prom.resolve(token);
        }
    });
    failedQueue = [];
};

// Interceptor de request
api.interceptors.request.use(
    async config => {
        let token = localStorage.getItem('token');
        if (!token) {
            return config; // Sin token, no hay Authorization ni refresco
        }

        try {
            const parts = token.split('.');
            const payload = JSON.parse(atob(parts[1]));
            if (payload.exp) {
                const expDate = new Date(payload.exp * 1000);
                const now = new Date();
                const secondsLeft = Math.floor((expDate - now) / 1000);

                if (secondsLeft < 120) {
                    if (isRefreshing) {
                        // Si ya se está refrescando, espera el nuevo token
                        return new Promise((resolve, reject) => {
                            failedQueue.push({ resolve, reject });
                        }).then(newToken => {
                            config.headers['Authorization'] = `Bearer ${newToken}`;
                            return config;
                        }).catch(err => Promise.reject(err));
                    }

                    isRefreshing = true;
                    try {
                        const { AuthService } = await import('./services/AuthService');
                        const newToken = await AuthService.refreshAccess();
                        if (!newToken) {
                            throw new Error('No se recibió un nuevo token');
                        }

                        localStorage.setItem('token', newToken);
                        api.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
                        config.headers['Authorization'] = `Bearer ${newToken}`;

                        processQueue(null, newToken);
                    } catch (err) {
                        console.warn('[AXIOS] Error al refrescar el token:', err);
                        processQueue(err, null);
                        localStorage.removeItem('token');
                        document.cookie = 'refreshToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                        Swal.fire({
                            icon: 'error',
                            title: 'Sesión expirada',
                            text: 'Por favor inicia sesión nuevamente.',
                            confirmButtonColor: '#16a34a',
                        }).then(() => {
                            window.location.href = '/login';
                        });
                        return Promise.reject(err);
                    } finally {
                        isRefreshing = false;
                    }
                } else {
                    config.headers['Authorization'] = `Bearer ${token}`;
                }
            }
        } catch (e) {
            console.warn('[AXIOS] Error decodificando el token:', e);
        }
        return config;
    },
    error => Promise.reject(error)
);

// Interceptor de response
api.interceptors.response.use(
    response => response,
    error => {
        if (error.response && error.response.status === 401 && !error.config._retry) {
            error.config._retry = true; // Evita reintentos infinitos
            if (!isRefreshing) {
                // Si no se está refrescando, intenta refrescar
                return api.interceptors.request.handlers[0].fulfilled(error.config)
                    .then(response => response)
                    .catch(err => Promise.reject(err));
            }
        }
        return Promise.reject(error);
    }
);

export default api;