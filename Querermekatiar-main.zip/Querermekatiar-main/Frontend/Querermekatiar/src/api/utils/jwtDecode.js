// Utilidad para decodificar JWT sin dependencias externas
export function decodeJwt(token) {
  if (!token) return null;
  const base64Url = token.split('.')[1];
  if (!base64Url) return null;
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  try {
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(function(c) {
          return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        })
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
};

export function hasRole(role) {
  const token = localStorage.getItem('token');
  const payload = decodeJwt(token);
  const roles = payload?.roles || [];
  return roles.includes(role);
}


export function isAuthenticated() {
  const token = localStorage.getItem('token');
  if (!token) return false;
  const payload = decodeJwt(token);
  // Opcional: verifica expiración
  if (!payload || (payload.exp && payload.exp * 1000 < Date.now())) return false;
  return true;
}


export function idUserToken() {
  const token = localStorage.getItem('token');
  const payload = decodeJwt(token);
  const userId = payload?.sub;
  return userId
}