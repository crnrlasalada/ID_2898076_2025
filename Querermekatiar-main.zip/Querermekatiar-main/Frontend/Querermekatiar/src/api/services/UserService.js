import { api } from "../axios";
import { decodeJwt } from '../utils/jwtDecode';

export const UserService = {

    getAllSuperUsers: async () => {
        const res = await api.get('/api/auth/user/super');
        return res.data;
    }

    , updateProfile: async (payload) => {
        const token = localStorage.getItem('token');
        const payloadJwt = decodeJwt(token);
        const userId = payloadJwt?.sub;
        if (!userId) throw new Error('No se pudo extraer el id del token');
        const { data } = await api.put(`/api/auth/user/${userId}`, payload);
        return data;
    }

    , deleteUser: async (id) => {
        await api.delete(`/api/auth/user/${id}`);
    },

    // Eliminar usuario por correo
    deleteUserByEmail: async (correo) => {
        await api.delete(`/api/auth/user`, { data: { email: correo } });
    },

    // Obtener datos del usuario autenticado
    getProfile: async () => {
        const token = localStorage.getItem('token');
        const payload = decodeJwt(token);
        const userId = payload?.sub;
        if (!userId) throw new Error('No se pudo extraer el id del token');
        return api.get(`/api/auth/user/${userId}`);
    },

    

    // Cambiar contraseña
    changePassword: async (payload) => {
        // payload: { actualPassword, newPassword }
        const token = localStorage.getItem('token');
        const payloadJwt = decodeJwt(token);
        const userId = payloadJwt?.sub;
        if (!userId) throw new Error('No se pudo extraer el id del token');
        return api.post(`/api/auth/user/${userId}/change-password`, payload);
    },

}