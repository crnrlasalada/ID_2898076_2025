import { api } from "../axios";

export const CatalogService = {
    getCatalogAmekatiar : async () => {
        return await api.get ('/api/product/catalogo/amekatiar')
    },
    getCatalogQuererte : async () => {
        return await api.get ('/api/product/catalogo/quererte')
    },
    getAddOns: async (id) => {
        return await api.get (`/api/product/catalogo/adiciones/${id}`)
    },
    getCategoriesAmekatiar: async()=>{
        return await api.get ('/api/product/catalogo/categorias/amekatiar')
    },
    getCategoriesQuererte: async()=>{
        return await api.get ('/api/product/catalogo/categorias/quererte')
    }
    
}