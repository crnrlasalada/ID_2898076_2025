import { api } from "../axios"; // ✅ CORRECTO: import nombrado

const ReportService = {
    obtenerUrlImagenes: async () => {
        try {
            return {
                headerImage: "/images/waves_design.png",
                logotype_both: "/images/logotype_both.png"
            };
        } catch (error) {
            console.error('Error obteniendo URLs de imágenes:', error);
            throw error;
        }
    },

    getPedidosPorRangoPaginado: async (desde, hasta, page = 0, size = 10) => {
        // Asegura que page y size sean enteros
        const pageInt = parseInt(page, 10);
        const sizeInt = parseInt(size, 10);
        const res = await api.get("api/report/rango/paginado", {
            params: { desde, hasta, page: pageInt, size: sizeInt },
        });
        return res.data;
    },
    getUltimosPedidos: async () => {
        const res = await api.get("api/report/ultimos");
        return res.data;
    },

    getPedidosPorRango: async (desde, hasta) => {
        const res = await api.get("api/report/rango", {
        params: { desde, hasta },
        });
        return res.data;
    },

    getPedidosPorAnio: async (anio) => {
        const res = await api.get(`api/report/anio/${anio}`);
        return res.data;
    },

    getPedidosPorMesYAnio: async (anio, mes) => {
        const res = await api.get("api/report/mes", {
        params: { anio, mes },
        });
        return res.data;
    },

    // Generar PDF de reporte de ventas
    generarReporteVentasPdf: async (filasReporte) => {
        if (!Array.isArray(filasReporte) || filasReporte.length === 0) {
            throw new Error('No hay datos para generar el reporte');
        }

        // Mapear productos para asegurar que siempre tengan 'adiciones' y 'addOns', y nombre cliente
        const pedidosMapeados = filasReporte.map(pedido => ({
            ...pedido,
            customerName: pedido.customerName || pedido.nombres || '',
            customerLastName: pedido.customerLastName || pedido.apellidos || '',
            products: (pedido.products || pedido.productos || []).map(prod => ({
                ...prod,
                adiciones: prod.adiciones || prod.addOns || [],
                addOns: prod.adiciones || prod.addOns || [],
            })),
        }));

        const res = await api.post("api/report/generate-html-pdf", pedidosMapeados, {
            responseType: 'blob',
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/pdf'
            }
        });

        if (!(res.data instanceof Blob) || res.data.size === 0) {
            throw new Error('Error al generar el PDF. Por favor, intente nuevamente.');
        }

        return res.data;
    },
};

export default ReportService;
