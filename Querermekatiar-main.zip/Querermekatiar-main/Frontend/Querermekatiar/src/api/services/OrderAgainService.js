import {api} from "../axios";

// Obtiene los 10 últimos pedidos de un usuario
export const OrderAgainService = {
  getLastOrders: async (idUsuario) => {
    const { data } = await api.get(`/api/order/historial-usuario/${idUsuario}`);
    return data;
  },

  // Obtiene el carrito listo para repetir pedido a partir del id del pedido
  getCartForOrderAgain: async (pedidoId) => {
    const { data } = await api.get(`/api/order/volver-a-pedir/${pedidoId}`);
    return data;
  }
};