
// src/services/OrderService.js
import { act } from "react";
import { api } from "../axios";

export const OrderService = {

    getActivo: async (id) => {
    const res = await api.get(`/api/admin-panel/${id}/activo`);
    return res.data;  // espera un boolean true/false
    },

    putActivo: async (id, activo) => {
        const res = await api.put(`/api/admin-panel/${id}/activo?activo=${activo}`);
        return res.data;
    },

    getActivos: async () => {
        const res = await api.get("/api/admin-panel/activos");
        return res.data;
    },

    getDetalle: async (id) => {
        const res = await api.get(`/api/admin-panel/${id}/detalle`);
        return res.data;
    },

    create : async (order) => {
        return await api.post ('/api/order', order)
    },

        getOrderStatus: async (id) => {
        const token = localStorage.getItem('token');
        try {
            const res = await api.get(`/api/order/${id}`);
            return res.data;
        } catch (error) {
            throw error;
        }
    },

    getDeliveryPrice: async () =>{
        const res = await api.get('/api/order/domicilio');
    return res.data;
    },

    updateEstado: async (id, nuevoEstado, motivo = null) => {
        const res = await api.put(`/api/admin-panel/${id}/estado`, null, {
            params: {
                nuevoEstado,
                ...(motivo ? { motivoRechazo: motivo } : {})
            }
        });
        return res.data;
    },

    getByClienteYEstado: async (clienteId, estado) => {
        const res = await api.get(`/api/admin-panel/cliente/${clienteId}/estado/${estado}`);
        return res.data;
    },

    getActivosCliente: async (clienteId) => {
        const res = await api.get(`/api/admin-panel/cliente/${clienteId}/activos`);
        return res.data;
    },

    //API DELIVERY -- Listar pedidos en reparto

    getEnReparto: async () => {
        const res = await api.get("/api/admin-panel/delivery/reparto");
        return res.data;
    },

    //API DELIVERY -- Actualizar estado de un pedido en reparto

    updateDesdeReparto: async (id, nuevoEstado, motivo = null) => {
        const res = await api.put(`/api/admin-panel/delivery/reparto/${id}/estado`, null, {
            params: {
                nuevoEstado,
                ...(motivo ? { motivo } : {})
            }
        });
        return res.data;
    },

    // --- NOVEDADES/IMAGENES ---
    getNovedadesByNegocio: async (negocioId) => {
        const res = await api.get(`/api/admin-panel/novedades/negocio/${negocioId}`);
        return res.data;
    },

    uploadNovedadImagen: async (formData) => {
        const res = await api.post(`/api/admin-panel/novedades/upload`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        });
        return res.data;
    },

    deleteNovedadImagen:async (idNovedad) => {
        const res = await api.delete(`/api/admin-panel/novedades/delete/${idNovedad}`);
        return res.data;
    }
};
