import { api } from "../axios";

export const ProductService = {

    getAllProducts: async () => {
        const res = await api.get('/api/product');
        return res.data;
    },
    
    getQuererteProducts: async () => {
        const res = await api.get('/api/product/quererte');
        return res.data;
    },
    
    getAmekatiarProducts: async () => {
        const res = await api.get('/api/product/amekatiar');
        return res.data;
    },
    
    getAllCategories: async () => {
        const res = await api.get('/api/product/categories/all');
        return res.data;
    },
    
    getCategoriesByType: async (type) => {
        const res = await api.get(`/api/product/categories/by-type/${type}`);
        return res.data;
    },
    
    getProductCategories: async () => {
        const res = await api.get('/api/product/categories/productos');
        return res.data;
    },
    
    getAdicionCategories: async () => {
        const res = await api.get('/api/product/categories/adiciones');
        return res.data;
    },
    
    createProduct: async (formData) => {
        const res = await api.post('/api/product', formData, {
            headers: { 'Content-Type': 'multipart/form-data' }
        });
        return res.data;
    },
    
    createCategory: async (payload) => {
        const res = await api.post('/api/product/categories/create', payload);
        return res.data;
    },
    updateProduct: async (id, payload) => {
        const res = await api.put(`/api/product/${id}`, payload);
        return res.data;
    },
    productActive: async (id, active) => {
        const res = await api.patch(`/api/product/${id}/active`, null, { params: { active } });
        return res.data;
    },
    DeleteProduct: async (id) => {
        const res = await api.delete(`/api/product/${id}`);
        return res.data;
    },

    // Métodos para adicciones
    getAllAdiciones: async () => {
        const res = await api.get('/api/product/adicciones');
        return res.data;
    },
    
    getAdicionesByBusiness: async (businessId) => {
        const res = await api.get(`/api/product/adicciones/business/${businessId}`);
        return res.data;
    },
    
    createAdicion: async (payload) => {
        const res = await api.post('/api/product/adicciones', payload);
        return res.data;
    },
    
    updateAdicion: async (id, payload) => {
        const res = await api.put(`/api/product/adicciones/${id}`, payload);
        return res.data;
    },
    
    toggleAdicionStatus: async (id, active) => {
        const res = await api.patch(`/api/product/adicciones/${id}/active`, null, { params: { active } });
        return res.data;
    },

    deleteAdicion: async (id) => {
        const res = await api.delete(`/api/product/adicciones/${id}`);
        return res.data;
    },

    // Métodos para gestión de categorías de adicciones en productos
    asignarCategoriaAdicion: async (productId, categoriaId) => {
        const res = await api.post(`/api/product/${productId}/categories/${categoriaId}`);
        return res.data;
    },

    quitarCategoriaAdicion: async (productId, categoriaId) => {
        const res = await api.delete(`/api/product/${productId}/categories/${categoriaId}`);
        return res.data;
    },

    getProductCategoriasAdiciones: async (productId) => {
        const res = await api.get(`/api/product/${productId}/categories`);
        return res.data;
    }

};
