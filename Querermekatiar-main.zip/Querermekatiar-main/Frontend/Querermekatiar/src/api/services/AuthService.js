import { api } from "../axios";

// Centraliza llamadas al backend auth-service
export const AuthService = {
    login: async (correo, password) => {
        const { data } = await api.post('/api/auth/login', { correo, password });
        // data.token es access token retornado
    localStorage.setItem('token', data.token);
        return data;
    },
    
    signupUser: async (correo, password) => {
        await api.post('/api/auth/signup/user', { correo, password });
    },
    
    createSpecialUser: async (payload) => {
        const { data } = await api.post('/api/auth/signup/special-user', payload);
        return data;
    },
    
    refreshAccess: async () => {
        localStorage.setItem('token', data.token);
        return data.token;
    },

    // Nuevos métodos para recuperación de contraseña
    forgotPassword: async (email) => {
        const { data } = await api.post('/api/auth/forgot-password', { email });
        return data;
    },

    validateResetToken: async (token) => {
        const { data } = await api.post('/api/auth/validate-reset-token', { token });
        return data;
    },

    resetPassword: async (token, password) => {
        const { data } = await api.post('/api/auth/reset-password', { token, password });
        return data;
    },

    // Método para logout
    logout: () => {
    localStorage.clear();
    window.location.href = '/login';
    },

    // Método para verificar si el usuario está autenticado
    isAuthenticated: () => {
        // VALIDACIÓN DESACTIVADA PARA PRUEBAS
        // TODO: Reactivar validación de token al final del proyecto
        return true; // Siempre autenticado durante las pruebas
        
    // const token = localStorage.getItem('token');
    // return !!token;
    },

    // Método para obtener el token actual
    getToken: () => {
    return localStorage.getItem('token');
    },

    // Método para verificar el correo
    verifyEmail: async (token) => {
        const { data } = await api.post('/api/auth/verify-email', { token });
        return data;
    },

    // Método para reenviar verificación
    resendVerificationEmail: async (email) => {
        const { data } = await api.post('/api/auth/resend-verification', { email });
        return data;
    }
};