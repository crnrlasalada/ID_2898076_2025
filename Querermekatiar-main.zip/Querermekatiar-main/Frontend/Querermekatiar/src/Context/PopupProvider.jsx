import React, { createContext, useContext, useState, useCallback } from "react";

const PopupContext = createContext();

export const usePopup = () => useContext(PopupContext);

export const PopupProvider = ({ children }) => {
  const [popup, setPopup] = useState({ show: false, message: '', success: false });

  const showPopup = useCallback((message, success = false, duration = 2200) => {
    setPopup({ show: true, message, success });
    setTimeout(() => setPopup({ show: false, message: '', success: false }), duration);
  }, []);

  return (
    <PopupContext.Provider value={{ popup, showPopup }}>
      {children}
      {popup.show && (
        <div
          style={{
            position: "fixed",
            top: 30,
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 9999,
            background: popup.success ? "#27ae60" : "#c0392b",
            color: "#fff",
            padding: "1rem 2rem",
            borderRadius: 12,
            fontWeight: "bold",
            boxShadow: "0 2px 12px #0003",
            fontSize: "1.1rem"
          }}
        >
          {popup.message}
        </div>
      )}
    </PopupContext.Provider>
  );
};