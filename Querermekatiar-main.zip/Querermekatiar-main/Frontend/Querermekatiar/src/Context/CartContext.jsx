import React, { createContext, useState, useEffect } from "react";

export const CartContext = createContext();

function areAdicionesEqual(a1 = [], a2 = []) {
  if (a1.length !== a2.length) return false;
  // Ordena por id_adicion para comparar sin importar el orden
  const sorted1 = [...a1].sort((a, b) => a.id_adicion - b.id_adicion);
  const sorted2 = [...a2].sort((a, b) => a.id_adicion - b.id_adicion);
  for (let i = 0; i < sorted1.length; i++) {
    if (
      sorted1[i].id_adicion !== sorted2[i].id_adicion ||
      sorted1[i].cantidad !== sorted2[i].cantidad
    ) {
      return false;
    }
  }
  return true;
}

function areProductsEqual(p1, p2) {
  // Compara id_producto y adiciones (incluyendo cantidad)
  return (
    (p1.id_producto || p1.id) === (p2.id_producto || p2.id) &&
    areAdicionesEqual(p1.adiciones, p2.adiciones)
  );
}

export const CartProvider = ({ children }) => {
  // Cargar carrito desde localStorage al iniciar
  const [cartItems, setCartItems] = useState(() => {
    try {
      const stored = localStorage.getItem("cartItems");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Guardar carrito en localStorage cada vez que cambia
  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  // Añadir producto al carrito
  const addToCart = (product) => {
    setCartItems((prev) => {
      const idx = prev.findIndex((item) => areProductsEqual(item, product));
      if (idx !== -1) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          quantity: updated[idx].quantity + (product.quantity || 1),
        };
        return updated;
      } else {
        return [...prev, { ...product, quantity: product.quantity || 1 }];
      }
    });
  };

  // Remover una unidad de producto
  const removeFromCart = (product) => {
    setCartItems((prev) => {
      const idx = prev.findIndex((item) => areProductsEqual(item, product));
      if (idx !== -1) {
        const updated = [...prev];
        if (updated[idx].quantity > 1) {
          updated[idx] = {
            ...updated[idx],
            quantity: updated[idx].quantity - 1,
          };
        } else {
          updated.splice(idx, 1);
        }
        return updated;
      }
      return prev;
    });
  };

  // Eliminar producto completamente
  const removeItem = (product) => {
    setCartItems((prev) =>
      prev.filter((item) => !areProductsEqual(item, product))
    );
  };

  // Vaciar carrito
  const clearCart = () => setCartItems([]);

  // Actualizar producto (por ejemplo, después de editar adiciones/cantidades)
  const updateItem = (oldProduct, newProduct) => {
    setCartItems((prev) => {
      const filtered = prev.filter((item) => !areProductsEqual(item, oldProduct));
      return [...filtered, { ...newProduct }];
    });
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        removeItem,
        clearCart,
        updateItem,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};