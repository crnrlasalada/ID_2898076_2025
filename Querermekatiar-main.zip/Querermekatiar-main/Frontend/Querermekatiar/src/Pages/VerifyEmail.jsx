import { useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { api } from '../api/axios';
import Swal from 'sweetalert2';

export const VerifyEmail = () => {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();

    useEffect(() => {
        const token = searchParams.get('token');
        
        if (!token) {
            Swal.fire({
                icon: 'error',
                title: 'Enlace inválido',
                text: 'El enlace de verificación no es válido o ha expirado.',
                confirmButtonColor: '#dc2626',
                confirmButtonText: 'Volver al inicio'
            }).then(() => {
                navigate('/');
            });
            return;
        }

        verifyEmail(token);
    }, [searchParams, navigate]);

    const verifyEmail = async (token) => {
        try {
            await api.post('/api/auth/verify-email', {
                token: token
            });

            // Verificación exitosa
            Swal.fire({
                icon: 'success',
                title: '¡Email verificado!',
                text: 'Tu correo electrónico ha sido verificado exitosamente. Ya puedes iniciar sesión.',
                confirmButtonColor: '#16a34a',
                confirmButtonText: 'Ir al Login'
            }).then(() => {
                navigate('/login');
            });

        } catch (error) {
            console.error('Error al verificar email:', error);
            
            const errorMessage = error.response?.data || 'El enlace de verificación no es válido o ha expirado.';
            
            Swal.fire({
                icon: 'error',
                title: 'Error de verificación',
                text: errorMessage,
                confirmButtonColor: '#dc2626',
                confirmButtonText: 'Ir al inicio'
            }).then(() => {
                navigate('/');
            });
        }
    };

    // Página completamente en blanco mientras procesa
    return (
        <div style={{
            width: '100vw',
            height: '100vh',
            backgroundColor: 'white'
        }}>
        </div>
    );
};

export default VerifyEmail;
