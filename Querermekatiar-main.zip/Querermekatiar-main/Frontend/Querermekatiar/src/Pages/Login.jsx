import { Link, useNavigate } from "react-router-dom";
import { FaHome } from "react-icons/fa";
import amekatiarLogo from "../assets/images/Amekatiar/User/amekatiar-logo.webp";
import quererteLogo from "../assets/images/Quererte/User/Logo_quererte.webp";
import style from "../assets/Styles/login.module.css";
import { useState, useEffect } from "react";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import Swal from 'sweetalert2';

import { GoogleButton } from "../Components/User/GoogleButton";
import { AuthService } from "../api/services/AuthService";
import { decodeJwt } from "../utils/jwtDecode";
import { validateUserProfile } from '../utils/profileValidation';

export const Login = () => {
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  // Guardar la ruta previa antes de ir al login
  useEffect(() => {
    const prevPath = window.location.pathname;
    localStorage.setItem('prevPath', prevPath);
  }, []);

  const login = async (e) => {
    e.preventDefault();
    try {
      // El AuthService.login ya guarda el token en localStorage como 'token'
      const response = await AuthService.login(correo.toLowerCase().trim(), password);

      Swal.fire({
        toast: true,
        position: 'top',
        title: 'BIENVENIDO',
        showConfirmButton: false,
        timer: 1000,
        background: '#16a34a',
        color: '#fff'
      });


      setCorreo("");
      setPassword("");

      // Decodificar el token y redirigir según el rol
      const token = localStorage.getItem('token');
      let role = '';
      try {
        const payload = decodeJwt(token);
        if (Array.isArray(payload?.roles) && payload.roles.length > 0) {
          role = payload.roles[0];
        } else {
          role = payload?.rol || payload?.role || '';
        }
      } catch (e) {}

      if (role === 'CLIENT') {
        const { UserService } = await import('../api/services/UserService');
        const valid = await validateUserProfile(UserService, navigate);
        if (!valid) return;
        navigate('/');
      } else if (role === 'ADMIN' || role === 'CASHIER') {
        navigate('/admin/pedidos');
      } else if (role === 'DELIVERY') {
        navigate('/delivery/pedidos');
      } else {
        navigate('/');
      }
    } catch (error) {
      console.error('Error en login:', error);
      // El interceptor de axios ya maneja los errores 401, 403, 500
      // Solo manejar errores específicos aquí
      if (error.response?.status === 400) {
        const mensajeError = error.response?.data?.message || "Credenciales incorrectas";
        Swal.fire({
          icon: "error",
          title: "Error al iniciar sesión",
          text: mensajeError,
          confirmButtonColor: '#16a34a'
        });
      }
      // Para otros errores, el interceptor ya los maneja
    }
  };

  const handleForgotPassword = async () => {
    const { value: email } = await Swal.fire({
      title: 'Recuperar contraseña',
      input: 'email',
      inputLabel: 'Ingresa tu correo registrado',
      inputPlaceholder: 'correo@ejemplo.com',
      confirmButtonText: 'Enviar correo',
      confirmButtonColor: '#16a34a',
      showCloseButton: true,
      background: '#ffffff',
      color: '#111827',
      focusConfirm: false,
      inputAttributes: { 'aria-label': 'Correo para recuperación' },
      preConfirm: (val) => {
        if (!val) {
          Swal.showValidationMessage('El correo es obligatorio');
          return;
        }
        const regex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
        if (!regex.test(val)) {
          Swal.showValidationMessage('Formato de correo inválido');
          return;
        }
        return val.toLowerCase();
      }
    });

    if (!email) return;

    try {
      await AuthService.forgotPassword(email);
      Swal.fire({
        icon: 'success',
        title: 'Correo enviado',
        html: `<p>Hemos enviado las instrucciones para restablecer tu contraseña a <strong>${email}</strong></p><p style='font-size:12px;opacity:.8;margin-top:8px;'>Revisa también tu carpeta de spam o promociones.</p>`,
        confirmButtonColor: '#16a34a',
        background: '#ffffff',
        color: '#111827'
      });
    } catch (err) {
      console.error('Error en forgot password:', err);
      // El interceptor ya maneja errores 401, 403, 500
      // Solo manejar errores específicos si es necesario
      if (err.response?.status === 400) {
        const msg = err.response?.data?.message || 'Error al enviar el correo';
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: msg,
          confirmButtonColor: '#16a34a',
          background: '#ffffff',
          color: '#111827'
        });
      }
    }
  };

  return (
    <main role="main">
      <section aria-label="visual background">
        <div className={style["background-left-black"]} aria-hidden="true">
          <figure>
            <img
              className={`${style['store-logo']} ${style.quererte}`}
              src={quererteLogo}
              alt="Quererte logo"
            />
            <figcaption>Logo de la heladería Quererte</figcaption>
          </figure>
        </div>

        <div className={style["background-right-yellow"]} aria-hidden="true">
          <figure>
            <img
              className={`${style['store-logo']} ${style.amekatiar}`}
              src={amekatiarLogo}
              alt="Amekatiar logo"
            />
          </figure>
        </div>
      </section>

      <section className={style["circles-container"]} aria-label="Decorative circles">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className={`${style.circle} ${i % 2 === 0 ? style["circle-yellow"] : style["circle-black"]}`}
            aria-hidden="true"
          ></div>
        ))}
      </section>

      <button
        type="button"
        aria-label="Inicio"
        onClick={() => navigate("/")}
        style={{ position: 'absolute', top: 24, left: 24, background: '#F0B617', color: '#23272f', border: 'none', padding: '10px 20px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', zIndex: 10, display: 'flex', alignItems: 'center', gap: 6 }}
      >
        <FaHome size={22} />
      </button>

      <section className={style["log-in-container"]}>
        <form onSubmit={login} autoComplete="on">
          <input
            className={style["user-date"]}
            type="email"
            name="email"
            autoComplete="email"
            placeholder="Ingrese su correo"
            value={correo}
            onChange={(e) => setCorreo(e.target.value.toLowerCase().trim())}
            required
          />

          <div className={style["password-container"]}>
            <input
              className={style["user-date"]}
              type={showPassword ? "text" : "password"}
              name="password"
              autoComplete="current-password"
              placeholder="Ingrese su contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              style={{ paddingRight: "40px" }}
            />
            <button
              type="button"
              className={style["show-password-btn"]}
              onClick={() => setShowPassword((prev) => !prev)}
              aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
              tabIndex={-1}
            >
              {showPassword ? (
                <FaEyeSlash className={style["eye-icon"]} />
              ) : (
                <FaEye className={style["eye-icon"]} />
              )}
            </button>
          </div>

          <button type="submit" className={style["login-btn"]}>Iniciar sesión</button>
        </form>

        <button
          type="button"
          className={style["forgot-link"]}
          onClick={handleForgotPassword}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
        >
          ¿Olvidaste tu contraseña?
        </button>

        <hr />

        <GoogleButton />

        <p className={style["register-text"]}>¿No tienes una cuenta?
          <Link className={style["register-link"]} to="/signup"> Registrate</Link>
        </p>
      </section>
    </main>
  );
};
