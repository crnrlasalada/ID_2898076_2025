import { useState, useEffect } from 'react'
import { FaEye, FaEyeSlash } from 'react-icons/fa'
import Swal from 'sweetalert2'
import { useSearchParams, Link, useNavigate } from 'react-router-dom'
import { AuthService } from '../api/services/AuthService'
import amekatiarLogo from '../assets/images/Amekatiar/User/amekatiar-logo.webp'
import quererteLogo from '../assets/images/Quererte/User/Logo_quererte.webp'
import style from '../assets/Styles/ForgotPassword.module.css'

export const ResetPassword = () => {
    // Estado de campos y flags de UI
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [showPassword, setShowPassword] = useState(false)
    const [showPassword2, setShowPassword2] = useState(false)
    const [triedSubmit, setTriedSubmit] = useState(false)
    const [isValidToken, setIsValidToken] = useState(null)
    const [isLoading, setIsLoading] = useState(true)

    // Token capturado del query string (?token=...)
    const [searchParams] = useSearchParams()
    const navigate = useNavigate()
    const token = searchParams.get('token') || ''

    // Validar token al cargar el componente
    useEffect(() => {
        if (!token) {
            setIsValidToken(false)
            setIsLoading(false)
            Swal.fire({
                icon: 'error',
                title: 'Enlace inválido',
                text: 'Este enlace no es válido. Por favor, solicita un nuevo enlace de recuperación.',
                confirmButtonColor: '#16a34a'
            }).then(() => {
                navigate('/login')
            })
            return
        }

        validateToken()
    }, [token, navigate])

    const validateToken = async () => {
        try {
            await AuthService.validateResetToken(token)
            setIsValidToken(true)
        } catch (error) {
            console.error('Error validando token:', error)
            setIsValidToken(false)
            
            Swal.fire({
                icon: 'error',
                title: 'Enlace expirado o inválido',
                text: 'Este enlace ha expirado o no es válido. Por favor, solicita un nuevo enlace de recuperación desde la página de login.',
                confirmButtonColor: '#16a34a',
                confirmButtonText: 'Ir al login'
            }).then(() => {
                navigate('/login')
            })
        } finally {
            setIsLoading(false)
        }
    }

    // Reglas de validación de contraseña
    const hasMinLength = password.length >= 8
    const hasUppercase = /[A-Z]/.test(password)
    const hasLowercase = /[a-z]/.test(password)
    const hasNumber = /\d/.test(password)
    const passwordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber
    const confirmValid = confirmPassword === password && confirmPassword.length > 0

    // Handler de submit: valida y llama al endpoint
    const submit = async e => {
        e.preventDefault()
        setTriedSubmit(true)

        // No continuar si las contraseñas no coinciden
        if (confirmPassword !== password) return

        // No continuar si no cumple reglas completas
        if (!passwordValid) return

        try {
            await AuthService.resetPassword(token, password)
            
            Swal.fire({ 
                icon: 'success', 
                title: '¡Contraseña actualizada!', 
                text: 'Tu contraseña ha sido cambiada exitosamente. Ya puedes iniciar sesión.',
                confirmButtonColor: '#16a34a',
                confirmButtonText: 'Ir al login'
            }).then(() => {
                navigate('/login')
            })

            setPassword('')
            setConfirmPassword('')
            setTriedSubmit(false)
        } catch (err) {
            console.error('Error reseteando contraseña:', err)
            
            // El interceptor ya maneja la mayoría de errores
            const msg = err.response?.data?.message || 'No se pudo restablecer la contraseña'
            Swal.fire({ 
                icon: 'error', 
                title: 'Error', 
                text: msg,
                confirmButtonColor: '#16a34a'
            })
        }
    }

        // Mostrar loading mientras se valida el token
        if (isLoading) {
            return (
                <main role="main" className={style.forgot_root}>
                    <section className={style.form_wrapper} style={{ textAlign: 'center' }}>
                        <div style={{ 
                            border: '4px solid #f3f3f3',
                            borderTop: '4px solid #16a34a',
                            borderRadius: '50%',
                            width: '40px',
                            height: '40px',
                            animation: 'spin 1s linear infinite',
                            margin: '0 auto 20px'
                        }}></div>
                        <p>Verificando enlace...</p>
                    </section>
                    <style>{`
                        @keyframes spin {
                            0% { transform: rotate(0deg); }
                            100% { transform: rotate(360deg); }
                        }
                    `}</style>
                </main>
            )
        }    // Si el token no es válido, no mostrar el formulario
    if (!isValidToken) {
        return null // El useEffect ya redirige
    }

    return (
        <main role="main" className={style.forgot_root}>

            <section aria-label="visual background">
                <div className={style['background-left-black']} aria-hidden="true">
                    <figure>
                        <img className={`${style['store-logo']} ${style.quererte}`} src={quererteLogo} alt="Quererte logo" />
                        <figcaption>Logo de la heladería Quererte</figcaption>
                    </figure>
                </div>
                <div className={style['background-right-yellow']} aria-hidden="true">
                    <figure>
                        <img className={`${style['store-logo']} ${style.mekatiar}`} src={amekatiarLogo} alt="Amekatiar logo" />
                    </figure>
                </div>
            </section>

            <section className={style['circles-container']} aria-label="Decorative circles">
                {[...Array(6)].map((_, i) => (
                    <div key={i} className={`${style.circle} ${i % 2 === 0 ? style['circle-yellow'] : style['circle-black']}`} aria-hidden="true"></div>
                ))}
            </section>

            <section className={style.form_wrapper}>
                <h1 className={style.title}>Restablecer contraseña</h1>
                <form onSubmit={submit} noValidate>

                    <div className={style.password_container}>
                        <input
                            className={`${style.input} ${triedSubmit && !passwordValid ? style.input_error : ''}`}
                            type={showPassword ? 'text' : 'password'}
                            placeholder="Nueva contraseña"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            minLength={8}
                            required
                        />
                        <button type="button" className={style.toggle_btn} onClick={() => setShowPassword(p => !p)} tabIndex={-1} aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}>
                            {showPassword ? <FaEyeSlash className={style.eye} /> : <FaEye className={style.eye} />}
                        </button>
                    </div>

                    {password.length > 0 && (
                        <div className={style.rules_box}>
                            <ul className={style.rules_list}>
                                <li className={hasMinLength ? style.rule_ok : style.rule_error}>Mínimo 8 caracteres</li>
                                <li className={hasUppercase ? style.rule_ok : style.rule_error}>Una mayúscula</li>
                                <li className={hasLowercase ? style.rule_ok : style.rule_error}>Una minúscula</li>
                                <li className={hasNumber ? style.rule_ok : style.rule_error}>Un número</li>
                            </ul>
                        </div>
                    )}

                    <div className={style.password_container}>
                        <input
                            className={`${style.input} ${triedSubmit && !confirmValid ? style.input_error : ''}`}
                            type={showPassword2 ? 'password' : 'password'}
                            placeholder="Confirmar contraseña"
                            value={confirmPassword}
                            onChange={e => setConfirmPassword(e.target.value)}
                            minLength={8}
                            required
                        />
                    </div>

                    {triedSubmit && !passwordValid && <div className={style.field_error}>La contraseña no cumple requisitos.</div>}
                    {triedSubmit && passwordValid && !confirmValid && <div className={style.field_error}>Las contraseñas no coinciden.</div>}

                    <button type="submit" className={style.submit_btn} disabled={!isValidToken}>Restablecer contraseña</button>
                </form>

                <p className={style.back_login}>¿Recordaste tu contraseña? <Link to="/login" className={style.back_login_link}>Inicia sesión</Link></p>
            </section>
        </main>
    )
}