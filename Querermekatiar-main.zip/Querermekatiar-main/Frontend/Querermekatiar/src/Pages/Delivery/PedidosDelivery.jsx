import React, { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { FiLogOut } from 'react-icons/fi';
import PedidoCard from '../../Components/Delivery/PedidoDelivery/PedidoCardDelivery';
import bgstyles from "../../assets/Styles/bg2.module.css";
import styles from './PedidosDelivery.module.css';
import { OrderService } from '../../api/services/OrderService';

const PedidosDelivery = () => {
    const navigate = useNavigate();
    // Cerrar sesión
    const handleLogout = () => {
        Swal.fire({
            title: '¿Cerrar sesión?',
            text: '¿Estás seguro que deseas salir de tu cuenta?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#16a34a',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, cerrar sesión',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                localStorage.removeItem('token');
                navigate('/login');
                Swal.fire({
                    toast: true,
                    position: 'top-end',
                    title: '¡Hasta la próxima!',
                    showConfirmButton: false,
                    timer: 1500,
                    background: '#d35400',
                    color: '#fff'
                });
            }
        });
    };
        // Fondo dinámico
    useEffect(() => {
        document.body.className = bgstyles.bg;
        return () => { document.body.className = ""; };
    }, []);


    const [pedidos, setPedidos] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [alertaFinalizado, setAlertaFinalizado] = useState(null); // {id, estado}

    // Mostrar alerta flotante cuando un pedido finaliza
    const mostrarAlertaFinalizado = (pedidoId, estado) => {
        setAlertaFinalizado({ id: pedidoId, estado });
        setPedidos(prev => prev.filter(p => p.id !== pedidoId));
        setTimeout(() => setAlertaFinalizado(null), 3500);
    };

    // Cargar solo pedidos en reparto y ordenarlos por fecha/hora ascendente
    const cargarPedidos = async () => {
        try {
            setCargando(true);
            const data = await OrderService.getEnReparto();
            const pedidosOrdenados = Array.isArray(data)
                ? [...data].sort((a, b) => new Date(a.fechaHora) - new Date(b.fechaHora))
                : [];
            setPedidos(pedidosOrdenados);
        } catch (error) {
            console.error("Error cargando pedidos en reparto:", error);
        } finally {
            setCargando(false);
        }
    };

    // Cargar un pedido específico y agregarlo siempre al final
    const cargarPedidoPorId = async (id) => {
        try {
            const pedido = await OrderService.getDetalle(id);
            setPedidos(prev => {
                const filtrados = prev.filter(p => p.id !== pedido.id);
                return [...filtrados, pedido];
            });
        } catch (error) {
            console.error("Error cargando pedido por id:", error);
        }
    };


    // Cargar pedidos iniciales
    useEffect(() => { cargarPedidos(); }, []);

    // Escuchar pedidos nuevos vía SSE
    useEffect(() => {
        const token = localStorage.getItem('token');
        const eventSource = new EventSource(`http://localhost:8080/api/stream/delivery?token=${token}`);

        // Listener principal con detección de todos los posibles id
        eventSource.addEventListener("actualizacion-delivery", (event) => {
            try {
                const data = JSON.parse(event.data);
                const pedidoId = data.id || data.pedidoId || data.pedido_id || data.idOrder;

                if (pedidoId) {
                    cargarPedidoPorId(pedidoId);
                } else {
                    cargarPedidos();
                }
            } catch (e) {
                console.error("Error procesando evento SSE:", e);
            }
        });

        // Fallback por si llega sin nombre
        eventSource.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                const pedidoId = data.id || data.pedidoId || data.pedido_id || data.idOrder;
                if (pedidoId) cargarPedidoPorId(pedidoId);
            } catch {}
        };

        // Manejo de errores (EventSource reintenta solo)
        eventSource.onerror = (err) => {
            console.error("SSE error (reintenta solo):", err);
        };

        return () => eventSource.close();
    }, []);

    // Solo mostrar pedidos en reparto que sean de tipoEntrega 'Domicilio'
    const pedidosReparto = pedidos.filter(p => p.tipoEntrega === 'Domicilio');

    return (
        <div style={{ position: 'relative', minHeight: '60vh' }}>
            <div className={styles.panelHeaderDelivery}>
                <h2 className={styles.titulo} style={{ margin: 0 }}>
                    Pedidos en Reparto ({pedidosReparto.length})
                </h2>
                <button className={styles.logoutDeliveryBtn} onClick={handleLogout}>
                    <FiLogOut className={styles.logoutIconDelivery} />
                    <span className={styles.logoutTextDelivery}>Cerrar sesión</span>
                </button>
            </div>
            {cargando && (
                <div className={styles.overlayCargando}>
                    <span className={styles.textoCargando}>Cargando pedidos...</span>
                </div>
            )}

            {alertaFinalizado && (
                <div className={styles.alertaFinalizado}>
                    <span>El pedido <b>#{alertaFinalizado.id}</b> acabó su proceso como <b>{alertaFinalizado.estado.replace(/_/g, ' ')}</b>.</span>
                </div>
            )}



            <div className={styles.listadoPedidos}>
                {pedidosReparto.length === 0 ? (
                    <p className={styles.sinPedidos}>No hay pedidos en reparto.</p>
                ) : (
                    pedidosReparto.map((pedido) => (
                        <PedidoCard key={pedido.id} pedido={pedido} onFinalizar={mostrarAlertaFinalizado} />
                    ))
                )}
            </div>
        </div>
    );
};

export default PedidosDelivery;
