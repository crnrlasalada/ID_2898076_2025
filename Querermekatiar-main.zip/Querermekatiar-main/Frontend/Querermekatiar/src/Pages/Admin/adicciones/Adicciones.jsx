import { useState, useEffect, useCallback } from "react";
import { ProductService } from '../../../api/services/ProductService';
import Swal from 'sweetalert2';
import { ToggleSwitch } from '../../../Components/toggle-switch.jsx';
import style from './Adicciones.module.css';
import trahsIcon from "../../../assets/Icons/contenedor-de-basura.webp";

export const Adicciones = () => {
    const [selectedBusiness, setSelectedBusiness] = useState('AMEKATIAR');
    const [adicciones, setAdiciones] = useState([]);
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    
    // Estado para el modo de visualización
    const [viewMode, setViewMode] = useState('categories'); // 'all' o 'categories'

    // Modal nueva adición
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [newAdicion, setNewAdicion] = useState({
        nombreAdicion: '',
        precio: '',
        idCategoria: ''
    });
    const [saving, setSaving] = useState(false);
    const [tried, setTried] = useState(false);

    // Modal editar
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingAdicion, setEditingAdicion] = useState(null);
    const [savingEdit, setSavingEdit] = useState(false);
    const [triedEdit, setTriedEdit] = useState(false);

    // Modal categoría
    const [isCatModalOpen, setIsCatModalOpen] = useState(false);
    const [newCatName, setNewCatName] = useState('');
    const [newCatBusiness, setNewCatBusiness] = useState('');
    const [newCatIncluida, setNewCatIncluida] = useState(false);
    const [savingCat, setSavingCat] = useState(false);

    // Función para formatear precio con puntos de miles
    const formatPrice = (price) => {
        if (!price) return '0';
        return Number(price).toLocaleString('es-CO');
    };

    // Función para formatear precio mientras se escribe
    const formatPriceInput = (value) => {
        if (!value) return '';
        // Remover todo excepto números
        const numericValue = value.replace(/[^0-9]/g, '');
        if (!numericValue) return '';
        // Formatear con puntos de miles
        return Number(numericValue).toLocaleString('es-CO');
    };

    // Función para obtener valor numérico desde input formateado
    const getNumericValue = (formattedValue) => {
        if (!formattedValue) return '';
        return formattedValue.replace(/[^0-9]/g, '');
    };

    // Función para eliminar adición
    const handleDeleteAdicion = async (adicion) => {
        const result = await Swal.fire({
            title: '¿Eliminar adición?',
            text: `${adicion.nombreAdicion} - $${formatPrice(adicion.precio)} COP`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
            confirmButtonColor: '#dc3545'
        });

        if (!result.isConfirmed) return;

        try {
            await ProductService.deleteAdicion(adicion.id);
            setAdiciones(prev => prev.filter(a => a.id !== adicion.id));
            Swal.fire({
                icon: 'success',
                title: 'Adición eliminada',
                text: `${adicion.nombreAdicion} ha sido eliminada exitosamente`,
                timer: 2000,
                showConfirmButton: false
            });
        } catch (error) {
            console.error('Error eliminando adición:', error);
            const errorMsg = error?.response?.data?.error || 'No se pudo eliminar la adición';
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMsg
            });
        }
    };

    // Función para agrupar adiciones por categoría
    const groupAdicionesByCategory = () => {
        const grouped = {};
        adicciones.forEach(adicion => {
            const categoryName = adicion.nombreCategoria || 'Sin categoría';
            const categoryId = adicion.idCategoria || 'sin-categoria';
            
            if (!grouped[categoryId]) {
                grouped[categoryId] = {
                    id: categoryId,
                    nombre: categoryName,
                    adicciones: []
                };
            }
            grouped[categoryId].adicciones.push(adicion);
        });
        
        // Convertir a array y ordenar por nombre de categoría
        return Object.values(grouped).sort((a, b) => a.nombre.localeCompare(b.nombre));
    };

    const fetchAdiciones = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            let data;

            // IDs actualizados: Amekatiar = 1, Quererte = 2
            if (selectedBusiness === 'QUERERTE') {
                data = await ProductService.getAdicionesByBusiness(2);
            } else if (selectedBusiness === 'AMEKATIAR') {
                data = await ProductService.getAdicionesByBusiness(1);
            }

            setAdiciones(data || []);
        } catch (er) {
            setError('No se pudieron cargar las adicciones: ' + er.message);
        } finally {
            setLoading(false);
        }
    }, [selectedBusiness]);

    const fetchCategories = useCallback(async () => {
        try {
            const data = await ProductService.getAdicionCategories();
            setCategories(data || []);
        } catch (er) {
            // Error silencioso para categorías
        }
    }, []);

    const openModal = () => {
        setNewAdicion({ nombreAdicion: '', precio: '', idCategoria: '' });
        setTried(false);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    const openEditModal = (adicion) => {
        // Formatear el precio antes de establecerlo en el modal
        const formattedAdicion = {
            ...adicion,
            precio: formatPriceInput(adicion.precio?.toString() || '0')
        };
        setEditingAdicion(formattedAdicion);
        setTriedEdit(false);
        setIsEditModalOpen(true);
    };

    const closeEditModal = () => {
        setIsEditModalOpen(false);
        setEditingAdicion(null);
    };

    const createAdicion = async (e) => {
        e.preventDefault();
        setTried(true);

        const nombreOk = newAdicion.nombreAdicion.trim().length > 0;
        const categoriaOk = !!newAdicion.idCategoria;

        // Verificar si la categoría seleccionada es incluida
        const selectedCategory = categories.find(cat => cat.id === parseInt(newAdicion.idCategoria));
        const isIncluida = selectedCategory?.incluido === 1;

        // Para categorías incluidas, el precio no es obligatorio
        const numericPrice = getNumericValue(newAdicion.precio);
        const precioOk = isIncluida || (numericPrice !== '' && !isNaN(numericPrice) && Number(numericPrice) > 0);

        if (!nombreOk || !precioOk || !categoriaOk) return;

        setSaving(true);
        try {
            const payload = {
                nombreAdicion: newAdicion.nombreAdicion.trim(),
                precio: isIncluida ? 0 : getNumericValue(newAdicion.precio), // Precio 0 para incluidas
                idCategoria: Number(newAdicion.idCategoria)
            };

            await ProductService.createAdicion(payload);
            closeModal();
            fetchAdiciones();
            Swal.fire({ icon: 'success', title: 'Adición creada exitosamente', timer: 1500, showConfirmButton: false });
        } catch (er) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo crear la adición' });
        } finally {
            setSaving(false);
        }
    };

    const updateAdicion = async (e) => {
        e.preventDefault();
        setTriedEdit(true);

        if (!editingAdicion) return;

        const nombreOk = editingAdicion.nombreAdicion?.trim().length > 0;
        const numericPriceEdit = getNumericValue(editingAdicion.precio);
        const precioOk = numericPriceEdit !== '' && !isNaN(numericPriceEdit) && Number(numericPriceEdit) > 0;

        if (!nombreOk || !precioOk) return;

        setSavingEdit(true);    
        try {
            const payload = {
                name: editingAdicion.nombreAdicion.trim(),
                price: getNumericValue(editingAdicion.precio),
                dCategory: editingAdicion.idCategoria
            };

            await ProductService.updateAdicion(editingAdicion.id, payload);
            closeEditModal();
            fetchAdiciones();
            Swal.fire({ icon: 'success', title: 'Adición actualizada', timer: 1500, showConfirmButton: false });
        } catch (er) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo actualizar la adición' });
        } finally {
            setSavingEdit(false);
        }
    };

    useEffect(() => {
        fetchAdiciones();
        fetchCategories();
    }, [fetchAdiciones, fetchCategories]);

    useEffect(() => {
        // Cambiar fondo según el negocio seleccionado
        if (selectedBusiness === 'QUERERTE') {
            document.body.className = style.bgBodyAdiccionesQuererte;
        } else {
            document.body.className = style.bgBodyAdiccionesAdmin;
        }

        return () => { document.body.className = ''; };
    }, [selectedBusiness]);

    return (
        <div className={style.container}>
            <div className={style.businessSelector}>
                <select
                    className={style.businessSelect}
                    value={selectedBusiness}
                    onChange={(e) => setSelectedBusiness(e.target.value)}
                >
                    <option value="AMEKATIAR">Amekatiar</option>
                    <option value="QUERERTE">Quererte</option>
                </select>
            </div>

            <div className={style.viewToggle}>
                <button 
                    className={viewMode === 'all' ? `${style.toggleButton} ${style.active}` : style.toggleButton}
                    onClick={() => setViewMode('all')}
                >
                    Ver Todas
                </button>
                <button 
                    className={viewMode === 'categories' ? `${style.toggleButton} ${style.active}` : style.toggleButton}
                    onClick={() => setViewMode('categories')}
                >
                    Por Categorías
                </button>
            </div>

            <div onClick={openModal} className={style.addButton}>Nueva Adición</div>

            {loading && <p>Cargando adicciones...</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}

            {/* Vista por categorías */}
            {!loading && !error && viewMode === 'categories' && (
                <div className={style.categoriesContainer}>
                    {groupAdicionesByCategory().map(categoria => (
                        <div key={categoria.id} className={style.categorySection}>
                            <div className={style.categoryHeader}>
                                <h2 className={style.categoryTitle}>
                                    📍 {categoria.nombre}
                                </h2>
                                <span className={style.categoryCount}>
                                    {categoria.adicciones.length} {categoria.adicciones.length === 1 ? 'adición' : 'adiciones'}
                                </span>
                            </div>
                            
                            <div className={style.grid}>
                                {categoria.adicciones.map((adicion) => {
                                    const isActive = adicion.activo === 1;
                                    return (
                                        <div key={adicion.id} className={isActive ? style.card : style.cardInactive}>
                                            <h3 className={isActive ? style.name : style.nameInactive}>
                                                {adicion.nombreAdicion}
                                            </h3>
                                            <p className={isActive ? style.price : style.priceInactive}>
                                                ${formatPrice(adicion.precio)} COP
                                            </p>

                                            <div className={style.controls}>
                                                <ToggleSwitch
                                                    checked={adicion.activo === 1}
                                                    title={isActive ? 'Activo' : 'Inactivo'}
                                                    onChange={async (checked) => {
                                                        const prev = adicion.activo;
                                                        const newActive = checked ? 1 : 0;

                                                        setAdiciones(prev => prev.map(a =>
                                                            a.id === adicion.id ? { ...a, activo: newActive } : a
                                                        ));

                                                        try {
                                                            await ProductService.toggleAdicionStatus(adicion.id, checked);
                                                        } catch (err) {
                                                            setAdiciones(prev => prev.map(a =>
                                                                a.id === adicion.id ? { ...a, activo: prev } : a
                                                            ));
                                                            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo cambiar el estado' });
                                                        }
                                                    }}
                                                />
                                                <button
                                                    onClick={() => openEditModal(adicion)}
                                                    className={style.editButton}
                                                    disabled={!isActive}
                                                >
                                                    Editar
                                                </button>
                                                <button
                                                    onClick={() => handleDeleteAdicion(adicion)}
                                                    className={style.deleteButton}
                                                    title="Eliminar adición"
                                                >
                                                    <img src={trahsIcon} className={style.trashIcon} alt="Eliminar" />
                                                </button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Vista de todas las adiciones */}
            {!loading && !error && viewMode === 'all' && (
                <div className={style.grid}>
                    {adicciones.map((adicion) => {
                        const isActive = adicion.activo === 1;
                        return (
                            <div key={adicion.id} className={isActive ? style.card : style.cardInactive}>
                                <h3 className={isActive ? style.name : style.nameInactive}>
                                    {adicion.nombreAdicion}
                                </h3>
                                <p className={isActive ? style.price : style.priceInactive}>
                                    ${formatPrice(adicion.precio)} COP
                                </p>
                                <p className={isActive ? style.category : style.categoryInactive}>
                                    Categoría: {adicion.nombreCategoria}
                                </p>

                                <div className={style.controls}>
                                    <ToggleSwitch
                                        checked={adicion.activo === 1}
                                        title={isActive ? 'Activo' : 'Inactivo'}
                                        onChange={async (checked) => {
                                            const prev = adicion.activo;
                                            const newActive = checked ? 1 : 0;

                                            setAdiciones(prev => prev.map(a =>
                                                a.id === adicion.id ? { ...a, activo: newActive } : a
                                            ));

                                            try {
                                                await ProductService.toggleAdicionStatus(adicion.id, checked);
                                            } catch (err) {
                                                setAdiciones(prev => prev.map(a =>
                                                    a.id === adicion.id ? { ...a, activo: prev } : a
                                                ));
                                                Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo cambiar el estado' });
                                            }
                                        }}
                                    />
                                    <button
                                        onClick={() => openEditModal(adicion)}
                                        className={style.editButton}
                                        disabled={!isActive}
                                    >
                                        Editar
                                    </button>
                                    <button
                                        onClick={() => handleDeleteAdicion(adicion)}
                                        className={style.deleteButton}
                                        title="Eliminar adición"
                                    >
                                        <img src={trahsIcon} className={style.trashIcon} alt="Eliminar" />
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* Modal Nueva Adición */}
            {isModalOpen && (
                <div className={style.modal}>
                    <div className={style.modalContent}>
                        <form onSubmit={createAdicion}>
                            <h2>Nueva Adición</h2>

                            <label>
                                <span>Nombre *</span>
                                <input
                                    className={tried && !newAdicion.nombreAdicion.trim() ? style.inputError : ''}
                                    type="text"
                                    value={newAdicion.nombreAdicion}
                                    onChange={(e) => setNewAdicion(prev => ({ ...prev, nombreAdicion: e.target.value }))}
                                />
                            </label>

                            {/* Mostrar campo de precio solo si la categoría NO es incluida */}
                            {(() => {
                                const selectedCategory = categories.find(cat => cat.id === parseInt(newAdicion.idCategoria));
                                const isIncluida = selectedCategory?.incluido === 1;
                                return !isIncluida && (
                                    <label>
                                        <span>Precio *</span>
                                        <input
                                            className={tried && (newAdicion.precio === '' || Number(getNumericValue(newAdicion.precio)) <= 0) ? style.inputError : ''}
                                            type="text"
                                            value={newAdicion.precio}
                                            onChange={(e) => {
                                                const formatted = formatPriceInput(e.target.value);
                                                setNewAdicion(prev => ({ ...prev, precio: formatted }));
                                            }}
                                            placeholder="Ej: 15.000"
                                        />
                                    </label>
                                );
                            })()}

                            {/* Mostrar mensaje informativo para categorías incluidas */}
                            {(() => {
                                const selectedCategory = categories.find(cat => cat.id === parseInt(newAdicion.idCategoria));
                                const isIncluida = selectedCategory?.incluido === 1;
                                return isIncluida && (
                                    <div className={style.incluidaMessage}>
                                        <p><strong>📝 Nota:</strong> Esta categoría es incluida, no requiere precio adicional.</p>
                                    </div>
                                );
                            })()}

                            <div className={style.inlineCategoryRow}>
                                <label className={style.label_edit} style={{ flex: 1 }}>
                                    <span>Categoría *</span>
                                    <select
                                        className={`${style.input_edit} ${style.categorySelect} ${tried && !newAdicion.idCategoria ? style.inputError : ''}`}
                                        value={newAdicion.idCategoria}
                                        onChange={(e) => {
                                            const selectedCategoryId = e.target.value;
                                            const selectedCategory = categories.find(cat => cat.id === parseInt(selectedCategoryId));
                                            const isIncluida = selectedCategory?.incluido === 1;

                                            setNewAdicion(prev => ({
                                                ...prev,
                                                idCategoria: selectedCategoryId,
                                                // Limpiar precio si la categoría es incluida
                                                precio: isIncluida ? '' : prev.precio
                                            }));
                                        }}
                                    >
                                        <option value="">-- Selecciona --</option>
                                        {categories.map(cat => (
                                            <option key={cat.id} value={cat.id}>
                                                {cat.nombre} {cat.incluido ? '(Incluida)' : ''}
                                            </option>
                                        ))}
                                    </select>
                                </label>
                                <button
                                    type="button"
                                    className={style.btn_add_category_inline}
                                    aria-label="Agregar categoría"
                                    title="Agregar categoría"
                                    onClick={() => {
                                        setNewCatName('');
                                        setNewCatBusiness('');
                                        setNewCatIncluida(false);
                                        setIsCatModalOpen(true);
                                    }}
                                >+</button>
                            </div>

                            {tried && (() => {
                                const selectedCategory = categories.find(cat => cat.id === parseInt(newAdicion.idCategoria));
                                const isIncluida = selectedCategory?.incluido === 1;
                                const precioRequerido = !isIncluida && (newAdicion.precio === '' || Number(getNumericValue(newAdicion.precio)) <= 0);
                                const camposIncompletos = !newAdicion.nombreAdicion.trim() || precioRequerido || !newAdicion.idCategoria;

                                return camposIncompletos && (
                                    <div className={style.error}>
                                        {!newAdicion.nombreAdicion.trim() && 'El nombre es obligatorio. '}
                                        {precioRequerido && 'El precio es obligatorio para categorías no incluidas. '}
                                        {!newAdicion.idCategoria && 'Debe seleccionar una categoría. '}
                                    </div>
                                );
                            })()}

                            <div className={style.buttons}>
                                <button type="submit" disabled={saving}>
                                    {saving ? 'Guardando...' : 'Guardar'}
                                </button>
                                <button type="button" onClick={closeModal}>Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal Editar */}
            {isEditModalOpen && editingAdicion && (
                <div className={style.modal}>
                    <div className={style.modalContent}>
                        <form onSubmit={updateAdicion}>
                            <h2>Editar Adición</h2>

                            <label>
                                <span>Nombre *</span>
                                <input
                                    className={triedEdit && !editingAdicion.nombreAdicion?.trim() ? style.inputError : ''}
                                    type="text"
                                    value={editingAdicion.nombreAdicion || ''}
                                    onChange={(e) => setEditingAdicion(prev => ({ ...prev, nombreAdicion: e.target.value }))}
                                />
                            </label>

                            <label>
                                <span>Precio *</span>
                                <input
                                    className={triedEdit && (editingAdicion.precio === '' || Number(getNumericValue(editingAdicion.precio)) <= 0) ? style.inputError : ''}
                                    type="text"
                                    value={editingAdicion.precio || ''}
                                    onChange={(e) => {
                                        const formatted = formatPriceInput(e.target.value);
                                        setEditingAdicion(prev => ({ ...prev, precio: formatted }));
                                    }}
                                    placeholder="Ej: 15.000"
                                />
                            </label>

                            <p><strong>Categoría:</strong> {editingAdicion.nombreCategoria}</p>

                            {triedEdit && (!editingAdicion.nombreAdicion?.trim() || editingAdicion.precio === '' || Number(getNumericValue(editingAdicion.precio)) <= 0) && (
                                <div className={style.error}>Completa todos los campos obligatorios</div>
                            )}

                            <div className={style.buttons}>
                                <button type="submit" disabled={savingEdit}>
                                    {savingEdit ? 'Guardando...' : 'Guardar'}
                                </button>
                                <button type="button" onClick={closeEditModal}>Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal Nueva Categoría */}
            {isCatModalOpen && (
                <div className={style.modal}>
                    <div className={`${style.modalContent} ${style.modalSmall}`}>
                        <form onSubmit={async (e) => {
                            e.preventDefault();
                            if (!newCatName.trim() || !newCatBusiness) {
                                Swal.fire({ icon: 'warning', title: 'Completa los campos' });
                                return;
                            }
                            setSavingCat(true);
                            try {
                                // Backend espera CategoryCreateDTO: { nombre, tipo, idNegocio }
                                let businessId;
                                if (newCatBusiness === 'AMEKATIAR') {
                                    businessId = 1; // Amekatiar = 1
                                } else if (newCatBusiness === 'QUERERTE') {
                                    businessId = 2; // Quererte = 2
                                }

                                const payload = {
                                    nombre: newCatName.trim(),
                                    tipo: 'ADICION', // Para adicciones siempre es ADICION
                                    idNegocio: businessId,
                                    incluido: newCatIncluida ? 1 : 0
                                };

                                const created = await ProductService.createCategory(payload);
                                Swal.fire({ icon: 'success', title: 'Categoría creada', timer: 1200, showConfirmButton: false });
                                setIsCatModalOpen(false);
                                // Agregar a la lista sin duplicar y seleccionar automáticamente
                                setCategories(prev => {
                                    if (!created) return prev;
                                    const exists = prev.some(c => c.id === created.id);
                                    const list = exists ? prev : [...prev, created];
                                    return list;
                                });
                                if (created?.id) {
                                    setNewAdicion(d => ({ ...d, idCategoria: created.id.toString() }));
                                }
                            } catch (err) {
                                console.error('Error completo:', err);
                                console.error('Response data:', err?.response?.data);
                                console.error('Response status:', err?.response?.status);

                                const errorMessage = err?.response?.data || 'No se pudo crear la categoría';
                                Swal.fire({ icon: 'error', title: 'Error', text: errorMessage });
                            } finally { setSavingCat(false); }
                        }}>
                            <h3>Nueva Categoría</h3>

                            <p className={style.warningCategory}>⚠️Una vez creada la categoría no podrá eliminarse ni modificarse. Por favor verifique la información antes de confirmar el registro.</p>

                            <label>
                                <span>Nombre</span>
                                <input value={newCatName} onChange={e => setNewCatName(e.target.value)} />
                            </label>

                            <label>
                                <span>Negocio</span>
                                <select value={newCatBusiness} onChange={e => setNewCatBusiness(e.target.value)}>
                                    <option value="">-- Selecciona --</option>
                                    <option value="AMEKATIAR">Amekatiar</option>
                                    <option value="QUERERTE">Quererte</option>
                                </select>
                            </label>

                            <div className={style.incluidaSection}>
                                <label className={style.checkboxLabel}>
                                    <input
                                        type="checkbox"
                                        checked={newCatIncluida}
                                        onChange={(e) => setNewCatIncluida(e.target.checked)}
                                    />
                                    <strong>Esta categoría es incluida (sin precio)</strong>
                                </label>
                                <p className={style.incluidaExplanation}>
                                    Las categorías incluidas se usan para adicciones obligatorias que no tienen costo adicional.
                                    Ejemplo: "Bolas de Helado Incluidas" para la Copa Oreo.
                                </p>
                            </div>

                            <div className={style.buttons}>
                                <button type="submit" disabled={savingCat}>{savingCat ? 'Guardando...' : 'Guardar'}</button>
                                <button type="button" onClick={() => setIsCatModalOpen(false)}>Cerrar</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Adicciones;
