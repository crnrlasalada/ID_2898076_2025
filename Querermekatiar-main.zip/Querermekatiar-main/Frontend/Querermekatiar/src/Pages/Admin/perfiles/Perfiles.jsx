import style from './Perfiles.module.css'
import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';
import { UserService } from '../../../api/services/UserService';
import { AuthService } from '../../../api/services/AuthService';
import iconProfile from '../../../assets/Icons/profile.webp'
import trahsIcon from "../../../assets/Icons/contenedor-de-basura.webp";
import bgstyle from '../../../assets/Styles/bg.module.css'
import { FaEye, FaEyeSlash } from "react-icons/fa";

const Perfiles = () => {

    const [isModalNewUserOpen, setIsModalNewUserOpen] = useState(false);
    const [perfiles, setPerfiles] = useState([]);
    const roleLabel = (code) => ({ CASHIER: 'Cajero', DELIVERY: 'Repartidor' }[code] || code);
    const roleToCode = (value) => {
        if (!value) return '';
        const v = String(value).trim();
        const up = v.toUpperCase();
        if (up === 'CAJERO' || up === 'CAJERO'.toUpperCase()) return 'CASHIER';
        if (up === 'REPARTIDOR' || up === 'REPARTIDOR'.toUpperCase()) return 'DELIVERY';
        if (up === 'CASHIER' || up === 'DELIVERY') return up;
        return v; // fallback
    };

    const [triedCreate, setTriedCreate] = useState(false);
    const [saving, setSaving] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [newUser, setNewUser] = useState({
        rol: '',
        correo: '',
        nombres: '',
        apellidos: '',
        telefono: '',
        cedula: '',
        password: '',
        confirmPassword: ''
    });

const openModalNewUser = () => {
    setNewUser({ 
        rol: '', 
        correo: '', 
        nombres: '', 
        apellidos: '', 
        telefono: '', 
        cedula: '',
        password: '',
        confirmPassword: '' 
    });
    setTriedCreate(false);
    setShowPassword(false);
    setIsModalNewUserOpen(true);
};
const closeModalNewUser = () => setIsModalNewUserOpen(false);

// Edit user modal state
const [editingUser, setEditingUser] = useState(null);
const [editingTried, setEditingTried] = useState(false);
const openEditModal = (perfil) => {
    setEditingTried(false);
    // normalize role to code (CASHIER/DELIVERY) in case it's a display label
    const rolCode = roleToCode(perfil.rol);
    console.debug('openEditModal perfil:', perfil);
    setEditingUser({
        ...perfil,
        rol: rolCode,
        nombre: perfil.nombre || `${perfil.nombres || ''} ${perfil.apellidos || ''}`.trim(),
        telefono: perfil.telefono || '',
        cedula: perfil.cedula || ''
    });
};
const closeEditModal = () => setEditingUser(null);

const onChangeField = (field, value) => {
    setNewUser(prev => ({ ...prev, [field]: value }));
};

const validate = () => {
    const emailOk = newUser.correo.trim().length > 5 && newUser.correo.includes('@');
    const roleOk = newUser.rol === 'CASHIER' || newUser.rol === 'DELIVERY';
    
    // Validaciones de seguridad de contraseña 
    const hasMinLength = newUser.password.length >= 8;
    const hasUppercase = /[A-Z]/.test(newUser.password);
    const hasLowercase = /[a-z]/.test(newUser.password);
    const hasNumber = /\d/.test(newUser.password);
    const passwordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber;
    
    const passwordsMatch = newUser.password === newUser.confirmPassword;
    return emailOk && roleOk && passwordValid && passwordsMatch;
};

// Variables de validación de contraseña para usar en el JSX
const hasMinLength = newUser.password.length >= 8;
const hasUppercase = /[A-Z]/.test(newUser.password);
const hasLowercase = /[a-z]/.test(newUser.password);
const hasNumber = /\d/.test(newUser.password);
const passwordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber;

const submitNewUser = async (e) => {
    e.preventDefault();
    setTriedCreate(true);
    if (!validate()) return;
    setSaving(true);
    try {
        const payload = { ...newUser };
        if (payload.correo) payload.correo = payload.correo.toLowerCase().trim();
        // Eliminamos confirmPassword del payload
        delete payload.confirmPassword;
        
        await AuthService.createSpecialUser(payload);
        const nextId = perfiles.length ? Math.max(...perfiles.map(p => p.id)) + 1 : 1;
        setPerfiles(prev => [
            ...prev,
            {
                id: nextId,
                nombre: `${newUser.nombres} ${newUser.apellidos}`.trim() || newUser.correo.split('@')[0],
                correo: newUser.correo,
                telefono: newUser.telefono,
                cedula: newUser.cedula,
                rol: newUser.rol
            }
        ]);
        Swal.fire({
            icon: 'success',
            title: 'Usuario creado exitosamente',
            text: 'El usuario ya puede iniciar sesión con la contraseña establecida',
            timer: 2000,
            showConfirmButton: false
        });
        closeModalNewUser();
    } catch (err) {
        console.error(err);
        Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo crear el usuario' });
    } finally {
        setSaving(false);
    }
};

const submitEditUser = async (e) => {
    e.preventDefault();
    if (!editingUser) return;
    setEditingTried(true);
    const emailOk = editingUser.correo?.trim().length > 5 && editingUser.correo?.includes('@');
    if (!emailOk) return;
        try {
        setSaving(true);
        const payload = {
            correo: editingUser.correo ? editingUser.correo.toLowerCase().trim() : editingUser.correo,
            nombres: editingUser.nombre?.split(' ')[0] || '',
            apellidos: editingUser.nombre?.split(' ').slice(1).join(' ') || '',
            telefono: editingUser.telefono || '',
            cedula: editingUser.cedula || '',
        };
        console.debug('submitEditUser payload:', payload);
        const updated = await UserService.updateUser(editingUser.id, payload);
        setPerfiles(prev => prev.map(p => p.id === updated.id ? {
            id: updated.id,
            nombre: `${updated.nombres || ''} ${updated.apellidos || ''}`.trim() || updated.correo.split('@')[0],
            correo: updated.correo,
            telefono: updated.telefono,
            cedula: updated.cedula || '',
            rol: updated.rol
        } : p));
        closeEditModal();
        Swal.fire({ icon: 'success', title: 'Usuario actualizado' });
    } catch (err) {
        console.error(err);
        Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo actualizar el usuario' });
    } finally {
        setSaving(false);
    }
};

const handleDelete = async (perfil) => {
    const res = await Swal.fire({
        title: '¿Eliminar usuario?',
        text: `Eliminar a ${perfil.nombre} (${perfil.correo})`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Eliminar',
        cancelButtonText: 'Cancelar'
    });
    if (res.isConfirmed) {
        try {
            await UserService.deleteUserByEmail(perfil.correo);
            setPerfiles(prev => prev.filter(p => p.id !== perfil.id));
            Swal.fire({ icon: 'success', title: 'Usuario eliminado' });
        } catch (err) {
            console.error(err);
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo eliminar el usuario' });
        }
    }
};

useEffect(() => {
    document.body.className = bgstyle.bg;
    const fetchPerfiles = async () => {
        try {
            const data = await UserService.getAllSuperUsers();
            console.debug('fetched users from backend:', data);
            setPerfiles(data.map(u => ({
                id: u.id,
                nombre: `${u.nombres || ''} ${u.apellidos || ''}`.trim() || u.correo.split('@')[0],
                correo: u.correo,
                telefono: u.telefono,
                cedula: u.cedula || '',
                rol: u.rol
            })));
        } catch (error) {
            console.error('Error al cargar perfiles:', error);
        }
    };
    fetchPerfiles();
    return () => { document.body.className = ''; };
}, []);

return (
    <div className={style.div_major_profile}>

        <button className={style.agg_employed} onClick={openModalNewUser}>Agregar empleado</button>

        {perfiles.map((perfil) => (
            <div key={perfil.id} className={style.div_profile}>

                <hr className={style.hrUp} />

                <figure className={style.figureProfile}>
                    <img src={iconProfile} alt="" className={style.iconProfile} />

                    <h3 className={style.rol}>{roleLabel(perfil.rol)}</h3>
                </figure>

                <ul className={style.ul_data}>
                    <li>
                        <div className={style.fieldBox}>
                            <span className={style.fieldLabel}>Nombre:</span>
                            <span className={style.fieldValue}>{perfil.nombre}</span>
                        </div>
                    </li>
                    <li>
                        <div className={style.fieldBox}>
                            <span className={style.fieldLabel}>Correo:</span>
                            <span className={style.fieldValue}>{perfil.correo}</span>
                        </div>
                    </li>
                    <li>
                        <div className={style.fieldBox}>
                            <span className={style.fieldLabel}>Teléfono:</span>
                            <span className={style.fieldValue}>{perfil.telefono}</span>
                        </div>
                    </li>
                    <li>
                        <div className={style.fieldBox}>
                            <span className={style.fieldLabel}>Cédula:</span>
                            <span className={style.fieldValue}>{perfil.cedula || '—'}</span>
                        </div>
                    </li>
                </ul>

                <div className={style.controls}>

                    <button className={style.btn_edit} onClick={() => openEditModal(perfil)}>Editar</button>

                    <button className={style.btn_delete} onClick={() => handleDelete(perfil)}>
                        <img src={trahsIcon} className={style.trashIcon} />
                    </button>

                </div>

                <hr className={style.hrDown} />
            </div>
        ))}

        {isModalNewUserOpen && (
            <div className={style.modal}>
                <div className={style.modalContent}>
                    <form className={style.form_modal_edit} onSubmit={submitNewUser}>
                        <h2>Nuevo usuario</h2>
                        <label className={style.label_edit}>
                            <span>Correo *</span>
                            <input
                                className={`${style.input_edit} ${triedCreate && (!newUser.correo || !newUser.correo.includes('@')) ? style.input_error : ''}`}
                                type="email"
                                value={newUser.correo}
                                onChange={e => onChangeField('correo', e.target.value)}
                                placeholder="correo@dominio.com"
                            />
                        </label>
                        <div style={{ display: 'flex', gap: '0.75rem' }}>
                            <label className={style.label_edit} style={{ flex: 1 }}>
                                <span>Nombres</span>
                                <input className={style.input_edit} value={newUser.nombres} required onChange={e => onChangeField('nombres', e.target.value)} />
                            </label>
                            <label className={style.label_edit} style={{ flex: 1 }}>
                                <span>Apellidos</span>
                                <input className={style.input_edit} value={newUser.apellidos} required onChange={e => onChangeField('apellidos', e.target.value)} />
                            </label>
                        </div>
                        <div style={{ display: 'flex', gap: '0.75rem' }}>
                            <label className={style.label_edit} style={{ flex: 1 }}>
                                <span>Teléfono</span>
                                <input className={style.input_edit} value={newUser.telefono} maxLength={10} onChange={e => onChangeField('telefono', e.target.value.replace(/[^0-9+\-\s]/g, '').slice(0,10))} />
                            </label>
                            <label className={style.label_edit} style={{ flex: 1 }}>
                                <span>Rol *</span>
                                <select
                                    className={`${style.input_edit} ${triedCreate && !newUser.rol ? style.input_error : ''}`}
                                    value={newUser.rol}
                                    onChange={e => onChangeField('rol', e.target.value)}
                                >
                                    <option value="">--Selecciona--</option>
                                    <option value="CASHIER">Cajero</option>
                                    <option value="DELIVERY">Repartidor</option>
                                </select>
                            </label>
                        </div>
                        <label className={style.label_edit}>
                            <span>Cédula</span>
                            <input className={style.input_edit} value={newUser.cedula} maxLength={10} onChange={e => onChangeField('cedula', e.target.value.replace(/[^0-9]/g, '').slice(0,10))} />
                        </label>
                        
                        {/* Nuevos campos de contraseña */}
                        <label className={style.label_edit}>
                            <span>Contraseña *</span>
                            <div style={{ position: 'relative' }}>
                                <input
                                    className={`${style.input_edit} ${triedCreate && !passwordValid ? style.input_error : ''}`}
                                    type={showPassword ? "text" : "password"}
                                    value={newUser.password}
                                    onChange={e => onChangeField('password', e.target.value)}
                                    placeholder="Mínimo 8 caracteres"
                                    style={{ paddingRight: "40px" }}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    style={{ 
                                        position: "absolute", 
                                        right: "14px", 
                                        top: 0, 
                                        height: "100%", 
                                        display: "flex", 
                                        alignItems: "center", 
                                        background: "none", 
                                        border: "none", 
                                        cursor: "pointer", 
                                        padding: 0, 
                                        zIndex: 2 
                                    }}
                                >
                                    {showPassword ? <FaEyeSlash /> : <FaEye />}
                                </button>
                            </div>
                        </label>
                        
                        {/* Indicadores de validación de contraseña */}
                        {newUser.password.length > 0 && (
                            <div className={style.password_rules_box}>
                                <ul className={style.password_rules}>
                                    <li className={hasMinLength ? style.rule_ok : style.rule_error}>Mínimo 8 caracteres</li>
                                    <li className={hasUppercase ? style.rule_ok : style.rule_error}>Al menos una mayúscula</li>
                                    <li className={hasLowercase ? style.rule_ok : style.rule_error}>Al menos una minúscula</li>
                                    <li className={hasNumber ? style.rule_ok : style.rule_error}>Al menos un número</li>
                                </ul>
                            </div>
                        )}
                        
                        <label className={style.label_edit}>
                            <span>Confirmar contraseña *</span>
                            <input
                                className={`${style.input_edit} ${triedCreate && (newUser.confirmPassword !== newUser.password || newUser.confirmPassword.length === 0) ? style.input_error : ''}`}
                                type="password"
                                value={newUser.confirmPassword}
                                onChange={e => onChangeField('confirmPassword', e.target.value)}
                                placeholder="Confirma la contraseña"
                            />
                        </label>
                        {triedCreate && !validate() && (
                            <div className={style.field_error}>
                                {!newUser.correo || !newUser.correo.includes('@') ? 'El correo es obligatorio y debe ser válido. ' : ''}
                                {!newUser.rol ? 'El rol es obligatorio. ' : ''}
                                {newUser.password.length === 0 ? 'La contraseña es obligatoria. ' : ''}
                                {newUser.password.length > 0 && !passwordValid ? 'La contraseña no cumple los requisitos de seguridad. ' : ''}
                                {newUser.password !== newUser.confirmPassword ? 'Las contraseñas no coinciden. ' : ''}
                            </div>
                        )}
                        <div>
                            <button type="submit" className={style.btn_modal} disabled={saving}>{saving ? 'Guardando...' : 'Guardar'}</button>
                            <button type="button" className={style.btn_modal} onClick={closeModalNewUser}>Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        )}

        {editingUser && (
            <div className={style.modal}>
                <div className={style.modalContent}>
                    <form className={style.form_modal_edit} onSubmit={submitEditUser}>
                        <h2>Editar usuario</h2>
                        <label className={style.label_edit}>
                            <span>Correo *</span>
                            <input
                                className={`${style.input_edit} ${editingTried && (!editingUser.correo || !editingUser.correo.includes('@')) ? style.input_error : ''}`}
                                type="email"
                                value={editingUser?.correo ?? ''}
                                onChange={e => setEditingUser(prev => ({ ...prev, correo: e.target.value }))}
                            />
                        </label>
                        <label className={style.label_edit}>
                            <span>Nombre completo</span>
                            <input className={style.input_edit} value={editingUser?.nombre ?? ''} required onChange={e => setEditingUser(prev => ({ ...prev, nombre: e.target.value }))} />
                        </label>
                        <label className={style.label_edit}>
                            <span>Teléfono</span>
                            <input className={style.input_edit} value={editingUser?.telefono ?? ''} maxLength={10} onChange={e => setEditingUser(prev => ({ ...prev, telefono: e.target.value.replace(/[^0-9+\-\s]/g, '').slice(0,10) }))} />
                        </label>
                        <label className={style.label_edit}>
                            <span>Cédula</span>
                            <input className={style.input_edit} value={editingUser?.cedula ?? ''} maxLength={10} onChange={e => setEditingUser(prev => ({ ...prev, cedula: e.target.value.replace(/[^0-9]/g, '').slice(0,10) }))} />
                        </label>
                        {editingTried && (!(editingUser.correo?.includes('@'))) && (
                            <div className={style.field_error}>Completa los campos obligatorios.</div>
                        )}
                        <div>
                            <button type="submit" className={style.btn_modal} disabled={saving}>{saving ? 'Guardando...' : 'Guardar'}</button>
                            <button type="button" className={style.btn_modal} onClick={closeEditModal}>Cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        )}
    </div>
);
};

export default Perfiles


