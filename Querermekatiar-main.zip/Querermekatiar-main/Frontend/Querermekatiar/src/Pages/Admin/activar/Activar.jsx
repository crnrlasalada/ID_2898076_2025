import {ActivarDesactivar} from "../../../Components/Admin/activar/ActivarDesactivar";
import style from "./Activar.module.css";

const Activar = () => {
    return (
        <div>
            <ActivarDesactivar />
        </div>
    );
};

export default Activar;
