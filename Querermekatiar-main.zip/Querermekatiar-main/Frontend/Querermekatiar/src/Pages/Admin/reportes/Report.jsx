    import ReportFilterPanel from "../../../Components/Admin/calendar/ReportFilterPanel";
    import styles from "./Report.module.css";
    import { useEffect } from "react";
    import bgstyles from "../../../assets/Styles/bg2.module.css";

    const Report = () => {
        useEffect(() => {
            document.body.className = bgstyles.bg;
            return () => {
            document.body.className = "";
            };
        }, []);
        return (
            <div className="container">
                <h1 style={{ textAlign: "center", paddingBottom: "2rem", paddingTop: "0.5rem", fontSize: "2.5rem", fontFamily: "Roboto, sans-serif" , color: "white"}}>Reportes</h1>
                <div className={styles.reportesContainer}>
                    <div className={styles.filtrosPanel}>
                        <ReportFilterPanel />
                    </div>
                </div>
            </div>
        );
    };
    export default Report;
