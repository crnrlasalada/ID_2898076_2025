// PedidoDetalle.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import EstadoBarra from '../../../Components/Admin/Pedido/EstadoBarra';
import styles from './PedidoDetalle.module.css';
import cardStyles from '../../../Components/Admin/Pedido/PedidoCard.module.css';
import { OrderService } from '../../../api/services/OrderService';
import bgstyles from "../../../assets/Styles/bg2.module.css";
import { RutaMapaCliente } from '../../../Components/Admin/Pedido/RutaMapaCliente';


const estadosFinales = ['Entregado', 'Rechazado', 'No_Recibido'];
const ordenEstados = ['Pendiente', 'En_Proceso', 'Reparto', 'Entregado'];

const formatearEstado = (estado) =>
    estado.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase());

const PedidoDetalle = () => {
    useEffect(() => {
        document.body.className = bgstyles.bg;
        return () => {
            document.body.className = "";
        };
    }, []);

    const { id } = useParams();
    const navigate = useNavigate();

    const [pedido, setPedido] = useState(null);
    const [estadoActual, setEstadoActual] = useState('');
    const [estadoPendiente, setEstadoPendiente] = useState('');
    const [motivo, setMotivo] = useState('');
    const [mostrarModal, setMostrarModal] = useState(false);
    const [mostrarConfirmacion, setMostrarConfirmacion] = useState(false);
    const [mensajeExito, setMensajeExito] = useState('');
    const [mostrarConfirmacionReparto, setMostrarConfirmacionReparto] = useState(false);
    const [productoSeleccionado, setProductoSeleccionado] = useState(null);
    const [mostrarPopupAsignado, setMostrarPopupAsignado] = useState(false);
    const [mostrarPopupFinalLocal, setMostrarPopupFinalLocal] = useState(false);

    useEffect(() => {
        const fetchPedido = async () => {
            try {
                const data = await OrderService.getDetalle(id);
                if (!data || !data.id) {
                    // Si no existe el pedido, redirige al 404
                    navigate('/404', { replace: true });
                    return;
                }
                setPedido(data);
                setEstadoActual(data.estadoPedido);
            } catch (err) {
                console.error('Error cargando pedido:', err);
                navigate('/404', { replace: true });
            }
        };
        fetchPedido();
    }, [id, navigate]);

    const tipoEntrega = pedido?.tipoEntrega;
    const esFinalizado = estadosFinales.includes(estadoActual);
    const estaPendiente = estadoActual === 'Pendiente';
    const esRepartoDomicilio = estadoActual === 'Reparto' && tipoEntrega === 'Domicilio';
    const esRepartoLocal = estadoActual === 'Reparto' && tipoEntrega === 'Local';

    const cambiarEstado = (nuevoEstado) => {
        const indiceActual = ordenEstados.indexOf(estadoActual);
        const indiceNuevo = ordenEstados.indexOf(nuevoEstado);

        if (esFinalizado) {
            alert("Este pedido ya está finalizado y no puede modificarse.");
            return;
        }

        if (indiceNuevo < indiceActual && nuevoEstado !== 'Rechazado' && nuevoEstado !== 'No_Recibido') {
            alert('No puedes devolver el estado del pedido.');
            return;
        }

        if (estadoActual === 'Pendiente' && nuevoEstado !== 'En_Proceso' && nuevoEstado !== 'Rechazado') {
            alert('Debes aceptar o rechazar el pedido antes de continuar.');
            return;
        }

        setEstadoPendiente(nuevoEstado);
        setMotivo('');

        // Si es pasar a Reparto y es domicilio, mostrar la modal mostaza/blanca
        if (nuevoEstado === 'Reparto' && (tipoEntrega || '').toLowerCase() === 'domicilio') {
            setMostrarConfirmacionReparto(true);
            return;
        }
        if (nuevoEstado === 'Rechazado' || nuevoEstado === 'No_Recibido') {
            setMostrarModal(true);
        } else {
            setMostrarConfirmacion(true);
        }
    };

    const confirmarCambio = async (nuevoEstado, motivoText = null, desdeRepartoModal = false) => {
        if ((nuevoEstado === 'Rechazado' || nuevoEstado === 'No_Recibido') && !motivoText?.trim()) {
            alert("Debes ingresar un motivo.");
            return;
        }

        try {
            await OrderService.updateEstado(pedido.id, nuevoEstado, motivoText);
            setEstadoActual(nuevoEstado);
            setPedido(prev => ({ ...prev, estadoPedido: nuevoEstado }));
            setMensajeExito(`Estado actualizado a ${formatearEstado(nuevoEstado)} correctamente.`);
            setTimeout(() => setMensajeExito(''), 2000);
            // Mostrar popup solo si es Domicilio -> Reparto
            if (nuevoEstado === 'Reparto' && (tipoEntrega || '').toLowerCase() === 'domicilio') {
                setMostrarPopupAsignado(true);
                setTimeout(() => {
                    setMostrarPopupAsignado(false);
                    navigate('/admin/pedidos');
                }, 2000);
            }
            // Mostrar popup de finalización si es Local y estado final
            if (["Entregado", "Rechazado", "No_Recibido"].includes(nuevoEstado) && (tipoEntrega || '').toLowerCase() === 'local') {
                setMostrarPopupFinalLocal(true);
                setTimeout(() => {
                    setMostrarPopupFinalLocal(false);
                    navigate('/admin/pedidos');
                }, 2000);
            }
        } catch (error) {
            console.error("Error actualizando estado:", error);
        } finally {
            setMostrarModal(false);
            setMostrarConfirmacion(false);
            setMostrarConfirmacionReparto(false);
            setMotivo('');
        }
    };

    // Popups para mostrar en la parte superior del return
    const popups = (
        <>
            {mostrarPopupAsignado && (
                <div className={cardStyles.modalOverlay}>
                    <div className={cardStyles.popupAsignado}>
                        <span className={cardStyles.iconoRepartidor} role="img" aria-label="Repartidor">🛵</span>
                        <h3>¡Pedido asignado al repartidor!</h3>
                        <p style={{ color: '#b8860b', fontWeight: 500, textAlign: 'center', margin: 0 }}>
                          El pedido será entregado por un repartidor a domicilio.
                        </p>
                    </div>
                </div>
            )}
            {mostrarPopupFinalLocal && (
                <div className={styles.productoModalOverlay}>
                    <div className={styles.productoModal}>
                        <h3>El pedido finalizó su proceso</h3>
                    </div>
                </div>
            )}
        </>
    );

    const abrirDetalleProducto = (prod) => setProductoSeleccionado(prod);
    const cerrarDetalleProducto = () => setProductoSeleccionado(null);

    if (!pedido) return <p>Cargando pedido...</p>;



    
    return (
        <>
            {popups}
            <div className={styles.pedidoDetalleContainer}>
            <button className={styles.volverBtn} onClick={() => navigate(-1)}>Volver</button>

            <h2 className={styles.titulo}>Detalle del Pedido #{pedido.id}</h2>

            {mensajeExito && <div className={styles.alertaExito}>✅ {mensajeExito}</div>}

            <div className={styles.infoPedido}>
                <span><strong>Nombre:</strong> {pedido.nombres} {pedido.apellidos}</span>
                <span><strong>Telefono:</strong> {pedido.telefono}</span>
                <span><strong>Fecha:</strong> {new Date(pedido.fechaHora).toLocaleString()}</span>
                <span><strong>Forma de pago:</strong> {pedido.formaPago}</span>
                <span><strong>Dirección:</strong> {pedido.direccion}</span>
                <span><strong>Tipo entrega:</strong> {tipoEntrega}</span>
                <span><strong>Costo domicilio:</strong> ${pedido.domicilio}</span>
                {pedido.mensajeCliente && pedido.mensajeCliente.trim() !== '' && (
                    <span><strong>Mensaje cliente:</strong> {pedido.mensajeCliente}</span>
                )}
                <span><strong>Total:</strong> ${pedido.total}</span>
                <span className={styles.estadoActual}><strong>Estado:</strong> {formatearEstado(estadoActual)}</span>
            </div>

            <EstadoBarra
                estadoActual={estadoActual}
                setEstadoActual={cambiarEstado}
                tipoEntrega={tipoEntrega}
            />

            {!esFinalizado && (
                <div className={styles.botonesTransicion}>
                    {estadoActual === 'Pendiente' && (
                        <button className={styles.botonEstado} style={{ backgroundColor: 'green' }} onClick={() => cambiarEstado('En_Proceso')}>
                            Aceptar Pedido
                        </button>
                    )}

                    {estadoActual === 'En_Proceso' && (
                        <button className={styles.botonEstado} style={{ backgroundColor: '#fb8d08' }} onClick={() => cambiarEstado('Reparto')}>
                            {(tipoEntrega && tipoEntrega.toLowerCase() === 'local') ? 'Pasar a Preparado' : 'Pasar a Reparto'}
                        </button>
                    )}

                    {esRepartoLocal && (
                        <>
                            <button className={styles.botonEstado} style={{ backgroundColor: 'red' }} onClick={() => cambiarEstado('No_Recibido')}>
                                No Recibido
                            </button>
                            <button className={styles.botonEstado} style={{ backgroundColor: 'green' }} onClick={() => cambiarEstado('Entregado')}>
                                Entregado
                            </button>
                            
                        </>
                    )}

                    <button className={styles.botonEstado} style={{ backgroundColor: 'red' }} onClick={() => cambiarEstado('Rechazado')}>
                        Rechazar Pedido
                    </button>
                </div>
            )}

            <div className={styles.listaProductos}>
                {pedido.productos.map((prod, i) => (
                    <div key={i} className={styles.producto} onClick={() => abrirDetalleProducto(prod)}>
                        <img src={prod.urlImagen || '/default.jpg'} alt={prod.nombre} />
                        <div className={styles.detalleProducto}>
                            <span><strong>{prod.nombre}</strong></span>
                            <span>Cantidad: {prod.cantidad}</span>
                            <span>Precio: ${prod.precio}</span>
                        </div>
                    </div>
                ))}
            </div>


            {productoSeleccionado && (
                <div className={styles.productoModalOverlay} onClick={cerrarDetalleProducto}>
                    <div className={styles.productoModal} onClick={(e) => e.stopPropagation()}>
                        <button className={styles.cerrarModalBtn} onClick={cerrarDetalleProducto}>×</button>
                        <h3>{productoSeleccionado.nombre}</h3>
                        <p><strong>Cantidad:</strong> {productoSeleccionado.cantidad}</p>
                        <p><strong>Precio:</strong> ${productoSeleccionado.precio}</p>
                        {productoSeleccionado.adiciones?.length > 0 ? (
                            <>
                                <p><strong>Adiciones:</strong></p>
                                <ul>
                                    {productoSeleccionado.adiciones.map((a, idx) => (
                                        <li key={idx}>{a.nombre} - ${a.precio}</li>
                                    ))}
                                </ul>
                            </>
                        ) : (
                            <p>Sin adiciones</p>
                        )}
                    </div>
                </div>
            )}

            {mostrarModal && (
                <div className={styles.productoModalOverlay}>
                    <div className={styles.productoModal}>
                        <h3>
                          Motivo del estado: {
                            (estadoPendiente === 'Reparto' && (tipoEntrega || '').toLowerCase() === 'local')
                              ? 'Preparado'
                              : formatearEstado(estadoPendiente)
                          }
                        </h3>
                        <textarea
                            rows="4"
                            value={motivo}
                            onChange={(e) => setMotivo(e.target.value)}
                            placeholder="Escribe el motivo aquí..."
                        />
                        <div className={styles.botonesTransicion}>
                            <button
                                className={styles.botonEstado}
                                onClick={() => confirmarCambio(estadoPendiente, motivo)}
                            >
                                Confirmar
                            </button>
                            <button className={styles.botonEstado} onClick={() => setMostrarModal(false)}>Cancelar</button>
                        </div>
                    </div>
                </div>
            )}

            {mostrarConfirmacion && (
                <div className={styles.productoModalOverlay}>
                    <div className={styles.productoModal}>
                        <p>
                          ¿Deseas cambiar el estado a <strong>{
                            (estadoPendiente === 'Reparto' && (tipoEntrega || '').toLowerCase() === 'local')
                              ? 'Preparado'
                              : formatearEstado(estadoPendiente)
                          }</strong>?
                        </p>
                        <div className={styles.botonesTransicion}>
                            <button className={styles.botonEstado} onClick={() => confirmarCambio(estadoPendiente)}>
                                Sí, confirmar
                            </button>
                            <button className={styles.botonEstado} onClick={() => setMostrarConfirmacion(false)}>Cancelar</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal mostaza/blanca para pasar a Reparto en domicilio */}
            {mostrarConfirmacionReparto && (
                <div className={cardStyles.modalOverlay}>
                    <div className={cardStyles.modalConfirmacionReparto}>
                        <h3>¿Deseas asignar este pedido al repartidor?</h3>
                        <div className={cardStyles.mensaje}>
                          El pedido será entregado por un repartidor a domicilio.
                        </div>
                        <div className={cardStyles.botonesConfirmacion}>
                            <button
                                className={cardStyles.botonMostaza}
                                onClick={async () => {
                                    setMostrarConfirmacionReparto(false);
                                    setMostrarPopupAsignado(true);
                                    setTimeout(async () => {
                                        setMostrarPopupAsignado(false);
                                        await confirmarCambio('Reparto', null, true);
                                    }, 1000);
                                }}
                            >
                                Sí, asignar
                            </button>
                            <button className={cardStyles.botonBlanco} onClick={() => setMostrarConfirmacionReparto(false)}>
                                Cancelar
                            </button>
                        </div>
                    </div>
                </div>
            )}
            {pedido.latitud && pedido.longitud && (
                <div style={{ marginTop: '30px' }}>
                    <h3>Ruta hasta el cliente</h3>
                    <RutaMapaCliente lat={pedido.latitud || pedido.latitude} lng={pedido.longitud || pedido.longitude} />       
                </div>
            )}
            </div>
        </>
    );
};

export default PedidoDetalle;