import React, { useEffect, useState } from 'react';
import PedidoCard from '../../../Components/Admin/Pedido/PedidoCard';
import bgstyles from "../../../assets/Styles/bg2.module.css";
import styles from './Pedidos.module.css';
import { OrderService } from '../../../api/services/OrderService';

const Pedidos = () => {
    const [pedidos, setPedidos] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [popupAsignado, setPopupAsignado] = useState(null); // {id}
    const [ocultandoId, setOcultandoId] = useState(null);

    // 🔹 Cargar todos los pedidos activos y ordenarlos por fecha/hora ascendente
    const cargarPedidos = async () => {
        try {
            setCargando(true);
            const data = await OrderService.getActivos();
            // Ordenar por fechaHora ascendente (más viejos primero)
            const pedidosOrdenados = Array.isArray(data)
                ? [...data].sort((a, b) => new Date(a.fechaHora) - new Date(b.fechaHora))
                : [];
            setPedidos(pedidosOrdenados);
        } catch (error) {
            console.error("Error cargando pedidos:", error);
        } finally {
            setCargando(false);
        }
    };

    // 🔹 Cargar un pedido específico y actualizar/agregarlo al final de la lista
    const cargarPedidoPorId = async (id) => {
        try {
            const pedido = await OrderService.getDetalle(id);
            setPedidos(prevPedidos => {
                const existe = prevPedidos.some(p => p.id === pedido.id);
                let nuevosPedidos;
                if (existe) {
                    // Actualizar el pedido existente
                    nuevosPedidos = prevPedidos.map(p => p.id === pedido.id ? pedido : p);
                } else {
                    // Agregar al final
                    nuevosPedidos = [...prevPedidos, pedido];
                }
                // Ordenar por fechaHora ascendente (más viejos primero)
                return [...nuevosPedidos].sort((a, b) => new Date(a.fechaHora) - new Date(b.fechaHora));
            });
        } catch (error) {
            console.error("Error cargando pedido por id:", error);
        }
    };

    // 🔹 Fondo dinámico
    useEffect(() => {
        document.body.className = bgstyles.bg;
        return () => { document.body.className = ""; };
    }, []);

    // 🔹 Cargar pedidos iniciales
    useEffect(() => { cargarPedidos(); }, []);

    // 🔹 Escuchar pedidos nuevos vía SSE
    useEffect(() => {
        const token = localStorage.getItem('token');
        const eventSource = new EventSource(`http://localhost:8080/api/stream/orders?token=${token}`);

        eventSource.addEventListener("nuevo-pedido", (event) => {
            try {
                const data = JSON.parse(event.data);
                const pedidoId = data.id || data.pedidoId || data.pedido_id;

                if (pedidoId) {
                    cargarPedidoPorId(pedidoId);
                } else {
                    cargarPedidos();
                }
            } catch (e) {
                console.error("Error procesando evento SSE:", e);
            }
        });

        eventSource.onerror = (err) => {
            console.error("Error en SSE, cerrando conexión:", err);
            eventSource.close();
        };

        return () => eventSource.close();
    }, []);

    // 🔹 Filtrar pedidos activos
    const estadosFinalizados = ['Entregado', 'Rechazado', 'No_Recibido'];
    // Excluir también los pedidos en 'Reparto' del listado y contador
    const pedidosActivos = pedidos.filter(p => !estadosFinalizados.includes(p.estadoPedido) && p.estadoPedido !== 'Reparto');
    const hayPendientes = pedidosActivos.some(p => p.estadoPedido === 'Pendiente');

    // Callback para mostrar popup y animar ocultamiento
    const handleAsignadoRepartidor = (pedidoId) => {
        setPopupAsignado({ id: pedidoId });
        setTimeout(() => {
            setOcultandoId(pedidoId);
            setTimeout(() => {
                setPedidos(prev => prev.filter(p => p.id !== pedidoId));
                setOcultandoId(null);
                setPopupAsignado(null);
            }, 700); // tiempo de animación
        }, 1800); // tiempo visible popup
    };

    return (
        <div style={{ position: 'relative', minHeight: '60vh' }}>
            {cargando && (
                <div className={styles.overlayCargando}>
                    <span className={styles.textoCargando}>Cargando pedidos...</span>
                </div>
            )}

            {/* Popup asignado al repartidor */}
            {popupAsignado && (
                <div className={styles.popupAsignado}>
                    <span className={styles.iconoRepartidor} role="img" aria-label="Repartidor">🛵</span>
                    <div>
                        <b>¡Pedido #{popupAsignado.id} asignado al repartidor!</b>
                        <div style={{ color: '#ff9800', fontWeight: 500, marginTop: 4, fontSize: '1.05rem' }}>
                            El pedido está en manos del repartidor para su entrega a domicilio.
                        </div>
                    </div>
                </div>
            )}

            <h2 className={styles.titulo}>
                Listado de Pedidos Activos ({pedidosActivos.length})
            </h2>

            {hayPendientes && (
                <div className={styles.alertaPendiente}>
                    <span className={styles.icono}>⚠️</span>
                    <p>
                        <strong>Nota:</strong> Los pedidos en estado <span className={styles.pendiente}>Pendiente</span> deben ser aceptados o rechazados desde el detalle.
                    </p>
                </div>
            )}

            <div className={styles.listadoPedidos}>
                {pedidosActivos.length === 0 ? (
                    <p className={styles.sinPedidos}>No hay pedidos registrados.</p>
                ) : (
                    pedidosActivos.map((pedido) => (
                        <PedidoCard
                            key={pedido.id}
                            pedido={pedido}
                            onAsignadoRepartidor={handleAsignadoRepartidor}
                            ocultando={ocultandoId === pedido.id}
                        />
                    ))
                )}
            </div>
        </div>
    );
};

export default Pedidos;
