import HomeComponent from "../../../Components/Admin/home/HomeComponent";

export const Home = () => {
    return (
        <div>
            <HomeComponent />   
        </div>
    );
};

export default Home;


