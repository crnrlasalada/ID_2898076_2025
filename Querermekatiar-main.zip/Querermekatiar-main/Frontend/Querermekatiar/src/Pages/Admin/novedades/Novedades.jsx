
import NovedadesAdmin from "../../../Components/Admin/Novedad/NovedadesAdmin";
import style from "./Novedades.module.css";
import { useEffect, useState } from "react";

const Novedades = () => {
    const [selectedNegocio, setSelectedNegocio] = useState(1); // 1: Amekatiar, 2: Quererte

    useEffect(() => {
        if (selectedNegocio === 1) {
            document.body.className = style.bgBodyCatalogosAdmin;
        } else {
            document.body.style.backgroundColor = "#18181b";
            document.body.className = "";
        }
        return () => {
            document.body.className = "";
            document.body.style.backgroundColor = "";
        };
    }, [selectedNegocio]);

        return (
            <div>
                        <h1
                            style={{
                                color: selectedNegocio === 1 ? '#fff' : '#fff',
                                textAlign: 'center',
                                marginTop: 36,
                                marginBottom: 18,
                                fontSize: '2.2rem',
                                fontFamily: 'Montserrat, Roboto, sans-serif',
                                fontWeight: 800,
                                letterSpacing: '0.01em',
                                zIndex: 2,
                                                        textShadow: selectedNegocio === 1
                                                            ? '0 2px 4px #bdbdbd, 0 1px 0 #e0e0e0'
                                                            : '0 2px 4px #2228',
                            }}
                        >
                            Novedades
                        </h1>
                <select
                    value={selectedNegocio}
                    onChange={e => setSelectedNegocio(Number(e.target.value))}
                    style={{
                        margin: "0 auto 28px auto",
                        display: "block",
                        border: '2.5px solid #fff',
                        boxShadow: '0 0 0 2px #fff8',
                        borderRadius: 18,
                        background: selectedNegocio === 1 ? '#fff' : '#18181b',
                        color: selectedNegocio === 1 ? '#2d3a7b' : '#fff',
                        fontWeight: 700,
                        fontSize: "1.13rem",
                        outline: "none",
                        transition: "box-shadow 0.22s, border 0.22s, background 0.22s, color 0.22s",
                        zIndex: 2,
                    }}
                    onFocus={e => e.target.style.boxShadow = '0 0 0 4px #fff8'}
                    onBlur={e => e.target.style.boxShadow = '0 0 0 2px #fff8'}
                >
                    <option value={1}>Amekatiar</option>
                    <option value={2}>Quererte</option>
                </select>
                <NovedadesAdmin selectedNegocio={selectedNegocio} />
            </div>
        );
};

export default Novedades;
