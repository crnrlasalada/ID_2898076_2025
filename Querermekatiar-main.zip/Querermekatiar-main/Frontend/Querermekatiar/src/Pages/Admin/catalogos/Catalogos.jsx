import { useState, useEffect, useCallback, useMemo, memo, useRef } from "react";
import style from "./Catalogos.module.css";
import trahsIcon from "../../../assets/Icons/contenedor-de-basura.webp";
import { ProductService } from '../../../api/services/ProductService'
import Swal from 'sweetalert2'
import { ToggleSwitch } from '../../../Components/toggle-switch.jsx'
import { decodeJwt } from '../../../utils/jwtDecode';

// Componente memoizado para cada producto
const ProductCard = memo(({
    plato,
    formatPrice,
    onToggleActive,
    onOpenAdiciones,
    onEdit,
    onDelete
}) => {
    const isActive = plato.active === 1;

    // Obtener el rol del usuario desde el token
    let role = '';
    try {
        const token = localStorage.getItem('token');
        const payload = decodeJwt(token);
        if (Array.isArray(payload?.roles) && payload.roles.length > 0) {
            role = payload.roles[0];
        } else {
            role = payload?.rol || payload?.role || '';
        }
    } catch (e) {}

    return (
        <div key={plato.id} className={isActive ? style.divDish : style.divDishInactive}>
            {/* Botón de eliminar solo para admin y productos distintos de id 1 y 2 */}
            {role === 'ADMIN' && plato.id !== 1 && plato.id !== 2 && (
                <button
                    className={style.btn_deletePro}
                    aria-label="Eliminar producto"
                    onClick={() => onDelete(plato)}
                    title="Eliminar producto"
                >
                    <img src={trahsIcon} className={style.trashIcon} alt="Eliminar" />
                </button>
            )}

            <figure className={style.dishPhoto}>
                <img
                    className={isActive ? style.dishImage : style.dishImageInactive}
                    src={plato.urlImage}
                    alt={"Imagen de:" + plato.name}
                    loading="lazy" // Lazy loading para mejor rendimiento
                />
            </figure>

            <h2 className={isActive ? style.dishName : style.dishNameInactive}>{plato.name}</h2>
            <p className={isActive ? style.precio : style.precioInactive}>${formatPrice(plato.price)} COP</p>
            <p className={isActive ? style.descriptionDish : style.descriptionInactive}>{plato.description}</p>

            <div className={style.controls}>
                {/* Primera fila: Toggle y Editar juntos */}
                <div className={style.controlsRow}>
                    <ToggleSwitch
                        checked={plato.active === 1}
                        title={isActive ? 'Activo' : 'Inactivo'}
                        onChange={(checked) => onToggleActive(plato.id, checked, plato.active)}
                    />
                    <button className={style.btn_edit} onClick={() => onEdit(plato)}>
                        Editar
                    </button>
                </div>

                {/* Segunda fila: Gestionar Adiciones solo */}
                <div className={style.controlsRowSingle}>
                    <button
                        className={style.btn_gestionar_adiciones}
                        onClick={() => onOpenAdiciones(plato)}
                        title="Gestionar adiciones del producto"
                    >
                        Gestionar Adiciones
                    </button>
                </div>
            </div>
        </div>
    );
});

ProductCard.displayName = 'ProductCard';

const Catalogos = () => {
    //falta por implementar la ediccion de los campos de los productos

    // Estado para seleccionar el negocio
    const [selectedBusiness, setSelectedBusiness] = useState('AMEKATIAR'); // Por defecto Amekatiar

    // Estado listado
    const [platos, setPlatos] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Modal editar
    const [isModalOpenEdit, setIsModalOpenEdit] = useState(false);
    const [selectedDish, setSelectedDish] = useState(null);
    const [savingEdit, setSavingEdit] = useState(false);
    const [triedEdit, setTriedEdit] = useState(false);

    // Modal nuevo
    const [isModalOpenNew, setIsModalOpenNew] = useState(false);

    // Campos alineados con ProductCreateDTO backend: nombre, precio, descripcion, categoriaId
    const [newDish, setNewDish] = useState({ nombre: '', precio: '', descripcion: '', categoriaId: '' });
    const [newDishImageFile, setNewDishImageFile] = useState(null);
    const [newDishImagePreview, setNewDishImagePreview] = useState(null);

    // Estados para gestión de adicciones por categorías
    const [categoriasAdicciones, setCategoriasAdicciones] = useState([]);
    const [tieneAdicionesObligatorias, setTieneAdicionesObligatorias] = useState(false);
    const [cantidadAdicionesObligatorias, setCantidadAdicionesObligatorias] = useState(1);
    const [categoriaObligatoria, setCategoriaObligatoria] = useState('');
    const [loadingCategorias, setLoadingCategorias] = useState(false);

    // Estados para modal de gestión de adicciones
    const [isModalGestionAdiccionesOpen, setIsModalGestionAdiccionesOpen] = useState(false);
    const [selectedProductForAdiciones, setSelectedProductForAdiciones] = useState(null);
    const [categoriasAsignadas, setCategoriasAsignadas] = useState([]);
    const [categoriasDisponibles, setCategoriasDisponibles] = useState([]);
    const [loadingAdiciones, setLoadingAdiciones] = useState(false);

    // Función memoizada para formatear precio
    const formatPrice = useCallback((price) => {
        if (!price) return '0';
        return Number(price).toLocaleString('es-CO');
    }, []);

    // Funciones optimizadas para ProductCard
    const handleToggleActive = useCallback(async (platoId, checked, prevActive) => {
        const newActive = checked ? 1 : 0;
        // Optimistic UI
        setPlatos(ps => ps.map(p => p.id === platoId ? { ...p, active: newActive } : p));
        try {
            await ProductService.productActive(platoId, checked);
        } catch (err) {
            setPlatos(ps => ps.map(p => p.id === platoId ? { ...p, active: prevActive } : p));
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo cambiar el estado' });
        }
    }, []);

    const handleOpenAdiciones = useCallback((plato) => {
        openModalGestionAdiciones(plato);
    }, []);

    const handleEdit = useCallback((plato) => {
        openModalEdit(plato);
    }, []);

    const handleDelete = useCallback(async (plato) => {
        const res = await Swal.fire({
            title: '¿Eliminar producto?',
            text: plato.name,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        });
        if (!res.isConfirmed) return;
        try {
            const resp = await ProductService.DeleteProduct(plato.id);
            setPlatos(ps => ps.filter(p => p.id !== plato.id));
            const msg = resp?.message || 'Producto eliminado';
            Swal.fire({ icon: 'success', title: msg, timer: 1400, showConfirmButton: false });
        } catch (er) {
            const backendMsg = er?.response?.data?.error || 'No se pudo eliminar';
            if (er?.response?.status === 409) {
                Swal.fire({ icon: 'warning', title: 'No permitido', text: backendMsg });
            } else {
                Swal.fire({ icon: 'error', title: 'Error', text: backendMsg });
            }
        }
    }, []);

    // Lista de productos memoizada
    const memoizedProducts = useMemo(() => {
        return platos.map((plato) => (
            <ProductCard
                key={plato.id}
                plato={plato}
                formatPrice={formatPrice}
                onToggleActive={handleToggleActive}
                onOpenAdiciones={handleOpenAdiciones}
                onEdit={handleEdit}
                onDelete={handleDelete}
            />
        ));
    }, [platos, formatPrice, handleToggleActive, handleOpenAdiciones, handleEdit, handleDelete]);
    const dropRef = useRef(null);
    // Categorías
    const [categories, setCategories] = useState([]);
    const [loadingCategories, setLoadingCategories] = useState(false);
    const [categoriesError, setCategoriesError] = useState(null);
    // Modal categoría
    const [isCatModalOpen, setIsCatModalOpen] = useState(false);
    const [newCatName, setNewCatName] = useState('');
    const [newCatBusiness, setNewCatBusiness] = useState('');
    const [newCatType, setNewCatType] = useState('PRODUCTO'); // Nuevo campo para tipo
    const [savingCat, setSavingCat] = useState(false);


    const onFileSelected = (file) => {
        if (!file) return;
        if (!file.type.startsWith('image/')) { Swal.fire({ icon: 'warning', title: 'Formato inválido', text: 'El archivo debe ser una imagen' }); return; }
        if (file.size > 2 * 1024 * 1024) { Swal.fire({ icon: 'warning', title: 'Imagen muy grande', text: 'La imagen no puede superar 2MB' }); return; }
        setNewDishImageFile(file);
        if (newDishImagePreview) URL.revokeObjectURL(newDishImagePreview);
        setNewDishImagePreview(URL.createObjectURL(file));
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropRef.current?.classList.remove(style.dragActive);
        const file = e.dataTransfer.files && e.dataTransfer.files[0];
        onFileSelected(file);
    };
    const handleDragOver = (e) => { e.preventDefault(); e.stopPropagation(); dropRef.current?.classList.add(style.dragActive); };
    const handleDragLeave = (e) => { e.preventDefault(); e.stopPropagation(); dropRef.current?.classList.remove(style.dragActive); };
    const [savingNew, setSavingNew] = useState(false);
    const [triedCreate, setTriedCreate] = useState(false);

    const openModalEdit = (plato) => {
        setSelectedDish({ ...plato });
        setIsModalOpenEdit(true);
        setTriedEdit(false);
    };

    const closeModalEdit = () => {
        setIsModalOpenEdit(false); // Cierra la modal
        setSelectedDish(null); // Limpia el plato seleccionado
    };

    //Agg nuevo producto

    const openModalNew = () => {
        setNewDish({ nombre: '', precio: '', descripcion: '', categoriaId: '' });
        if (newDishImagePreview) URL.revokeObjectURL(newDishImagePreview);
        setNewDishImageFile(null);
        setNewDishImagePreview(null);

        // Limpiar estados de adicciones
        setTieneAdicionesObligatorias(false);
        setCantidadAdicionesObligatorias(1);
        setCategoriaObligatoria('');

        setIsModalOpenNew(true);
        if (!categories.length) fetchCategories();
        if (!categoriasAdicciones.length) fetchCategoriasAdicciones();
        setTriedCreate(false);
    };

    const closeModalNew = () => {
        setIsModalOpenNew(false);
    }



    //Axios - Función optimizada
    const getAllProducts = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            let data;
            // IDs de negocio: Amekatiar = 1, Quererte = 2
            if (selectedBusiness === 'QUERERTE') {
                data = await ProductService.getQuererteProducts();
            } else if (selectedBusiness === 'AMEKATIAR') {
                data = await ProductService.getAmekatiarProducts();
            } else {
                data = await ProductService.getAllProducts();
            }
            setPlatos(data || []);
        } catch (er) {
            setError('No se pudieron traer los productos');
        } finally {
            setLoading(false);
        }
    }, [selectedBusiness]);


    const updateProduct = async (e) => {
        e.preventDefault();
        setTriedEdit(true);
        if (!selectedDish) return;
        const nombreOk = selectedDish.name?.trim().length > 0;
        const precioOk = selectedDish.price !== '' && !isNaN(selectedDish.price) && Number(selectedDish.price) > 0;
        if (!nombreOk || !precioOk) return;
        setSavingEdit(true);
        try {
            await ProductService.updateProduct(selectedDish.id, {
                name: selectedDish.name,
                price: Number(selectedDish.price),
                description: selectedDish.description
            });
            getAllProducts();
        } catch (er) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo actualizar el producto' });
        } finally {
            setSavingEdit(false);
        }
    };

    const createProduct = async (e) => {
        e.preventDefault();
        setTriedCreate(true);
        const nombreOk = newDish.nombre.trim().length > 0;
        const precioOk = newDish.precio !== '' && !isNaN(newDish.precio) && Number(newDish.precio) > 0;
        const categoriaOk = !!newDish.categoriaId;
        const imagenOk = !!newDishImageFile;
        const imagenTipoOk = imagenOk && newDishImageFile.type.startsWith('image/');
        const imagenPesoOk = imagenOk && newDishImageFile.size <= 2 * 1024 * 1024;

        // Validar adicciones obligatorias si están habilitadas
        const adicionesOk = !tieneAdicionesObligatorias || (tieneAdicionesObligatorias && categoriaObligatoria);

        if (!nombreOk || !precioOk || !categoriaOk || !imagenOk || !imagenTipoOk || !imagenPesoOk || !adicionesOk) return;
        setSavingNew(true);
        try {
            // Backend espera CreateProductDTO { name, price, description, idCategory, idCategoriaAdicionObligatoria?, cantidadAdicionesObligatorias? }
            const dto = {
                name: newDish.nombre.trim(),
                price: Number(newDish.precio),
                description: newDish.descripcion,
                idCategory: Number(newDish.categoriaId)
            };

            // Agregar campos de adicciones obligatorias si están configuradas
            if (tieneAdicionesObligatorias && categoriaObligatoria) {
                dto.idCategoriaObligatoria = Number(categoriaObligatoria);
                dto.cantidadAdicionesObligatorias = cantidadAdicionesObligatorias;
            }

            const formData = new FormData();
            formData.append('data', new Blob([JSON.stringify(dto)], { type: 'application/json' }));
            formData.append('imagen', newDishImageFile);
            await ProductService.createProduct(formData);
            closeModalNew();
            getAllProducts();
        } catch (er) {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo crear el producto' });
        } finally {
            setSavingNew(false);
        }
    }

    // Cargar productos
    useEffect(() => {
        // Cambiar fondo según el negocio seleccionado
        if (selectedBusiness === 'QUERERTE') {
            document.body.className = style.bgBodyCatalogosQuerete; // Fondo negro para Quererte
        } else {
            document.body.className = style.bgBodyCatalogosAdmin; // Fondo naranja para Amekatiar
        }

        getAllProducts();
        return () => { document.body.className = '' }
    }, [getAllProducts, selectedBusiness]);

    // Fetch categorías al montar si se desea precargar
    const fetchCategories = useCallback(async () => {
        setLoadingCategories(true);
        setCategoriesError(null);
        try {
            const data = await ProductService.getProductCategories();
            setCategories(data || []);
        } catch (er) {
            setCategoriesError('No se pudieron cargar categorías');
        } finally {
            setLoadingCategories(false);
        }
    }, []);

    useEffect(() => { fetchCategories(); }, [fetchCategories]);

    // Función para cargar categorías de adicciones
    const fetchCategoriasAdicciones = useCallback(async () => {
        setLoadingCategorias(true);
        try {
            const data = await ProductService.getAdicionCategories();
            // Filtrar solo las categorías que son incluidas (incluido = 1) para adicciones incluidas
            const categoriasObligatorias = data?.filter(categoria => categoria.incluido === 1) || [];
            setCategoriasAdicciones(categoriasObligatorias);
        } catch (error) {
            setCategoriasAdicciones([]); // Array vacío en caso de error
        } finally {
            setLoadingCategorias(false);
        }
    }, []);

    // Función para abrir modal de gestión de adicciones
    const openModalGestionAdiciones = async (producto) => {
        setSelectedProductForAdiciones(producto);
        setLoadingAdiciones(true);
        setIsModalGestionAdiccionesOpen(true);

        try {
            // Cargar todas las categorías de adicciones disponibles
            const todasLasCategorias = await ProductService.getAdicionCategories();

            // Obtener las categorías asignadas al producto desde el backend
            let categoriasAsignadasDelProducto = [];
            try {
                categoriasAsignadasDelProducto = await ProductService.getProductCategoriasAdiciones(producto.id);
            } catch (error) {
                categoriasAsignadasDelProducto = todasLasCategorias.filter(categoria =>
                    producto.categoriesIds && producto.categoriesIds.includes(categoria.id)
                );
            }

            // Si el producto tiene una categoría obligatoria, asegurarla en la lista de asignadas
            if (producto.idCategoriaObligatoria && producto.nombreCategoriaObligatoria) {
                const categoriaObligatoria = todasLasCategorias.find(c => c.id === producto.idCategoriaObligatoria);
                if (categoriaObligatoria) {
                    // Verificar si ya está en las asignadas
                    const yaEstaAsignada = categoriasAsignadasDelProducto.some(c => c.id === categoriaObligatoria.id);
                    if (!yaEstaAsignada) {
                        categoriasAsignadasDelProducto.push(categoriaObligatoria);
                    }
                }
            }

            // Filtrar las categorías disponibles (no asignadas)
            const idsAsignados = categoriasAsignadasDelProducto.map(c => c.id);
            const disponibles = todasLasCategorias.filter(categoria =>
                !idsAsignados.includes(categoria.id)
            );

            setCategoriasAsignadas(categoriasAsignadasDelProducto);
            setCategoriasDisponibles(disponibles);
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se pudieron cargar las categorías de adicciones'
            });
            setCategoriasAsignadas([]);
            setCategoriasDisponibles([]);
        } finally {
            setLoadingAdiciones(false);
        }
    };

    // Función para cerrar modal de gestión de adicciones
    const closeModalGestionAdiciones = () => {
        setIsModalGestionAdiccionesOpen(false);
        setSelectedProductForAdiciones(null);
        setCategoriasAsignadas([]);
        setCategoriasDisponibles([]);
    };

    // Función para asignar categoría de adición al producto
    const asignarCategoriaAdicion = async (categoriaId) => {
        if (!selectedProductForAdiciones) return;

        try {
            // Llamar al endpoint del backend para asignar la categoría al producto
            const response = await ProductService.asignarCategoriaAdicion(selectedProductForAdiciones.id, categoriaId);

            // Actualizar el estado del frontend
            const categoriaAsignada = categoriasDisponibles.find(c => c.id === categoriaId);
            if (categoriaAsignada) {
                setCategoriasAsignadas(prev => [...prev, categoriaAsignada]);
                setCategoriasDisponibles(prev => prev.filter(c => c.id !== categoriaId));

                // Actualizar el producto en la lista principal
                setPlatos(prevPlatos =>
                    prevPlatos.map(plato =>
                        plato.id === selectedProductForAdiciones.id
                            ? {
                                ...plato,
                                categoriesIds: [...(plato.categoriesIds || []), categoriaId]
                            }
                            : plato
                    )
                );

                // Actualizar el producto seleccionado para adicciones
                setSelectedProductForAdiciones(prev => ({
                    ...prev,
                    categoriesIds: [...(prev.categoriesIds || []), categoriaId]
                }));

                // Mostrar mensaje apropiado según la respuesta
                const messageType = response.info ? 'info' : 'success';
                const title = response.info ? 'Categoría preparada' : 'Categoría asignada';
                const text = response.info ?
                    `${response.info}` :
                    `La categoría "${categoriaAsignada.nombre}" ha sido asignada al producto`;

                Swal.fire({
                    icon: messageType,
                    title: title,
                    text: text,
                    timer: 3000,
                    showConfirmButton: false
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error?.response?.data?.message || 'No se pudo asignar la categoría'
            });
        }
    };

    // Función para quitar categoría de adición del producto
    const quitarCategoriaAdicion = async (categoriaId) => {
        if (!selectedProductForAdiciones) return;

        // Verificar si es la categoría obligatoria
        const categoriaAQuitar = categoriasAsignadas.find(c => c.id === categoriaId);
        if (selectedProductForAdiciones.idCategoriaObligatoria === categoriaId) {
            Swal.fire({
                icon: 'warning',
                title: 'No se puede quitar',
                text: 'Esta categoría es obligatoria y no puede ser removida'
            });
            return;
        }

        try {
            // Llamar al endpoint del backend para quitar la categoría del producto
            await ProductService.quitarCategoriaAdicion(selectedProductForAdiciones.id, categoriaId);

            // Actualizar el estado del frontend
            if (categoriaAQuitar) {
                setCategoriasDisponibles(prev => [...prev, categoriaAQuitar]);
                setCategoriasAsignadas(prev => prev.filter(c => c.id !== categoriaId));

                // Actualizar el producto en la lista principal
                setPlatos(prevPlatos =>
                    prevPlatos.map(plato =>
                        plato.id === selectedProductForAdiciones.id
                            ? {
                                ...plato,
                                categoriesIds: (plato.categoriesIds || []).filter(id => id !== categoriaId)
                            }
                            : plato
                    )
                );

                // Actualizar el producto seleccionado para adicciones
                setSelectedProductForAdiciones(prev => ({
                    ...prev,
                    categoriesIds: (prev.categoriesIds || []).filter(id => id !== categoriaId)
                }));

                Swal.fire({
                    icon: 'success',
                    title: 'Categoría removida',
                    text: `La categoría "${categoriaAQuitar.nombre}" ha sido removida del producto`,
                    timer: 2000,
                    showConfirmButton: false
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error?.response?.data?.message || 'No se pudo quitar la categoría'
            });
        }
    };

    return (
        <div className={style.mainDish}>

            <div className={style.businessSelector}>
                <select
                    id="business-selector"
                    name="selectedBusiness"
                    className={style.businessSelect}
                    value={selectedBusiness}
                    onChange={(e) => setSelectedBusiness(e.target.value)}
                >
                    <option value="AMEKATIAR">Amekatiar</option>
                    <option value="QUERERTE">Quererte</option>
                </select>
            </div>

            <div onClick={openModalNew} className={style.agg_dish}>Nuevo producto</div>
            {loading && <p>Cargando productos...</p>}
            {error && <p style={{ color: 'tomato' }}>{error}</p>}
            {!loading && !error && (
                <div className={style.productsGrid}>
                    {memoizedProducts}
                </div>
            )}

            {/* Modal EDIT PRODUCT*/}
            {isModalOpenEdit && selectedDish && (
                <div className={style.modal}>
                    <div className={style.modalContent}>
                        <form className={style.form_modal_edit} onSubmit={updateProduct}>

                            <h2>{selectedDish.name}</h2>

                            <label className={style.label_edit}>
                                <span>Nombre</span>
                                <input
                                    className={`${style.input_edit} ${triedEdit && !selectedDish.name.trim() ? style.input_error : ''}`}
                                    name="nombre"
                                    value={selectedDish.name}
                                    onChange={(e) =>
                                        setSelectedDish({ ...selectedDish, name: e.target.value })}
                                />
                            </label>

                            <label className={style.label_edit}>
                                <span>Precio</span>
                                <input
                                    className={`${style.input_edit} ${triedEdit && (selectedDish.price === '' || Number(selectedDish.price) <= 0) ? style.input_error : ''}`}
                                    type="text"
                                    name="precio"
                                    value={selectedDish.price ? formatPrice(selectedDish.price) : ''}
                                    onChange={(e) => {
                                        const v = e.target.value.replace(/[^0-9]/g, '');
                                        setSelectedDish({ ...selectedDish, price: v });
                                    }}
                                />
                            </label>
                            {triedEdit && (!selectedDish.name.trim() || selectedDish.price === '' || Number(selectedDish.price) <= 0) && (
                                <div className={style.field_error}>No se pudo actualizar. Revisa los campos en rojo.</div>
                            )}

                            <label className={style.label_edit}>
                                <span>Descripción</span>
                                <textarea
                                    className={`${style.input_edit}`}
                                    name="descripcion"
                                    rows={3}
                                    value={selectedDish.description || ''}
                                    onChange={(e) => setSelectedDish({ ...selectedDish, description: e.target.value })}
                                />
                            </label>

                            <div>
                                <button className={style.btn_modal} type="submit" disabled={savingEdit}>{savingEdit ? 'Guardando...' : 'Guardar'}</button>
                                <button type="button" className={style.btn_modal} onClick={closeModalEdit}>Cerrar</button>

                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal AGG PRODUCTO */}
            {isModalOpenNew && (
                <div className={style.modal}>
                    <div className={style.modalContent}>
                        <form className={style.form_modal_edit} onSubmit={createProduct}>

                            <h2>Agregar Nuevo producto</h2>

                            <label className={style.label_edit}>
                                <span>Nombre</span>
                                <input
                                    className={`${style.input_edit} ${triedCreate && !newDish.nombre.trim() ? style.input_error : ''}`}
                                    type="text"
                                    name="nombre"
                                    value={newDish.nombre}
                                    onChange={(e) => setNewDish(d => ({ ...d, nombre: e.target.value }))}
                                />
                            </label>

                            <label className={style.label_edit}>
                                <span>Precio</span>
                                <input
                                    className={`${style.input_edit} ${triedCreate && (newDish.precio === '' || Number(newDish.precio) <= 0) ? style.input_error : ''}`}
                                    type="text"
                                    name="precio"
                                    value={newDish.precio ? formatPrice(newDish.precio) : ''}
                                    onChange={(e) => {
                                        const v = e.target.value.replace(/[^0-9]/g, '');
                                        setNewDish(d => ({ ...d, precio: v }));
                                    }}
                                />
                            </label>

                            <div className={style.inlineCategoryRow}>
                                <label className={style.label_edit} style={{ flex: 1 }}>
                                    <span>Categoría</span>
                                    <select
                                        id="categoria-select"
                                        name="categoriaId"
                                        className={`${style.input_edit} ${style.categorySelect} ${triedCreate && !newDish.categoriaId ? style.input_error : ''}`}
                                        value={newDish.categoriaId}
                                        onChange={(e) => setNewDish(d => ({ ...d, categoriaId: e.target.value }))}
                                    >
                                        <option value="">-- Selecciona --</option>
                                        {categories.map(cat => (
                                            <option key={cat.id} value={cat.id}>
                                                {cat.nombre || `Categoría ${cat.id}`}
                                            </option>
                                        ))}
                                    </select>
                                    {loadingCategories && <span style={{ fontSize: '12px', opacity: .7 }}>Cargando...</span>}
                                    {categoriesError && <span style={{ fontSize: '12px', color: 'tomato' }}>{categoriesError}</span>}
                                </label>
                                <button
                                    type="button"
                                    className={style.btn_add_category_inline}
                                    aria-label="Agregar categoría"
                                    title="Agregar categoría"
                                    onClick={() => { setNewCatName(''); setNewCatBusiness(''); setNewCatType('PRODUCTO'); setIsCatModalOpen(true); }}
                                >+</button>
                            </div>

                            <label className={style.label_edit}>
                                <span>Descripción</span>
                                <textarea
                                    className={style.input_edit}
                                    name="descripcion"
                                    rows={3}
                                    value={newDish.descripcion}
                                    onChange={(e) => setNewDish(d => ({ ...d, descripcion: e.target.value }))}
                                />
                            </label>

                            {/* Sección de Adicciones Incluidas */}
                            <div className={style.adicionesSection}>
                                <h4 className={style.adicionesTitle}>Adiciones Incluidas</h4>

                                <div className={style.adicionesCheckbox}>
                                    <label>
                                        <input
                                            type="checkbox"
                                            checked={tieneAdicionesObligatorias}
                                            onChange={(e) => {
                                                setTieneAdicionesObligatorias(e.target.checked);
                                                if (!e.target.checked) {
                                                    setCantidadAdicionesObligatorias(1);
                                                    setCategoriaObligatoria('');
                                                }
                                            }}
                                        />
                                        <strong>Este producto tiene adiciones incluidas</strong>
                                    </label>
                                </div>

                                {tieneAdicionesObligatorias && (
                                    <div className={style.adicionesConfig}>
                                        <div className={style.configVertical}>
                                            <label className={style.configLabel}>
                                                <span>Cantidad de adiciones incluidas:</span>
                                                <select
                                                    id="cantidad-adicciones-select"
                                                    name="cantidadAdicciones"
                                                    value={cantidadAdicionesObligatorias}
                                                    onChange={(e) => setCantidadAdicionesObligatorias(parseInt(e.target.value))}
                                                    className={style.configSelect}
                                                >
                                                    <option value={1}>1 adición</option>
                                                    <option value={2}>2 adiciones</option>
                                                    <option value={3}>3 adiciones</option>
                                                    <option value={4}>4 adiciones</option>
                                                    <option value={5}>5 adiciones</option>
                                                </select>
                                            </label>

                                            <label className={style.configLabel}>
                                                <span>Categoría de la cual seleccionar:</span>
                                                <select
                                                    id="categoria-obligatoria-select"
                                                    name="categoriaObligatoria"
                                                    value={categoriaObligatoria}
                                                    onChange={(e) => setCategoriaObligatoria(e.target.value)}
                                                    className={`${style.configSelect} ${style.categorySelect} ${triedCreate && tieneAdicionesObligatorias && !categoriaObligatoria ? style.input_error : ''}`}
                                                >
                                                    <option value="">-- Seleccionar categoría --</option>
                                                    {loadingCategorias ? (
                                                        <option disabled>Cargando...</option>
                                                    ) : (
                                                        categoriasAdicciones.map(categoria => (
                                                            <option key={categoria.id} value={categoria.id}>
                                                                {categoria.nombre}
                                                            </option>
                                                        ))
                                                    )}
                                                </select>
                                            </label>
                                        </div>

                                        {categoriaObligatoria && (
                                            <div className={style.adicionesPreview}>
                                                <div className={style.previewCard}>
                                                    <h5 className={style.previewTitle}>Configuración establecida:</h5>
                                                    <p className={style.previewText}>
                                                        Para este producto los clientes deberán seleccionar{' '}
                                                        <strong className={style.cantidadDestacada}>
                                                            {cantidadAdicionesObligatorias}
                                                        </strong>{' '}
                                                        {cantidadAdicionesObligatorias === 1 ? 'adición' : 'adiciones'} de la categoría{' '}
                                                        <strong className={style.categoriaDestacada}>
                                                            {categoriasAdicciones.find(c => c.id == categoriaObligatoria)?.nombre}
                                                        </strong>
                                                        {' '}<span className={style.incluidaText}>(incluidas sin costo)</span>
                                                    </p>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>

                            <div
                                ref={dropRef}
                                className={`${style.dropZone} ${triedCreate && !newDishImageFile ? style.input_error : ''}`}
                                onDrop={handleDrop}
                                onDragOver={handleDragOver}
                                onDragLeave={handleDragLeave}
                                onClick={() => document.getElementById('fileNewDish')?.click()}
                                role="button"
                                tabIndex={0}
                                aria-label="Zona para subir imagen del producto"
                            >
                                <strong>{newDishImageFile ? 'Cambiar imagen' : 'Sube o arrastra una imagen'}</strong>
                                <span style={{ display: 'block', fontSize: '.75rem', opacity: .7 }}>PNG, JPG, WEBP (max 2MB)</span>
                                <input
                                    id='fileNewDish'
                                    type='file'
                                    accept='image/*'
                                    onChange={(e) => onFileSelected(e.target.files && e.target.files[0])}
                                />
                                {newDishImagePreview && <img className={style.previewImage} src={newDishImagePreview} alt='Vista previa' />}
                            </div>
                            {triedCreate && (
                                (!newDish.nombre.trim() || newDish.precio === '' || Number(newDish.precio) <= 0 || !newDish.categoriaId || !newDishImageFile || (tieneAdicionesObligatorias && !categoriaObligatoria)) &&
                                <div className={style.field_error}>No se pudo agregar. Revisa los campos en rojo.</div>
                            )}

                            <div>
                                <button className={style.btn_modal} type="submit" disabled={savingNew}>{savingNew ? 'Guardando...' : 'Guardar'}</button>
                                <button type="button" className={style.btn_modal} onClick={closeModalNew}>Cerrar</button>

                            </div>
                        </form>
                    </div>
                </div>
            )}
            {isCatModalOpen && (
                <div className={style.modal}>
                    <div className={`${style.modalContent} ${style.modalSmall}`}>
                        <form onSubmit={async (e) => {
                            e.preventDefault();
                            if (!newCatName.trim() || !newCatBusiness || !newCatType) {
                                Swal.fire({ icon: 'warning', title: 'Completa los campos' });
                                return;
                            }
                            setSavingCat(true);
                            try {
                                // Backend espera CategoryCreateDTO: { nombre, tipo, idNegocio }
                                let businessId;
                                if (newCatBusiness === 'AMEKATIAR') {
                                    businessId = 1; // Amekatiar = 1
                                } else if (newCatBusiness === 'QUERERTE') {
                                    businessId = 2; // Quererte = 2
                                }

                                const payload = {
                                    nombre: newCatName.trim(),
                                    tipo: newCatType,
                                    idNegocio: businessId
                                };

                                const created = await ProductService.createCategory(payload);
                                Swal.fire({ icon: 'success', title: 'Categoría creada', timer: 1200, showConfirmButton: false });
                                setIsCatModalOpen(false);

                                // Actualizar las listas correspondientes
                                if (newCatType === 'PRODUCTO') {
                                    setCategories(prev => {
                                        if (!created) return prev;
                                        const exists = prev.some(c => c.id === created.id);
                                        const list = exists ? prev : [...prev, created];
                                        return list;
                                    });
                                    if (created?.id) {
                                        setNewDish(d => ({ ...d, categoriaId: created.id.toString() }));
                                    }
                                } else if (newCatType === 'ADICION') {
                                    setCategoriasAdicciones(prev => {
                                        if (!created) return prev;
                                        const exists = prev.some(c => c.id === created.id);
                                        return exists ? prev : [...prev, created];
                                    });
                                }
                            } catch (err) {
                                const errorMessage = err?.response?.data || 'No se pudo crear la categoría';
                                Swal.fire({ icon: 'error', title: 'Error', text: errorMessage });
                            } finally { setSavingCat(false); }
                        }} className={style.form_modal_edit}>
                            <h3>Nueva Categoría</h3>

                            <p className={style.warningCategory}>⚠️Una vez creada la categoría no podrá eliminarse ni modificarse. Por favor verifique la información antes de confirmar el registro.</p>

                            <label className={style.label_edit}>
                                <span>Nombre</span>
                                <input className={style.input_edit} value={newCatName} onChange={e => setNewCatName(e.target.value)} />
                            </label>

                            <label className={style.label_edit}>
                                <span>Negocio</span>
                                <select
                                    id="negocio-categoria-select"
                                    name="negocioCategoria"
                                    className={style.input_edit}
                                    value={newCatBusiness}
                                    onChange={e => setNewCatBusiness(e.target.value)}
                                >
                                    <option value="">-- Selecciona --</option>
                                    <option value="AMEKATIAR">Amekatiar</option>
                                    <option value="QUERERTE">Quererte</option>
                                </select>
                            </label>
                            <div>
                                <button type="submit" className={style.btn_modal} disabled={savingCat}>{savingCat ? 'Guardando...' : 'Guardar'}</button>
                                <button type="button" className={style.btn_modal} onClick={() => setIsCatModalOpen(false)}>Cerrar</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal GESTIÓN DE ADICCIONES */}
            {isModalGestionAdiccionesOpen && selectedProductForAdiciones && (
                <div className={style.modal}>
                    <div className={`${style.modalContent} ${style.modalLarge}`}>
                        <div className={style.modalAdicionesContainer}>
                            <div className={style.modalAdicionesHeader}>
                                    <h2 className={style.modalAdicionesTitle}>
                                        Gestionar Adiciones - {selectedProductForAdiciones.name}
                                    </h2>
                                <button
                                    type="button"
                                    className={style.btn_close_modal}
                                    onClick={closeModalGestionAdiciones}
                                    aria-label="Cerrar modal"
                                >
                                    ✕
                                </button>
                            </div>

                            {loadingAdiciones ? (
                                <div className={style.loadingAdiciones}>
                                    <p>Cargando categorías de adiciones...</p>
                                </div>
                            ) : (
                                <div className={style.adicionesContent}>
                                    {/* Información del producto */}
                                    <div className={style.productInfo}>
                                        <div className={style.productImage}>
                                            <img
                                                src={selectedProductForAdiciones.urlImage}
                                                alt={selectedProductForAdiciones.name}
                                                className={style.productThumb}
                                            />
                                        </div>
                                        <div className={style.productDetails}>
                                            <h3>{selectedProductForAdiciones.name}</h3>
                                            <p className={style.productPrice}>${formatPrice(selectedProductForAdiciones.price)} COP</p>
                                            <p className={style.productDescription}>{selectedProductForAdiciones.description}</p>

                                        </div>
                                    </div>

                                    <div className={style.adicionesManagement}>
                                        {/* Sección de categorías asignadas */}
                                        <div className={style.categoriasAsignadas}>
                                            <h4 className={style.sectionTitle}>
                                                Categorías de Adiciones Asignadas
                                                <span className={style.counter}>({categoriasAsignadas.length})</span>
                                            </h4>

                                            {categoriasAsignadas.length === 0 ? (
                                                <div className={style.emptyState}>
                                                    <p>No hay categorías de adiciones asignadas a este producto</p>
                                                    <small>Selecciona categorías de la lista disponible para asignarlas</small>
                                                </div>
                                            ) : (
                                                <div className={style.categoriasList}>
                                                    {categoriasAsignadas.map(categoria => (
                                                        <div key={categoria.id} className={style.categoriaCard}>
                                                            <div className={style.categoriaInfo}>
                                                                <h5 className={style.categoriaNombre}>{categoria.nombre}</h5>
                                                                <div className={style.categoriaDetails}>
                                                                    <span className={`${style.categoriaType} ${categoria.incluido === 1 ? style.incluida : style.noIncluida}`}>
                                                                        {categoria.incluido === 1 ? 'Incluida' : '$ Con costo adicional'}
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div className={style.categoriaActions}>
                                                                {/* Verificar si es la categoría obligatoria */}
                                                                {selectedProductForAdiciones.idCategoriaObligatoria === categoria.id ? (
                                                                    <span className={style.obligatoriaTag}>
                                                                        Incluida
                                                                    </span>
                                                                ) : (
                                                                    <button
                                                                        className={style.btn_quitar_categoria}
                                                                        onClick={() => quitarCategoriaAdicion(categoria.id)}
                                                                        title="Quitar categoría"
                                                                    >
                                                                        Quitar
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>

                                        {/* Separador */}
                                        <div className={style.divider}></div>

                                        {/* Sección de categorías disponibles */}
                                        <div className={style.categoriasDisponibles}>
                                            <h4 className={style.sectionTitle}>
                                                Categorías Disponibles para Asignar
                                                <span className={style.counter}>({categoriasDisponibles.length})</span>
                                            </h4>

                                            {categoriasDisponibles.length === 0 ? (
                                                <div className={style.emptyState}>
                                                    <p>Todas las categorías están asignadas o no hay categorías disponibles</p>
                                                    <small>Puedes crear nuevas categorías desde el formulario de productos</small>
                                                </div>
                                            ) : (
                                                <div className={style.categoriasList}>
                                                    {categoriasDisponibles.map(categoria => (
                                                        <div key={categoria.id} className={style.categoriaCard}>
                                                            <div className={style.categoriaInfo}>
                                                                <h5 className={style.categoriaNombre}>{categoria.nombre}</h5>
                                                                <div className={style.categoriaDetails}>
                                                                    <span className={`${style.categoriaType} ${categoria.incluido === 1 ? style.incluida : style.noIncluida}`}>
                                                                        {categoria.incluido === 1 ? '✓ Incluida' : '$ Con costo adicional'}
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div className={style.categoriaActions}>
                                                                <button
                                                                    className={style.btn_asignar_categoria}
                                                                    onClick={() => asignarCategoriaAdicion(categoria.id)}
                                                                    title="Asignar categoría"
                                                                >
                                                                    Asignar
                                                                </button>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    {/* Acciones del modal */}
                                    <div className={style.modalAdicionesFooter}>
                                        <div className={style.adicionesInfo}>
                                            <p>
                                                <strong>Total categorías asignadas:</strong> {categoriasAsignadas.length}
                                            </p>
                                        </div>
                                        <button
                                            type="button"
                                            className={style.btn_modal}
                                            onClick={closeModalGestionAdiciones}
                                        >
                                            Cerrar
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// Exportar componente optimizado con memo
export default memo(Catalogos);
