import React from 'react';
import { useEffect } from 'react';

import { LayoutHeaderFooter } from '../../Layouts/User/LayoutHeaderFooter';
import { HomeAmekatiar as Home } from '../../Components/User/HomeAmekatiar';
import "../../assets/Styles/Amekatiar/User/global-amekatiar.module.css";

export const HomeAmekatiar = () => {
    useEffect(() => {
    document.body.className = 'bg-amekatiar'
    return () => {
      document.body.className = ''
    }
  })



  return (
    <LayoutHeaderFooter>
        <Home/>
    </LayoutHeaderFooter>
  );
};