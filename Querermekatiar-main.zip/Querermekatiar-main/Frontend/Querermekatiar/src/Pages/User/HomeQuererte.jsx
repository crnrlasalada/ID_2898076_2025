import React from 'react';
import { useEffect } from 'react';

import { LayoutHeaderFooter } from '../../Layouts/User/LayoutHeaderFooter.jsx';
import { HomeQuererte as Home } from '../../Components/User/HomeQuererte.jsx';
import '../../assets/Styles/Quererte/User/global-quererte.module.css'

export const HomeQuererte = () => {
  console.log('HomeQuererte montado');
    useEffect(() => {
    document.body.className = 'bg-quererte'
    return () => {
      document.body.className = ''
    }
  })
  return (
    <LayoutHeaderFooter>
        <Home/>
    </LayoutHeaderFooter>
  );
};