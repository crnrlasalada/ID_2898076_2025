import React from 'react';
import { useEffect } from 'react';

import { OrderHistory as History } from '../../Components/User/OrderHistory';
import '../../assets/Styles/bg.css'
import { LayoutWithAsidebar } from '../../Layouts/User/LayoutWithAsidebar';

export const OrderHistory = () => {

  useEffect(() => {
    document.body.className = 'bg'
    return () => {
      document.body.className = ''
    }
  })
  return (
    <LayoutWithAsidebar>
        <History/>
    </LayoutWithAsidebar> 
  );
};