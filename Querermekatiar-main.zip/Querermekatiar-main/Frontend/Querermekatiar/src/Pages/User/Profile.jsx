import React from 'react';
import { useEffect } from 'react';
import { ProfileInfo } from '../../Components/User/ProfileInfo';
import "../../assets/Styles/Quererte/User/global-quererte.css";
import '../../assets/Styles/bg.css'
import { LayoutWithAsidebar } from '../../Layouts/User/LayoutWithAsidebar';
export const Profile = () => {
    useEffect(() => {
      document.body.className = 'bg'
      return () => {
        document.body.className = ''
      }
    })
  return (
    <LayoutWithAsidebar>
        <ProfileInfo/>
    </LayoutWithAsidebar>
  );
};