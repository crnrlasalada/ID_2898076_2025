import { useState,  } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from 'sweetalert2'
import { FaHome } from "react-icons/fa";

import quererteImage from "../assets/images/Quererte/User/Logo_quererte.webp";
import amekatiarImage from "../assets/images//Amekatiar/User/amekatiar-logo.webp";
import style from "../assets/styles/singup.module.css";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { GoogleButton } from "../Components/User/GoogleButton";

export const Singup = () => {
  // Estados primero (para poder usar 'password' después)
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [triedSubmit, setTriedSubmit] = useState(false);

  const navigate = useNavigate();
  const hasMinLength = password.length >= 8;
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /\d/.test(password);
  const passwordValid = hasMinLength && hasUppercase && hasLowercase && hasNumber;


  const singup = async (e) => {
    e.preventDefault();
    setTriedSubmit(true);

    const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    const emailValid = emailRegex.test(correo);
    const confirmValid = confirmPassword === password && confirmPassword.length > 0;

    // si faltan condiciones no disparamos SweetAlert, solo bloqueamos
    if (!emailValid || !passwordValid || !confirmValid || !acceptedTerms) return;

    try {
      const response = await axios.post("http://localhost:8080/api/auth/signup/user", {
        correo: correo.toLowerCase().trim(),
        password
      });

      console.log(response);

      Swal.fire({
        icon: "success",
        title: "Registro exitoso",
        html: `<p style='margin:6px 0 0;'>Hemos enviado un correo a <strong>${correo}</strong> con un enlace de verificación.</p>
               <p style='margin:8px 0 0;'>Debes verificar tu cuenta para poder iniciar sesión.</p>
               <p style='margin:8px 0 0; font-size:13px; opacity:.85;'>Si no lo ves, revisa la carpeta de spam o promociones.</p>`,
        confirmButtonText: 'Entendido'
      });
      setCorreo("");
      setPassword("");
      setconfirmPassword("");
      setAcceptedTerms(false);
      setTriedSubmit(false);
    } catch (error) {
      if (error.response) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: error.response.data
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Error en conexión",
          text: error.message
        });
      }
    }
  };

  return (
    <main role="main">
      <section aria-label="visual background">
        <div className={style["background-left-black"]} aria-hidden="true">
          <img className={`${style["store-logo"]} ${style.quererte}`} src={quererteImage} alt="Quererte logo" />
        </div>
        <div className={style["background-right-yellow"]} aria-hidden="true">
          <img className={`${style["store-logo"]} ${style.mekatiar}`} src={amekatiarImage} alt="Amekatiar logo" />
        </div>
      </section>

      <section className={style["circles-container"]} aria-label="Decorative circles">
        <div className={`${style.circle} ${style["circle-yellow"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-black"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-yellow"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-black"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-yellow"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-black"]}`} aria-hidden="true"></div>
      </section>

      <button
        type="button"
        aria-label="Inicio"
        onClick={() => navigate("/")}
        style={{ position: 'absolute', top: 24, left: 24, background: '#F0B617', color: '#23272f', border: 'none', padding: '10px 20px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', zIndex: 10, display: 'flex', alignItems: 'center', gap: 6 }}
      >
        <FaHome size={22} />
      </button>

      <section className={style["log-in-container"]}>
        <form onSubmit={singup}>
          <input
            className={`${style["user-date"]} ${triedSubmit && (!correo || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(correo)) ? style.input_error : ''}`}
            type="email"
            placeholder="Ingrese su correo"
            value={correo}
            onChange={(e) => setCorreo(e.target.value.toLowerCase().trim())}
            required
            autoComplete="email"
          />
          {triedSubmit && !correo && <div className={style.field_error}>El correo es obligatorio.</div>}
          {triedSubmit && correo && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(correo) && <div className={style.field_error}>Formato de correo inválido.</div>}

          <div className={style["password-container"]} style={{ position: "relative" }}>
            <input
              className={`${style["user-date"]} ${triedSubmit && (!passwordValid || password.length === 0) ? style.input_error : ''}`}
              type={showPassword ? "text" : "password"}
              placeholder="Ingrese una contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8}
              style={{ paddingRight: "40px" }}
            />
            <button
              type="button"
              className={style["show-password-btn"]}
              onClick={() => setShowPassword((prev) => !prev)}
              aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
              tabIndex={-1}
              style={{ position: "absolute", right: "14px", top: 0, height: "100%", display: "flex", alignItems: "center", background: "none", border: "none", cursor: "pointer", padding: 0, zIndex: 2 }}
            >
              {showPassword ? (
                <FaEyeSlash className={style["eye-icon"]} />
              ) : (
                <FaEye className={style["eye-icon"]} />
              )}
            </button>
          </div>

          {password.length > 0 && (
            <div className={style.password_rules_box}>
              <ul className={style.password_rules}>
                <li className={hasMinLength ? style.rule_ok : style.rule_error}>Mínimo 8 caracteres</li>
                <li className={hasUppercase ? style.rule_ok : style.rule_error}>Al menos una mayúscula</li>
                <li className={hasLowercase ? style.rule_ok : style.rule_error}>Al menos una minúscula</li>
                <li className={hasNumber ? style.rule_ok : style.rule_error}>Al menos un número</li>
              </ul>
            </div>
          )}
          {triedSubmit && password.length === 0 && <div className={style.field_error}>La contraseña es obligatoria.</div>}
          {triedSubmit && password.length > 0 && !passwordValid && <div className={style.field_error}>La contraseña no cumple los requisitos.</div>}

          <input
            className={`${style["user-date"]} ${triedSubmit && (confirmPassword.length === 0 || confirmPassword !== password) ? style.input_error : ''}`}
            type="password"
            placeholder="Ingrese nuevamente su contraseña"
            value={confirmPassword}
            onChange={(e) => setconfirmPassword(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
          />
          {triedSubmit && confirmPassword.length === 0 && <div className={style.field_error}>Debes confirmar la contraseña.</div>}
          {triedSubmit && confirmPassword.length > 0 && confirmPassword !== password && <div className={style.field_error}>Las contraseñas no coinciden.</div>}

          <div style={{ display: "flex", alignItems: "center", margin: "12px 0 18px 0" }}>
            <input
              type="checkbox"
              id="terms"
              checked={acceptedTerms}
              onChange={(e) => setAcceptedTerms(e.target.checked)}
              required
            />
            <label htmlFor="terms" style={{ color: "white", fontSize: "16px", marginLeft: "8px" }}>
              <span>
                Acepto los <a href="/terminos" target="_blank" rel="noopener noreferrer" style={{ color: "white", textDecoration: "underline", fontSize: "inherit", borderBottom: "1px solid #fff", paddingBottom: "1px" }}>términos y condiciones</a>
              </span>
            </label>
          </div>
          {triedSubmit && !acceptedTerms && <div className={style.field_error}>Debes aceptar los términos y condiciones.</div>}

          <button type="submit" className={style["register-btn"]} disabled={false}>
            Registrarme
          </button>
        </form>

        <hr />

        <GoogleButton />

        <p className={style["text-terms-conditions"]}>
          Al registrarte, aceptas nuestras condiciones de uso y nuestra política de privacidad
        </p>

        <p className={style["login-text"]}>
          ¿Ya tienes cuenta?{" "}
          <Link className={style["login-link"]} to="/login">
            Inicia sesión
          </Link>
        </p>
      </section>
    </main>
  );
};
