import { useNavigate } from 'react-router-dom';
import amekatiarLogo from "../assets/images//Amekatiar/User/amekatiar-logo.webp"
import amekatiarImagen from "../assets/images/amekatiar-imagen.webp";
import quereteImagen from "../assets/images/quererte-imagen.webp";
import quererteLogo from "../assets/images/Quererte/User/Logo_quererte.webp"
import style from "../assets/Styles/selectorHome.module.css"




export const SelectorHome = () => {
  const navigate = useNavigate()


  return (
    <main>
      <section aria-label="visual background">
        <div className={style["background-left-black"]} aria-hidden="true">
          <img
            className={style["store-logo-quererte"]}
            src= {quererteLogo}
            alt="logo quererte"
          />

          <img
            className={style["quererte-photo"]}
            src= {quereteImagen}
            alt="imagen amekatiar"
          />

          <p className={style["store-description-quererte"]}>
            ¡Bienvenidos a Heladería Quererte! Descubre una experiencia única
            con nuestros helados artesanales, elaborados con ingredientes
            frescos y de alta calidad. Cada sabor está cuidadosamente creado
            para brindarte momentos de pura felicidad. Visítanos y déjate
            sorprender por nuestras deliciosas creaciones.
          </p>

          <button onClick={() => navigate('/usuario/home-quererte')}>Visítanos</button>
        </div>

        <div className={style["background-right-yellow"]} aria-hidden="true">
          <img
            className={style["store-logo-amekatiar"]}
            src= {amekatiarLogo}
            alt="Logo amekatiar"
          />

          <img
            className={style["amekatiar-photo"]}
            src= {amekatiarImagen}
            alt="foto amekatiar"
          />

          <p className={style["store-description-amekatiar"]}>
            ¡Bienvenidos a Amekatiar! Donde la rapidez de la comida rápida se
            fusiona con la calidad de la cocina tradicional. Disfruta de una
            amplia variedad de platos que satisfacen todos los gustos, desde
            opciones rápidas hasta recetas clásicas. En Amekatiar, cada comida
            es una experiencia única que te invita a volver.
          </p>
          

          <button onClick={() => navigate('/usuario/home-amekatiar')}>Visítanos</button>

        </div>
      </section>

      <section className={style["circles-container"]} aria-label="Decorative circles">
        <div className={`${style.circle} ${style["circle-yellow"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-black"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-yellow"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-black"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-yellow"]}`} aria-hidden="true"></div>
        <div className={`${style.circle} ${style["circle-black"]}`} aria-hidden="true"></div>
      </section>


    </main>
  );
};
