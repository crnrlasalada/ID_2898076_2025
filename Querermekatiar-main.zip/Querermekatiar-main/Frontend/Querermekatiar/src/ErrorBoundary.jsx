import React from "react";
import NotFound from "./Components/ui/NotFound";

const ErrorBoundary = () => <NotFound />;

export default ErrorBoundary;
