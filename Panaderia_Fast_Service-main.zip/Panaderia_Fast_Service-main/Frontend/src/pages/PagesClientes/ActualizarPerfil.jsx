import React from "react";
import PerfilInformacion from "../../components/PerfilInformacion";

export default function ActualizarPerfilUsuario() {
    return (
        <>
            <PerfilInformacion></PerfilInformacion>
        </>
    )
}