// src/pages/categorias/CategoriaPanes.jsx

import React from "react";
import ComponenteProductos from "../../components/ComponenteCategorias";

export default function CategoriaMecato() {
    return (
        <>
            <ComponenteProductos nombreCategoria="mecato" />
        </>
    );
}

