import { MostrarInformacion } from "../../components/PerfilInformacion"


export default function PerfilUsario(){
    return (
        <MostrarInformacion></MostrarInformacion>
    )
}