import PerfilInformacion from "../../components/PerfilInformacion";
import { MostrarInformacion } from "../../components/PerfilInformacion";

import React from 'react'

const EditarPerfil = () => {
  return (
    <div>
      <MostrarInformacion></MostrarInformacion>
    </div>
  )
}
export default EditarPerfil

