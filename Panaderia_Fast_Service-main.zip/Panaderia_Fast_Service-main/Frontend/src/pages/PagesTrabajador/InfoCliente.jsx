import React from 'react'
import PerfilUsuarioTrabajador from '../../components/PerfilUsuarioTrabajador'


export default function PerfilUsario(){
    return (
        <>
        <PerfilUsuarioTrabajador></PerfilUsuarioTrabajador>
        </>

    )
}
