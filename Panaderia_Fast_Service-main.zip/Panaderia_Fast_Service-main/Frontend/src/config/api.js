// src/config/api.js
const API_URL = "https://panaderia-fast-service.onrender.com";

export default API_URL;
