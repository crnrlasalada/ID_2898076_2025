import "../assets/styles/Experiencia.css"


export default function CalificacionInformacion({texto}){
    return (
        <div className="recuadro-informacion-2">
            <h4 className="estilo-titulo">{texto}</h4>
        </div>
    )
}
