
import React from "react";
import "../assets/styles/EtiquetaPago.css"

const EtiquetaPago = ({ texto }) => {
    return <span className="etiqueta-pago">{texto}</span>;
};

export default EtiquetaPago;