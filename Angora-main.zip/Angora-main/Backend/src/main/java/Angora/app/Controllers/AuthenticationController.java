package Angora.app.Controllers;

import Angora.app.Controllers.dto.AuthCreateUserRequest;
import Angora.app.Controllers.dto.AuthLoginRequest;
import Angora.app.Controllers.dto.AuthResponse;
import Angora.app.Controllers.dto.RefreshTokenRequest;
import Angora.app.Entities.RefreshToken;
import Angora.app.Entities.Usuario;
import Angora.app.Repositories.UsuarioRepository;
import Angora.app.Services.RefreshTokenService;
import Angora.app.Services.UserDetailService;
import Angora.app.Utils.JwtUtils;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

// Controlador para la autenticación de usuarios
@RestController
@RequestMapping("/auth")
public class AuthenticationController {

    // Servicio del UserDetailService
    @Autowired
    private UserDetailService userDetailService;

    // Servicio de refresh token
    @Autowired
    private RefreshTokenService refreshTokenService;

    // Utilidad
    @Autowired
    private JwtUtils jwtUtils;

    // Repositorio del usuario
    @Autowired
    private UsuarioRepository usuarioRepository;

    // Metodo para autenticar y autorizar un usuario
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody @Valid AuthLoginRequest authLogin){
        AuthResponse authResponse = userDetailService.loginUser(authLogin);
        System.out.println("Respuesta Login: " + authResponse);
        return new ResponseEntity<>(authResponse, HttpStatus.OK);
    }

    // Metodo que refresca el token
    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refreshToken(@RequestBody @Valid RefreshTokenRequest refreshTokenRequest){
        try {

            String requestRefreshToken = refreshTokenRequest.refreshToken();

            System.out.println("Token recibido: " + requestRefreshToken + "");
            RefreshToken refreshToken = refreshTokenService.findByToken(requestRefreshToken)
                    .orElseThrow(() -> new RuntimeException("Refresh token no encontrado"));
            refreshToken = refreshTokenService.verifyExpiration(refreshToken);

            // Crear nuevo access token
            UserDetails userDetails = userDetailService.loadUserByUsername(refreshToken.getUsuario().getCorreo());

            Authentication authentication = new UsernamePasswordAuthenticationToken(
                    userDetails,
                    null,
                    userDetails.getAuthorities()
            );

            String newAccessToken = jwtUtils.createAccessToken(authentication);

            // Crear nuevo refresh token
            RefreshToken newRefreshToken = refreshTokenService.createRefreshToken(refreshToken.getUsuario().getCorreo());

            AuthResponse authResponse = new AuthResponse(
                    refreshToken.getUsuario().getCorreo(),
                    "Token renovado correctamente",
                    newAccessToken,
                    newRefreshToken.getToken(),
                    true
            );

            System.out.println("Token renovado: " + newAccessToken + "");

            return new ResponseEntity<>(authResponse, HttpStatus.OK);

        } catch (RuntimeException e) {
            return new ResponseEntity<>(
                    new AuthResponse(
                            null,
                            "Error al renovar token: " + e.getMessage(),
                            null,
                            null,
                            false), HttpStatus.UNAUTHORIZED
            );
        }
    }

    // Endpoint que elimina el token cuando cierran sesión
    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestBody RefreshTokenRequest refreshTokenRequest) {
        try {
            refreshTokenService.revokeToken(refreshTokenRequest.refreshToken());

            System.out.println("Token eliminado: " + refreshTokenRequest.refreshToken());

            return ResponseEntity.ok("Sesión cerrada correctamente");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Error al cerrar sesión: " + e.getMessage());
        }
    }

    // Método que busca un usuario por correo que se acaba de autenticar.
    @GetMapping("/authenticated/{correo}")
    public ResponseEntity<Usuario> buscarUsuarioPorCorreoAutenticado(@PathVariable String correo){

        Usuario usuario = usuarioRepository.findUsuarioByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Usuario usuarioAutenticado = Usuario.builder()
                .id(usuario.getId())
                .correo(usuario.getCorreo())
                .nombre(usuario.getNombre())
                .apellido(usuario.getApellido())
                .telefono(usuario.getTelefono())
                .direccion(usuario.getDireccion())
                .permisos(usuario.getPermisos())
                .foto(usuario.getFoto())
                .primerLogin(usuario.getPrimerLogin())
                .build();

        System.out.println("Usuario autenticado buscado por correo: " + usuarioAutenticado);
        return new ResponseEntity<>(usuarioAutenticado, HttpStatus.OK);
    }
}