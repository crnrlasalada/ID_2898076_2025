package Angora.app.Contract;

import java.time.LocalDateTime;

public interface Inventariable {
    Long getId();
    String getNombre();
    Integer getCantidad();
}