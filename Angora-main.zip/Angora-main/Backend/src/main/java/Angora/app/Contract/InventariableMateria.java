package Angora.app.Contract;

public interface InventariableMateria {
    String getId();
    String getNombre();
    Float getCantidad();
}