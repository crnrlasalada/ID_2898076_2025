package Angora.app.Controllers.dto;

import lombok.Data;

@Data
public class CategoriaIdDTO {

    private Long idCategoria;
}
