package Angora.app.Controllers.dto;

import lombok.Data;

@Data
public class MateriaProductoDTO {
    private String idMateria;
    private Float cantidad;
}
