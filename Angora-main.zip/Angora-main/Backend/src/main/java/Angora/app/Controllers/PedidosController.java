package Angora.app.Controllers;

import Angora.app.Controllers.dto.ConfirmarFacturaDTO;
import Angora.app.Controllers.dto.FacturaPendienteDTO;
import Angora.app.Entities.*;
import Angora.app.Repositories.*;
import Angora.app.Services.Email.EnviarCorreo;
import Angora.app.Services.MovimientoInventarioService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import jakarta.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RequestMapping("/pedidos")
@RestController
public class PedidosController {

    private static final Logger log = LoggerFactory.getLogger(PedidosController.class);

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private CarteraRepository carteraRepository;

    @Autowired
    private EnviarCorreo enviarCorreo;

    @Autowired
    private MovimientoInventarioService movimientoInventarioService;

    @Autowired
    private HistorialAbonoRepository historialAbonoRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @GetMapping("/pendientes")
    public ResponseEntity<?> obtenerFacturasPendientes() {
        try {
            List<Factura> facturas = facturaRepository.findByEstadoWithCajeroLeftJoin("PENDIENTE");
            log.info("Facturas pendientes encontradas: {}", facturas.size());
            List<FacturaPendienteDTO> facturasDTO = facturas.stream().map(factura -> {
                FacturaPendienteDTO dto = new FacturaPendienteDTO();
                dto.setIdFactura(factura.getIdFactura());
                dto.setFecha(factura.getFecha());

                // Manejar cliente nulo
                FacturaPendienteDTO.ClienteDTO clienteDTO = new FacturaPendienteDTO.ClienteDTO();
                if (factura.getCliente() != null) {
                    clienteDTO.setIdCliente(factura.getCliente().getIdCliente());
                    clienteDTO.setNombre(factura.getCliente().getNombre());
                    clienteDTO.setCorreo(factura.getCliente().getEmail());
                    clienteDTO.setApellido(factura.getCliente().getApellido());
                } else {
                    clienteDTO.setIdCliente(0L);
                    clienteDTO.setNombre("Consumidor final");
                }
                dto.setCliente(clienteDTO);

                // Mapear productos con precios persistidos o dinámicos
                dto.setProductos(factura.getProductos().stream().map(fp -> {
                    FacturaPendienteDTO.ProductoDTO productoDTO = new FacturaPendienteDTO.ProductoDTO();
                    productoDTO.setId(fp.getProducto().getIdProducto());
                    productoDTO.setNombre(fp.getProducto().getNombre());
                    productoDTO.setCantidad(fp.getCantidad());

                    // Usar precio persistido (precioUnitario) si está disponible, sino dinámico
                    if (fp.getPrecioUnitario() != null) {
                        productoDTO.setPrecio(fp.getPrecioUnitario().doubleValue());
                    } else {
                        productoDTO.setPrecio(fp.getProducto().getPrecioDetal());
                    }

                    productoDTO.setIva(fp.getProducto().getIva());
                    return productoDTO;
                }).collect(Collectors.toList()));

                dto.setSubtotal(factura.getSubtotal() != null ? factura.getSubtotal() : 0);
                dto.setTotal(factura.getTotal() != null ? factura.getTotal() : 0);
                dto.setSaldoPendiente(factura.getSaldoPendiente());
                dto.setEstado(factura.getEstado());
                dto.setNotas(factura.getNotas());

                // Manejar cartera
                if (factura.getIdCartera() != null) {
                    FacturaPendienteDTO.CarteraDTO carteraDTO = new FacturaPendienteDTO.CarteraDTO();
                    carteraDTO.setIdCartera(factura.getIdCartera().getIdCartera());
                    carteraDTO.setAbono(factura.getIdCartera().getAbono());
                    carteraDTO.setDeudas(factura.getIdCartera().getDeudas());
                    carteraDTO.setEstado(factura.getIdCartera().getEstado());
                    dto.setIdCartera(carteraDTO);
                }

                // Manejar cajero
                if (factura.getCajero() != null) {
                    FacturaPendienteDTO.UsuarioDTO cajeroDTO = new FacturaPendienteDTO.UsuarioDTO();
                    cajeroDTO.setId(factura.getCajero().getId());
                    cajeroDTO.setNombre(factura.getCajero().getNombre());
                    cajeroDTO.setApellido(factura.getCajero().getApellido());
                    dto.setCajero(cajeroDTO);
                    dto.setCajeroNombre(factura.getCajero().getNombre());
                    dto.setCajeroApellido(factura.getCajero().getApellido());
                } else {
                    dto.setCajero(null);
                    dto.setCajeroNombre(factura.getCajeroNombre() != null ? factura.getCajeroNombre() : "Desconocido");
                    dto.setCajeroApellido(factura.getCajeroApellido() != null ? factura.getCajeroApellido() : "");
                }

                return dto;
            }).collect(Collectors.toList());

            log.info("Facturas DTO generadas: {}", facturasDTO.size());
            return ResponseEntity.ok(facturasDTO);
        } catch (Exception e) {
            log.error("Error al obtener facturas pendientes: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener facturas pendientes: " + e.getMessage());
        }
    }

    @PutMapping("/confirmar/{id}")
    @Transactional
    public ResponseEntity<?> confirmarFactura(@PathVariable Long id, @RequestBody ConfirmarFacturaDTO dto) {
        try {
            Factura factura = entityManager.find(Factura.class, id, LockModeType.PESSIMISTIC_WRITE);
            if (factura == null) {
                throw new RuntimeException("Factura no encontrada: " + id);
            }

            if (!factura.getEstado().equals("PENDIENTE")) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("La factura no está en estado PENDIENTE");
            }

            // Validar stock de productos
            for (ConfirmarFacturaDTO.FacturaProductoDTO fpDTO : dto.getProductos()) {
                Producto producto = productoRepository.findById(fpDTO.getIdProducto())
                        .orElseThrow(() -> new RuntimeException("Producto no encontrado: " + fpDTO.getIdProducto()));
                if (producto.getStock() == null || producto.getStock() < fpDTO.getCantidad()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Stock insuficiente para el producto: " + producto.getNombre());
                }
            }

            // Hacer snapshot de precios basados en el tipo de precio seleccionado
            if (factura.getProductos().size() != dto.getProductos().size()) {
                throw new RuntimeException("La cantidad de productos en el DTO no coincide con la factura");
            }

            for (int i = 0; i < factura.getProductos().size(); i++) {
                FacturaProducto fp = factura.getProductos().get(i);
                ConfirmarFacturaDTO.FacturaProductoDTO fpDTO = dto.getProductos().get(i);

                if (!fp.getProducto().getIdProducto().equals(fpDTO.getIdProducto()) || !fp.getCantidad().equals(fpDTO.getCantidad())) {
                    throw new RuntimeException("Los productos o cantidades no coinciden con la factura");
                }

                Double precioActual;
                String tipoPrecio = fpDTO.getTipoPrecio();

                if ("detal".equals(tipoPrecio)) {
                    precioActual = fp.getProducto().getPrecioDetal();
                } else if ("mayorista".equals(tipoPrecio)) {
                    precioActual = fp.getProducto().getPrecioMayorista();
                    if (precioActual == null) {
                        throw new RuntimeException("El producto " + fp.getProducto().getNombre() + " no tiene precio mayorista");
                    }
                } else if ("opcional".equals(tipoPrecio)) {
                    precioActual = fpDTO.getPrecioOpcional();
                    if (precioActual == null || precioActual <= 0) {
                        throw new RuntimeException("El precio opcional debe ser mayor que 0 para el producto: " + fp.getProducto().getNombre());
                    }
                } else {
                    throw new RuntimeException("Tipo de precio no válido: " + tipoPrecio);
                }

                Double subtotalItem = precioActual * fp.getCantidad();

                fp.setPrecioUnitario(precioActual);
                fp.setSubtotal(subtotalItem);
            }

            // Recalcular totales
            recalcularTotalesFactura(factura);

            // Aplicar crédito a favor solo al confirmar
            if (factura.getIdCartera() != null) {
                Cartera cartera = carteraRepository.findById(factura.getIdCartera().getIdCartera())
                        .orElseThrow(() -> new RuntimeException("Cartera no encontrada: " + factura.getIdCartera().getIdCartera()));
                Float creditoAFavor = cartera.getCreditoAFavor() != null ? cartera.getCreditoAFavor() : 0f;
                Float total = factura.getTotal() != null ? factura.getTotal().floatValue() : 0f;
                Float nuevoSaldoPendiente = Math.max(0f, total - creditoAFavor);
                Float nuevoCreditoAFavor = Math.max(0f, creditoAFavor - total);

                factura.setSaldoPendiente(Double.valueOf(nuevoSaldoPendiente));
                cartera.setDeudas(cartera.getDeudas() + nuevoSaldoPendiente);
                cartera.setCreditoAFavor(nuevoCreditoAFavor);
                carteraRepository.save(cartera);

                // Registrar historial si se usó crédito a favor
                if (creditoAFavor > 0) {
                    HistorialAbono historial = new HistorialAbono();
                    historial.setCliente(factura.getCliente());
                    historial.setFactura(factura);
                    historial.setMontoAbono(Math.min(creditoAFavor, total));
                    historial.setSaldoAnterior(total);
                    historial.setSaldoNuevo(nuevoSaldoPendiente);
                    historial.setFechaAbono(LocalDateTime.now());
                    historial.setDescripcion("Abono automático desde crédito a favor para factura #" + factura.getIdFactura());
                    historialAbonoRepository.save(historial);
                }
            }

            // Cambiar estado a CONFIRMADO
            factura.setEstado("CONFIRMADO");

            // Actualizar inventario
            for (ConfirmarFacturaDTO.FacturaProductoDTO fp : dto.getProductos()) {
                movimientoInventarioService.descontarPorVenta(fp.getIdProducto(), fp.getCantidad());
            }

            // Guardar la factura actualizada
            Factura updatedFactura = facturaRepository.save(factura);

            return ResponseEntity.ok(updatedFactura);
        } catch (RuntimeException e) {
            log.error("Error al confirmar la factura: ", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al confirmar la factura: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error inesperado: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error inesperado: " + e.getMessage());
        }
    }

    @PostMapping("/enviar-factura")
    public ResponseEntity<?> enviarFactura(@RequestBody Map<String, Object> request) {
        try {
            Long idFactura = Long.valueOf(request.get("idFactura").toString());
            Boolean enviarCorreoHabilitado = (Boolean) request.get("enviarCorreo");

            Factura factura = facturaRepository.findById(idFactura)
                    .orElseThrow(() -> new RuntimeException("Factura no encontrada: " + idFactura));

            if (!enviarCorreoHabilitado || factura.getCliente() == null || factura.getCliente().getEmail() == null) {
                return ResponseEntity.ok("Correo no enviado: configuración o datos insuficientes");
            }

            String productosHTML = factura.getProductos().stream().map(fp -> {
                Float precioUnitario = fp.getPrecioUnitario() != null ? fp.getPrecioUnitario().floatValue() : fp.getProducto().getPrecioDetal().floatValue();
                Float subtotal = fp.getProducto().getIva()
                        ? precioUnitario * 1.19f * fp.getCantidad()
                        : precioUnitario * fp.getCantidad();

                return String.format(
                        "<tr style=\"border-bottom: 1px solid #b3d4fc;\">" +
                                "<td style=\"padding: 8px; border: 1px solid #b3d4fc;\">%s</td>" +
                                "<td style=\"padding: 8px; border: 1px solid #b3d4fc; text-align: right;\">%d</td>" +
                                "<td style=\"padding: 8px; border: 1px solid #b3d4fc; text-align: right;\">$%.2f</td>" +
                                "<td style=\"padding: 8px; border: 1px solid #b3d4fc; text-align: right;\">$%.2f</td>" +
                                "</tr>",
                        fp.getProducto().getNombre(),
                        fp.getCantidad(),
                        precioUnitario,
                        subtotal
                );
            }).collect(Collectors.joining());

            String notasHTML = factura.getNotas() != null && !factura.getNotas().isEmpty()
                    ? "<li style=\"margin-bottom: 10px;\"><strong>Notas:</strong> " + factura.getNotas() + "</li>"
                    : "";

            Float totalFactura = factura.getTotal() != null ? factura.getTotal().floatValue() : 0.0f;

            Map<String, String> variables = Map.of(
                    "nombre", factura.getCliente() != null ? factura.getCliente().getNombre() : "Consumidor final",
                    "factura", factura.getIdFactura().toString(),
                    "fecha", factura.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")),
                    "productos", productosHTML,
                    "notas", notasHTML,
                    "total", String.format("%.2f", totalFactura)
            );

            enviarCorreo.enviarConPlantilla(
                    factura.getCliente().getEmail(),
                    "Factura #" + factura.getIdFactura() + " - Fraganceys",
                    "factura-body.html",
                    variables,
                    null,
                    null
            );

            return ResponseEntity.ok("Correo enviado correctamente");
        } catch (RuntimeException e) {
            log.error("Error al enviar factura por correo: ", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al enviar la factura: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error inesperado al enviar factura por correo: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error inesperado: " + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarFactura(@PathVariable Long id) {
        try {
            Factura factura = facturaRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Factura no encontrada: " + id));
            facturaRepository.delete(factura);
            return ResponseEntity.ok("Factura eliminada correctamente");
        } catch (RuntimeException e) {
            log.error("Error al eliminar la factura: ", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al eliminar la factura: " + e.getMessage());
        } catch (Exception e) {
            log.error("Error inesperado: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error inesperado: " + e.getMessage());
        }
    }

    private void recalcularTotalesFactura(Factura factura) {
        Double subtotalCalculado = 0d;
        Double totalCalculado = 0d;

        for (FacturaProducto fp : factura.getProductos()) {
            Double precioUnitario;
            Double subtotalItem;

            // Priorizar precioUnitario persistido si existe
            if (fp.getPrecioUnitario() != null) {
                precioUnitario = fp.getPrecioUnitario();
                subtotalItem = fp.getSubtotal() != null ? fp.getSubtotal() : precioUnitario * fp.getCantidad();
            } else {
                precioUnitario = fp.getProducto().getPrecioDetal();
                subtotalItem = precioUnitario * fp.getCantidad();
            }

            subtotalCalculado += subtotalItem;

            // Aplicar IVA si corresponde (19%)
            if (fp.getProducto().getIva()) {
                totalCalculado += Math.round(subtotalItem * 1.19f);
            } else {
                totalCalculado += subtotalItem;
            }
        }

        factura.setSubtotal(subtotalCalculado);
        factura.setTotal(totalCalculado);

        // Actualizar saldo pendiente si no se ha pagado nada
        if (factura.getSaldoPendiente() == null || factura.getSaldoPendiente().equals(factura.getTotal())) {
            factura.setSaldoPendiente(totalCalculado);
        }
    }
}