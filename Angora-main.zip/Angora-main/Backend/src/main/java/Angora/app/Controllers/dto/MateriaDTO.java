package Angora.app.Controllers.dto;

import lombok.Data;

@Data
public class MateriaDTO {
    private String idMateria;
    private String nombre;
    private Integer costo;
    private Integer venta;
    private Float cantidad;
}
