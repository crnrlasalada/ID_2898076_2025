package Angora.app.Services;

import Angora.app.Entities.Factura;

public interface IFacturaService {

    void agregarFactura(Factura factura);
}
