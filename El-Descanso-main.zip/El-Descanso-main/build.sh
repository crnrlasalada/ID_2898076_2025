#!/usr/bin/env bash
set -o errexit

# 🛠 Instalar wkhtmltopdf en Render (Linux)
apt-get update && apt-get install -y wkhtmltopdf


# Instalar dependencias Python (requirements.txt está en la raíz del repo)
python -m pip install -r requirements.txt

# Entrar en la carpeta correcta donde está manage.py
cd backend/hotel_casa_luna

# Recoger archivos estáticos
python manage.py collectstatic --noinput

# Aplicar migraciones
python manage.py migrate
