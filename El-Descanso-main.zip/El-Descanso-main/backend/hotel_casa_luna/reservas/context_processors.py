from reservas.models import Administrador

def usuario_contexto(request):
    correo = request.session.get('correo')

    if correo:
        try:
            usuario = Administrador.objects.get(correo=correo)
            return {'usuario_logueado': usuario}
        except Administrador.DoesNotExist:
            pass
    return {}