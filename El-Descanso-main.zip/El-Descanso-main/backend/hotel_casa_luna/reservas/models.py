# Create your models here.
from django.db import models


class Administrador(models.Model):
    id_admin = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    correo = models.CharField(max_length=100)
    contraseña = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    id_rol = models.ForeignKey('reservas.Roles', models.DO_NOTHING, db_column='id_rol', blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'administrador'


class AdministradorAdministrador(models.Model):
    id_admin = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    correo = models.CharField(max_length=100)
    contrasena = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    rol = models.ForeignKey('AdministradorRol', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'administrador_administrador'


class AdministradorFormulario(models.Model):
    id = models.BigAutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    cedula = models.BigIntegerField()
    correo_u = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    cuidad = models.CharField(max_length=50)
    pais = models.CharField(max_length=50)
    peticiones = models.TextField(blank=True, null=True)
    fecha_entrada = models.DateField()
    fecha_salida = models.DateField()
    nombre_extra = models.CharField(max_length=100, blank=True, null=True)
    apellido_extra = models.CharField(max_length=100, blank=True, null=True)
    admin = models.ForeignKey(AdministradorAdministrador, models.DO_NOTHING)
    habitacion = models.ForeignKey('AdministradorHabitacion', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'administrador_formulario'


class AdministradorHabitacion(models.Model):
    id = models.BigAutoField(primary_key=True)
    tipo_habitacion = models.CharField(max_length=50)
    precios = models.IntegerField()
    estado_habitacion = models.CharField(max_length=50)
    num_habitacion = models.IntegerField()
    descripcion = models.CharField(max_length=200)
    cantidad_personas = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'administrador_habitacion'


class AdministradorRol(models.Model):
    id = models.BigAutoField(primary_key=True)
    rol = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'administrador_rol'


class Factura(models.Model):
    id_factura = models.AutoField(primary_key=True)
    nombre_hospedaje = models.CharField(max_length=100, blank=True, null=True)
    id_formulario = models.ForeignKey('Formulario', models.DO_NOTHING, db_column='id_formulario', blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'factura'


from cloudinary.models import CloudinaryField

class Habitaciones(models.Model):
    id_habitacion = models.AutoField(primary_key=True)
    tipo_habitacion = models.CharField(max_length=50)
    precios = models.IntegerField()
    estado_habitacion = models.CharField(max_length=50)
    num_habitacion = models.IntegerField()
    descripcion = models.CharField(max_length=600)
    cantidad_personas = models.IntegerField()
    nombre_imagen = CloudinaryField('image', null=True, blank=True)  # Cambia ImageField por CloudinaryField

    class Meta:
        db_table = 'habitaciones'
        managed = True

    def __str__(self):
        return f"Habitación {self.id_habitacion} - {self.tipo_habitacion}"

class Formulario(models.Model):
    id_formulario = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    cedula = models.IntegerField()
    correo_u = models.EmailField(max_length=100)
    direccion = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    ciudad = models.CharField(max_length=50)
    pais = models.CharField(max_length=50)
    peticiones = models.TextField(blank=True, null=True)
    fecha_entrada = models.DateField()
    fecha_salida = models.DateField()
    nombre_extra = models.CharField(max_length=100, blank=True, null=True)
    apellido_extra = models.CharField(max_length=100, blank=True, null=True)
    precio_total = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    anticipo = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    estado = models.CharField(
        max_length=20,
        choices=[
            ('activo', 'Activo'),
            ('inactivo', 'Inactivo'),
            ('invalido', 'Inválido')
        ],
        default='activo'
    )

    cantidad = models.IntegerField(null=True, blank=True)

    id_admin = models.ForeignKey(
        Administrador,
        on_delete=models.DO_NOTHING,
        db_column='id_admin',
        blank=True,
        null=True
    )

    id_habitacion = models.ForeignKey('reservas.Habitaciones', models.DO_NOTHING, db_column='id_habitacion', blank=True, null=True)


    class Meta:
        managed = True
        db_table = 'formulario'

    def _str_(self):
        return f"{self.nombre} {self.apellido} - {self.fecha_entrada}"

class ReservasAdministrador(models.Model):
    id_admin = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    correo = models.CharField(max_length=100)
    contrasena = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    rol = models.ForeignKey('ReservasRol', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'reservas_administrador'


class ReservasFormulario(models.Model):
    id = models.BigAutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    cedula = models.BigIntegerField()
    correo_u = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    cuidad = models.CharField(max_length=50)
    pais = models.CharField(max_length=50)
    peticiones = models.TextField(blank=True, null=True)
    fecha_entrada = models.DateField()
    fecha_salida = models.DateField()
    nombre_extra = models.CharField(max_length=100, blank=True, null=True)
    apellido_extra = models.CharField(max_length=100, blank=True, null=True)
    admin = models.ForeignKey(ReservasAdministrador, models.DO_NOTHING)
    habitacion = models.ForeignKey('ReservasHabitacion', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'reservas_formulario'


class ReservasHabitacion(models.Model):
    id = models.BigAutoField(primary_key=True)
    tipo_habitacion = models.CharField(max_length=50)
    precios = models.IntegerField()
    estado_habitacion = models.CharField(max_length=50)
    num_habitacion = models.IntegerField()
    descripcion = models.CharField(max_length=200)
    cantidad_personas = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'reservas_habitacion'


class ReservasRol(models.Model):
    id = models.BigAutoField(primary_key=True)
    rol = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'reservas_rol'


class Roles(models.Model):
    id_rol = models.AutoField(primary_key=True)
    rol = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'roles'

# ---------- Imagen Galería ----------
from cloudinary.models import CloudinaryField

class ImagenGaleria(models.Model):
    imagen = CloudinaryField('image')  # Cambia ImageField por CloudinaryField
    descripcion = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.descripcion or f'Imagen {self.id}'

    class Meta:
        managed = True
        db_table = 'reservas_imagengaleria'


class ComprobantePago(models.Model):
    id = models.AutoField(primary_key=True)
    formulario = models.ForeignKey(Formulario, on_delete=models.CASCADE)
    imagen_comprobante = models.ImageField(upload_to='comprobantes/')
    fecha_envio = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(
        max_length=20,
        choices=[('en_espera', 'En espera'), ('confirmado', 'Confirmado'), ('rechazado', 'Rechazado')],
        default='en_espera'
    )

    class Meta:
        managed = True
        db_table = 'comprobante_pago'


class LoginAdministrador(models.Model):
    id_admin = id_admin = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    correo = models.CharField(max_length=100)
    contrasena = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    rol = models.ForeignKey('LoginRol', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'login_administrador'


class LoginFormulario(models.Model):
    id = models.BigAutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    cedula = models.BigIntegerField()
    correo_u = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    telefono = models.BigIntegerField()
    cuidad = models.CharField(max_length=50)
    pais = models.CharField(max_length=50)
    peticiones = models.TextField(blank=True, null=True)
    fecha_entrada = models.DateField()
    fecha_salida = models.DateField()
    admin = models.ForeignKey(LoginAdministrador, models.DO_NOTHING)
    habitacion = models.ForeignKey('LoginHabitacion', models.DO_NOTHING)
    nombre_extra = models.CharField(max_length=100, blank=True, null=True)
    apellido_extra = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'login_formulario'


class LoginHabitacion(models.Model):
    id = models.BigAutoField(primary_key=True)
    tipo_habitacion = models.CharField(max_length=50)
    precios = models.IntegerField()
    estdo_habitacion = models.CharField(max_length=50)
    num_habitacion = models.IntegerField()
    descripcion = models.CharField(max_length=200)
    cantidad_personas = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'login_habitacion'


class LoginRol(models.Model):
    id = models.BigAutoField(primary_key=True)
    rol = models.CharField(max_length=100)

    class Meta:
        managed = True
        db_table = 'login_rol'

