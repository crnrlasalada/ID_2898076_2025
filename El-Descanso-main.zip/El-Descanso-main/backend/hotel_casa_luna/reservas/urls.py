from django.urls import path
from . import views

app_name = 'reservas'

urlpatterns = [
    path('', views.home, name='home_'),
    path('habitaciones/', views.habitaciones_clien, name='habitaciones_'),
    path('servicios/', views.servicios, name='servicios_'),
    path('galeria/', views.galeria_clien, name='galeria_'),
    path('buscar/', views.buscar, name='buscar_'),
    path('seleccionar_habitacion/', views.seleccionar_habi, name='seleccionar_habi_'),
    path('formulario/', views.formulario, name='formulario_'),
    path('soporte/', views.soporte, name='soporte_'),
    path('terminos/', views.terminos, name='terminos_'),
    path('guardar_reserva_individual/', views.guardar_reserva_individual, name='guardar_reserva_individual'),
    path('metodo_pago/<int:id_formulario>/', views.metodo_pago, name='metodo_pago'),
    path('confirmar_reserva/', views.confirmar_reserva, name='confirmar_reserva'),
    path('resumen_pago/', views.resumen_pago, name='resumen_pago'),
    path('editar_formulario/<int:id_formulario>/', views.editar_datos_formulario, name='editar_formulario'),
]
