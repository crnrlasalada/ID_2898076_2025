// Obtener referencias a los elementos del DOM del componente integrado (NUEVA ESTRUCTURA)
const guestDropdownBtn = document.getElementById('guestDropdownBtn'); // Botón principal para abrir/cerrar el desplegable
const dropdownContent = document.getElementById('dropdownContent'); // Contenedor del contenido desplegable
const guestSummary = document.getElementById('guestSummary'); // Texto que resume la selección actual
const roomsInput = document.getElementById('rooms'); // Campo de número de habitaciones
const adultsInput = document.getElementById('adults'); // Campo de número de adultos
const childrenInput = document.getElementById('childrenInput'); // Campo de número de niños (ID actualizado)
const childAgesContainer = document.getElementById('childAgesContainer'); // Contenedor para los inputs de edades de los niños
const useCombinationBtn = document.getElementById('useCombinationBtn'); // Botón "Usa esta combinación"

// Almacenar las edades de los niños para persistencia
let childAges = []; // Arreglo para guardar las edades de los niños

// Función para alternar la visibilidad del desplegable
function toggleDropdown() {
    dropdownContent.classList.toggle('show'); // Agrega o quita la clase 'show' al contenedor desplegable
}

// Función para validar y corregir valores de un input
function validateInput(input, min, max) {
    let value = parseInt(input.value);
    if (isNaN(value) || value < min) {
        input.value = min; // Corregir al mínimo si es inválido
    } else if (value > max) {
        input.value = max; // Corregir al máximo si excede
    }
}

// Validar entradas manuales en los campos
roomsInput.addEventListener('input', () => validateInput(roomsInput, 1, 4));
adultsInput.addEventListener('input', () => validateInput(adultsInput, 1, 4));
childrenInput.addEventListener('input', () => {
    validateInput(childrenInput, 0, 4);
    updateChildAgeInputs(); // Actualizar campos de edades al cambiar niños
});

// Listener de eventos para el botón principal del desplegable
guestDropdownBtn.addEventListener('click', function (e) {
    e.stopPropagation(); // Evitar que el clic se propague al documento y cierre el dropdown
    toggleDropdown(); // Llamar a la función para abrir/cerrar el menú desplegable
});

// Listener de eventos para el botón "USA ESTA COMBINACIÓN"
useCombinationBtn.addEventListener('click', function () {
    const rooms = parseInt(roomsInput.value);
    const adults = parseInt(adultsInput.value);
    const children = parseInt(childrenInput.value);

    // Validaciones antes de cerrar el desplegable
    if (isNaN(rooms) || rooms < 1 || rooms > 4) {
        alert('El número de habitaciones debe estar entre 1 y 4.');
        roomsInput.value = 1; // Restablecer a un valor válido
        return;
    }
    if (isNaN(adults) || adults < 1 || adults > 4) {
        alert('El número de adultos debe estar entre 1 y 4.');
        adultsInput.value = 1; // Restablecer a un valor válido
        return;
    }
    if (isNaN(children) || children < 0 || children > 4) {
        alert('El número de niños debe estar entre 0 y 4.');
        childrenInput.value = 0; // Restablecer a un valor válido
        updateChildAgeInputs(); // Actualizar campos de edades
        return;
    }
    if (children > 0 && childAges.length !== children) {
        alert('Debe especificar la edad de todos los niños.');
        return;
    }
    for (let i = 0; i < childAges.length; i++) {
        if (isNaN(childAges[i]) || childAges[i] < 1 || childAges[i] > 12) {
            alert(`La edad del niño ${i + 1} debe estar entre 1 y 12 años.`);
            return;
        }
    }

    toggleDropdown(); // Cerrar el desplegable
    updateGuestSummary(); // Actualizar el resumen de huéspedes
});

// Función para actualizar el texto del resumen en el botón principal
function updateGuestSummary() {
    const rooms = parseInt(roomsInput.value);
    const adults = parseInt(adultsInput.value);
    const children = parseInt(childrenInput.value);

    // Generar texto usando template literals
    let summaryHtml = `${rooms} habitación${rooms > 1 ? 'es' : ''} para ${adults} adulto${adults > 1 ? 's' : ''}`;
    if (children > 0) {
        summaryHtml += ` y ${children} niño${children > 1 ? 's' : ''}`; // Agregar niños si hay
    }
    guestSummary.innerHTML = summaryHtml; // Establecer el resumen generado en el DOM
}

// Función para añadir/eliminar dinámicamente campos de entrada de edad de niños
function updateChildAgeInputs() {
    const currentChildren = parseInt(childrenInput.value) || 0;
    // Asegurar que no se exceda el límite de 4 niños
    if (currentChildren > 4) {
        childrenInput.value = 4;
    }

    // Guardar las edades actuales antes de limpiar el contenedor
    const existingChildInputs = childAgesContainer.querySelectorAll('input.child-age-input');
    const tempChildAges = Array.from(existingChildInputs).map(input => parseInt(input.value) || 0);

    childAgesContainer.innerHTML = ''; // Limpiar inputs existentes

    if (currentChildren > 0) { // Solo añadir encabezado si hay niños
        const headingRow = document.createElement('div');
        headingRow.classList.add('row', 'align-items-center', 'mb-2');
        headingRow.style.paddingTop = '10px';

        const heading = document.createElement('span');
        heading.classList.add('label', 'col-12', 'mb-2', 'fw-bold');
        heading.textContent = 'Edades de los Niños:';
        headingRow.appendChild(heading);
        childAgesContainer.appendChild(headingRow);
    }

    for (let i = 0; i < currentChildren; i++) {
        const childAgeRow = document.createElement('div');
        childAgeRow.classList.add('row', 'align-items-center', 'mb-2');
        childAgeRow.style.borderTop = '1px solid #eee';
        childAgeRow.style.paddingTop = '10px';

        const label = document.createElement('span');
        label.classList.add('label', 'col-5');
        label.textContent = `Edad del niño ${i + 1}`;
        childAgeRow.appendChild(label);

        const counterDiv = document.createElement('div');
        counterDiv.classList.add('counter', 'col-7', 'd-flex', 'align-items-center', 'justify-content-end');

        const decreaseBtn = document.createElement('button');
        decreaseBtn.type = 'button';
        decreaseBtn.classList.add('btn', 'btn-sm', 'rounded-pill', 'px-2');
        decreaseBtn.textContent = '-';
        decreaseBtn.style.backgroundColor = '#f0f0f0';
        decreaseBtn.style.color = '#555';
        decreaseBtn.dataset.index = i;
        decreaseBtn.dataset.action = 'decreaseChildAge';
        counterDiv.appendChild(decreaseBtn);

        const input = document.createElement('input');
        input.type = 'number';
        input.classList.add('form-control', 'form-control-sm', 'child-age-input');
        input.value = tempChildAges.length > i ? tempChildAges[i] : 1;
        input.min = '1';
        input.max = '12';
        input.dataset.index = i;
        input.style.width = '40px';
        input.style.textAlign = 'center';
        input.style.border = '1px solid #ddd';
        input.style.borderRadius = '3px';
        input.addEventListener('input', (e) => {
            validateInput(e.target, 1, 12); // Validar edad del niño
            childAges[i] = parseInt(e.target.value); // Actualizar array
        });
        counterDiv.appendChild(input);

        const increaseBtn = document.createElement('button');
        increaseBtn.type = 'button';
        increaseBtn.classList.add('btn', 'btn-sm', 'rounded-pill', 'px-2');
        increaseBtn.textContent = '+';
        increaseBtn.style.backgroundColor = '#f0f0f0';
        increaseBtn.style.color = '#555';
        increaseBtn.dataset.index = i;
        increaseBtn.dataset.action = 'increaseChildAge';
        counterDiv.appendChild(increaseBtn);

        childAgeRow.appendChild(counterDiv);
        childAgesContainer.appendChild(childAgeRow);
    }

    // Actualizar el array con los nuevos valores de edad
    childAges = Array.from(childAgesContainer.querySelectorAll('input.child-age-input')).map(input => parseInt(input.value) || 0);
}

// Event listeners para los botones de incremento y decremento
dropdownContent.addEventListener('click', function (e) {
    if (e.target.classList.contains('btn') && e.target.dataset.action) {
        const action = e.target.dataset.action;
        const target = e.target.dataset.target;
        const index = e.target.dataset.index;
        let inputField;

        if (target === 'rooms') {
            inputField = roomsInput;
        } else if (target === 'adults') {
            inputField = adultsInput;
        } else if (target === 'children') {
            inputField = childrenInput;
        } else if (action === 'decreaseChildAge' || action === 'increaseChildAge') {
            const childAgeInput = childAgesContainer.querySelector(`input.child-age-input[data-index="${index}"]`);
            if (childAgeInput) {
                let currentValue = parseInt(childAgeInput.value);
                if (action === 'increaseChildAge' && currentValue < 12) {
                    childAgeInput.value = currentValue + 1;
                } else if (action === 'decreaseChildAge' && currentValue > 1) {
                    childAgeInput.value = currentValue - 1;
                }
                childAges[index] = parseInt(childAgeInput.value);
            }
            return;
        }

        if (inputField) {
            let currentValue = parseInt(inputField.value);
            let maxLimit = 4;
            let minLimit = target === 'children' ? 0 : 1;

            if (action === 'increase' && currentValue < maxLimit) {
                inputField.value = currentValue + 1;
            } else if (action === 'decrease' && currentValue > minLimit) {
                inputField.value = currentValue - 1;
            }

            if (target === 'children') {
                updateChildAgeInputs();
            }
        }
    }
});

// Inicializar los campos de edad de los niños si hay algún niño al cargar la página
updateChildAgeInputs();
updateGuestSummary();

// Cerrar el dropdown si se hace clic fuera de él
document.addEventListener('click', function (e) {
    if (!dropdownContent.contains(e.target) && !guestDropdownBtn.contains(e.target)) {
        dropdownContent.classList.remove('show');
    }
});