function guardarReserva(tipo, precio) {
    localStorage.setItem("tipoHabitacion", tipo);
    localStorage.setItem("precioHabitacion", precio);
}

// Reutilizamos la lógica antes de enviar el formulario
function actualizarCamposOcultos() {
    const rooms = document.getElementById('rooms').value;
    const adults = document.getElementById('adults').value;
    const children = document.getElementById('childrenInput').value;

    document.getElementById('roomsHidden').value = rooms;
    document.getElementById('adultsHidden').value = adults;
    document.getElementById('childrenHidden').value = children;
}

document.getElementById('useCombinationBtn').addEventListener('click', function () {
    actualizarCamposOcultos();
    document.getElementById('dropdownContent').style.display = 'none';
});

document.querySelector('form').addEventListener('submit', function () {
    actualizarCamposOcultos(); // asegura que los datos se actualicen antes de enviar
});
