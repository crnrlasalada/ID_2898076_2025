// /js/validarYGenerarComprobante.js

// Función para detectar valores con todos los caracteres iguales (ej: aaaaaaa, 111111)
function esRepetitivo(valor) {
    return /^([a-zA-Z0-9])\1*$/.test(valor);
}

// Función para detectar secuencias obvias (ascendentes o descendentes)
function esSecuencia(valor) {
    const secuencias = [
        "abcdefghijklmnopqrstuvwxyz",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "0123456789",
        "0987654321"
    ];
    for (let seq of secuencias) {
        if (seq.includes(valor) || seq.includes(valor.split("").reverse().join(""))) {
            return true;
        }
    }
    return false;
}

document.addEventListener('DOMContentLoaded', function () {

    if (!localStorage.getItem("tipoHabitacion") || !localStorage.getItem("precioHabitacion")) {
        alert("Debes seleccionar una habitación antes de continuar con la reserva.");
        window.location.href = "/seleccionar_habitacion/";
    }

    const form = document.querySelector('.main-center');
    const btnConfirmar = document.getElementById('btnConfirmarReserva');

    if (btnConfirmar && form) {
        btnConfirmar.addEventListener('click', function (event) {
            event.preventDefault();

            let allFieldsValid = true;
            let mensajesError = [];

            // Reglas de validación con expresiones regulares
            const reglas = {
                nombre: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
                apellidos: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
                cedula: /^(?!1234567890$)\d{6,10}$/,
                email: /^[a-zA-Z0-9._%+-]+@gmail\.com$/,
                direccion: /^.{5,100}$/,
                telefono: /^\d{10}$/,
                ciudad: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
                pais: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/
            };

            // Validar campos
            Object.keys(reglas).forEach(id => {
                const input = document.getElementById(id);
                const valor = input.value.trim();

                if (!reglas[id].test(valor) || esRepetitivo(valor) || esSecuencia(valor)) {
                    allFieldsValid = false;
                    input.classList.add('is-invalid');
                    mensajesError.push(`El campo ${id} no es válido.`);
                } else {
                    input.classList.remove('is-invalid');
                }
            });

            // Validar aceptación de términos y condiciones
            const condicionesCheckbox = document.getElementById('condiciones');
            if (!condicionesCheckbox.checked) {
                allFieldsValid = false;
                condicionesCheckbox.classList.add('is-invalid');
                mensajesError.push("Debes aceptar los términos y condiciones.");
            } else {
                condicionesCheckbox.classList.remove('is-invalid');
            }

            // Si no es válido, mostrar mensaje
            if (!allFieldsValid) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Errores de validación',
                    html: mensajesError.join('<br>'),
                    confirmButtonText: 'Entendido',
                    customClass: {
                        confirmButton: 'mi-boton-advertencia'
                    },
                });
                return;
            }

            // Mensaje de éxito
            Swal.fire({
                icon: 'success',
                title: '¡Reserva Casi Lista!',
                text: 'Ahora puedes proceder al pago.',
                confirmButtonText: 'Aceptar',
                customClass: {
                    confirmButton: 'mi-boton-confirmacion'
                },
            }).then(() => {
                form.submit();
            });

            // Resumen de la reserva
            const tipo = localStorage.getItem("tipoHabitacion") || "Habitación no seleccionada";
            const precio = localStorage.getItem("precioHabitacion") || "0";
            document.getElementById("resumen-detalle").innerText = `1 ${tipo.toLowerCase()}, 2 adultos`;
            document.getElementById("resumen-precio").innerText = `COP ${precio}`;
        });
    }
});