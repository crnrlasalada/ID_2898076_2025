document.addEventListener("DOMContentLoaded", function () {
    // Localiza el formulario (varios fallbacks)
    const form =
        document.querySelector('form[action*="editar_formulario"]') ||
        document.querySelector('form#editar_formulario') ||
        document.querySelector("form");

    if (!form) return;

    // Reglas base (mismas del otro JS)
    const reglas = {
        nombre: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        apellidos: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        cedula: /^(?!1234567890$)\d{6,10}$/,
        correo_u: /^[a-zA-Z0-9._%+-]+@gmail\.com$/,
        direccion: /^.{5,100}$/,
        telefono: /^\d{10}$/,
        ciudad: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        pais: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/
    };

    // Posibles selectores por campo (name/id alternativos)
    const selectores = {
        nombre: ['[name="nombre"]', '#nombre', '[name="nombre_u"]', '[name="first_name"]'],
        apellidos: [
            '[name="apellidos"]', '#apellidos',
            '[name="apellido"]', '[name="apellidos_u"]', '[name="last_name"]'
        ],
        cedula: ['[name="cedula"]', '#cedula', '[name="documento"]', '[name="dni"]'],
        correo_u: ['[name="correo_u"]', '#correo_u', '[name="email"]', '#email', '[name="correo"]'],
        direccion: ['[name="direccion"]', '#direccion', '[name="direccion_u"]'],
        telefono: ['[name="telefono"]', '#telefono', '[name="telefono_u"]', '[name="celular"]'],
        ciudad: ['[name="ciudad"]', '#ciudad', '[name="ciudad_u"]'],
        pais: ['[name="pais"]', '#pais', '[name="pais_u"]']
    };

    function getInput(campo) {
        for (const sel of (selectores[campo] || [])) {
            const el = form.querySelector(sel);
            if (el) return el;
        }
        return null;
    }

    // ---- Utilidades de validación ----
    function normalizar(v) { return (v || "").trim().normalize("NFC"); }

    // Todo el valor igual (aaaaaa, 111111)
    function esRepetitivo(valor) {
        const v = normalizar(valor);
        return /^([\p{L}\p{N}])\1*$/u.test(v);
    }

    // 3 o más caracteres idénticos seguidos (incluye ñ y tildes)
    function tieneRepetidos3Mas(valor) {
        const v = normalizar(valor);
        return /([\p{L}\p{N}])\1{2,}/u.test(v);
    }

    // Secuencias obvias (abc, 123 o descendente)
    function esSecuencia(valor) {
        const v = normalizar(valor);
        if (v.length < 3) return false;
        const bases = ["abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "0123456789"];
        for (const base of bases) {
            for (let i = 0; i <= v.length - 3; i++) {
                const slice = v.slice(i, i + 3);
                const rev = [...slice].reverse().join("");
                if (base.includes(slice) || base.includes(rev)) return true;
            }
        }
        return false;
    }

    function mostrarErrores(errores) {
        if (window.Swal && Swal.fire) {
            Swal.fire({
                icon: "warning",
                title: "Errores de validación",
                html: errores.join("<br>"),
                confirmButtonText: "Entendido"
            });
        } else {
            alert("Errores de validación:\n\n" + errores.join("\n"));
        }
    }

    form.addEventListener("submit", function (e) {
        const errores = [];

        for (const campo of Object.keys(reglas)) {
            const input = getInput(campo);
            if (!input) continue; // si no existe en este form, se omite

            const valor = normalizar(input.value);

            // 1) Formato base
            if (!reglas[campo].test(valor)) {
                errores.push(`El campo ${campo} no cumple con el formato permitido.`);
            }

            // 2) Todo repetido
            if (esRepetitivo(valor)) {
                errores.push(`El campo ${campo} no puede tener todos los caracteres iguales.`);
            }

            // 3) 3+ repetidos seguidos
            //    Permitimos dobles como "ll" en "Medellín".
            if (tieneRepetidos3Mas(valor)) {
                errores.push(`El campo ${campo} no puede tener más de 2 caracteres iguales seguidos.`);
            }

            // 4) Secuencias (evita cosas como "abc", "123456")
            //    No aplica a email ni dirección.
            if (!["correo_u", "direccion"].includes(campo) && esSecuencia(valor)) {
                errores.push(`El campo ${campo} no puede contener secuencias obvias.`);
            }

            // 5) Secuencias SOLO para dirección
            if (campo === "direccion" && esSecuencia(valor)) {
                errores.push(`El campo ${campo} no puede ser una secuencia obvia.`);
            }
        }

        if (errores.length > 0) {
            e.preventDefault();
            mostrarErrores(errores);
        }
    });
});




