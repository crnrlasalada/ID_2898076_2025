document.addEventListener('DOMContentLoaded', function () {
    // Forzar evento scroll al cargar la página
    window.dispatchEvent(new Event('scroll'));
});

const navbar = document.getElementById('navbar');
const logo = document.getElementById('logo');
const hamburger = document.getElementById('hamburger');
const menu = document.querySelector('.menu');
const scrollBtn = document.getElementById('scrollIndicator');

window.addEventListener('scroll', function () {
    const allowTransparency = !document.body.classList.contains('no-transparent-navbar');

    // Navbar y logo
    if (allowTransparency && window.scrollY > 0) {
        navbar.classList.add('navbar-colored');
        navbar.classList.remove('navbar-transparent');
        logo.src = logo.getAttribute("data-logoNegro");
        hamburger.style.color = '#000';
        document.querySelectorAll('.menu .item').forEach(i => i.style.color = '#000');
    } else {
        navbar.classList.remove('navbar-colored');
        if (allowTransparency) {
            navbar.classList.add('navbar-transparent');
            logo.src = logo.getAttribute("data-logoBlanco");
            hamburger.style.color = '#fff';
            document.querySelectorAll('.menu .item').forEach(i => i.style.color = '#fff');
        } else {
            navbar.classList.add('navbar-colored');
            logo.src = logo.getAttribute("data-logoNegro");
            hamburger.style.color = '#000';
            document.querySelectorAll('.menu .item').forEach(i => i.style.color = '#000');
        }
    }

    // Mostrar u ocultar botón scroll arriba
    if (window.scrollY > 200) {
        scrollBtn.style.display = "flex";
    } else {
        scrollBtn.style.display = "none";
    }
});

// Toggle menú con botón "Hamburguesa"
hamburger.addEventListener('click', () => {
    menu.classList.toggle('active');
    // Mantener color de los items según scroll
    document.querySelectorAll('.menu .item').forEach(i => i.style.color = window.scrollY > 0 ? '#000' : '#fff');
});

// Scroll hacia arriba al hacer clic
scrollBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});
