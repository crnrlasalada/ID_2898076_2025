from django.http import HttpResponseRedirect
from django.urls import reverse
from functools import wraps

# Decorador para requerir que el usuario esté logueado
def login_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if 'usuario_id' not in request.session:  # Suponiendo que guardas id de usuario en sesión
            return HttpResponseRedirect(reverse('reservas:home_'))
        return view_func(request, *args, **kwargs)
    return wrapper

# Decorador para requerir que el usuario tenga rol de cliente
def cliente_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        rol = request.session.get('rol', None)
        if rol != 'cliente':
            return HttpResponseRedirect(reverse('reservas:home_'))
        return view_func(request, *args, **kwargs)
    return wrapper

# Decorador para requerir que el usuario tenga rol de administrador
def admin_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        rol = request.session.get('rol', None)
        if rol != 'administrador':
            return HttpResponseRedirect(reverse('reservas:home_'))
        return view_func(request, *args, **kwargs)
    return wrapper

# Decorador para bloquear acceso si el usuario está logueado (solo para login o registro)
def logout_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if 'usuario_id' in request.session:
            return HttpResponseRedirect(reverse('reservas:home_'))
        return view_func(request, *args, **kwargs)
    return wrapper
