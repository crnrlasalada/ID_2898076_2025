from django.shortcuts import render, redirect, get_object_or_404
from .models import Habitaciones, Formulario, ReservasFormulario, AdministradorFormulario, Administrador, ReservasAdministrador, AdministradorAdministrador, ReservasHabitacion, AdministradorHabitacion,ImagenGaleria,ComprobantePago
from datetime import datetime, date
from django.db.models import Q
from django.contrib import messages
from datetime import timedelta
from django.core.mail import EmailMessage
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.templatetags.static import static
from django.http import HttpResponse
from django.conf import settings
from pdfkit.configuration import Configuration
import threading
import re
import threading
import imgkit
from .decorators import logout_required

# reservas/views.py
from django.shortcuts import render

def custom_404(request, exception):
    # Determina la ruta desde la que se accedió
    current_path = request.path_info
    if current_path.startswith('/administrador/'):
        home_url = 'administrador:home'  # Ajusta según el nombre de la URL del home del administrador
    elif current_path.startswith('/login/') or current_path.startswith('/inicio/'):  # Ajusta según tus rutas de login
        home_url = 'reservas:home_'  # Home de reservas
    else:
        home_url = 'reservas:home_'  # Valor por defecto

    return render(request, '404.html', {'home_url': home_url}, status=404)

@logout_required
def home(request):
    return render(request, 'reservas/home.html')


@logout_required
def habitaciones_clien(request):
    habitaciones = Habitaciones.objects.all().order_by('num_habitacion')
    return render(request, 'reservas/habitaciones.html', {
        'habitaciones': habitaciones
    })


@logout_required
def confirmar_reserva(request):
    return render(request, 'reservas/confirmar_reserva.html')


@logout_required
def servicios(request):
    return render(request, 'reservas/servicios.html')


@logout_required
def buscar(request):
    return render(request, 'reservas/buscar.html')


@logout_required
def soporte(request):
    return render(request, 'reservas/soporte.html')


@logout_required
def terminos(request):
    return render(request, 'reservas/terminos.html')


@logout_required
def galeria_clien(request):
    imagenes = ImagenGaleria.objects.all()
    return render(request, 'reservas/galeria.html', {'imagenes': imagenes})


@logout_required
def seleccionar_habi(request):
    # 1. Actualizar estado de habitaciones con reservas vencidas
    hoy = date.today()
    formularios_vencidos = Formulario.objects.filter(fecha_salida__lt=hoy)
    for f in formularios_vencidos:
        hab = f.id_habitacion
        if hab and hab.estado_habitacion != 'disponible':
            hab.estado_habitacion = 'disponible'
            hab.save()

    # Si viene del formulario inicial, guardamos datos base y reiniciamos selección
    if request.method == 'POST':
        fecha_entrada = request.POST.get('fecha_entrada')
        fecha_salida = request.POST.get('fecha_salida')
        adultos = int(request.POST.get('adultos') or 0)
        ninos = int(request.POST.get('ninos') or 0)
        cantidad_habitaciones = int(request.POST.get('habitaciones') or 1)

        request.session['reserva_info'] = {
            'fecha_entrada': fecha_entrada,
            'fecha_salida': fecha_salida,
            'adultos': adultos,
            'ninos': ninos,
            'habitaciones': cantidad_habitaciones,
        }
        # clave única: guardamos sólo IDs en 'reservadas'
        request.session['reservadas'] = []

    datos = request.session.get('reserva_info')
    if not datos:
        return render(request, 'reservas/selecc_habi.html', {'habitaciones': []})

    fecha_entrada = datos['fecha_entrada']
    fecha_salida = datos['fecha_salida']
    adultos = int(datos['adultos'])
    ninos = int(datos['ninos'])
    cantidad_habitaciones = int(datos['habitaciones'])

    total_personas = adultos + ninos
    capacidad_por_hab = max((total_personas + cantidad_habitaciones - 1) // cantidad_habitaciones, 2)

    # IDs ya seleccionadas
    reservadas = request.session.get('reservadas', [])
    reservadas_ids = [int(x) for x in reservadas]

    # Fechas a objetos
    fecha_entrada_dt = datetime.strptime(fecha_entrada, '%Y-%m-%d').date()
    fecha_salida_dt = datetime.strptime(fecha_salida, '%Y-%m-%d').date()

    # Habitaciones ocupadas por cruce de fechas
    habitaciones_ocupadas = Formulario.objects.filter(
        Q(fecha_entrada__lt=fecha_salida_dt) & Q(fecha_salida__gt=fecha_entrada_dt)
    ).values_list('id_habitacion_id', flat=True)

    # Filtrar por capacidad
    if capacidad_por_hab == 1:
        habitaciones_disponibles = Habitaciones.objects.filter(cantidad_personas=1)
    elif capacidad_por_hab == 2:
        habitaciones_disponibles = Habitaciones.objects.filter(cantidad_personas=2)
    elif capacidad_por_hab in [3,4]:
        habitaciones_disponibles = Habitaciones.objects.filter(cantidad_personas__in=[3,4])
    else:
        habitaciones_disponibles = Habitaciones.objects.filter(cantidad_personas__gte=capacidad_por_hab, cantidad_personas__lte=6)

    # Excluir ocupadas y ya seleccionadas
    habitaciones_disponibles = habitaciones_disponibles.exclude(id_habitacion__in=habitaciones_ocupadas).exclude(id_habitacion__in=reservadas_ids)

    dias_estadia = max((fecha_salida_dt - fecha_entrada_dt).days, 1)
    for hab in habitaciones_disponibles:
        hab.precio_total = hab.precios * dias_estadia

    # Si ya seleccionó el número requerido, redirigir al formulario
    if len(reservadas_ids) >= cantidad_habitaciones:
        return redirect('reservas:formulario_')

    # logs útiles para debug
    print("🔁 Selección activa (IDs):", reservadas_ids)
    print("📌 Disponibles:", habitaciones_disponibles.count())

    return render(request, 'reservas/selecc_habi.html', {
        'habitaciones': habitaciones_disponibles,
        'fecha_entrada': fecha_entrada,
        'fecha_salida': fecha_salida,
        'adultos': adultos,
        'ninos': ninos,
        'cantidad_habitaciones': cantidad_habitaciones,
        'dias_estadia': dias_estadia,
    })


@logout_required
def guardar_reserva_individual(request):
    if request.method == 'POST':
        habitacion_id = request.POST.get('habitacion_id')
        if not habitacion_id:
            return redirect('reservas:seleccionar_habi_')

        reserva_info = request.session.get('reserva_info')
        if not reserva_info:
            return redirect('reservas:seleccionar_habi_')

        total_habitaciones = int(reserva_info.get('habitaciones', 1))
        reservadas = request.session.get('reservadas', [])

        try:
            habitacion = Habitaciones.objects.get(id_habitacion=int(habitacion_id))
        except Habitaciones.DoesNotExist:
            print(f"❌ Habitación id {habitacion_id} no existe")
            return redirect('reservas:seleccionar_habi_')

        # agregar id si no existe
        if str(habitacion.id_habitacion) not in [str(x) for x in reservadas]:
            reservadas.append(str(habitacion.id_habitacion))
            # re-asignar para forzar guardado de sesión
            request.session['reservadas'] = reservadas

            # opcional: guardar datos rápidos para mostrar en front (no obligatorio)
            request.session['tipo_habitacion'] = habitacion.tipo_habitacion
            request.session['precio_habitacion'] = habitacion.precios

        print("✅ Reservadas ahora (IDs):", request.session.get('reservadas'))

        if len(reservadas) >= total_habitaciones:
            return redirect('reservas:formulario_')

        return redirect('reservas:seleccionar_habi_')

    return redirect('reservas:seleccionar_habi_')


@logout_required
def formulario(request):
    datos = request.session.get('reserva_info')
    reservadas = request.session.get('reservadas', [])

    if not datos:
        return redirect('reservas:seleccionar_habi_')

    if not reservadas:
        # mostramos mensaje y redirigimos al selector (evita loops)
        messages.error(request, "Debes seleccionar una habitación antes de continuar.")
        return redirect('reservas:seleccionar_habi_')

    # convertir a ints
    try:
        ids = [int(x) for x in reservadas]
    except Exception:
        ids = []

    habitaciones = Habitaciones.objects.filter(id_habitacion__in=ids)

    # calcular días y total
    fecha_entrada = datetime.strptime(datos['fecha_entrada'], '%Y-%m-%d').date()
    fecha_salida = datetime.strptime(datos['fecha_salida'], '%Y-%m-%d').date()
    dias_estadia = max((fecha_salida - fecha_entrada).days, 1)

    total_reserva = sum(h.precios * dias_estadia for h in habitaciones)

    print("✅ Sesión recibida (reservadas IDs):", ids)
    print("✅ Sesión recibida (reserva_info):", datos)

    return render(request, 'reservas/formulario.html', {
        'habitaciones': habitaciones,
        'fecha_entrada': datos['fecha_entrada'],
        'fecha_salida': datos['fecha_salida'],
        'adultos': datos['adultos'],
        'ninos': datos['ninos'],
        'cantidad_habitaciones': datos['habitaciones'],
        'total_reserva': total_reserva,
        'dias_estadia': dias_estadia,
    })


@logout_required
def editar_datos_formulario(request, id_formulario):
    formulario = get_object_or_404(Formulario, id_formulario=id_formulario)

    if request.method == 'POST':
        formulario.nombre = request.POST['nombre']
        formulario.apellido = request.POST['apellido']
        formulario.cedula = request.POST['cedula']
        formulario.correo_u = request.POST['correo_u']
        formulario.direccion = request.POST['direccion']
        formulario.telefono = request.POST['telefono']
        formulario.ciudad = request.POST['ciudad']
        formulario.pais = request.POST['pais']
        formulario.save()

        return redirect('reservas:metodo_pago', id_formulario=id_formulario)


@logout_required
def confirmar_reserva(request):
    datos = request.session.get('reserva_info')
    reservadas = request.session.get('reservadas', [])

    if not datos or not reservadas:
        return redirect('reservas:seleccionar_habi_')

    total_personas = int(datos['adultos']) + int(datos['ninos'])

    cedula = request.POST.get('cedula')
    correo = request.POST.get('correo_u')
    direccion = request.POST.get('direccion')
    telefono = request.POST.get('telefono')
    ciudad = request.POST.get('ciudad')
    pais = request.POST.get('pais')
    peticiones = request.POST.get('peticiones')

    admin = Administrador.objects.get(id_admin=399387)
    reservas_admin = ReservasAdministrador.objects.get(id_admin=399387)
    admin_admin = AdministradorAdministrador.objects.get(id_admin=399387)

    # Calcular total de la reserva y anticipo
    fecha_entrada_dt = datetime.strptime(datos['fecha_entrada'], '%Y-%m-%d').date()
    fecha_salida_dt = datetime.strptime(datos['fecha_salida'], '%Y-%m-%d').date()
    dias_estadia = max((fecha_salida_dt - fecha_entrada_dt).days, 1)

    total_reserva = 0
    for id_hab in reservadas:
        hab = Habitaciones.objects.get(id_habitacion=int(id_hab))
        total_reserva += hab.precios * dias_estadia

    anticipo_reserva = total_reserva / 2

    formulario_guardado = None

    for i, id_hab in enumerate(reservadas):
        habitacion = Habitaciones.objects.get(id_habitacion=int(id_hab))

        nombre_principal = request.POST.get('nombre')
        apellido_principal = request.POST.get('apellido')

        if i == 0:
            nombre_extra = None
            apellido_extra = None
        else:
            nombre_extra = request.POST.get(f'nombre_extra_{i}')
            apellido_extra = request.POST.get(f'apellido_extra_{i}')

        # === Guardar en Formulario (usa Habitaciones) ===
        formulario_guardado = Formulario.objects.create(
            nombre=nombre_principal,
            apellido=apellido_principal,
            cedula=cedula,
            correo_u=correo,
            direccion=direccion,
            telefono=telefono,
            ciudad=ciudad,
            pais=pais,
            peticiones=peticiones,
            fecha_entrada=datos['fecha_entrada'],
            fecha_salida=datos['fecha_salida'],
            id_admin=admin,
            id_habitacion=habitacion,
            nombre_extra=nombre_extra,
            apellido_extra=apellido_extra,
            cantidad=total_personas,
            estado='en_espera',
            precio_total=total_reserva,
            anticipo=anticipo_reserva
        )

        # Buscar equivalentes en ReservasHabitacion y AdministradorHabitacion
        try:
            reservas_hab = ReservasHabitacion.objects.get(num_habitacion=habitacion.num_habitacion)
        except ReservasHabitacion.DoesNotExist:
            reservas_hab = None
            print(f'❌ No existe habitación en reservas con número {habitacion.num_habitacion}')

        try:
            admin_hab = AdministradorHabitacion.objects.get(num_habitacion=habitacion.num_habitacion)
        except AdministradorHabitacion.DoesNotExist:
            admin_hab = None
            print(f'❌ No existe habitación en administrador con número {habitacion.num_habitacion}')

        # === Guardar en ReservasFormulario (usa ReservasHabitacion) ===
        if reservas_hab:
            ReservasFormulario.objects.create(
                nombre=nombre_principal,
                apellido=apellido_principal,
                cedula=cedula,
                correo_u=correo,
                direccion=direccion,
                telefono=telefono,
                cuidad=ciudad,
                pais=pais,
                peticiones=peticiones,
                fecha_entrada=datos['fecha_entrada'],
                fecha_salida=datos['fecha_salida'],
                admin=reservas_admin,
                habitacion=reservas_hab,
                nombre_extra=nombre_extra,
                apellido_extra=apellido_extra
            )
            reservas_hab.estado_habitacion = 'reservada'
            reservas_hab.save()

        # === Guardar en AdministradorFormulario (usa AdministradorHabitacion) ===
        if admin_hab:
            AdministradorFormulario.objects.create(
                nombre=nombre_principal,
                apellido=apellido_principal,
                cedula=cedula,
                correo_u=correo,
                direccion=direccion,
                telefono=telefono,
                cuidad=ciudad,
                pais=pais,
                peticiones=peticiones,
                fecha_entrada=datos['fecha_entrada'],
                fecha_salida=datos['fecha_salida'],
                admin=admin_admin,
                habitacion=admin_hab,
                nombre_extra=nombre_extra,
                apellido_extra=apellido_extra
            )
            admin_hab.estado_habitacion = 'reservada'
            admin_hab.save()

        # Actualizar estado de la habitación principal
        habitacion.estado_habitacion = 'reservada'
        habitacion.save()

    # Guardar todos los datos necesarios en la sesión
    request.session['reserva_info'] = {
        'fecha_entrada': datos['fecha_entrada'],
        'fecha_salida': datos['fecha_salida'],
        'adultos': datos['adultos'],
        'ninos': datos['ninos'],
        'total_reserva': total_reserva,
        'dias_estadia': dias_estadia,
        'habitaciones': [hab.id_habitacion for hab in Habitaciones.objects.filter(id_habitacion__in=reservadas)]
    }
    request.session['id_formulario_temporal'] = formulario_guardado.id_formulario

    # Redirigir a método de pago con el último formulario registrado
    return redirect('reservas:metodo_pago', id_formulario=formulario_guardado.id_formulario)


@logout_required
def galeria_clien(request):
    imagenes = ImagenGaleria.objects.all()
    return render(request, 'reservas/galeria.html', {'imagenes': imagenes})


# Hilo para envío de correos
class EmailThread(threading.Thread):
    def __init__(self, email_usuario, email_admin):
        self.email_usuario = email_usuario
        self.email_admin = email_admin
        threading.Thread.__init__(self)

    def run(self):
        self.email_usuario.send()
        self.email_admin.send()


# Hilo para envío de correos
class EmailThread(threading.Thread):
    def __init__(self, email_usuario, email_admin):
        self.email_usuario = email_usuario
        self.email_admin = email_admin
        threading.Thread.__init__(self)

    def run(self):
        self.email_usuario.send()
        self.email_admin.send()


@logout_required
def metodo_pago(request, id_formulario):
    formulario = get_object_or_404(Formulario, id_formulario=id_formulario)

    # Recuperar datos de la sesión
    reserva_info = request.session.get('reserva_info', {})

    # Buscar todas las filas 'Formulario' que corresponderían a la misma reserva
    # (mismo cliente y mismas fechas). Ajusta filtros si usas otro criterio.
    formularios = Formulario.objects.filter(
        cedula=formulario.cedula,
        fecha_entrada=formulario.fecha_entrada,
        fecha_salida=formulario.fecha_salida,
    ).order_by('id_formulario')

    if request.method == 'POST' and request.FILES.get('comprobante'):
        imagen = request.FILES['comprobante']

        comprobante_nombre = imagen.name
        comprobante_bytes = imagen.file.read()
        content_type = imagen.content_type

        ComprobantePago.objects.create(
            formulario=formulario,
            imagen_comprobante=imagen
        )

        habitaciones = []
        subtotal = 0
        # Calcular noches (mínimo 1)
        noches = (formulario.fecha_salida - formulario.fecha_entrada).days
        noches = noches if noches >= 1 else 1

        # Recorremos todas las filas relacionadas y sumamos
        for f in formularios:
            hab = f.id_habitacion  # Habitaciones desde cada Formulario
            if not hab:
                continue
            total_hab = (hab.precios or 0) * noches
            subtotal += total_hab
            habitaciones.append({
                'numero': hab.num_habitacion,
                'tipo': hab.tipo_habitacion,
                'precio': hab.precios,
                'total': total_hab
            })

        # Debug (temporal): imprime en consola lo que encontró
        print("DEBUG: formularios encontrados:", [f.id_formulario for f in formularios])
        print("DEBUG: habitaciones en resumen:", [h['numero'] for h in habitaciones])
        print("DEBUG: noches:", noches, "subtotal:", subtotal)

        total = subtotal
        anticipo = total // 2
        saldo = total - anticipo

        # Correo al usuario (solo HTML, sin imagen)
        html_correo_usuario = render_to_string('reservas/correo_reserva.html', {
            'nombre': formulario.nombre,
            'correo': formulario.correo_u,
            'telefono': formulario.telefono,
            'ciudad': formulario.ciudad,
            'pais': formulario.pais,
            'fecha_entrada': formulario.fecha_entrada,
            'fecha_salida': formulario.fecha_salida,
            'habitaciones': habitaciones,
            'noches': noches,
            'subtotal': subtotal,
            'total': total,
            'anticipo': anticipo,
            'saldo': saldo,
        })

        email_usuario = EmailMultiAlternatives(
            'Resumen de tu reserva - Hotel Casa Luna',
            '',  # Cuerpo de texto plano vacío, ya que usamos HTML
            'eldescansoacaf@gmail.com',
            [formulario.correo_u],
        )
        email_usuario.attach_alternative(html_correo_usuario, "text/html")

        # Correo al admin
        html_correo_admin = render_to_string('reservas/nueva_reserva.html', {
            'nombre': formulario.nombre,
            'apellido': formulario.apellido,
        })

        email_admin = EmailMessage(
            'Nueva reserva en espera',
            html_correo_admin,
            'eldescansoacaf@gmail.com',
            ['eldescansoacaf@gmail.com'],
        )
        email_admin.content_subtype = "html"
        email_admin.attach(comprobante_nombre, comprobante_bytes, content_type)

        EmailThread(email_usuario, email_admin).start()
        return redirect('reservas:resumen_pago')

    # Pasar datos adicionales al template
    context = {
        'formulario': formulario,
        'fecha_entrada': reserva_info.get('fecha_entrada', formulario.fecha_entrada),
        'fecha_salida': reserva_info.get('fecha_salida', formulario.fecha_salida),
        'adultos': reserva_info.get('adultos', 0),
        'ninos': reserva_info.get('ninos', 0),
        'total_reserva': reserva_info.get('total_reserva', formulario.precio_total),
        'dias_estadia': reserva_info.get('dias_estadia', 1),
        'habitaciones': [Habitaciones.objects.get(id_habitacion=id) for id in reserva_info.get('habitaciones', [])]
    }
    return render(request, 'reservas/metodo_pago.html', context)


@logout_required
def resumen_pago(request):
    return render(request, 'reservas/resumen_pago.html')