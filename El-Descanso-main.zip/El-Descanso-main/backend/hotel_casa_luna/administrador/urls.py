from django.urls import path
from . import views

app_name = 'administrador'

urlpatterns = [
    path('', views.home, name='home'),  # /administrador/
    path('redireccion/', views.redireccion_por_rol, name='redireccion'),  # /administrador/redireccion/
    path('logout/', views.cerrar_sesion, name='cerrar_sesion'),

    # Perfil
    path('perfil/', views.ver_perfil, name='ver_perfil'),
    path('actualizar/', views.actualizar_datos, name='actualizar_datos'),

    # Gestión de habitaciones
    path('habitaciones/registrar/', views.registrar_habitacion, name='registrar_habitacion'),
    path('habitaciones/', views.habitaciones_admin, name='habitaciones_admin'),
    path('habitaciones/modificar/<int:id_habitacion>/', views.modificar_habitacion, name='modificar'),
    path('habitaciones/eliminar/<int:id_habitacion>/', views.eliminar_habitacion, name='eliminar_habitacion'),

    # Reservas
    path('historial/', views.historial, name='historial'),
    path('reserva/<int:id>/', views.detalle_reserva, name='detalle_reserva'),
    path('reserva/modificar/<int:id>/', views.modificar_reservas, name='modificar_reservas'),
    path('reserva/eliminar/<int:id>/', views.eliminar_reservas, name='eliminar_reservas'),
    path('confirmacion/<int:id>/', views.confirmar_reserva, name='confirmacion'),
    path('cancelar_reserva/<int:id>/', views.cancelar_reserva, name='cancelar_reserva'),

    # Galería
    path('galeria/', views.galeria_admin, name='galeria_admin'),

    # Páginas estáticas
    path('confirmacion/<int:id_formulario>/', views.confirmacion, name='confirmacion'),
    path('soporte/', views.soporte, name='soporte'),
    path('terminos/', views.terminos, name='terminos'),
]
