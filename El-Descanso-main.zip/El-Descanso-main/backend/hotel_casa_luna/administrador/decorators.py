# administrador/decorators.py
from django.http import HttpResponseRedirect
from django.urls import reverse
from functools import wraps

def admin_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        rol = request.session.get('rol', None)
        if rol != 'administrador':
            # Redirige al login si no es administrador
            return HttpResponseRedirect(reverse('login:inicio'))
        return view_func(request, *args, **kwargs)
    return _wrapped_view

# administrador/decorators.py
from django.shortcuts import get_object_or_404, redirect
from reservas.models import Formulario
from functools import wraps

def reserva_valida(view_func):
    @wraps(view_func)
    def _wrapped_view(request, id, *args, **kwargs):
        reserva = get_object_or_404(Formulario, id_formulario=id)
        if reserva.estado not in ["activo", "en_espera"]:
            # Si no está en los estados permitidos, redirige al historial
            return redirect('administrador:historial')
        return view_func(request, id, *args, **kwargs)
    return _wrapped_view