from django import forms
from django.forms.widgets import ClearableFileInput
from reservas.models import ImagenGaleria, Habitaciones


# =========================
# WIDGET PERSONALIZADO PARA QUITAR "CLEAR" Y "CURRENTLY"
# =========================
class CustomClearableFileInput(ClearableFileInput):
    template_name = 'widgets/custom_clearable_file_input.html'


# =========================
# FORMULARIO PARA GALERÍA
# =========================
class ImagenGaleriaForm(forms.ModelForm):
    class Meta:
        model = ImagenGaleria
        fields = ['imagen']
        widgets = {
            'imagen': forms.ClearableFileInput(
                attrs={'class': 'form-control', 'id': 'id_imagen', 'accept': 'image/*'}
            ),
        }
        labels = {
            'imagen': 'Agregar una imagen',  # Cambia la etiqueta aquí
        }


# =========================
# FORMULARIO PARA REGISTRAR HABITACIONES
# =========================
class HabitacionForm(forms.ModelForm):
    class Meta:
        model = Habitaciones
        fields = [
            'tipo_habitacion',
            'precios',
            'estado_habitacion',
            'num_habitacion',
            'descripcion',
            'cantidad_personas',
            'nombre_imagen'
        ]
        widgets = {
            'tipo_habitacion': forms.TextInput(attrs={'class': 'form-control'}),
            'precios': forms.NumberInput(attrs={'class': 'form-control'}),
            'estado_habitacion': forms.Select(
                choices=[
                    ('Disponible', 'Disponible'),
                    ('Ocupada', 'Reservada'),
                ],
                attrs={'class': 'form-select'}
            ),
            'num_habitacion': forms.NumberInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'cantidad_personas': forms.NumberInput(attrs={'class': 'form-control'}),
            'nombre_imagen': forms.ClearableFileInput(
                attrs={'class': 'form-control', 'accept': 'image/*'}
            ),
        }

    # ==============
    # VALIDACIONES
    # ==============
    def clean_precios(self):
        precios = self.cleaned_data.get('precios')
        if precios is None or precios <= 0:
            raise forms.ValidationError("El precio debe ser mayor que 0.")
        return precios

    def clean_num_habitacion(self):
        num_habitacion = self.cleaned_data.get('num_habitacion')
        if num_habitacion is None or num_habitacion <= 0:
            raise forms.ValidationError("El número de habitación debe ser mayor que 0.")
        return num_habitacion

    def clean_cantidad_personas(self):
        cantidad_personas = self.cleaned_data.get('cantidad_personas')
        if cantidad_personas is None or cantidad_personas <= 0:
            raise forms.ValidationError("La capacidad debe ser mayor que 0.")
        return cantidad_personas

    def clean_nombre_imagen(self):
        imagen = self.cleaned_data.get('nombre_imagen')
        if imagen:
            if imagen.size > 5 * 1024 * 1024:  # 5 MB
                raise forms.ValidationError("La imagen no debe exceder los 5MB.")
            if not imagen.content_type in ['image/jpeg', 'image/png']:
                raise forms.ValidationError("Solo se permiten imágenes JPEG o PNG.")
        return imagen


# =========================
# FORMULARIO PARA MODIFICAR HABITACIONES
# =========================
class ModificarForm(forms.ModelForm):
    class Meta:
        model = Habitaciones
        fields = [
            'tipo_habitacion',
            'precios',
            'estado_habitacion',
            'num_habitacion',
            'descripcion',
            'cantidad_personas',
            'nombre_imagen'
        ]
        widgets = {
            'tipo_habitacion': forms.TextInput(attrs={'class': 'form-control'}),
            'precios': forms.NumberInput(attrs={'class': 'form-control'}),
            'estado_habitacion': forms.Select(
                choices=[
                    ('Disponible', 'Disponible'),
                    ('Ocupada', 'Reservada'),
                ],
                attrs={'class': 'form-select'}
            ),
            'num_habitacion': forms.NumberInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'cantidad_personas': forms.NumberInput(attrs={'class': 'form-control'}),
            # 👇 Aquí usamos el widget personalizado
            'nombre_imagen': CustomClearableFileInput(
                attrs={'class': 'form-control', 'accept': 'image/*'}
            ),
        }
