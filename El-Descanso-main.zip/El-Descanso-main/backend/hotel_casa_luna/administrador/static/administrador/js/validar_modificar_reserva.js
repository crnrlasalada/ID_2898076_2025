document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form');

    const reglas = {
        nombre: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        cedula: /^(?!1234567890$)\d{6,10}$/,
        telefono: /^\d{10}$/,
        correo_u: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}$/,
        direccion: /^.{5,100}$/,
        pais: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        ciudad: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        nombre_extra: /^$|^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        apellido_extra: /^$|^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/,
        cantidad: /^[1-9]\d{0,1}$/ // 1 a 99 personas
    };

    function esRepetitivo(valor) {
        return /^([a-zA-Z0-9])\1*$/.test(valor);
    }

    function tieneMuchasLetrasIguales(valor) {
        return /(.)\1{2,}/u.test(valor);
    }

    function esSecuencia(valor) {
        const secuencias = [
            "abcdefghijklmnopqrstuvwxyz",
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
            "0123456789"
        ];
        for (let seq of secuencias) {
            if (seq.includes(valor) || seq.includes(valor.split("").reverse().join(""))) {
                return true;
            }
        }
        return false;
    }

    form.addEventListener("submit", function (e) {
        let errores = [];

        Object.keys(reglas).forEach(campo => {
            const input = form.querySelector(`[name="${campo}"]`);
            if (input) {
                const valor = input.value.trim();

                // Validación principal
                if (!reglas[campo].test(valor)) {
                    errores.push(`El campo ${campo} no es válido.`);
                }

                // Reglas extra (excepto para 'cantidad')
                if (campo !== "cantidad") {
                    if (esRepetitivo(valor)) {
                        errores.push(`El campo ${campo} no puede tener todos los caracteres iguales.`);
                    }
                    if (tieneMuchasLetrasIguales(valor)) {
                        errores.push(`El campo ${campo} no puede tener más de 2 caracteres idénticos seguidos.`);
                    }
                    if (!["correo_u", "direccion"].includes(campo) && esSecuencia(valor)) {
                        errores.push(`El campo ${campo} no puede contener secuencias obvias.`);
                    }
                    if (campo === "direccion" && esSecuencia(valor)) {
                        errores.push(`El campo ${campo} no puede ser una secuencia obvia.`);
                    }
                }
            }
        });

        if (errores.length > 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'error',
                title: 'Errores de validación',
                html: errores.map(err => `<p>${err}</p>`).join(""),
                confirmButtonText: 'Entendido',
                confirmButtonColor: '#d33'
            });
        }
    });
});