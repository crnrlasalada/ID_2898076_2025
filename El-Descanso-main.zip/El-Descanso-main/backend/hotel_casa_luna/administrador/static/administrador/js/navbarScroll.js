document.addEventListener('DOMContentLoaded', function () {
    // Forzar evento scroll al cargar la página
    window.dispatchEvent(new Event('scroll'));
});

const navbar = document.getElementById('navbar');
const logo = document.getElementById('logo');
const hamburger = document.getElementById('hamburger');
const menu = document.querySelector('.menu');

// Crear botón scroll hacia arriba dinámicamente
const scrollBtn = document.createElement('button');
scrollBtn.id = 'scrollIndicator';
scrollBtn.className = 'scroll-indicator';
scrollBtn.title = 'Ir arriba';
scrollBtn.innerText = '↑';
scrollBtn.style.display = 'none'; // oculto inicialmente
document.body.appendChild(scrollBtn);

window.addEventListener('scroll', function () {
    const allowTransparency = !document.body.classList.contains('no-transparent-navbar');

    // Cambiar navbar y logo según scroll
    if (allowTransparency && window.scrollY > 0) {
        navbar.classList.add('navbar-colored');
        navbar.classList.remove('navbar-transparent');
        logo.src = logo.getAttribute("data-logoNegro");
    } else {
        navbar.classList.remove('navbar-colored');
        if (allowTransparency) {
            navbar.classList.add('navbar-transparent');
            logo.src = logo.getAttribute("data-logoBlanco");
        } else {
            navbar.classList.add('navbar-colored');
            logo.src = logo.getAttribute("data-logoNegro");
        }
    }

    // Mostrar u ocultar botón scroll arriba
    scrollBtn.style.display = window.scrollY > 200 ? 'flex' : 'none';
});

// Toggle menú hamburguesa
hamburger.addEventListener('click', () => {
    menu.classList.toggle('active');
});

// Scroll hacia arriba al hacer clic
scrollBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});







