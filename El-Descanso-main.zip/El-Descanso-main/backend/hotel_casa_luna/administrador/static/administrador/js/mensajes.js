document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("formActualizar");

    // Funciones reutilizadas
    function esRepetitivo(valor) {
        return /^([a-zA-Z0-9])\1*$/.test(valor);
    }

    function tieneMuchasLetrasIguales(valor) {
        return /(.)\1{2,}/u.test(valor);
    }

    function esSecuencia(valor) {
        const secuencias = [
            "abcdefghijklmnopqrstuvwxyz",
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
            "0123456789"
        ];
        for (let seq of secuencias) {
            if (seq.includes(valor) || seq.includes(valor.split("").reverse().join(""))) {
                return true;
            }
        }
        return false;
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        let errores = [];

        const telefono = form.telefono.value.trim();
        const correo = form.correo.value.trim();
        const contraseña = form.contraseña.value.trim();

        // Validación teléfono
        if (!/^\d{10}$/.test(telefono)) {
            errores.push("El teléfono debe tener 10 dígitos.");
        }

        // Validación correo con regex
        const correoRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}$/;
        if (!correoRegex.test(correo)) {
            errores.push("El correo no es válido.");
        } else {
            // Reglas extra para correo
            if (esRepetitivo(correo)) {
                errores.push("El correo no puede tener todos los caracteres iguales.");
            }
            if (tieneMuchasLetrasIguales(correo)) {
                errores.push("El correo no puede tener más de 2 caracteres idénticos seguidos.");
            }
            if (esSecuencia(correo)) {
                errores.push("El correo no puede contener secuencias obvias.");
            }
        }

        // Validación contraseña
        if (contraseña) {
            if (contraseña.length < 8) {
                errores.push("La contraseña debe tener al menos 8 caracteres.");
            }
            if (!/[a-zA-Z]/.test(contraseña) || !/[0-9]/.test(contraseña)) {
                errores.push("La contraseña debe contener letras y números.");
            }
        }

        // Mostrar errores si los hay
        if (errores.length > 0) {
            Swal.fire({
                icon: 'error',
                title: 'Errores de validación',
                html: errores.map(err => `<p>${err}</p>`).join(""),
                confirmButtonText: 'Entendido',
                confirmButtonColor: '#d33'
            });
        } else {
            Swal.fire({
                icon: 'success',
                title: 'Validacion exitosa',
                text: 'Todos los campos son validos',
                confirmButtonText: 'Continuar',
                confirmButtonColor: '#28a745'
            }).then(() => {
                form.submit(); // se envian despues de confirmar
            })
        }
    });

    // Mensajes de Django (se mantienen si el servidor envía messages)
    const djangoMessages = JSON.parse(document.getElementById('django-messages')?.textContent || '[]');
    djangoMessages.forEach(msg => {
        Swal.fire({
            icon: msg.tags.includes('success') ? 'success' : msg.tags.includes('error') ? 'error' : 'info',
            title: msg.message,
            confirmButtonText: 'Aceptar',
            confirmButtonColor: '#6c63ff'
        });
    });
});

