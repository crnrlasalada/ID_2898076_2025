document.addEventListener("DOMContentLoaded", () => {
    // Animación de conteo en métricas
    document.querySelectorAll(".number").forEach(el => {
        let value = parseFloat(el.dataset.value) || 0;
        let counter = 0;
        let steps = 50; // cantidad de pasos de la animación
        let increment = value / steps;

        let interval = setInterval(() => {
            counter += increment;
            if (counter >= value) {
                counter = value;
                clearInterval(interval);
            }
            el.textContent = Math.round(counter).toLocaleString();
        }, 20);
    });

    // Gráfico de ocupación mensual con Chart.js
    const ctx = document.getElementById('ocupacionChart');
    if (ctx) {
        const ocupado = parseFloat(ctx.dataset.ocupado) || 0;
        const libre = 100 - ocupado;

        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Ocupado (%)', 'Libre (%)'],
                datasets: [{
                    data: [ocupado, libre],
                    backgroundColor: ['#4CAF50', '#E0E0E0']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }
});
