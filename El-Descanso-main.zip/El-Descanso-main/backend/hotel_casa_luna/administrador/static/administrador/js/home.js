// ====== Animar contadores ======
function animateCounter(id, target, prefix = "", suffix = "") {
    let count = 0;
    const speed = target / 50;
    const update = () => {
        if (count < target) {
            count += Math.ceil(speed);
            document.getElementById(id).innerText = prefix + count + suffix;
            requestAnimationFrame(update);
        } else {
            document.getElementById(id).innerText = prefix + target + suffix;
        }
    };
    update();
}

document.querySelectorAll(".number").forEach(el => {
    let value = parseFloat(el.dataset.value) || 0;
    animateCounter(el.id, value);
});


// ====== Gráfico de ocupación mensual ======
const ctx = document.getElementById("ocupacionChart").getContext("2d");
new Chart(ctx, {
    type: "line",
    data: {
        labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago"],
        datasets: [{
            label: "Ocupación (%)",
            data: [75, 60, 80, 90, 85, 70, 88, 95],
            borderColor: "#2563eb",
            backgroundColor: "rgba(37, 99, 235, 0.2)",
            fill: true,
            tension: 0.4,
            pointRadius: 5,
            pointBackgroundColor: "#2563eb"
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: true }
        },
        scales: {
            y: { min: 0, max: 100 }
        }
    }
});
