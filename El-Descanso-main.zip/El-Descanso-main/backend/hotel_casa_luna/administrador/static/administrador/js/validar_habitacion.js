document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form');

    const reglas = {
        tipo_habitacion: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]{2,50}$/, // Solo letras y espacios
        precios: /^[1-9]\d*(\.\d{1,2})?$/, // Números positivos con hasta 2 decimales
        estado_habitacion: /^(Disponible|Ocupada)$/, // Solo valores permitidos
        num_habitacion: /^[1-9]\d{0,3}$/, // 1 a 4 dígitos, no empieza en 0
        descripcion: /^.{5,600}$/, // Entre 5 y 600 caracteres
        cantidad_personas: /^[1-9]\d{0,1}$/ // 1 a 99 personas
    };

    function esRepetitivo(valor) {
        return /^([a-zA-Z0-9])\1*$/.test(valor);
    }

    function tieneMuchasLetrasIguales(valor) {
        return /(.)\1{2,}/u.test(valor);
    }

    function esSecuencia(valor) {
        const secuencias = [
            "abcdefghijklmnopqrstuvwxyz",
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
            "0123456789"
        ];
        for (let seq of secuencias) {
            if (seq.includes(valor) || seq.includes(valor.split("").reverse().join(""))) {
                return true;
            }
        }
        return false;
    }

    form.addEventListener("submit", function (e) {
        let errores = [];

        Object.keys(reglas).forEach(campo => {
            const input = form.querySelector(`[name="${campo}"]`);
            if (input) {
                const valor = input.value.trim();

                // Validación principal
                if (!reglas[campo].test(valor)) {
                    errores.push(`El campo ${campo.replace("_", " ")} no es válido.`);
                }

                // Reglas extra para texto
                if (!["cantidad_personas", "precios", "num_habitacion", "estado_habitacion"].includes(campo)) {
                    if (esRepetitivo(valor)) {
                        errores.push(`El campo ${campo.replace("_", " ")} no puede tener todos los caracteres iguales.`);
                    }
                    if (tieneMuchasLetrasIguales(valor)) {
                        errores.push(`El campo ${campo.replace("_", " ")} no puede tener más de 2 caracteres idénticos seguidos.`);
                    }
                    if (!["descripcion"].includes(campo) && esSecuencia(valor)) {
                        errores.push(`El campo ${campo.replace("_", " ")} no puede contener secuencias obvias.`);
                    }
                    if (campo === "descripcion" && esSecuencia(valor)) {
                        errores.push(`El campo ${campo.replace("_", " ")} no puede ser una secuencia obvia.`);
                    }
                }

                // Regla especial para precios: no secuencias numéricas
                if (campo === "precios" && esSecuencia(valor)) {
                    errores.push(`El campo ${campo.replace("_", " ")} no puede ser una secuencia numérica obvia.`);
                }
            }
        });

        if (errores.length > 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'error',
                title: 'Errores de validación',
                html: errores.map(err => `<p>${err}</p>`).join(""),
                confirmButtonText: 'Entendido',
                confirmButtonColor: '#d33'
            });
        }
    });

    // Restringir entrada en campos numéricos
    ["precios", "num_habitacion", "cantidad_personas"].forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.addEventListener("input", function () {
                this.value = this.value.replace(/[^0-9.]/g, "");
            });
        }
    });
});