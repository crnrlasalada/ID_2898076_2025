from reservas.models import Administrador

def datos_usuario(request):
    contexto = {}
    
    if request.session.get('admin_id'):
        try:
            admin = Administrador.objects.get(id_admin=request.session['admin_id'])
            contexto = {
                'nombre': admin.nombre,
                'correo': admin.correo,
                'tipo_usuario': 'Administrador',
            }
        except Administrador.DoesNotExist:
            pass

    return contexto
