from django.shortcuts import render, redirect,get_object_or_404
from reservas.models import Administrador, ImagenGaleria,Formulario,Habitaciones
from django.contrib import messages
from .forms import ImagenGaleriaForm
from django.core.paginator import Paginator
from django.core.mail import EmailMessage
from django.db.models import Q
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
import os
from datetime import date, datetime, timedelta
from django.contrib.auth.hashers import make_password
import calendar
from decimal import Decimal
from django.templatetags.static import static
import imgkit
import threading
# -------------------------
# AUTENTICACIÓN Y PERFIL
# -------------------------
from django.http import JsonResponse
from reservas.models import Formulario
from django.db.models import Count
import calendar
from datetime import date, timedelta
from django.db.models import Sum
import calendar
import json

def ocupacion_mensual(request):
    ocupacion = (
        Formulario.objects.values_list("fecha_entrada")
        .annotate(total=Count("id"))
        .order_by("fecha_entrada")
    )

    labels = []
    data = []

    for mes, total in ocupacion:
        labels.append(calendar.month_abbr[mes])  # Ene, Feb, Mar...
        data.append(total)

    return JsonResponse({"labels": labels, "data": data})


def redireccion_por_rol(request):
    rol = request.session.get('rol')
    if rol == 'administrador':
        return redirect('administrador:home')
    return redirect('login:inicio')

# ✅ Vista principal del administrador (home)



def home(request):
    nombre = "Administrador"
    apellido = ""

    hoy = date.today()
    primer_dia_mes = hoy.replace(day=1)
    ultimo_dia_mes = (primer_dia_mes + timedelta(days=32)).replace(day=1) - timedelta(days=1)

    # Próximas reservas en 7 días
    proximas_reservas = Formulario.objects.filter(
        fecha_entrada__gte=hoy,
        fecha_entrada__lte=hoy + timedelta(days=7)
    ).order_by('fecha_entrada')[:5]

    # Reservas hoy
    reservas_hoy = Formulario.objects.filter(fecha_entrada=hoy).count()

    # Habitaciones disponibles
    habitaciones_disponibles = Habitaciones.objects.filter(estado_habitacion="Disponible").count()

    # Reservas activas en el mes actual
    reservas_mes = Formulario.objects.filter(
        fecha_entrada__gte=primer_dia_mes,
        fecha_entrada__lte=ultimo_dia_mes,
        estado='activo'
    )
    ingresos_agg = reservas_mes.aggregate(ingresos_mes=Sum('precio_total'))
    ingresos_mes = ingresos_agg['ingresos_mes'] or 0

    # Opiniones pendientes
    opiniones_pendientes = Formulario.objects.filter(peticiones__isnull=False).count()

    # Ocupación por mes (optimizada)
    total_habitaciones = Habitaciones.objects.count()
    meses = [calendar.month_abbr[m] for m in range(1, 13)]
    ocupacion_ocupadas = [0] * 12
    ocupacion_inactivas = [0] * 12

    # Consulta única para todas las reservas del año
    reservas_anio = Formulario.objects.filter(
        fecha_entrada__year=hoy.year
    ).values('fecha_entrada__month', 'estado').annotate(total=Count('id_habitacion', distinct=True))

    # Procesar en memoria
    for reserva in reservas_anio:
        mes = reserva['fecha_entrada__month'] - 1  # Índice 0-based
        if mes < 12:  # Asegurarse de no exceder el rango
            if reserva['estado'] == 'activo':
                ocupacion_ocupadas[mes] = min(reserva['total'], total_habitaciones)
            elif reserva['estado'] == 'inactivo':
                ocupacion_inactivas[mes] = min(reserva['total'], total_habitaciones)

    context = {
        "nombre": nombre,
        "apellido": apellido,
        "proximas_reservas": proximas_reservas,
        "reservas_hoy": reservas_hoy,
        "habitaciones_disponibles": habitaciones_disponibles,
        "ingresos_mes": ingresos_mes,
        "peticiones": opiniones_pendientes,
        "meses": json.dumps(meses),
        "ocupacion_ocupadas": json.dumps(ocupacion_ocupadas),
        "ocupacion_inactivas": json.dumps(ocupacion_inactivas)
    }

    return render(request, "administrador/home.html", context)

def ver_perfil(request):
    admin_id = request.session.get('admin_id')
    if not admin_id:
        messages.error(request, 'Debes iniciar sesión.')
        return redirect('login:inicio')
    try:
        admin = Administrador.objects.get(id_admin=admin_id)
        contexto = {
            'username': admin.nombre,
            'nombre': admin.nombre,
            'apellido': admin.apellido,
            'correo': admin.correo,
            'telefono': getattr(admin, 'telefono', ''),
            'tipo_usuario': 'administrador',
        }
        return render(request, 'administrador/ver_perfil.html', contexto)
    except Administrador.DoesNotExist:
        return redirect('inicio')

def actualizar_datos(request):
    # Obtener el ID del administrador de la sesión
    admin_id = request.session.get('admin_id')
    if not admin_id:
        return redirect('login:inicio')  # Redirige al login si no hay sesión

    try:
        administrador = Administrador.objects.get(id_admin=admin_id)

        if request.method == 'POST':
            # Actualizar datos
            administrador.telefono = request.POST.get('telefono', administrador.telefono)
            administrador.correo = request.POST.get('correo', administrador.correo)

            nueva_contraseña = request.POST.get('contraseña')
            if nueva_contraseña:
                administrador.contraseña = make_password(nueva_contraseña)

            administrador.save()

            # Redirigir al perfil (template destino donde se mostrará el mensaje)
            return redirect('administrador:ver_perfil')

        # GET: renderiza el formulario con los datos actuales
        return render(request, 'administrador/actualizar_datos.html', {'administrador': administrador})

    except Administrador.DoesNotExist:
        return redirect('login:inicio')

def cerrar_sesion(request):
    request.session.flush()
    messages.success(request, "Sesión cerrada correctamente.", extra_tags='cerrar')
    return redirect('login:inicio')

# -------------------------
# HABITACIONES
# -------------------------

def habitaciones_admin(request):
    habitaciones = Habitaciones.objects.all().order_by('num_habitacion')
    for habitacion in habitaciones:
        if habitacion.nombre_imagen:
            # Generar URL firmada para Cloudinary
            habitacion.signed_url, _ = cloudinary_url(habitacion.nombre_imagen.public_id, sign_url=True)
            print(f"Habitación {habitacion.num_habitacion} URL: {habitacion.signed_url}")  # Depuración
        else:
            habitacion.signed_url = None
    return render(request, 'administrador/habitaciones.html', {
        'habitaciones': habitaciones
    })


from django.shortcuts import render, redirect
from .forms import HabitacionForm, ModificarForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def registrar_habitacion(request):
    if request.method == 'POST':
        form = HabitacionForm(request.POST, request.FILES)
        if form.is_valid():
            habitacion = form.save()
            if habitacion.nombre_imagen:
                print(f"Imagen subida para habitación {habitacion.num_habitacion}: {habitacion.nombre_imagen.url}")  # Depuración
                messages.success(request, f"Habitación registrada con imagen: {habitacion.nombre_imagen.url}")
            else:
                messages.success(request, "Habitación registrada sin imagen.")
            return redirect('administrador:habitaciones_admin')
        else:
            print(form.errors)  # Depuración
            messages.error(request, f"Error al registrar: {form.errors}")
    else:
        form = HabitacionForm()
    return render(request, 'administrador/agregar.html', {'form': form})

def modificar_habitacion(request, id_habitacion):
    habitacion = get_object_or_404(Habitaciones, id_habitacion=id_habitacion)
    if request.method == 'POST':
        form = ModificarForm(request.POST, request.FILES, instance=habitacion)
        if form.is_valid():
            habitacion = form.save()
            if habitacion.nombre_imagen:
                print(f"Imagen actualizada para habitación {habitacion.num_habitacion}: {habitacion.nombre_imagen.url}")  # Depuración
                messages.success(request, f"Habitación actualizada con imagen: {habitacion.nombre_imagen.url}")
            else:
                messages.success(request, "Habitación actualizada sin imagen.")
            return redirect('administrador:habitaciones_admin')
        else:
            print(form.errors)  # Depuración
            messages.error(request, f"Error al actualizar: {form.errors}")
    else:
        form = ModificarForm(instance=habitacion)
    return render(request, 'administrador/modificar.html', {'form': form, 'habitacion': habitacion})

def eliminar_habitacion(request, id_habitacion):
    habitacion = Habitaciones.objects.get(id_habitacion=id_habitacion)
    if habitacion.formulario_set.exists():
        return redirect('administrador:habitaciones_admin')
    else:
        habitacion.delete()
        return redirect('administrador:habitaciones_admin')


# -------------------------
# RESERVAS
# -------------------------

def historial(request):
    admin_id = request.session.get('admin_id')

    if not admin_id:
        return redirect('login:inicio')

    hoy = date.today()
    # Cambiar a inactivo las reservas vencidas que estaban activas
    vencidas = Formulario.objects.filter(estado='activo', fecha_salida__lt=hoy)
    for reserva in vencidas:
        reserva.estado = 'inactivo'
        reserva.save()

    # Obtener todas las reservas
    reservas_lista = Formulario.objects.all().order_by('-fecha_entrada')

    # Filtrar por búsqueda de nombre o cédula
    buscar = request.GET.get('buscar') or ''
    if buscar:
        reservas_lista = reservas_lista.filter(
            Q(nombre__icontains=buscar) | Q(cedula__icontains=buscar)
        )

    # Filtrar por estado (en espera, activo o inactivo)
    estado_filtro = request.GET.get('estado')
    if estado_filtro in ['en_espera', 'activo', 'inactivo', 'cancelada']:
        reservas_lista = reservas_lista.filter(estado=estado_filtro)

    # ✅ Exportar a PDF si se solicita
    if request.GET.get('accion') == 'descargar_pdf':
        return generar_pdf_reservas(reservas_lista)

    # Paginación
    paginator = Paginator(reservas_lista, 10)
    page = request.GET.get('page')
    reservas = paginator.get_page(page)

    contexto = {
        'reservas': reservas,
        'buscar': buscar,
        'estado': estado_filtro,
    }

    return render(request, 'administrador/historial.html', contexto)

def detalle_reserva(request, id):
    try:
        reserva = Formulario.objects.get(id_formulario=id)
    except Formulario.DoesNotExist:
        return redirect('historial')

    return render(request, 'administrador/detalle_reserva.html', {'reserva': reserva})


def modificar_reservas(request, id):
    formularios = get_object_or_404(Formulario, id_formulario=id)
    habitacion = formularios.id_habitacion

    if request.method == 'POST':
        fecha_entrada_str = request.POST.get('fecha_entrada')
        fecha_salida_str = request.POST.get('fecha_salida')

        if not fecha_entrada_str or not fecha_salida_str:
            return render(request, 'administrador/modificar_reservas.html', {
                'reserva': formularios,
                'fechas_ocupadas': get_fechas_ocupadas(habitacion.id_habitacion, formularios.id_formulario)
            })

        try:
            nueva_entrada = datetime.strptime(fecha_entrada_str, "%Y-%m-%d").date()
            nueva_salida  = datetime.strptime(fecha_salida_str, "%Y-%m-%d").date()
        except ValueError:
            return render(request, 'administrador/modificar_reservas.html', {
                'reserva': formularios,
                'fechas_ocupadas': get_fechas_ocupadas(habitacion.id_habitacion, formularios.id_formulario)
            })

        # Verificar disponibilidad
        cruces = Formulario.objects.filter(
            id_habitacion=habitacion,
            fecha_entrada__lt=nueva_salida,
            fecha_salida__gt=nueva_entrada
        ).exclude(id_formulario=formularios.id_formulario)

        if cruces.exists():
            return render(request, 'administrador/modificar_reservas.html', {
                'reserva': formularios,
                'fechas_ocupadas': get_fechas_ocupadas(habitacion.id_habitacion, formularios.id_formulario),
                'error_disponibilidad': True
            })

        # Calcular noches y precio
        noches = (nueva_salida - nueva_entrada).days
        noches = max(noches, 1)

        precio_noche = habitacion.precios or 0
        nuevo_total = Decimal(precio_noche) * Decimal(noches)
        nuevo_anticipo = (nuevo_total / Decimal('2')).quantize(Decimal('0.01'))
        saldo = nuevo_total - nuevo_anticipo

        # Guardar cambios
        formularios.fecha_entrada = nueva_entrada
        formularios.fecha_salida = nueva_salida
        formularios.nombre = request.POST.get('nombre', formularios.nombre)
        formularios.telefono = request.POST.get('telefono', formularios.telefono)
        formularios.direccion = request.POST.get('direccion', formularios.direccion)
        formularios.pais = request.POST.get('pais', formularios.pais)
        formularios.nombre_extra = request.POST.get('nombre_extra', formularios.nombre_extra)
        formularios.apellido_extra = request.POST.get('apellido_extra', formularios.apellido_extra)
        formularios.cedula = request.POST.get('cedula', formularios.cedula)
        formularios.correo_u = request.POST.get('correo_u', formularios.correo_u)
        formularios.cantidad = request.POST.get('cantidad', formularios.cantidad)
        formularios.ciudad = request.POST.get('ciudad', formularios.ciudad)
        formularios.precio_total = nuevo_total
        formularios.anticipo = nuevo_anticipo
        formularios.save()

        # Datos para el correo
        habitaciones = [{
            'numero': habitacion.num_habitacion,
            'tipo': habitacion.tipo_habitacion,
            'total': nuevo_total
        }]

        # Correo al usuario (solo HTML, sin imagen)
        html_correo_usuario = render_to_string('reservas/correo_modificacion.html', {
            'nombre': formularios.nombre,
            'correo': formularios.correo_u,
            'telefono': formularios.telefono,
            'ciudad': formularios.ciudad,
            'pais': formularios.pais,
            'fecha_entrada': formularios.fecha_entrada,
            'fecha_salida': formularios.fecha_salida,
            'habitaciones': habitaciones,
            'noches': noches,
            'subtotal': nuevo_total,
            'total': nuevo_total,
            'anticipo': nuevo_anticipo,
            'saldo': saldo,
        })

        email_usuario = EmailMultiAlternatives(
            'Tu reserva ha sido modificada - Hotel Casa Luna',
            '',  # Cuerpo de texto plano vacío, ya que usamos HTML
            'eldescansoacaf@gmail.com',
            [formularios.correo_u],
        )
        email_usuario.attach_alternative(html_correo_usuario, "text/html")

        # Correo al admin
        html_correo_admin = f"La reserva #{formularios.id_formulario} ha sido modificada."
        email_admin = EmailMessage(
            'Reserva modificada - Hotel Casa Luna',
            html_correo_admin,
            'eldescansoacaf@gmail.com',
            ['eldescansoacaf@gmail.com'],
        )
        email_admin.content_subtype = "html"

        EmailThread(email_usuario, email_admin).start()

        return redirect('administrador:detalle_reserva', id=formularios.id_formulario)

    # GET → Pasar fechas ocupadas para el calendario
    fechas_ocupadas = get_fechas_ocupadas(habitacion.id_habitacion, formularios.id_formulario)
    return render(request, 'administrador/modificar_reservas.html', {
        'reserva': formularios,
        'fechas_ocupadas': fechas_ocupadas
    })

def eliminar_reservas(request, id):
    # Obtener la reserva o devolver 404 si no existe
    reserva = get_object_or_404(Formulario, id_formulario=id)
    reserva.delete()
    return redirect('administrador:historial')



def cancelar_reserva(request, id):
    reserva = get_object_or_404(Formulario, id_formulario=id)

    # Renderizar plantilla HTML con datos del usuario
    html_content = render_to_string('administrador/cancelacion_reserva.html', {
        'nombre': reserva.nombre,
    })

    # Crear correo en HTML
    subject = 'Reserva cancelada - Hotel Casa Luna'
    from_email = 'Hotel Casa Luna <eldescansoacaf@gmail.com>'
    to_email = [reserva.correo_u]

    email = EmailMultiAlternatives(subject, '', from_email, to_email)
    email.attach_alternative(html_content, "text/html")
    email.send()
    # Cambiar estado a cancelada
    reserva.estado = 'cancelada'
    reserva.save()

    return redirect('administrador:historial')



def confirmar_reserva(request, id):
    reserva = get_object_or_404(Formulario, id_formulario=id)

    # Cambiar estado a activo
    reserva.estado = 'activo'
    reserva.save()

    # Renderizar el contenido del correo en HTML
    html_content = render_to_string('administrador/confirmacion_reserva.html', {
        'nombre': reserva.nombre,
    })

    # Crear el correo con contenido HTML
    subject = 'Reserva confirmada - Hotel Casa Luna'
    from_email = 'Hotel Casa Luna <eldescansoacaf@gmail.com>'
    to_email = [reserva.correo_u]

    email = EmailMultiAlternatives(subject, '', from_email, to_email)
    email.attach_alternative(html_content, "text/html")
    email.send()

    return redirect('administrador:historial')


# -------------------------
# GALERÍA
# -------------------------

import cloudinary.uploader
from cloudinary.utils import cloudinary_url
from django.contrib import messages
from django.shortcuts import render, redirect
from .forms import ImagenGaleriaForm
from .models import ImagenGaleria

def galeria_admin(request):
    if request.method == 'POST':
        if 'subir' in request.POST:
            form = ImagenGaleriaForm(request.POST, request.FILES)
            if form.is_valid():
                # Validar tamaño y tipo de archivo
                imagen_file = request.FILES.get('imagen')
                max_size = 5 * 1024 * 1024  # 5MB
                allowed_types = ['image/jpeg', 'image/png', 'image/gif']
                if imagen_file:
                    if imagen_file.size > max_size:
                        return redirect('administrador:galeria_admin')
                    if imagen_file.content_type not in allowed_types:
                        return redirect('administrador:galeria_admin')
                try:
                    form.save()
                except Exception:
                    pass  # Ignorar errores silenciosamente
                return redirect('administrador:galeria_admin')
            else:
                return redirect('administrador:galeria_admin')
        
        elif 'eliminar' in request.POST:
            imagen_id = request.POST.get('imagen_id')
            try:
                imagen = ImagenGaleria.objects.get(id=imagen_id)
                if imagen.imagen and hasattr(imagen.imagen, 'public_id') and imagen.imagen.public_id:
                    cloudinary.uploader.destroy(imagen.imagen.public_id)
                imagen.delete()
            except (ImagenGaleria.DoesNotExist, Exception):
                pass  # Ignorar errores silenciosamente
            return redirect('administrador:galeria_admin')

    form = ImagenGaleriaForm()
    imagenes = ImagenGaleria.objects.all()
    return render(request, 'administrador/galeria.html', {
        'form': form,
        'imagenes': imagenes
    })


# -------------------------
# OTRAS VISTAS
# -------------------------


def confirmacion(request):
    return render(request, 'administrador/confirmacion.html')

def soporte(request):
    return render(request, 'administrador/soporte.html')

def terminos(request):
    return render(request, 'administrador/terminos.html')


class EmailThread(threading.Thread):
    def __init__(self, email_usuario, email_admin):
        self.email_usuario = email_usuario
        self.email_admin = email_admin
        threading.Thread.__init__(self)

    def run(self):
        self.email_usuario.send()
        self.email_admin.send()


def get_fechas_ocupadas(habitacion_id, id_excluir):
    """Obtiene todas las fechas ocupadas de una habitación, excluyendo la reserva actual"""
    reservas = Formulario.objects.filter(id_habitacion=habitacion_id).exclude(id_formulario=id_excluir)
    fechas = []
    for r in reservas:
        dia = r.fecha_entrada
        while dia < r.fecha_salida:
            fechas.append(dia.strftime("%Y-%m-%d"))
            dia += timedelta(days=1)
    return fechas


from django.template.loader import get_template
from xhtml2pdf import pisa
from django.http import HttpResponse
from io import BytesIO



def generar_pdf_reservas(reservas):
    template_path = 'administrador/reservas_pdf.html'
    contexto = {'reservas': reservas}
    template = get_template(template_path)
    html = template.render(contexto)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="historial_reservas.pdf"'
    pisa_status = pisa.CreatePDF(html, dest=response)
    if pisa_status.err:
        return HttpResponse('Error al generar el PDF', status=500)
    return response
