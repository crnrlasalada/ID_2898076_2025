from reservas.models import Administrador, Roles
from django.shortcuts import redirect

def guardar_usuario_custom(backend, user, response, *args, **kwargs):
    request = backend.strategy.request

    correo = response.get('email')

    try:
        usuario = Administrador.objects.get(correo=correo)
    except Administrador.DoesNotExist:
        
        rol_usuario = Roles.objects.get(rol='usuario')
        usuario = Administrador.objects.create(
            nombre=response.get('given_name', ''),
            apellido=response.get('family_name', ''),
            correo=correo,
            contraseña='oauth_google',  # contraseña por defecto para OAuth
            telefono='',
            id_roles=rol_usuario
        )

    request.session['rol'] = usuario.id_roles.rol
    request.session['correo'] = usuario.correo