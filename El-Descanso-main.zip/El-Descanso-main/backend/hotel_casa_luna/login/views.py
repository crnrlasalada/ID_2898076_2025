from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from .forms import administradorForm
from django.contrib import messages
from reservas.models import Roles, Administrador
from django.core.mail import send_mail
from django.conf import settings
import random
import re
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from login.decorators import logout_requerido

from django.shortcuts import render, redirect
from django.contrib import messages

@logout_requerido
def verificar_clave(request):
    if request.method == "POST":
        clave = request.POST.get("clave").strip()
        print(f"Clave recibida: {clave}")  # Para depuración
        if not clave:
            messages.error(request, "Debes ingresar una clave.")
            return redirect('login:verificar_clave')
        if clave == "admin123":
            request.session['registro_autorizado'] = True
            messages.success(request, "Clave correcta. Redirigiendo...")
            return redirect('login:inicio')
        else:
            messages.error(request, "Clave incorrecta. No tienes permiso para registrarte.")
            return redirect('login:verificar_clave')
    return render(request, 'login/verificar_clave.html')

# ✅ Vista de inicio de sesión
@logout_requerido
def login_usuario(request):
    if request.method == 'POST':
        correo = request.POST.get('correo', '').strip()
        contraseña = request.POST.get('contraseña', '').strip()

        errores = []

        # Validaciones personalizadas
        if not correo:
            errores.append("El correo es obligatorio.")
        elif not correo.endswith('@gmail.com'):
            errores.append("El correo debe terminar en @gmail.com.")

        if not contraseña:
            errores.append("La contraseña es obligatoria.")
        elif len(contraseña) < 8:
            errores.append("La contraseña debe tener al menos 8 caracteres.")

        # Si hay errores, se retornan al formulario
        if errores:
            return render(request, 'login/inicio.html', {'errores': errores})

        # Validación en la base de datos
        try:
            admin = Administrador.objects.get(correo=correo)
            if check_password(contraseña, admin.contraseña):
                request.session['admin_id'] = admin.id_admin
                request.session['rol'] = 'administrador'
                return redirect('login:redireccion')
        except Administrador.DoesNotExist:
            pass

        # Si correo o contraseña están mal
        errores.append("Correo o contraseña incorrectos.")
        return render(request, 'login/inicio.html', {'errores': errores})

    # GET
    return render(request, 'login/inicio.html')

# ✅ Registro de usuarios
@logout_requerido
def registro_usuario(request):
    if request.method == 'POST':
        form = administradorForm(request.POST)
        if form.is_valid():
            usuario = form.save(commit=False)
            usuario.contraseña = make_password(form.cleaned_data['contraseña'])

            try:
                rol_usuario = Roles.objects.get(rol='administrador')
                usuario.id_rol = rol_usuario
            except Roles.DoesNotExist:
                form.add_error(None, "El rol 'administrador' no existe.")
                return render(request, 'login/registro.html', {'form': form})

            usuario.save()
            request.session.pop('registro_autorizado', None)
            return redirect('login:inicio')
        else:
            return render(request, 'login/registro.html', {'form': form})
    else:
        form = administradorForm()

    return render(request, 'login/registro.html', {'form': form})

@logout_requerido
def solicitar_codigo(request):
    if request.method == 'POST':
        correo = request.POST.get('correo', '').strip()
        errores = []

        # Validación del correo
        if not correo:
            errores.append("El campo correo es obligatorio.")
        elif not correo.endswith('@gmail.com'):
            errores.append("El correo debe terminar en @gmail.com.")

        if errores:
            return render(request, 'login/solicitar_correo.html', {'errores': errores})

        # Verificar si existe en la base de datos
        try:
            usuario = Administrador.objects.get(correo=correo)
        except Administrador.DoesNotExist:
            errores.append("Este correo no está registrado.")
            return render(request, 'login/solicitar_correo.html', {'errores': errores})

        # Generar código
        codigo = str(random.randint(1000, 9999))
        request.session['codigo_verificacion'] = codigo
        request.session['correo_recuperacion'] = correo

        # 📩 Renderizar plantilla HTML
        html_content = render_to_string('login/codigo_verificacion.html', {
            'nombre': usuario.nombre,
            'codigo': codigo,
        })

        # Enviar correo HTML
        subject = 'Código de verificación - Hotel Casa Luna'
        from_email = 'Hotel Casa Luna <' + settings.EMAIL_HOST_USER + '>'
        to_email = [correo]

        email = EmailMultiAlternatives(subject, '', from_email, to_email)
        email.attach_alternative(html_content, "text/html")
        email.send()

        return redirect('login:validar_codigo')

    return render(request, 'login/solicitar_correo.html')

# ✅ Validar código recibido por correo
@logout_requerido
def validar_codigo(request):
    if request.method == 'POST':
        codigo_ingresado = ''.join([
            request.POST.get('dig1', ''),
            request.POST.get('dig2', ''),
            request.POST.get('dig3', ''),
            request.POST.get('dig4', ''),
        ])

        if codigo_ingresado == request.session.get('codigo_verificacion'):
            return redirect('login:restaurar')
        else:
            return redirect('login:validar_codigo')

    return render(request, 'login/validar.html')

# ✅ Restaurar la contraseña
@logout_requerido
def nueva_contraseña(request):
    if request.method == 'POST':
        nueva = request.POST.get('contraseña')
        confirmar = request.POST.get('confirmar')

        errores = []

        # Validar que coincidan
        if nueva != confirmar:
            errores.append("Las contraseñas no coinciden.")

        # Validaciones de seguridad
        if len(nueva) < 8:
            errores.append("La contraseña debe tener al menos 8 caracteres.")
        if re.match(r'^[a-zA-Z]{1}[0-9]{5,}$', nueva):
            errores.append("La contraseña no puede tener solo una letra seguida de muchos números.")
        if not re.search(r'[a-zA-Z]', nueva) or not re.search(r'[0-9]', nueva):
            errores.append("La contraseña debe contener letras y números.")
        if re.match(r'(.)\1{3,}', nueva):
            errores.append("La contraseña no puede repetir mucho el mismo carácter.")

        if errores:
            return render(request, 'login/restaurar.html', {'errores': errores})

        # Si pasa todo, guardar
        correo = request.session.get('correo_recuperacion')
        try:
            usuario = Administrador.objects.get(correo=correo)
            usuario.contraseña = make_password(nueva)
            usuario.save()
            return redirect('login:inicio')
        except Administrador.DoesNotExist:
            return redirect('login:inicio')

    return render(request, 'login/restaurar.html')

# ✅ Redirigir al panel según rol 
def redireccion_por_rol(request):
    rol = request.session.get('rol', None)

    if rol == 'administrador':
        return redirect('administrador:home')  # Panel principal del administrador
    elif rol == 'cliente':
        return redirect('reservas:home_')
    else:
        return redirect('login:inicio')