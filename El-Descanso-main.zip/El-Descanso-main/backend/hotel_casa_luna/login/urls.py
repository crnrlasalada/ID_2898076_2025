from django.urls import path
from . import views

app_name = 'login'

urlpatterns = [
    path('', views.login_usuario, name='inicio'),  # /login/
    path('registro/', views.registro_usuario, name='registro'),
    path('redireccion/', views.redireccion_por_rol, name='redireccion'),  # /login/redireccion/
    path('solicitar_codigo/', views.solicitar_codigo, name='solicitar_codigo'),
    path('validar_codigo/', views.validar_codigo, name='validar_codigo'),
    path('restaurar/', views.nueva_contraseña, name='restaurar'),
    path('verificar_clave/', views.verificar_clave, name='verificar_clave'),
]



