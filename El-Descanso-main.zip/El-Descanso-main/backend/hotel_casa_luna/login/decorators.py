from functools import wraps
from django.shortcuts import redirect

def login_requerido(rol=None):
    """
    Decorador que asegura que el usuario esté logueado.
    Si se especifica 'rol', solo permite ese rol.
    """
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            usuario_rol = request.session.get('rol', None)
            
            if not usuario_rol:
                return redirect('login:inicio')
            
            if rol and usuario_rol != rol:
                return redirect('login:inicio')
            
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator

def logout_requerido(view_func):
    """
    Decorador que solo permite acceder si NO estás logueado.
    """
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        rol = request.session.get('rol', None)
        
        if rol == 'administrador':
            return redirect('administrador:home')
        elif rol == 'cliente':
            return redirect('reservas:home_')
        
        return view_func(request, *args, **kwargs)
    
    return _wrapped_view



def verificacion_requerida(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.session.get('registro_autorizado'):
            return redirect('login:verificar_clave')
        return view_func(request, *args, **kwargs)
    return wrapper
