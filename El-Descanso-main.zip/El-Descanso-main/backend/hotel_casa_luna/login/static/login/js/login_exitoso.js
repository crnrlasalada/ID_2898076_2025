document.addEventListener("DOMContentLoaded", function () {
    Swal.fire({
        icon: 'success',
        title: 'Inicio de sesión exitoso.',
        confirmButtonText: 'Aceptar',
        allowOutsideClick: false,
        allowEscapeKey: false
    }).then(() => {
        window.location.href = redireccionUrl;
    });
});
