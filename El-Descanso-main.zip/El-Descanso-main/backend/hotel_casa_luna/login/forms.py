from django import forms
from reservas.models import Administrador
from django import forms
from reservas.models import Administrador
import re

class administradorForm(forms.ModelForm):
    confirmar = forms.CharField(widget=forms.PasswordInput(), label='Confirmar contraseña')

    class Meta:
        model = Administrador
        fields = ['nombre', 'apellido', 'telefono', 'correo', 'contraseña']
        widgets = {
            'contraseña': forms.PasswordInput()
        }

    def clean_correo(self):
        correo = self.cleaned_data.get('correo')
        if Administrador.objects.filter(correo=correo).exists():
            raise forms.ValidationError('Este correo ya está registrado.')
        return correo

    def clean(self):
        cleaned_data = super().clean()
        contrasena = cleaned_data.get("contraseña")
        confirmar = cleaned_data.get("confirmar")
        if contrasena and confirmar and contrasena != confirmar:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return cleaned_data
    


class administradorForm(forms.ModelForm):
    confirmar = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = Administrador
        fields = ['nombre', 'apellido', 'telefono', 'correo', 'contraseña']

        widgets = {
            'contraseña': forms.PasswordInput(),
        }

    def clean_nombre(self):
        nombre = self.cleaned_data.get('nombre')
        if not nombre.replace(" ", "").isalpha():
            raise forms.ValidationError("El nombre solo puede contener letras.")
        return nombre

    def clean_apellido(self):
        apellido = self.cleaned_data.get('apellido')
        if not apellido.replace(" ", "").isalpha():
            raise forms.ValidationError("El apellido solo puede contener letras.")
        return apellido

    def clean_telefono(self):
        telefono = self.cleaned_data.get('telefono')
        if not telefono.isdigit():
            raise forms.ValidationError("El teléfono solo debe contener números.")
        if len(telefono) < 7 or len(telefono) > 10:
            raise forms.ValidationError("El teléfono debe tener entre 7 y 10 dígitos.")
        return telefono

    def clean_correo(self):
        correo = self.cleaned_data.get('correo')
        if not correo.endswith('@gmail.com'):
            raise forms.ValidationError("El correo debe terminar en @gmail.com.")
        return correo

    def clean_contraseña(self):
        contraseña = self.cleaned_data.get('contraseña')
        if len(contraseña) < 8:
            raise forms.ValidationError("La contraseña debe tener al menos 8 caracteres.")
        return contraseña

    def clean(self):
        cleaned_data = super().clean()
        contraseña = cleaned_data.get('contraseña')
        confirmar = cleaned_data.get('confirmar')

        if contraseña and confirmar and contraseña != confirmar:
            self.add_error('confirmar', "Las contraseñas no coinciden.")


class administradorForm(forms.ModelForm):
    confirmar = forms.CharField(widget=forms.PasswordInput(), label="Confirmar contraseña")

    class Meta:
        model = Administrador
        fields = ['nombre', 'apellido', 'telefono', 'correo', 'contraseña']
        widgets = {
            'contraseña': forms.PasswordInput(),
        }

    # Validar nombre: solo letras y espacios
    def clean_nombre(self):
        nombre = self.cleaned_data.get('nombre')
        if not re.match(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$', nombre):
            raise forms.ValidationError("El nombre solo puede contener letras.")
        return nombre

    # Validar apellido: solo letras y espacios
    def clean_apellido(self):
        apellido = self.cleaned_data.get('apellido')
        if not re.match(r'^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$', apellido):
            raise forms.ValidationError("El apellido solo puede contener letras.")
        return apellido

    # Validar teléfono: solo números y longitud
    def clean_telefono(self):
        telefono = self.cleaned_data.get('telefono')
        telefono_str = str(telefono)
        if not telefono_str.isdigit():
            raise forms.ValidationError("El teléfono solo debe contener números.")
        if len(telefono_str) < 7 or len(telefono_str) > 10:
            raise forms.ValidationError("El teléfono debe tener entre 7 y 10 dígitos.")
        return telefono

    # Validar correo: estructura, terminación y duplicación
    def clean_correo(self):
        correo = self.cleaned_data.get('correo')

        # Termina en @gmail.com
        if not correo.endswith('@gmail.com'):
            raise forms.ValidationError("El correo debe terminar en @gmail.com.")

        # No permitir letras/símbolos después de @gmail.com
        if not re.match(r'^[\w\.-]+@gmail\.com$', correo):
            raise forms.ValidationError("El correo no debe tener caracteres adicionales después de @gmail.com.")

        # Ya registrado
        if Administrador.objects.filter(correo=correo).exists():
            raise forms.ValidationError("Este correo ya está registrado.")
        
        return correo

    # Validar contraseña con reglas estrictas
    def clean_contraseña(self):
        contraseña = self.cleaned_data.get('contraseña')

        if len(contraseña) < 8:
            raise forms.ValidationError("La contraseña debe tener al menos 8 caracteres.")
        
        if re.match(r'^[a-zA-Z]{1}[0-9]{5,}$', contraseña):
            raise forms.ValidationError("La contraseña no puede tener solo una letra seguida de muchos números.")
        
        if not re.search(r'[a-zA-Z]', contraseña) or not re.search(r'[0-9]', contraseña):
            raise forms.ValidationError("La contraseña debe contener letras y números.")
        
        if re.match(r'(.)\1{3,}', contraseña):
            raise forms.ValidationError("No repitas demasiado el mismo carácter.")
        
        return contraseña

    # Validar confirmación de contraseña
    def clean(self):
        cleaned_data = super().clean()
        contraseña = cleaned_data.get('contraseña')
        confirmar = cleaned_data.get('confirmar')

        if contraseña and confirmar and contraseña != confirmar:
            self.add_error('confirmar', "Las contraseñas no coinciden.")
